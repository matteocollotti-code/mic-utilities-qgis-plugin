# -*- coding: utf-8 -*-
"""Metriche di space syntax (segment analysis topologica) sul grafo stradale.

Gli elementi sono i SEGMENTI della rete: i tratti di strada tra due incroci
reali (vertici condivisi da almeno tre bracci) o tra un incrocio e un vicolo
cieco, ricavati da topology.build_topology. Due segmenti sono connessi se
condividono un incrocio. Così il risultato non dipende da come la rete è
digitalizzata (una via in una feature o spezzata in dieci) e una strada che
attraversa un incrocio senza interrompersi viene comunque divisa lì.

Si calcolano connettività, profondità media, integrazione (HH), choice
(betweenness), NAIN e NACH. Puro Python (nessun oggetto QGIS): gira in un
QgsTask.
"""
import math


def segment_map(roads_lonlat, sources=None, snap_tol_m=1.0, progress=None,
                is_canceled=None):
    """Segmenti tra incroci reali e loro adiacenza.

    :param sources: id della feature d'origine per polilinea.
    :return: (topology, adjacency) con adjacency[i] = indici dei segmenti
        che condividono un estremo con il segmento i.
    """
    from . import topology
    topo = topology.build_topology(roads_lonlat, sources=sources,
                                   snap_tol_m=snap_tol_m, progress=progress,
                                   is_canceled=is_canceled)
    return topo, topo.chain_adjacency()


def attach_segments(metrics, topo, n_features_in=None):
    """Aggiunge alle metriche geometria e origine dei segmenti (per il layer)."""
    metrics["coords"] = [topo.chain_coords(i) for i in range(len(topo.chains))]
    metrics["src"] = [c["src"] for c in topo.chains]
    metrics["n_feature"] = [len(c["srcs"]) for c in topo.chains]
    metrics["length_m"] = [c["length_m"] for c in topo.chains]
    metrics["n_junctions"] = len(topo.junctions())
    if n_features_in is not None:
        metrics["n_features_in"] = n_features_in
    return metrics


FAST_MIN_SEGMENTS = 1500


def _brandes_numpy(adjacency, rmax, progress=None, is_canceled=None,
                   batch=64):
    """Brandes vettoriale (numpy) su blocchi di sorgenti.

    Le BFS di `batch` sorgenti avanzano insieme, livello per livello, su un
    grafo "replicato" (nodo globale = sorgente × n + segmento); gli archi del
    DAG dei cammini minimi di ogni livello servono poi all'accumulo all'indietro.
    Stessi risultati della versione Python, molte volte più veloce sulle reti
    grandi. None se numpy manca.

    :return: (node_count, total_depth, betweenness) come liste, o None.
    """
    try:
        import numpy as np
    except Exception:
        return None
    from itertools import chain
    n = len(adjacency)
    it = np.int64 if n * batch >= 2 ** 31 else np.int32
    deg = np.fromiter((len(a) for a in adjacency), dtype=it, count=n)
    indptr = np.concatenate(([0], np.cumsum(deg))).astype(it)
    indices = np.fromiter(chain.from_iterable(adjacency), dtype=it,
                          count=int(indptr[-1]))
    node_count = np.ones(n, dtype=np.int64)
    total_depth = np.zeros(n)
    bet = np.zeros(n)
    # tabella di appoggio: posizione di un nodo nel suo livello (niente
    # ordinamenti per raggruppare)
    slot = np.zeros(n * batch, dtype=it)
    for b0 in range(0, n, batch):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress:
            progress(int(100 * b0 / n))
        src = np.arange(b0, min(n, b0 + batch), dtype=it)
        nb = len(src)
        gsrc = np.arange(nb, dtype=it) * n + src
        dist = np.full(nb * n, -1, dtype=np.int32)
        dist[gsrc] = 0
        sigma = np.zeros(nb * n)
        sigma[gsrc] = 1.0
        levels = [gsrc]
        dag = []
        frontier = gsrc
        d = 0
        while frontier.size and (rmax is None or d < rmax):
            loc = frontier % n
            cnt = deg[loc]
            tot = int(cnt.sum())
            if tot == 0:
                break
            ends = np.cumsum(cnt)
            pos = np.repeat(indptr[loc] - ends + cnt, cnt) + \
                np.arange(tot, dtype=it)
            nbr = indices[pos] + np.repeat(frontier - loc, cnt)
            dn = dist[nbr]
            cand = nbr[dn == -1]
            if cand.size == 0:
                break
            # nuovi nodi senza doppioni: vince l'ultima scrittura
            slot[cand] = np.arange(cand.size, dtype=it)
            new = cand[slot[cand] == np.arange(cand.size, dtype=it)]
            dist[new] = d + 1
            m = (dn == -1) | (dn == d + 1)
            u_k = np.repeat(frontier, cnt)[m]
            v_k = nbr[m]
            slot[new] = np.arange(new.size, dtype=it)
            sigma[new] += np.bincount(slot[v_k], weights=sigma[u_k],
                                      minlength=new.size)
            dag.append((u_k, v_k))
            levels.append(new)
            frontier = new
            d += 1
        dm = dist.reshape(nb, n)
        node_count[b0:b0 + nb] = (dm >= 0).sum(axis=1)
        total_depth[b0:b0 + nb] = np.where(dm > 0, dm, 0).sum(axis=1)
        delta = np.zeros(nb * n)
        for k in range(len(dag) - 1, -1, -1):
            u_k, v_k = dag[k]
            w = sigma[u_k] / sigma[v_k] * (1.0 + delta[v_k])
            lv = levels[k]
            slot[lv] = np.arange(lv.size, dtype=it)
            delta[lv] += np.bincount(slot[u_k], weights=w, minlength=lv.size)
        delta[gsrc] = 0.0
        bet += delta.reshape(nb, n).sum(axis=0)
    return node_count.tolist(), total_depth.tolist(), bet.tolist()


def compute_metrics(adjacency, radius=0, progress=None, is_canceled=None,
                    fast=True):
    """Metriche di space syntax (globali con radius=0, locali con radius=n).

    :param radius: profondita' topologica massima (0 = globale, es. 3 = R3).
    :param fast: sulle reti grandi usa la versione numpy (stessi
        risultati, molto più veloce); con fast=False Python puro.
    :return: dict con liste allineate all'ordine dell'adiacenza:
        connectivity, mean_depth, total_depth, node_count, integration,
        choice, nain (integrazione normalizzata), nach (choice normalizzata).
    """
    n = len(adjacency)
    rmax = radius if radius and radius > 0 else None
    connectivity = [len(adjacency[i]) for i in range(n)]
    fast_res = None
    if fast and n >= FAST_MIN_SEGMENTS:
        fast_res = _brandes_numpy(adjacency, rmax, progress, is_canceled)
    if fast_res is not None:
        node_count, total_depth, betweenness = fast_res
        mean_depth = [td / float(nc - 1) if nc > 1 else 0.0
                      for td, nc in zip(total_depth, node_count)]
        return _finish(n, connectivity, node_count, total_depth, mean_depth,
                       betweenness, progress)
    betweenness = [0.0] * n
    mean_depth = [0.0] * n
    total_depth = [0.0] * n
    node_count = [1] * n

    # strutture riusate: a ogni sorgente si azzerano solo i nodi visitati
    # (con raggio locale sono pochi: niente array da n elementi per sorgente).
    # Brandes senza liste dei predecessori: nell'accumulo i predecessori di w
    # sono i vicini a distanza dist[w] - 1.
    adj = [tuple(a) for a in adjacency]
    dist = [-1] * n
    sigma = [0.0] * n
    delta = [0.0] * n

    for s in range(n):
        if is_canceled and s % 64 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and s % 256 == 0 and n:
            progress(int(100 * s / n))

        stack = [s]
        push = stack.append
        sigma[s] = 1.0
        dist[s] = 0
        td = 0
        i = 0
        while i < len(stack):
            v = stack[i]
            i += 1
            dv = dist[v]
            if rmax is not None and dv >= rmax:
                continue  # non espandere oltre il raggio
            dv1 = dv + 1
            sv = sigma[v]
            for w in adj[v]:
                dw = dist[w]
                if dw < 0:
                    dist[w] = dv1
                    td += dv1
                    sigma[w] = sv
                    push(w)
                elif dw == dv1:
                    sigma[w] += sv

        reached = len(stack) - 1
        node_count[s] = reached + 1
        total_depth[s] = float(td)
        mean_depth[s] = td / float(reached) if reached else 0.0

        # accumulo di Brandes in ordine inverso di visita, poi azzeramento
        for k in range(reached, 0, -1):
            w = stack[k]
            dw1 = dist[w] - 1
            coef = (1.0 + delta[w]) / sigma[w]
            for v in adj[w]:
                if dist[v] == dw1:
                    delta[v] += sigma[v] * coef
            betweenness[w] += delta[w]
        for w in stack:
            dist[w] = -1
            delta[w] = 0.0

    return _finish(n, connectivity, node_count, total_depth, mean_depth,
                   betweenness, progress)


def _finish(n, connectivity, node_count, total_depth, mean_depth,
            betweenness, progress=None):
    """Integrazione, NAIN, NACH e choice finali dai totali dei BFS."""
    integration = [0.0] * n
    nain = [0.0] * n
    nach = [0.0] * n
    hubs = []
    betweenness = [b / 2.0 for b in betweenness]  # non orientato
    for i in range(n):
        nn = node_count[i]
        if nn > 2 and mean_depth[i] > 0:
            ra = 2.0 * (mean_depth[i] - 1.0) / (nn - 2)
            dn = 2.0 * (nn * (math.log2((nn + 2) / 3.0) - 1.0) + 1.0) / \
                ((nn - 1) * (nn - 2))
            rra = ra / dn if dn > 0 else 0.0
            if rra > 0:
                integration[i] = 1.0 / rra
            else:
                hubs.append(i)  # profondità media 1: collegato a tutti
        td = total_depth[i]
        if td > 0:
            # Hillier, Yang, Turner 2012: NAIN = NC^1.2 / (TD + 2)
            nain[i] = (nn ** 1.2) / (td + 2.0)
            nach[i] = math.log10(betweenness[i] + 1.0) / math.log10(td + 3.0)
    if hubs:
        # il segmento collegato direttamente a tutti è il più integrato:
        # prende il massimo finito invece di 0 (1/RRA è infinito)
        top = max(integration) if any(integration) else 1.0
        for i in hubs:
            integration[i] = top

    if progress:
        progress(100)
    return {
        "connectivity": connectivity,
        "mean_depth": mean_depth,
        "total_depth": total_depth,
        "node_count": node_count,
        "integration": integration,
        "choice": betweenness,
        "nain": nain,
        "nach": nach,
    }
