# -*- coding: utf-8 -*-
"""Classe principale del plugin: integra azioni, menu e dock widget."""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsApplication

from .analyzer_dockwidget import AnalyzerDockWidget
from .processing_alg import MicProvider

# logo MIC Hub (barra strumenti, menu Vettore, Processing)
ICON_PATH = os.path.join(os.path.dirname(__file__), "icon.svg")


class RoadNetworkAnalyzer:
    """Gestisce il ciclo di vita del plugin in QGIS."""

    def __init__(self, iface):
        self.iface = iface
        self.menu = "&MIC - Utilities"
        self.actions = []
        self.dockwidget = None
        self.provider = None

    def initProcessing(self):  # noqa: N802 (API QGIS)
        """Registra il provider Processing. Chiamato anche in modalità headless
        (qgis_process) grazie a hasProcessingProvider=yes nel metadata."""
        if self.provider is None:
            self.provider = MicProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):  # noqa: N802 (API QGIS)
        self.initProcessing()
        action = QAction(QIcon(ICON_PATH), "MIC - Utilities",
                         self.iface.mainWindow())
        action.triggered.connect(self.run)
        self.iface.addToolBarIcon(action)
        self.iface.addPluginToVectorMenu(self.menu, action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginVectorMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        self.actions = []
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
        if self.dockwidget is not None:
            self.iface.removeDockWidget(self.dockwidget)
            self.dockwidget.deleteLater()
            self.dockwidget = None

    def run(self):
        if self.dockwidget is None:
            self.dockwidget = AnalyzerDockWidget(self.iface, self.iface.mainWindow())
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dockwidget)
        self.dockwidget.show()
        self.dockwidget.raise_()
