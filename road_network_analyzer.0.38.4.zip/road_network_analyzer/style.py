# -*- coding: utf-8 -*-
"""Tema "liquid glass" (ispirato a shadcn) per il pannello, via QSS.

Nota: shadcn e' una libreria React/Tailwind e non puo' girare in un dock Qt;
qui se ne riproduce l'estetica (palette neutra, angoli arrotondati, accento
indaco, superfici translucide) con un foglio di stile Qt.
"""

MIC_STYLE = """
QWidget {
    background: transparent;
    color: #0f172a;
    font-family: "Segoe UI", "Inter", sans-serif;
    font-size: 9pt;
}
QScrollArea, QAbstractScrollArea {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 #eef2f7, stop:1 #e7ecf3);
    border: none;
}
QTabWidget::pane {
    border: 1px solid rgba(148,163,184,0.35);
    border-radius: 12px;
    background: rgba(255,255,255,0.65);
    top: -1px;
}
QTabBar::tab {
    background: rgba(255,255,255,0.45);
    color: #475569;
    padding: 6px 12px;
    margin-right: 3px;
    border: 1px solid rgba(148,163,184,0.30);
    border-top-left-radius: 9px;
    border-top-right-radius: 9px;
}
QTabBar::tab:selected {
    background: rgba(255,255,255,0.92);
    color: #4f46e5;
    font-weight: 600;
    border-bottom: 2px solid #4f46e5;
}
QTabBar::tab:hover { background: rgba(255,255,255,0.75); }
QGroupBox {
    background: rgba(255,255,255,0.55);
    border: 1px solid rgba(148,163,184,0.35);
    border-radius: 12px;
    margin-top: 14px;
    padding: 10px 8px 8px 8px;
    font-weight: 600;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 1px 8px;
    color: #334155;
    background: rgba(255,255,255,0.85);
    border-radius: 7px;
}
QPushButton {
    background: #4f46e5;
    color: #ffffff;
    border: none;
    border-radius: 9px;
    padding: 6px 12px;
    font-weight: 600;
}
QPushButton:hover { background: #4338ca; }
QPushButton:pressed { background: #3730a3; }
QPushButton:checked { background: #0ea5e9; }
QPushButton:disabled { background: rgba(148,163,184,0.45); color: #f1f5f9; }
QPushButton[flat="true"] {
    background: transparent; color: #4f46e5; font-weight: 600; padding: 2px;
}
QPushButton[flat="true"]:hover { background: rgba(79,70,229,0.10); }
QLineEdit, QComboBox, QSpinBox, QTimeEdit, QDateTimeEdit, QTextBrowser, QPlainTextEdit {
    background: rgba(255,255,255,0.92);
    border: 1px solid rgba(148,163,184,0.45);
    border-radius: 8px;
    padding: 4px 6px;
    selection-background-color: #c7d2fe;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QTimeEdit:focus {
    border: 1px solid #6366f1;
}
QComboBox::drop-down { border: none; width: 18px; }
QCheckBox { spacing: 6px; }
QLabel { background: transparent; }
QTableWidget, QTableView {
    background: rgba(255,255,255,0.85);
    border: 1px solid rgba(148,163,184,0.35);
    border-radius: 10px;
    gridline-color: rgba(148,163,184,0.30);
}
QHeaderView::section {
    background: rgba(241,245,249,0.95);
    color: #334155;
    border: none;
    border-right: 1px solid rgba(148,163,184,0.25);
    padding: 4px 6px;
    font-weight: 600;
}
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical {
    background: rgba(148,163,184,0.55); border-radius: 5px; min-height: 24px;
}
QScrollBar::add-line, QScrollBar::sub-line { height: 0; }
"""
