# -*- coding: utf-8 -*-
"""Scenari A/B: confronto di accessibilità tra due reti stradali.

Esegue l'accessibilità cumulativa sulle stesse origini con due reti diverse
(es. stato attuale vs progetto: nuova strada, passerella, strada chiusa) e
misura la differenza per origine.
"""


def accessibility_ab(origins_latlon, dests, roads_a, roads_b, speed_kmh,
                     times_min, dir_a=None, dir_b=None, progress=None,
                     is_canceled=None):
    """Accessibilità A vs B sulle stesse origini.

    :return: (rows, time) dove rows[i] = {a, b, delta, delta_pct, classe} sul
        tempo massimo, e time è la soglia usata.
    """
    from . import accessibility
    times = sorted({float(t) for t in times_min if float(t) > 0})
    t = times[-1]
    out_a, _ = accessibility.accessibility_network(
        origins_latlon, dests, roads_a, speed_kmh, times, directions=dir_a,
        progress=(lambda p: progress(int(p * 0.5))) if progress else None,
        is_canceled=is_canceled)
    out_b, _ = accessibility.accessibility_network(
        origins_latlon, dests, roads_b, speed_kmh, times, directions=dir_b,
        progress=(lambda p: progress(50 + int(p * 0.5))) if progress else None,
        is_canceled=is_canceled)
    rows = []
    for ra, rb in zip(out_a, out_b):
        a = float(ra.get(t, 0.0))
        b = float(rb.get(t, 0.0))
        delta = b - a
        if a > 0:
            pct = 100.0 * delta / a
        else:
            pct = 100.0 if b > 0 else 0.0
        cls = "gain" if delta > 1e-9 else ("loss" if delta < -1e-9
                                           else "unchanged")
        rows.append({"a": round(a, 2), "b": round(b, 2),
                     "delta": round(delta, 2), "delta_pct": round(pct, 1),
                     "classe": cls})
    return rows, t


def ptal_ab(points_latlon, gtfs_a, gtfs_b, start_h, end_h, params=None,
            service_date=None, progress=None):
    """PTAL A vs B sugli stessi punti con due feed GTFS (es. servizio attuale
    vs progetto). Ritorna rows {a, b, delta, delta_pct, classe} (a/b = livello
    PTAL 0..8; delta_pct dall'Accessibility Index).
    """
    from . import ptal
    sr_a, xy_a = ptal.compute_stop_frequencies(gtfs_a, start_h, end_h,
                                               service_date)
    if progress:
        progress(25)
    res_a = ptal.compute_ptal(points_latlon, sr_a, xy_a, params)
    if progress:
        progress(55)
    sr_b, xy_b = ptal.compute_stop_frequencies(gtfs_b, start_h, end_h,
                                               service_date)
    res_b = ptal.compute_ptal(points_latlon, sr_b, xy_b, params)
    if progress:
        progress(95)
    rows = []
    for ra, rb in zip(res_a, res_b):
        a = ra["level"]
        b = rb["level"]
        d = b - a
        ai_a = ra["ai"]
        if ai_a > 0:
            pct = 100.0 * (rb["ai"] - ai_a) / ai_a
        else:
            pct = 100.0 if rb["ai"] > 0 else 0.0
        cls = "gain" if d > 0 else ("loss" if d < 0 else "unchanged")
        rows.append({"a": a, "b": b, "delta": d, "delta_pct": round(pct, 1),
                     "classe": cls})
    if progress:
        progress(100)
    return rows


def scenario_summary(rows):
    """Sintesi del confronto A/B."""
    n = len(rows)
    gain = sum(1 for r in rows if r["classe"] == "gain")
    loss = sum(1 for r in rows if r["classe"] == "loss")
    mean_delta = (sum(r["delta"] for r in rows) / n) if n else 0.0
    return {"n": n, "migliorate": gain, "peggiorate": loss,
            "invariate": n - gain - loss, "delta_medio": round(mean_delta, 2)}
