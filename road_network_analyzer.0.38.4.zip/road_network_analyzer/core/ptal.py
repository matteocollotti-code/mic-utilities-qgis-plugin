# -*- coding: utf-8 -*-
"""PTAL - Public Transport Accessibility Level (metodo Transport for London).

Per ogni punto di analisi si trovano le fermate raggiungibili a piedi entro le
soglie per modo; per ogni rotta servita si calcola il tempo totale di accesso
(cammino + attesa + affidabilita') e la frequenza equivalente alla porta (EDF).
La somma pesata (rotta migliore x1, le altre x0.5) e' l'Accessibility Index,
mappato sulle fasce PTAL 0..6b.

Riferimento: TfL - "Measuring Public Transport Accessibility Levels (PTALs)".
"""
import math
from collections import defaultdict

# soglie/parametri di default (TfL)
DEFAULT_PARAMS = {
    "walk_speed_kmh": 4.8,
    # soglia di cammino (m) per tipo di rotta GTFS (route_type)
    "thresholds": {"0": 640, "1": 960, "2": 960, "3": 640, "4": 960},
    # affidabilita' (min) per tipo di rotta
    "reliability": {"0": 1.5, "1": 0.75, "2": 0.75, "3": 2.0, "4": 0.75},
    "default_threshold": 640,
    "default_reliability": 2.0,
    "weight_primary": 1.0,
    "weight_secondary": 0.5,
}

# profili orari standard (etichetta, ora_inizio, ora_fine, descrizione).
# Il primo e' il "primario" (AM peak): da' i campi base ai/ptal/ptal_level.
TIME_BANDS = [
    ("am", 7, 10, "AM peak (7-10)"),
    ("ip", 10, 16, "Interpeak (10-16)"),
    ("pm", 16, 19, "PM peak (16-19)"),
]

# (limite superiore AI, etichetta, livello numerico)
PTAL_BANDS = [
    (0.0, "0", 0),
    (2.5, "1a", 1),
    (5.0, "1b", 2),
    (10.0, "2", 3),
    (15.0, "3", 4),
    (20.0, "4", 5),
    (25.0, "5", 6),
    (40.0, "6a", 7),
    (float("inf"), "6b", 8),
]


def map_band(ai):
    if ai <= 0:
        return "0", 0
    for hi, label, level in PTAL_BANDS:
        if ai <= hi:
            return label, level
    return "6b", 8


def _haversine(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def compute_stop_frequencies(source, start_h, end_h, service_date=None):
    """Frequenze (corse/ora) per fermata e rotta nella fascia oraria.

    :param service_date: data YYYYMMDD per selezionare i servizi dal calendario;
        None = giorno di servizio dominante.
    :return: (stop_routes, stops_xy)
        stop_routes = {stop_id: [(route_id, route_type, freq_per_hour), ...]}
        stops_xy    = {stop_id: (lat, lon)}
    """
    import pandas as pd
    from . import gtfs_static as gs

    hours = max(0.5, float(end_h) - float(start_h))
    start_s = float(start_h) * 3600.0
    end_s = float(end_h) * 3600.0

    routes = gs._read_table(source, "routes.txt")
    route_type = {}
    if routes is not None:
        for r in routes.itertuples(index=False):
            route_type[r.route_id] = str(getattr(r, "route_type", "3") or "3")

    trips = gs._read_subset(source, "trips.txt",
                            ["trip_id", "route_id", "service_id"])
    if trips is None or trips.empty:
        raise ValueError("trips.txt mancante o vuoto.")
    trips, _desc = gs.select_trips(trips, source, service_date)
    trip_route = dict(zip(trips["trip_id"], trips["route_id"]))
    allowed = set(trips["trip_id"])

    stops = gs._read_table(source, "stops.txt")
    stops_xy = {}
    for r in stops.itertuples(index=False):
        try:
            stops_xy[r.stop_id] = (float(r.stop_lat), float(r.stop_lon))
        except (TypeError, ValueError):
            continue

    st_cols = gs._table_columns(source, "stop_times.txt")
    timecol = "departure_time" if "departure_time" in st_cols else "arrival_time"
    use = [c for c in ["trip_id", timecol, "stop_id"] if c in st_cols]
    counts = defaultdict(int)

    def _consume(reader):
        for chunk in reader:
            chunk = chunk[chunk["trip_id"].isin(allowed)]
            if chunk.empty:
                continue
            parts = chunk[timecol].str.split(":", expand=True)
            if parts.shape[1] < 3:
                continue
            sec = (pd.to_numeric(parts[0], errors="coerce") * 3600
                   + pd.to_numeric(parts[1], errors="coerce") * 60
                   + pd.to_numeric(parts[2], errors="coerce"))
            chunk = chunk[(sec >= start_s) & (sec < end_s)]
            if chunk.empty:
                continue
            chunk = chunk.assign(route=chunk["trip_id"].map(trip_route))
            grp = chunk.groupby(["stop_id", "route"]).size()
            for (sid, rid), c in grp.items():
                counts[(sid, rid)] += int(c)

    import os
    import zipfile
    if os.path.isdir(source):
        path = os.path.join(source, "stop_times.txt")
        _consume(pd.read_csv(path, dtype=str, keep_default_na=False,
                             usecols=use, chunksize=400000))
    else:
        with zipfile.ZipFile(source) as zf:
            with zf.open("stop_times.txt") as fh:
                _consume(pd.read_csv(fh, dtype=str, keep_default_na=False,
                                     usecols=use, chunksize=400000))

    stop_routes = defaultdict(list)
    for (sid, rid), c in counts.items():
        if c <= 0:
            continue
        stop_routes[sid].append((rid, route_type.get(rid, "3"), c / hours))
    return dict(stop_routes), stops_xy


def _edf_for_stop(routes, dist, walk_speed, thresholds, reliability, p):
    """EDF pesata del nodo-fermata data la distanza pedonale (m)."""
    walk_time = dist / 1000.0 / walk_speed * 60.0
    edfs = []
    for rid, rtype, freq in routes:
        thr = thresholds.get(rtype, p["default_threshold"])
        if dist > thr or freq <= 0:
            continue
        rel = reliability.get(rtype, p["default_reliability"])
        tat = walk_time + 0.5 * (60.0 / freq) + rel
        if tat > 0:
            edfs.append(0.5 * (60.0 / tat))
    if not edfs:
        return 0.0
    edfs.sort(reverse=True)
    return edfs[0] * p["weight_primary"] + sum(edfs[1:]) * p["weight_secondary"]


def compute_ptal_network(points_latlon, stop_routes, stops_xy, roads_lonlat,
                         params=None, progress=None, is_canceled=None):
    """PTAL con distanze pedonali sulla RETE (Dijkstra) invece che in linea d'aria."""
    from . import net_iso
    p = dict(DEFAULT_PARAMS)
    if params:
        p.update(params)
    walk_speed = p["walk_speed_kmh"]
    thresholds = p["thresholds"]
    reliability = p["reliability"]
    max_thr = max(list(thresholds.values()) + [p["default_threshold"]])

    pts = [(la, lo) for la, lo in points_latlon]
    lat0 = sum(la for la, lo in pts) / len(pts) if pts else 0.0
    graph = net_iso.build_metric_graph(roads_lonlat, lat0)
    if progress:
        progress(20)
    stop_info = {}
    for sid, (la, lo) in stops_xy.items():
        if sid in stop_routes:
            info = graph.snap_edge_ll(la, lo, 500.0)
            if info:
                stop_info[sid] = info

    out = []
    n = len(pts)
    for idx, (plat, plon) in enumerate(pts):
        if is_canceled and idx % 25 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and idx % 50 == 0 and n:
            progress(20 + int(75 * idx / n))
        src_info = graph.snap_edge_ll(plat, plon, 500.0)
        ai = 0.0
        if src_info:
            cost = graph.dijkstra_multi(src_info["seeds"], max_thr)
            for sid, sinfo in stop_info.items():
                d = graph.edge_distance(cost, src_info, sinfo)
                if d > max_thr:
                    continue
                ai += _edf_for_stop(stop_routes[sid], d, walk_speed,
                                    thresholds, reliability, p)
        band, level = map_band(ai)
        out.append({"ai": ai, "band": band, "level": level})
    if progress:
        progress(100)
    return out


def _grid_index(stops_xy, cell_deg=0.01):
    grid = defaultdict(list)
    for sid, (la, lo) in stops_xy.items():
        grid[(round(la / cell_deg), round(lo / cell_deg))].append(sid)
    return grid, cell_deg


def compute_ptal(points_latlon, stop_routes, stops_xy, params=None,
                 progress=None, is_canceled=None):
    """Calcola AI e fascia PTAL per ogni punto di analisi.

    :param points_latlon: lista [(lat, lon)] dei punti di analisi.
    :return: lista di dict {ai, band, level} allineata ai punti.
    """
    p = dict(DEFAULT_PARAMS)
    if params:
        p.update(params)
    walk_speed = p["walk_speed_kmh"]
    thresholds = p["thresholds"]
    reliability = p["reliability"]
    max_thr = max(list(thresholds.values()) + [p["default_threshold"]])
    grid, cell = _grid_index(stops_xy)
    cell_span = int(max_thr / (cell * 111000.0)) + 1

    out = []
    n = len(points_latlon)
    for idx, (plat, plon) in enumerate(points_latlon):
        if is_canceled and idx % 50 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and idx % 100 == 0 and n:
            progress(int(100 * idx / n))

        gi, gj = round(plat / cell), round(plon / cell)
        ai = 0.0
        for di in range(-cell_span, cell_span + 1):
            for dj in range(-cell_span, cell_span + 1):
                for sid in grid.get((gi + di, gj + dj), ()):
                    routes = stop_routes.get(sid)
                    if not routes:
                        continue
                    slat, slon = stops_xy[sid]
                    dist = _haversine(plat, plon, slat, slon)
                    walk_time = dist / 1000.0 / walk_speed * 60.0
                    edfs = []
                    for rid, rtype, freq in routes:
                        thr = thresholds.get(rtype, p["default_threshold"])
                        if dist > thr or freq <= 0:
                            continue
                        rel = reliability.get(rtype, p["default_reliability"])
                        swt = 0.5 * (60.0 / freq)
                        tat = walk_time + swt + rel
                        if tat > 0:
                            edfs.append(0.5 * (60.0 / tat))
                    if not edfs:
                        continue
                    edfs.sort(reverse=True)
                    node_edf = edfs[0] * p["weight_primary"]
                    node_edf += sum(edfs[1:]) * p["weight_secondary"]
                    ai += node_edf
        band, level = map_band(ai)
        out.append({"ai": ai, "band": band, "level": level})
    if progress:
        progress(100)
    return out
