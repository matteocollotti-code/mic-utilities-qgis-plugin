# -*- coding: utf-8 -*-
"""Costruzione dei memory layer QGIS dai risultati GTFS."""
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsPalLayerSettings,
    QgsPointXY,
    QgsRendererCategory,
    QgsSymbol,
    QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
    QgsWkbTypes,
)

from . import style_util


def _line_from_latlon(coords):
    pts = [QgsPointXY(lon, lat) for lat, lon in coords]
    return QgsGeometry.fromPolylineXY(pts)


def _make_layer(name, fields):
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes(fields)
    layer.updateFields()
    return layer


def _apply_line_categories(layer, field="linea"):
    """Renderer categorizzato (un colore per linea) + etichette col nome linea."""
    values = sorted({f[field] for f in layer.getFeatures() if f[field]})
    cats = []
    n = max(1, len(values))
    for i, val in enumerate(values):
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setWidth(0.8)
        sym.setColor(QColor.fromHsv(int(360 * i / n), 200, 230))
        cats.append(QgsRendererCategory(val, sym, str(val)))
    if cats:
        layer.setRenderer(QgsCategorizedSymbolRenderer(field, cats))
    settings = QgsPalLayerSettings()
    settings.fieldName = field
    try:
        settings.enabled = True
    except Exception:
        pass
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    layer.setLabelsEnabled(True)
    layer.triggerRepaint()


def update_lines_layer(layer, acc, name="GTFS - Linee"):
    """Crea o aggiorna l'UNICO layer delle linee, categorizzato per linea.

    :param acc: accumulatore {shapes:{id:coords}, shape_routes:{id:(rid,dir)},
                routes:{rid:{short_name,..}}}
    """
    if layer is None or not layer.isValid():
        layer = _make_layer(name, [
            QgsField("shape_id", QVariant.String),
            QgsField("route_id", QVariant.String),
            QgsField("linea", QVariant.String),
            QgsField("direction", QVariant.String),
        ])
    else:
        layer.dataProvider().truncate()

    routes = acc.get("routes", {})
    shape_routes = acc.get("shape_routes", {})
    feats = []
    for shape_id, coords in acc.get("shapes", {}).items():
        c = [(la, lo) for la, lo, _ in coords]
        if len(c) < 2:
            continue
        route_id, direction = shape_routes.get(shape_id, ("", ""))
        linea = routes.get(route_id, {}).get("short_name", "") or route_id
        f = QgsFeature(layer.fields())
        f.setGeometry(_line_from_latlon(c))
        f.setAttributes([shape_id, route_id, linea, direction])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    _apply_line_categories(layer, "linea")
    return layer


def update_metrics_layer(layer, line_metrics, rt_lines=None,
                         name="GTFS - Metriche linee"):
    """Crea o aggiorna l'UNICO layer (tabella) con le metriche per linea."""
    rt_lines = rt_lines or {}
    fields = [
        QgsField("route_id", QVariant.String),
        QgsField("linea", QVariant.String),
        QgsField("direction", QVariant.String),
        QgsField("lunghezza_km", QVariant.Double),
        QgsField("commerciale_kmh", QVariant.Double),
        QgsField("esercizio_kmh", QVariant.Double),
        QgsField("eff_rt_kmh", QVariant.Double),
        QgsField("sosta_s", QVariant.Double),
        QgsField("n_corse", QVariant.Int),
    ]
    if layer is None or not layer.isValid():
        layer = QgsVectorLayer("None", name, "memory")
        layer.dataProvider().addAttributes(fields)
        layer.updateFields()
    else:
        layer.dataProvider().truncate()

    feats = []
    for key, m in sorted(line_metrics.items()):
        eff = rt_lines.get(key, {}).get("eff_speed_kmh")
        f = QgsFeature(layer.fields())
        f.setAttributes([
            m["route_id"], m.get("route_short_name") or m["route_id"],
            m["direction_id"],
            round(m["mean_length_m"] / 1000.0, 3),
            round(m["commercial_speed_kmh"], 2),
            round(m["running_speed_kmh"], 2),
            round(eff, 2) if eff is not None else None,
            round(m["mean_dwell_s"], 0),
            m["n_trips"],
        ])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    return layer


def style_segments_by_deviation(layer, classes=5):
    """Stile graduato sullo scarto di velocita' (rosso = osservata << teorica).

    :return: numero di feature con dev_kmh valorizzato.
    """
    values = [f["dev_kmh"] for f in layer.getFeatures() if f["dev_kmh"] is not None]
    if not values:
        return 0
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol.setWidth(0.9)
    # rampa: valore basso (scarto molto negativo) = rosso, alto = verde
    ramp = QgsGradientColorRamp(QColor(198, 40, 40), QColor(46, 125, 50))
    n_classes = min(classes, len(set(values)))
    for mode in (QgsGraduatedSymbolRenderer.Jenks,
                 QgsGraduatedSymbolRenderer.Quantile,
                 QgsGraduatedSymbolRenderer.EqualInterval):
        renderer = QgsGraduatedSymbolRenderer.createRenderer(
            layer, "dev_kmh", n_classes, mode, symbol.clone(), ramp.clone())
        if renderer and renderer.ranges():
            layer.setRenderer(renderer)
            layer.triggerRepaint()
            return len(values)
    return 0


def select_worst_segments(layer, top_n):
    """Seleziona gli N segmenti con lo scarto piu' negativo (osservata << teorica)."""
    feats = [(f["dev_kmh"], f.id()) for f in layer.getFeatures()
             if f["dev_kmh"] is not None]
    feats.sort(key=lambda x: x[0])  # piu' negativo prima
    ids = [fid for _, fid in feats[:max(1, top_n)]]
    layer.selectByIds(ids)
    return len(ids)


def build_matched_roads_layer(road_layer, results,
                              name="Rete stradale - velocita trasporto"):
    """Clona la rete stradale aggiungendo le velocita' GTFS map-matchate.

    :param results: dict {fid: {v_sched, v_eff, dev, n_seg, n_routes, routes}}
    """
    wkb = QgsWkbTypes.displayString(road_layer.wkbType()) or "LineString"
    uri = "%s?crs=%s" % (wkb, road_layer.crs().authid())
    layer = QgsVectorLayer(uri, name, "memory")
    prov = layer.dataProvider()

    src_fields = road_layer.fields()
    extra = [
        QgsField("v_sched_kmh", QVariant.Double),
        QgsField("v_eff_kmh", QVariant.Double),
        QgsField("dev_kmh", QVariant.Double),
        QgsField("n_seg", QVariant.Int),
        QgsField("n_routes", QVariant.Int),
        QgsField("routes", QVariant.String),
    ]
    prov.addAttributes(list(src_fields) + extra)
    layer.updateFields()

    n_src = len(src_fields)
    feats = []
    for f in road_layer.getFeatures():
        r = results.get(f.id())
        out = QgsFeature(layer.fields())
        out.setGeometry(f.geometry())
        attrs = list(f.attributes())
        if len(attrs) < n_src:
            attrs += [None] * (n_src - len(attrs))
        if r:
            attrs += [
                round(r["v_sched"], 2),
                round(r["v_eff"], 2) if r["v_eff"] is not None else None,
                round(r["dev"], 2) if r["dev"] is not None else None,
                r["n_seg"], r["n_routes"], r["routes"],
            ]
        else:
            attrs += [None, None, None, None, None, None]
        out.setAttributes(attrs)
        feats.append(out)
    prov.addFeatures(feats)
    layer.updateExtents()
    return layer


def _ptal_fields(profiles):
    """Campi base ai/ptal/ptal_level + (se profili) un set per fascia."""
    fields = [
        QgsField("ai", QVariant.Double),
        QgsField("ptal", QVariant.String),
        QgsField("ptal_level", QVariant.Int),
    ]
    if profiles:
        for label, _res in profiles:
            fields.append(QgsField("ai_%s" % label, QVariant.Double))
            fields.append(QgsField("ptal_%s" % label, QVariant.String))
    return fields


def _ptal_attrs(idx, results, profiles):
    """Attributi: primario (results[idx]) + un valore per fascia se profili."""
    r = results[idx]
    attrs = [round(r["ai"], 2), r["band"], r["level"]]
    if profiles:
        for _label, res in profiles:
            rb = res[idx]
            attrs.append(round(rb["ai"], 2))
            attrs.append(rb["band"])
    return attrs


def build_ptal_layer(points_layer, results, name="PTAL", profiles=None):
    """Copia i punti di analisi con AI, fascia PTAL e livello; stile per livello.

    Se `profiles` (lista di (label, results)) e' dato, aggiunge i campi
    ai_<label>/ptal_<label> per ogni fascia oraria; i campi base usano la fascia
    primaria (`results`).
    """
    wkb = QgsWkbTypes.displayString(points_layer.wkbType()) or "Point"
    uri = "%s?crs=%s" % (wkb, points_layer.crs().authid())
    layer = QgsVectorLayer(uri, name, "memory")
    layer.dataProvider().addAttributes(_ptal_fields(profiles))
    layer.updateFields()
    feats = []
    idx = 0
    # salta le feature senza geometria: `results` è allineato alle SOLE feature
    # valide (le coordinate sono costruite con lo stesso filtro a monte).
    for src in points_layer.getFeatures():
        g = src.geometry()
        if g is None or g.isEmpty() or idx >= len(results):
            continue
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        f.setAttributes(_ptal_attrs(idx, results, profiles))
        feats.append(f)
        idx += 1
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    apply_ptal_style(layer)
    return layer


# palette PTAL (tutte le fasce 0..6b)
PTAL_COLORS = [
    ("0", "#9e9e9e"), ("1a", "#08306b"), ("1b", "#2171b5"),
    ("2", "#41b6c4"), ("3", "#78c679"), ("4", "#c2e699"),
    ("5", "#fee08b"), ("6a", "#fc8d59"), ("6b", "#d73027"),
]


def apply_ptal_style(layer):
    """Renderer categorizzato con TUTTE le fasce PTAL in legenda."""
    cats = []
    for band, hexc in PTAL_COLORS:
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(QColor(hexc))
        cats.append(QgsRendererCategory(band, sym, "PTAL " + band))
    layer.setRenderer(QgsCategorizedSymbolRenderer("ptal", cats))


def build_ptal_grid_layer(cells, results, name="PTAL", profiles=None):
    """Layer poligonale a celle (esagoni/quadrati) colorato per fascia PTAL.

    :param cells: lista di anelli [[(lat, lon), ...], ...].
    :param results: lista di dict {ai, band, level} (fascia primaria).
    :param profiles: opzionale, lista di (label, results) per i profili orari.
    """
    layer = QgsVectorLayer("Polygon?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes(_ptal_fields(profiles))
    layer.updateFields()
    feats = []
    for idx, ring in enumerate(cells):
        pts = [QgsPointXY(lo, la) for la, lo in ring]
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolygonXY([pts]))
        f.setAttributes(_ptal_attrs(idx, results, profiles))
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    apply_ptal_style(layer)
    return layer


def build_walkability_layer(cells_latlon, results, name="Walkability"):
    """Layer poligonale degli indici di walkability, graduato 0-100."""
    layer = QgsVectorLayer("Polygon?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("walkability", QVariant.Double),
        QgsField("design", QVariant.Double),
        QgsField("destinazioni", QVariant.Double),
        QgsField("pendenza", QVariant.Double),
        QgsField("attraversam", QVariant.Double),
        QgsField("n_incroci", QVariant.Int),
        QgsField("dens_incroci", QVariant.Double),
        QgsField("dens_strade", QVariant.Double),
        QgsField("link_node", QVariant.Double),
        QgsField("conn_media", QVariant.Double),
        QgsField("n_poi", QVariant.Int),
        QgsField("n_attrav", QVariant.Int),
        QgsField("grade_pct", QVariant.Double),
    ])
    layer.updateFields()
    feats = []
    for ring, r in zip(cells_latlon, results):
        pts = [QgsPointXY(lo, la) for la, lo in ring]
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolygonXY([pts]))
        f.setAttributes([
            r["walkability"], r.get("design", 0.0), r.get("destinazioni", 0.0),
            r.get("pendenza", 0.0), r.get("attraversamenti", 0.0),
            r["n_incroci"], r["int_density"],
            r["street_density"], r["link_node"], r["mean_conn"],
            r.get("n_poi", 0), r.get("n_attrav", 0), r.get("grade_pct", 0.0)])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    values = [f["walkability"] for f in layer.getFeatures()
              if f["walkability"] is not None]
    n = min(6, len(set(values))) if values else 0
    if n >= 1:
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        ramp = QgsGradientColorRamp(QColor(215, 48, 39), QColor(26, 152, 80))
        r = style_util.graduated_from(layer, "walkability", n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer


def build_access_layer(origins_layer, results, times, name="Accessibilita"):
    """Copia le origini con un campo di accessibilita' per ogni fascia."""
    wkb = QgsWkbTypes.displayString(origins_layer.wkbType()) or "Point"
    layer = QgsVectorLayer("%s?crs=%s" % (wkb, origins_layer.crs().authid()),
                           name, "memory")
    fields = [QgsField("acc_%gmin" % t, QVariant.Double) for t in times]
    layer.dataProvider().addAttributes(fields)
    layer.updateFields()
    feats = []
    # salta le origini senza geometria per restare allineati a `results`
    # (le coordinate origine sono costruite con lo stesso filtro a monte).
    res_iter = iter(results)
    for src in origins_layer.getFeatures():
        g = src.geometry()
        if g is None or g.isEmpty():
            continue
        res = next(res_iter, None)
        if res is None:
            break
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        f.setAttributes([round(res.get(t, 0.0), 2) for t in times])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    field = "acc_%gmin" % max(times)
    values = [f[field] for f in layer.getFeatures() if f[field] is not None]
    n = min(6, len(set(values))) if values else 0
    if n >= 1:
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        ramp = QgsGradientColorRamp(QColor(255, 255, 204), QColor(0, 104, 55))
        r = style_util.graduated_from(layer, field, n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer


def build_space_syntax_layer(road_layer, fids, metrics,
                             name="Space syntax"):
    """Copia la rete con i campi space syntax, stile per integrazione."""
    wkb = QgsWkbTypes.displayString(road_layer.wkbType()) or "LineString"
    uri = "%s?crs=%s" % (wkb, road_layer.crs().authid())
    layer = QgsVectorLayer(uri, name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("connettivita", QVariant.Int),
        QgsField("profondita_media", QVariant.Double),
        QgsField("profondita_tot", QVariant.Double),
        QgsField("integrazione", QVariant.Double),
        QgsField("choice", QVariant.Double),
        QgsField("nain", QVariant.Double),
        QgsField("nach", QVariant.Double),
    ])
    layer.updateFields()
    feats = []
    for i, fid in enumerate(fids):
        src = road_layer.getFeature(fid)
        f = QgsFeature(layer.fields())
        f.setGeometry(src.geometry())
        f.setAttributes([
            metrics["connectivity"][i],
            round(metrics["mean_depth"][i], 4),
            round(metrics["total_depth"][i], 1),
            round(metrics["integration"][i], 4),
            round(metrics["choice"][i], 2),
            round(metrics["nain"][i], 4),
            round(metrics["nach"][i], 4),
        ])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol.setWidth(0.7)
    ramp = QgsGradientColorRamp(QColor(43, 131, 186), QColor(215, 25, 28))
    values = [f["integrazione"] for f in layer.getFeatures()
              if f["integrazione"] is not None]
    n = min(6, len(set(values))) if values else 0
    if n >= 1:
        renderer = style_util.graduated_from(layer, "integrazione", n, symbol, ramp)
        if renderer and renderer.ranges():
            layer.setRenderer(renderer)
    return layer


def build_segments_layer(result, rt_stats=None, name="GTFS - Segmenti"):
    """Un feature per segmento stop-to-stop, con metriche programmate e (se
    disponibili) effettive da GTFS-RT."""
    fields = [
        QgsField("route_id", QVariant.String),
        QgsField("direction", QVariant.String),
        QgsField("from_stop", QVariant.String),
        QgsField("from_name", QVariant.String),
        QgsField("to_stop", QVariant.String),
        QgsField("to_name", QVariant.String),
        QgsField("length_m", QVariant.Double),
        QgsField("sched_t_s", QVariant.Double),
        QgsField("v_sched_kmh", QVariant.Double),
        QgsField("v_eff_kmh", QVariant.Double),
        QgsField("dev_kmh", QVariant.Double),
        QgsField("dev_pct", QVariant.Double),
        QgsField("delay_s", QVariant.Double),
        QgsField("n_obs", QVariant.Int),
    ]
    layer = _make_layer(name, fields)
    rt_stats = rt_stats or {}
    feats = []
    for key, seg in result["segments"].items():
        f = QgsFeature(layer.fields())
        f.setGeometry(_line_from_latlon(seg["coords"]))
        rt = rt_stats.get(key)
        f.setAttributes([
            seg["route_id"], seg["direction_id"],
            seg["from_stop"], seg["from_name"],
            seg["to_stop"], seg["to_name"],
            round(seg["length_m"], 1),
            round(seg["sched_time_s"], 1),
            round(seg["sched_speed_kmh"], 2),
            round(rt["eff_speed_kmh"], 2) if rt else None,
            round(rt["dev_kmh"], 2) if rt else None,
            round(rt["dev_pct"], 1) if rt else None,
            round(rt["mean_delay_s"], 1) if rt and rt["mean_delay_s"] is not None else None,
            rt["n_obs"] if rt else None,
        ])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    return layer
