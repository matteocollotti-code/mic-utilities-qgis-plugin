# -*- coding: utf-8 -*-
"""Validatore/diagnostica della rete stradale per le analisi su grafo.

Spiega i risultati nulli o sottostimati: componenti scollegate, sorgenti su
componenti isolate, punti non agganciati, incroci non noded.

`diagnose_network` è puro Python (riusa net_iso/net_clean/network_prepare) e
restituisce un dict serializzabile, da cui net_layers costruisce i layer.
"""
import math
from collections import deque


def _components(graph):
    """Componenti connesse (non orientate) -> lista comp per nodo."""
    comp = [-1] * graph.n
    # adiacenza non orientata dagli archi
    undir = [[] for _ in range(graph.n)]
    for a, b, _d in graph.edges:
        undir[a].append(b)
        undir[b].append(a)
    cid = 0
    for s in range(graph.n):
        if comp[s] != -1:
            continue
        comp[s] = cid
        q = deque([s])
        while q:
            v = q.popleft()
            for w in undir[v]:
                if comp[w] == -1:
                    comp[w] = cid
                    q.append(w)
        cid += 1
    return comp, cid


def preflight(roads, directions, coords, max_segments=80000):
    """Controllo rapido prima delle analisi su rete (thread-safe).

    :return: (ok_to_run, messaggio). Blocca se NESSUNA sorgente aggancia la
        rete; avvisa (senza bloccare) se alcune non agganciano o sono su una
        componente isolata. Saltato su reti molto grandi.
    """
    from collections import Counter
    from . import net_iso
    if not coords or not roads or len(roads) > max_segments:
        return True, ""
    try:
        graph = net_iso.build_metric_graph(roads, roads[0][0][1],
                                           directions=directions)
        comp, _n = _components(graph)
        cnt = Counter(comp)
        main = max(cnt, key=cnt.get) if cnt else 0
        n_snap = n_iso = 0
        for la, lo in coords:
            info = graph.snap_edge_ll(la, lo, 500.0)
            if info is None:
                continue
            n_snap += 1
            if comp[info["seeds"][0][0]] != main:
                n_iso += 1
    except Exception:
        return True, ""
    if n_snap == 0:
        return False, ("Nessuna delle %d sorgenti aggancia la rete entro "
                       "500 m. Verifica la rete o usa 'Prepara rete'."
                       % len(coords))
    warn = []
    if n_snap < len(coords):
        warn.append("%d/%d sorgenti non agganciate"
                    % (len(coords) - n_snap, len(coords)))
    if n_iso:
        warn.append("%d su componente isolata" % n_iso)
    return True, ("⚠️ " + ", ".join(warn) + ". " if warn else "")


def diagnose_network(roads_lonlat, sources_latlon=None, dests_latlon=None,
                     stops_latlon=None, times_min=None, speed_kmh=4.8,
                     directions=None, snap_max_m=500.0, crossing_check=True,
                     max_crossings=500, progress=None, is_canceled=None):
    """Diagnostica la rete + (opzionale) sorgenti/destinazioni/fermate."""
    from . import net_iso, net_clean, network_prepare

    report = {"ok": True, "issues": [], "stats": {}, "segments": [],
              "comp_of_seg": [], "main_comp": 0, "snaps": {}, "crossings": [],
              "dead_ends": []}

    polys = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    if not polys:
        report["ok"] = False
        report["issues"].append({"code": "no_roads", "severity": "error",
                                 "message": "Nessuna strada valida.", "count": 0})
        return report

    clean, cdirs, cstats = net_clean.clean_network(roads_lonlat, 1.0, directions)
    lat0 = clean[0][0][1]
    graph = net_iso.build_metric_graph(clean, lat0, directions=cdirs)
    if progress:
        progress(30)

    comp_of_node, n_comp = _components(graph)

    # lunghezza per componente (dagli archi) + segmenti per il layer
    comp_len = {}
    segments = []
    comp_of_seg = []
    for a, b, d in graph.edges:
        c = comp_of_node[a]
        comp_len[c] = comp_len.get(c, 0.0) + d
        la1, lo1 = graph.to_ll(*graph.node_xy[a])[::-1]
        la2, lo2 = graph.to_ll(*graph.node_xy[b])[::-1]
        segments.append([(lo1, la1), (lo2, la2)])
        comp_of_seg.append(c)
    main_comp = max(comp_len, key=comp_len.get) if comp_len else 0
    total_len = sum(comp_len.values()) or 1.0
    main_pct = 100.0 * comp_len.get(main_comp, 0.0) / total_len
    report["segments"] = segments
    report["comp_of_seg"] = comp_of_seg
    report["main_comp"] = main_comp
    report["stats"] = {"segmenti": len(segments), "nodi": graph.n,
                       "componenti": n_comp, "pct_principale": round(main_pct, 1)}

    if n_comp > 1:
        report["issues"].append({
            "code": "multi_component", "severity": "warning",
            "message": "Rete in %d componenti scollegate; la principale "
                       "contiene il %.0f%% della lunghezza." % (n_comp, main_pct),
            "count": n_comp})
    if progress:
        progress(50)

    # dead ends (nodi di grado 1)
    deg = [len(graph.adj[i]) for i in range(graph.n)]
    # grado non orientato
    undeg = [0] * graph.n
    for a, b, _d in graph.edges:
        undeg[a] += 1
        undeg[b] += 1
    for i in range(graph.n):
        if undeg[i] == 1:
            lo, la = graph.to_ll(*graph.node_xy[i])
            report["dead_ends"].append((la, lo, {"component": comp_of_node[i]}))

    def _snap_points(points, label):
        out = []
        n_fail = 0
        n_isolated = 0
        for idx, (la, lo) in enumerate(points):
            info = graph.snap_edge_ll(la, lo, snap_max_m)
            if info is None:
                n_fail += 1
                out.append({"idx": idx, "lat": la, "lon": lo, "snapped": False,
                            "snap_m": None, "component": None})
                continue
            px, py = graph.to_m(lo, la)
            fx, fy = info["foot"]
            sd = math.hypot(px - fx, py - fy)
            comp = comp_of_node[info["seeds"][0][0]]
            if comp != main_comp:
                n_isolated += 1
            out.append({"idx": idx, "lat": la, "lon": lo, "snapped": True,
                        "snap_m": round(sd, 1), "component": comp,
                        "info": info})
        return out, n_fail, n_isolated

    for key, pts, lbl in (("sources", sources_latlon, "sorgenti"),
                          ("dests", dests_latlon, "destinazioni"),
                          ("stops", stops_latlon, "fermate")):
        if not pts:
            continue
        snaps, n_fail, n_iso = _snap_points(pts, lbl)
        report["snaps"][key] = snaps
        if n_fail:
            report["issues"].append({
                "code": "snap_fail_%s" % key, "severity": "warning",
                "message": "%d %s non agganciano la rete entro %.0f m."
                           % (n_fail, lbl, snap_max_m), "count": n_fail})
        if n_iso:
            report["issues"].append({
                "code": "isolated_%s" % key, "severity": "warning",
                "message": "%d %s su una componente diversa dalla principale."
                           % (n_iso, lbl), "count": n_iso})
    if progress:
        progress(70)

    # reachability rapida sorgenti->destinazioni
    if sources_latlon and dests_latlon and times_min:
        max_t = max(times_min)
        max_dist = speed_kmh * 1000.0 / 60.0 * max_t
        dest_infos = [graph.snap_edge_ll(la, lo, snap_max_m)
                      for la, lo in dests_latlon]
        for s in report["snaps"].get("sources", []):
            if not s["snapped"]:
                s["reachable"] = 0
                continue
            cost = graph.dijkstra_multi(graph.source_seeds(s["info"]), max_dist)
            reach = 0
            for di in dest_infos:
                if di is None:
                    continue
                d = graph.edge_distance(cost, s["info"], di)
                if d <= max_dist:
                    reach += 1
            s["reachable"] = reach
        n_zero = sum(1 for s in report["snaps"]["sources"]
                     if s.get("reachable") == 0)
        if n_zero:
            report["issues"].append({
                "code": "no_reach", "severity": "warning",
                "message": "%d sorgenti non raggiungono alcuna destinazione "
                           "entro %g min." % (n_zero, max_t), "count": n_zero})

    # incroci non noded
    if crossing_check:
        cr = network_prepare.find_unresolved_crossings(roads_lonlat, max_crossings)
        report["crossings"] = cr
        if cr:
            report["issues"].append({
                "code": "unresolved_crossings", "severity": "warning",
                "message": "Rilevati %d incroci non noded: usa 'Prepara rete' "
                           "prima dell'analisi." % len(cr), "count": len(cr)})
    if progress:
        progress(100)

    report["ok"] = not any(i["severity"] == "error" for i in report["issues"])
    return report
