# -*- coding: utf-8 -*-
"""Helper di stile condivisi (renderer graduato senza API deprecate)."""
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsSymbol,
)


def graduated_renderer(layer, field, n, color_lo, color_hi):
    """Renderer graduato a quantili, senza `createRenderer` (deprecato).

    color_lo/color_hi: QColor o stringhe hex. Ritorna il renderer o None.
    """
    if isinstance(color_lo, str):
        color_lo = QColor(color_lo)
    if isinstance(color_hi, str):
        color_hi = QColor(color_hi)
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    ramp = QgsGradientColorRamp(color_lo, color_hi)
    r = QgsGraduatedSymbolRenderer(field)
    r.setSourceSymbol(symbol)
    r.setSourceColorRamp(ramp)
    try:
        from qgis.core import QgsClassificationQuantile
        r.setClassificationMethod(QgsClassificationQuantile())
        r.updateClasses(layer, n)
    except Exception:
        # fallback per versioni QGIS senza QgsClassificationQuantile
        r.updateClasses(layer, QgsGraduatedSymbolRenderer.Quantile, n)
    return r if r.ranges() else None


def graduated_from(layer, field, n, symbol, ramp):
    """Come graduated_renderer ma con symbol/ramp già pronti."""
    r = QgsGraduatedSymbolRenderer(field)
    r.setSourceSymbol(symbol)
    r.setSourceColorRamp(ramp)
    try:
        from qgis.core import QgsClassificationQuantile
        r.setClassificationMethod(QgsClassificationQuantile())
        r.updateClasses(layer, n)
    except Exception:
        r.updateClasses(layer, QgsGraduatedSymbolRenderer.Quantile, n)
    return r if r.ranges() else None
