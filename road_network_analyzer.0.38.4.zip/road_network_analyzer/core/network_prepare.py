# -*- coding: utf-8 -*-
"""Preparazione della rete: noding alle intersezioni + snap + dedup.

Trasforma una rete grezza (anche non "noded") in una rete pronta per il grafo:
spezza le linee dove si incrociano geometricamente senza un vertice condiviso,
così che le analisi su rete (isocrone, accessibilità, PTAL, space syntax) possano
attraversare quegli incroci.

`node_network` lavora su segmenti lon/lat (puro Python, thread-safe). La
proiezione è equirettangolare locale in metri (coerente con net_iso/net_clean).
Limiti v1: ignora le sovrapposizioni collineari; per reti molto grandi può
essere costoso (mitigato da indice a griglia + progress).
"""
import math


def _projector(lat0):
    mlat = 111320.0
    mlon = 111320.0 * math.cos(math.radians(lat0))

    def to_m(lon, lat):
        return (lon * mlon, lat * mlat)

    def to_ll(x, y):
        return (x / mlon, y / mlat)

    return to_m, to_ll


def _seg_intersection(ax, ay, bx, by, cx, cy, dx, dy):
    """Intersezione dei segmenti AB e CD. Ritorna (t, u) lungo AB/CD o None.

    Include i contatti a T (estremo di un segmento sull'interno dell'altro).
    Ignora i casi paralleli/collineari.
    """
    rx, ry = bx - ax, by - ay
    sx, sy = dx - cx, dy - cy
    denom = rx * sy - ry * sx
    if denom == 0:
        return None
    qpx, qpy = cx - ax, cy - ay
    t = (qpx * sy - qpy * sx) / denom
    u = (qpx * ry - qpy * rx) / denom
    if -1e-9 <= t <= 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9:
        return t, u
    return None


def node_network(roads_lonlat, snap_tol_m=1.0, min_seg_m=0.2, directions=None,
                 split=True, progress=None, is_canceled=None):
    """Spezza i segmenti alle intersezioni e pulisce.

    :param split: se False salta il noding (solo snap + dedup, come net_clean).
    :return: (segmenti lon/lat, directions allineate o None, stats).
    """
    from . import net_clean

    polys = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    stats = {"segmenti_in": 0, "segmenti_out": 0, "split": 0,
             "intersezioni": 0, "nulli": 0, "duplicati": 0, "nodi": 0}
    if not polys:
        return [], (None if directions is None else []), stats
    if not split:
        cleaned, cdirs, cstats = net_clean.clean_network(
            roads_lonlat, snap_tol_m, directions)
        stats.update(cstats)
        return cleaned, cdirs, stats

    lat0 = polys[0][0][1]
    to_m, to_ll = _projector(lat0)

    # 1) segmenti elementari in metri, con direzione del parent
    segs = []          # (ax, ay, bx, by)
    seg_dir = []
    for ri, road in enumerate(polys):
        rd = directions[ri] if directions and ri < len(directions) else 0
        m = [to_m(lon, lat) for lon, lat in road]
        for (ax, ay), (bx, by) in zip(m, m[1:]):
            if ax == bx and ay == by:
                continue
            segs.append((ax, ay, bx, by))
            seg_dir.append(rd)
    stats["segmenti_in"] = len(segs)
    if not segs:
        return [], (None if directions is None else []), stats

    # 2) indice a griglia delle bbox dei segmenti
    cell = 25.0
    grid = {}
    for i, (ax, ay, bx, by) in enumerate(segs):
        x0, x1 = sorted((ax, bx))
        y0, y1 = sorted((ay, by))
        for gx in range(int(x0 // cell), int(x1 // cell) + 1):
            for gy in range(int(y0 // cell), int(y1 // cell) + 1):
                grid.setdefault((gx, gy), []).append(i)

    # 3) per ogni segmento raccogli i parametri di split (t interni)
    splits = [set() for _ in segs]
    n = len(segs)
    checked = set()
    for i, (ax, ay, bx, by) in enumerate(segs):
        if is_canceled and i % 256 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and i % 512 == 0:
            progress(int(60 * i / n))
        x0, x1 = sorted((ax, bx))
        y0, y1 = sorted((ay, by))
        cand = set()
        for gx in range(int(x0 // cell), int(x1 // cell) + 1):
            for gy in range(int(y0 // cell), int(y1 // cell) + 1):
                cand.update(grid.get((gx, gy), ()))
        for j in cand:
            if j <= i:
                continue
            key = (i, j)
            if key in checked:
                continue
            checked.add(key)
            cx, cy, ddx, ddy = segs[j]
            r = _seg_intersection(ax, ay, bx, by, cx, cy, ddx, ddy)
            if r is None:
                continue
            t, u = r
            hit = False
            if 1e-6 < t < 1 - 1e-6:
                splits[i].add(t)
                hit = True
            if 1e-6 < u < 1 - 1e-6:
                splits[j].add(u)
                hit = True
            if hit:
                stats["intersezioni"] += 1

    # 4) spezza i segmenti ai punti di split (lon/lat) e conta gli split
    out_roads = []
    out_dirs = []
    n_split = 0
    for i, (ax, ay, bx, by) in enumerate(segs):
        ts = sorted(splits[i])
        if ts:
            n_split += len(ts)
        params = [0.0] + ts + [1.0]
        for ta, tb in zip(params, params[1:]):
            pax, pay = ax + (bx - ax) * ta, ay + (by - ay) * ta
            pbx, pby = ax + (bx - ax) * tb, ay + (by - ay) * tb
            out_roads.append([to_ll(pax, pay), to_ll(pbx, pby)])
            out_dirs.append(seg_dir[i])
    stats["split"] = n_split
    if progress:
        progress(75)

    # 5) snap finale + rimozione nulli/duplicati (riusa net_clean)
    cleaned, cdirs, cstats = net_clean.clean_network(
        out_roads, snap_tol_m, out_dirs if directions is not None else None)
    stats["segmenti_out"] = cstats["segmenti_out"]
    stats["nulli"] = cstats["nulli"]
    stats["duplicati"] = cstats["duplicati"]
    stats["nodi"] = cstats["nodi"]
    if progress:
        progress(100)
    return cleaned, cdirs, stats


def find_unresolved_crossings(roads_lonlat, max_report=500):
    """Punti dove due segmenti si incrociano nell'INTERNO di entrambi (cioè
    senza un vertice condiviso): sono gli incroci da nodare.

    :return: lista di (lat, lon).
    """
    polys = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    if not polys:
        return []
    lat0 = polys[0][0][1]
    to_m, to_ll = _projector(lat0)
    segs = []
    for road in polys:
        m = [to_m(lon, lat) for lon, lat in road]
        for (ax, ay), (bx, by) in zip(m, m[1:]):
            if (ax, ay) != (bx, by):
                segs.append((ax, ay, bx, by))
    cell = 25.0
    grid = {}
    for i, (ax, ay, bx, by) in enumerate(segs):
        x0, x1 = sorted((ax, bx))
        y0, y1 = sorted((ay, by))
        for gx in range(int(x0 // cell), int(x1 // cell) + 1):
            for gy in range(int(y0 // cell), int(y1 // cell) + 1):
                grid.setdefault((gx, gy), []).append(i)
    seen = set()
    out = []
    checked = set()
    for i, (ax, ay, bx, by) in enumerate(segs):
        x0, x1 = sorted((ax, bx))
        y0, y1 = sorted((ay, by))
        cand = set()
        for gx in range(int(x0 // cell), int(x1 // cell) + 1):
            for gy in range(int(y0 // cell), int(y1 // cell) + 1):
                cand.update(grid.get((gx, gy), ()))
        for j in cand:
            if j <= i or (i, j) in checked:
                continue
            checked.add((i, j))
            cx, cy, dx, dy = segs[j]
            r = _seg_intersection(ax, ay, bx, by, cx, cy, dx, dy)
            if r is None:
                continue
            t, u = r
            if 1e-6 < t < 1 - 1e-6 and 1e-6 < u < 1 - 1e-6:
                px, py = ax + (bx - ax) * t, ay + (by - ay) * t
                k = (round(px, 1), round(py, 1))
                if k in seen:
                    continue
                seen.add(k)
                lon, lat = to_ll(px, py)
                out.append((lat, lon))
                if len(out) >= max_report:
                    return out
    return out


def prepare_summary(stats):
    return ("rete preparata: %d segmenti (noding: %d split su %d intersezioni; "
            "−%d nulli, −%d duplicati), %d nodi"
            % (stats.get("segmenti_out", 0), stats.get("split", 0),
               stats.get("intersezioni", 0), stats.get("nulli", 0),
               stats.get("duplicati", 0), stats.get("nodi", 0)))
