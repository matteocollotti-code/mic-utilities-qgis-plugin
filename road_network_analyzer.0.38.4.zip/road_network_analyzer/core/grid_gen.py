# -*- coding: utf-8 -*-
"""Generazione di griglie regolari (esagonali o quadrate) per l'analisi."""
import math


def build_grid(lat0, lat1, lon0, lon1, cell_m, shape="hex"):
    """Genera una griglia che copre il riquadro [lat0,lat1] x [lon0,lon1].

    :param cell_m: dimensione cella in metri (circumraggio per gli esagoni,
        lato per i quadrati).
    :param shape: "hex" o "square".
    :return: (centroids, cells) con
        centroids = [(lat, lon), ...] (per l'analisi)
        cells     = [[(lat, lon), ...], ...] (anelli poligonali)
    """
    if lat1 < lat0:
        lat0, lat1 = lat1, lat0
    if lon1 < lon0:
        lon0, lon1 = lon1, lon0
    mlat = 111000.0
    mlon = 111000.0 * math.cos(math.radians((lat0 + lat1) / 2.0))
    centroids = []
    cells = []
    s = float(cell_m)

    if shape == "square":
        ny = int((lat1 - lat0) * mlat / s) + 1
        nx = int((lon1 - lon0) * mlon / s) + 1
        for iy in range(ny):
            for ix in range(nx):
                cx = lon0 * mlon + (ix + 0.5) * s
                cy = lat0 * mlat + (iy + 0.5) * s
                clon, clat = cx / mlon, cy / mlat
                ring = [
                    ((cx - s / 2) / mlon, (cy - s / 2) / mlat),
                    ((cx + s / 2) / mlon, (cy - s / 2) / mlat),
                    ((cx + s / 2) / mlon, (cy + s / 2) / mlat),
                    ((cx - s / 2) / mlon, (cy + s / 2) / mlat),
                ]
                centroids.append((clat, clon))
                cells.append([(la, lo) for lo, la in ring])
        return centroids, cells

    # esagoni pointy-top
    dx = math.sqrt(3) * s
    dy = 1.5 * s
    row = 0
    y = lat0 * mlat
    while y < lat1 * mlat:
        x0 = lon0 * mlon + (dx / 2 if row % 2 else 0)
        x = x0
        while x < lon1 * mlon:
            clat, clon = y / mlat, x / mlon
            ring = []
            for k in range(6):
                ang = math.radians(60 * k - 30)
                vx = (x + s * math.cos(ang)) / mlon
                vy = (y + s * math.sin(ang)) / mlat
                ring.append((vy, vx))
            centroids.append((clat, clon))
            cells.append(ring)
            x += dx
        row += 1
        y += dy
    return centroids, cells
