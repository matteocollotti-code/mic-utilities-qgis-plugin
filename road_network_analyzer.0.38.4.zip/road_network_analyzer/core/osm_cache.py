# -*- coding: utf-8 -*-
"""Cache locale dei download OSM (rete, attraversamenti).

Evita di riscaricare lo stesso bbox/modo: i risultati grezzi (le tuple prodotte
da osm_download.fetch_*) sono salvati come JSON in una cartella nel profilo QGIS.
"""
import os
import json
import time
import hashlib

QUERY_VERSION = 1


def _cache_dir():
    try:
        from qgis.core import QgsApplication
        base = QgsApplication.qgisSettingsDirPath()
    except Exception:
        import tempfile
        base = tempfile.gettempdir()
    d = os.path.join(base, "MIC-Utilities", "osm_cache")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def cache_key(bbox, mode, kind):
    s, w, n, e = [round(float(x), 4) for x in bbox]
    raw = "%s|%s|%.4f,%.4f,%.4f,%.4f|v%d" % (kind, mode, s, w, n, e,
                                             QUERY_VERSION)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def _path(kind, key):
    return os.path.join(_cache_dir(), "%s_%s.json" % (kind, key))


def get_cached(kind, bbox, mode, max_age_days=30):
    """Ritorna il payload in cache (dict con 'features') o None."""
    p = _path(kind, cache_key(bbox, mode, kind))
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as fh:
            data = json.load(fh)
        if time.time() - data.get("ts", 0) > max_age_days * 86400:
            return None
        return data
    except Exception:
        return None


def put_cached(kind, bbox, mode, features, extra=None):
    p = _path(kind, cache_key(bbox, mode, kind))
    payload = {"ts": time.time(), "bbox": [float(x) for x in bbox],
               "mode": mode, "kind": kind, "count": len(features),
               "query_version": QUERY_VERSION, "features": features}
    if extra:
        payload.update(extra)
    try:
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(payload, fh)
    except Exception:
        pass
    return p


def _presets_path():
    return os.path.join(_cache_dir(), "presets.json")


def list_presets():
    """Lista dei preset salvati: [{name, bbox:[s,w,n,e], mode}]."""
    p = _presets_path()
    if not os.path.exists(p):
        return []
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return []


def save_preset(name, bbox, mode="all"):
    """Salva/aggiorna un preset area+modo."""
    presets = [x for x in list_presets() if x.get("name") != name]
    presets.append({"name": name, "bbox": [float(b) for b in bbox],
                    "mode": mode})
    try:
        with open(_presets_path(), "w", encoding="utf-8") as fh:
            json.dump(presets, fh)
    except Exception:
        pass
    return presets


def delete_preset(name):
    presets = [x for x in list_presets() if x.get("name") != name]
    try:
        with open(_presets_path(), "w", encoding="utf-8") as fh:
            json.dump(presets, fh)
    except Exception:
        pass
    return presets


def clear_cache():
    """Svuota la cache; ritorna il numero di file rimossi."""
    d = _cache_dir()
    n = 0
    for f in os.listdir(d):
        if f.endswith(".json"):
            try:
                os.remove(os.path.join(d, f))
                n += 1
            except Exception:
                pass
    return n
