# -*- coding: utf-8 -*-
"""Costruzione di layer QGIS per la rete preparata e la diagnostica.

Solo creazione/stile di layer dai risultati dei core (network_prepare,
network_diagnostics). Nessuna logica di analisi qui.
"""
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsPointXY,
    QgsRendererCategory,
    QgsSymbol,
    QgsVectorLayer,
    QgsWkbTypes,
)

from . import style_util


def build_prepared_layer(segments, directions=None,
                         name="MIC - Rete preparata"):
    """Layer di linee (EPSG:4326) dalla rete preparata (noded/snap).

    Campi: oneway (−1/0/1) e mic_prepared=1.
    """
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("oneway", QVariant.Int),
        QgsField("mic_prepared", QVariant.Int),
    ])
    layer.updateFields()
    feats = []
    for i, seg in enumerate(segments):
        d = directions[i] if directions and i < len(directions) else 0
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY(
            [QgsPointXY(lo, la) for lo, la in seg]))
        f.setAttributes([int(d), 1])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    return layer


# ---------------------------------------------------------------- diagnostica
_SEV_COLOR = {"error": "#d73027", "warning": "#fc8d59", "info": "#4575b4"}


def build_components_layer(segments, comp_of_seg, main_comp,
                           name="MIC diagnostic - componenti"):
    """Linee colorate per componente connessa; la principale in verde."""
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("component", QVariant.Int),
        QgsField("main_comp", QVariant.Int),
    ])
    layer.updateFields()
    feats = []
    comps = set()
    for seg, comp in zip(segments, comp_of_seg):
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY(
            [QgsPointXY(lo, la) for lo, la in seg]))
        f.setAttributes([int(comp), 1 if comp == main_comp else 0])
        feats.append(f)
        comps.add(comp)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    # stile: principale verde, le altre con colori ciclici
    palette = ["#7b3294", "#e66101", "#1b9e77", "#d95f02", "#7570b3",
               "#e7298a", "#66a61e", "#a6761d"]
    cats = []
    for c in sorted(comps):
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        if c == main_comp:
            sym.setColor(QColor("#1a9850"))
            sym.setWidth(0.6)
            lbl = "principale"
        else:
            sym.setColor(QColor(palette[c % len(palette)]))
            lbl = "componente %d" % c
        cats.append(QgsRendererCategory(int(c), sym, lbl))
    layer.setRenderer(QgsCategorizedSymbolRenderer("component", cats))
    return layer


def build_points_diag_layer(points, name, extra_fields=None):
    """Punti diagnostici con campi liberi.

    :param points: lista di (lat, lon, attrs_dict).
    :param extra_fields: lista di (nome, QVariant.type).
    """
    layer = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    fields = QgsFields()
    for nm, typ in (extra_fields or []):
        fields.append(QgsField(nm, typ))
    layer.dataProvider().addAttributes(fields)
    layer.updateFields()
    feats = []
    names = [f.name() for f in layer.fields()]
    for la, lo, attrs in points:
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lo, la)))
        f.setAttributes([attrs.get(nm) for nm in names])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    return layer


def build_scenario_layer(origins_layer, rows, name="MIC scenario A/B (delta)"):
    """Copia le origini con a_value/b_value/delta/delta_pct/classe.

    Salta le origini con geometria vuota per restare allineate a `rows`.
    """
    wkb = QgsWkbTypes.displayString(origins_layer.wkbType()) or "Point"
    layer = QgsVectorLayer("%s?crs=%s" % (wkb, origins_layer.crs().authid()),
                           name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("a_value", QVariant.Double),
        QgsField("b_value", QVariant.Double),
        QgsField("delta", QVariant.Double),
        QgsField("delta_pct", QVariant.Double),
        QgsField("classe", QVariant.String),
    ])
    layer.updateFields()
    feats = []
    it = iter(rows)
    for src in origins_layer.getFeatures():
        g = src.geometry()
        if g is None or g.isEmpty():
            continue
        r = next(it, None)
        if r is None:
            break
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        f.setAttributes([r["a"], r["b"], r["delta"], r["delta_pct"],
                         r["classe"]])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    values = [f["delta"] for f in layer.getFeatures() if f["delta"] is not None]
    n = min(7, len(set(values)))
    if n >= 1:
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        ramp = QgsGradientColorRamp(QColor(202, 0, 32), QColor(5, 113, 176))
        r = style_util.graduated_from(layer, "delta", n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer


def build_summary_table(issues, name="MIC diagnostic - sintesi"):
    """Tabella senza geometria dei problemi diagnostici."""
    layer = QgsVectorLayer("None", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("code", QVariant.String),
        QgsField("severity", QVariant.String),
        QgsField("message", QVariant.String),
        QgsField("count", QVariant.Int),
    ])
    layer.updateFields()
    feats = []
    for it in issues:
        f = QgsFeature(layer.fields())
        f.setAttributes([it.get("code", ""), it.get("severity", ""),
                         it.get("message", ""), int(it.get("count", 0))])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    return layer
