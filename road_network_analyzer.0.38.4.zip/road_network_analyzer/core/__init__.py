# -*- coding: utf-8 -*-
"""Logica di analisi (priva di GUI) del plugin Analizzatore Rete Stradale."""
