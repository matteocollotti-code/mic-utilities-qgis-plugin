# -*- coding: utf-8 -*-
"""Isocrona di trasporto pubblico (Connection Scan Algorithm) sul GTFS.

Da una sorgente e un orario di partenza calcola le fermate raggiungibili entro
un budget di tempo combinando: cammino di accesso alle fermate, viaggi in
mezzo (orari GTFS) e trasbordi a piedi. L'area e' l'unione dei bacini pedonali
attorno alle fermate raggiunte, con il tempo residuo.
"""
import math
from collections import defaultdict


def _haversine(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def _to_sec(series):
    import pandas as pd
    parts = series.str.split(":", expand=True)
    if parts.shape[1] < 3:
        return pd.Series([float("nan")] * len(series), index=series.index)
    return (pd.to_numeric(parts[0], errors="coerce") * 3600
            + pd.to_numeric(parts[1], errors="coerce") * 60
            + pd.to_numeric(parts[2], errors="coerce"))


def prepare_transit(source_path, start_h, budget_min, walk_speed_kmh=4.8,
                    transfer_m=200.0, service_date=None, progress=None,
                    is_canceled=None):
    """Legge il GTFS UNA volta e prepara i dati per il CSA (riusabili da più
    sorgenti). Restituisce un dict opaco da passare a `reach_from`.

    Questo evita di rileggere stops/trips/stop_times per ogni origine.
    """
    import os
    import zipfile
    import pandas as pd
    from . import gtfs_static as gs

    start_s = float(start_h) * 3600.0
    end_s = start_s + float(budget_min) * 60.0
    walk_mps = walk_speed_kmh * 1000.0 / 3600.0

    stops = gs._read_table(source_path, "stops.txt")
    stops_xy = {}
    for r in stops.itertuples(index=False):
        try:
            stops_xy[r.stop_id] = (float(r.stop_lat), float(r.stop_lon))
        except (TypeError, ValueError):
            continue

    trips = gs._read_subset(source_path, "trips.txt", ["trip_id", "service_id"])
    if trips is not None and not trips.empty:
        trips, _desc = gs.select_trips(trips, source_path, service_date)
        allowed = set(trips["trip_id"])
    else:
        allowed = set()

    st_cols = gs._table_columns(source_path, "stop_times.txt")
    use = [c for c in ["trip_id", "stop_id", "stop_sequence",
                       "arrival_time", "departure_time"] if c in st_cols]
    kept = []

    def _consume(reader):
        for chunk in reader:
            chunk = chunk[chunk["trip_id"].isin(allowed)]
            if chunk.empty:
                continue
            dep = _to_sec(chunk["departure_time"])
            arr = _to_sec(chunk["arrival_time"]) if "arrival_time" in chunk else dep
            mask = (dep >= start_s - 600) & (dep <= end_s)
            chunk = chunk[mask]
            if chunk.empty:
                continue
            kept.append(pd.DataFrame({
                "trip": chunk["trip_id"].values,
                "stop": chunk["stop_id"].values,
                "seq": pd.to_numeric(chunk["stop_sequence"], errors="coerce").values,
                "arr": arr[mask].values,
                "dep": dep[mask].values,
            }))

    if os.path.isdir(source_path):
        path = os.path.join(source_path, "stop_times.txt")
        _consume(pd.read_csv(path, dtype=str, keep_default_na=False,
                             usecols=use, chunksize=400000))
    else:
        with zipfile.ZipFile(source_path) as zf:
            with zf.open("stop_times.txt") as fh:
                _consume(pd.read_csv(fh, dtype=str, keep_default_na=False,
                                     usecols=use, chunksize=400000))
    if progress:
        progress(60)

    connections = []
    if kept:
        df = pd.concat(kept, ignore_index=True).dropna(subset=["seq", "dep", "arr"])
        df = df.sort_values(["trip", "seq"])
        g = df.groupby("trip", sort=False)
        df["to_stop"] = g["stop"].shift(-1)
        df["to_arr"] = g["arr"].shift(-1)
        conn = df.dropna(subset=["to_stop"])
        conn = conn[conn["to_arr"] > conn["dep"]]
        connections = list(zip(conn["dep"].values, conn["stop"].values,
                               conn["to_arr"].values, conn["to_stop"].values))
        connections.sort(key=lambda c: c[0])

    grid = defaultdict(list)
    cell = transfer_m / 111000.0
    # in longitudine un grado e' piu' corto (cos lat): cella piu' ampia in
    # gradi, altrimenti fermate a < transfer_m in direzione E-O cadono a due
    # celle di distanza e il trasbordo non viene trovato
    lat_ref = max((abs(la) for la, _lo in stops_xy.values()), default=0.0)
    cell_lon = cell / max(0.05, math.cos(math.radians(lat_ref)))
    for sid, (la, lo) in stops_xy.items():
        grid[(round(la / cell), round(lo / cell_lon))].append(sid)
    if progress:
        progress(100)
    return {"connections": connections, "stops_xy": stops_xy, "grid": grid,
            "cell": cell, "cell_lon": cell_lon, "transfer_m": transfer_m,
            "walk_mps": walk_mps, "walk_speed_kmh": walk_speed_kmh,
            "start_s": start_s, "end_s": end_s}


def reach_from(data, source_latlon, access_speed_kmh=None, egress_speed_kmh=None,
               max_access_m=800.0, transfer_penalty_s=0.0):
    """CSA earliest-arrival da una sorgente, usando i dati di `prepare_transit`.

    :return: (earliest, stops_xy, start_s, egress_mps).
    """
    stops_xy = data["stops_xy"]
    grid = data["grid"]
    cell = data["cell"]
    cell_lon = data.get("cell_lon", cell)
    transfer_m = data["transfer_m"]
    walk_mps = data["walk_mps"]
    start_s = data["start_s"]
    end_s = data["end_s"]
    base_kmh = data["walk_speed_kmh"]
    access_mps = (access_speed_kmh or base_kmh) * 1000.0 / 3600.0
    egress_mps = (egress_speed_kmh or base_kmh) * 1000.0 / 3600.0
    slat, slon = source_latlon

    def neighbors(sid):
        la, lo = stops_xy[sid]
        gi, gj = round(la / cell), round(lo / cell_lon)
        out = []
        for di in (-1, 0, 1):
            for dj in (-1, 0, 1):
                for other in grid.get((gi + di, gj + dj), ()):
                    if other == sid:
                        continue
                    d = _haversine(la, lo, *stops_xy[other])
                    if d <= transfer_m:
                        out.append((other, d / walk_mps))
        return out

    INF = float("inf")
    earliest = defaultdict(lambda: INF)
    for sid, (la, lo) in stops_xy.items():
        d = _haversine(slat, slon, la, lo)
        if d <= max_access_m:
            t = start_s + d / access_mps
            if t < earliest[sid]:
                earliest[sid] = t

    def relax_footpaths(sid):
        base = earliest[sid]
        for other, wt in neighbors(sid):
            nt = base + wt + transfer_penalty_s
            if nt < earliest[other] and nt <= end_s:
                earliest[other] = nt

    for sid in list(earliest.keys()):
        relax_footpaths(sid)
    for dep, dstop, arr, astop in data["connections"]:
        if dep > end_s:
            break
        if earliest[dstop] <= dep and arr < earliest[astop] and arr <= end_s:
            earliest[astop] = arr
            relax_footpaths(astop)
    return dict(earliest), stops_xy, start_s, egress_mps


def compute_transit_reach(source_path, source_latlon, start_h, budget_min,
                          walk_speed_kmh, transfer_m=200.0, max_access_m=800.0,
                          access_speed_kmh=None, egress_speed_kmh=None,
                          transfer_penalty_s=0.0, service_date=None,
                          progress=None, is_canceled=None):
    """Wrapper a singola sorgente: prepare_transit + reach_from."""
    data = prepare_transit(source_path, start_h, budget_min, walk_speed_kmh,
                           transfer_m, service_date, progress, is_canceled)
    if is_canceled and is_canceled():
        from .gtfs_static import GtfsCancelled
        raise GtfsCancelled()
    return reach_from(data, source_latlon, access_speed_kmh, egress_speed_kmh,
                      max_access_m, transfer_penalty_s)


def egress_budgets(results, sources_latlon, t_min):
    """Sorgenti con budget per l'egress su rete pedonale (compute_union_reach).

    Per ogni sorgente: il cammino diretto dall'origine e ogni fermata
    raggiunta entro t_min, con il tempo residuo convertito in metri.

    :param results: lista allineata alle sorgenti di risultati `reach_from`.
    :return: lista di (lat, lon, budget_m).
    """
    out = []
    for src, (earliest, stops_xy, start_s, egress_mps) in zip(sources_latlon,
                                                               results):
        out.append((src[0], src[1], t_min * 60.0 * egress_mps))
        limit = start_s + t_min * 60.0
        for sid, ta in earliest.items():
            if ta <= limit:
                la, lo = stops_xy[sid]
                out.append((la, lo, (limit - ta) * egress_mps))
    return out


def transit_circles_for_band(earliest, stops_xy, start_s, walk_mps,
                             source_latlon, t_min, max_access_m=800.0):
    """Bacini pedonali (lat, lon, radius_m) raggiungibili entro t_min."""
    limit = start_s + float(t_min) * 60.0
    out = [(source_latlon[0], source_latlon[1],
            min(float(t_min) * 60.0 * walk_mps, max_access_m))]
    for sid, t in earliest.items():
        if t > limit:
            continue
        rem = limit - t
        if rem <= 0:
            continue
        la, lo = stops_xy[sid]
        out.append((la, lo, min(rem * walk_mps, max_access_m)))
    return out
