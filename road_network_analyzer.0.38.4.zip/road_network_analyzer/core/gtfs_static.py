# -*- coding: utf-8 -*-
"""Lettura del GTFS statico e calcolo delle metriche programmate.

Costruisce:
  * geometrie delle linee dalle shapes;
  * segmenti stop-to-stop con lunghezza, tempo e velocita' programmati;
  * metriche di linea (velocita' commerciale e di esercizio, sosta media).

Usa pandas (disponibile nel Python di QGIS) per join e aggregazioni.
Le distanze sono misurate in modo ellissoidale su WGS84.
"""
import os
import zipfile

try:  # pandas è opzionale: serve solo alle funzioni GTFS
    import pandas as pd
except ImportError:  # pragma: no cover
    pd = None

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsDistanceArea,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsUnitTypes,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


class GtfsCancelled(Exception):
    """Sollevata quando l'utente annulla il caricamento in background."""


def _geod():
    da = QgsDistanceArea()
    da.setSourceCrs(WGS84, QgsProject.instance().transformContext())
    da.setEllipsoid("WGS84")
    return da


def _require_pandas():
    if pd is None:
        raise RuntimeError(
            "Le funzioni GTFS richiedono il modulo 'pandas', non installato nel "
            "Python di QGIS. Installalo dalla OSGeo4W Shell: "
            "python -m pip install pandas.")


def _read_table(source, name, usecols=None, dtype=str):
    """Legge una tabella GTFS da cartella o zip; None se assente."""
    _require_pandas()
    kwargs = dict(dtype=dtype, keep_default_na=False, usecols=usecols)
    if os.path.isdir(source):
        path = os.path.join(source, name)
        if not os.path.exists(path):
            return None
        return pd.read_csv(path, **kwargs)
    with zipfile.ZipFile(source) as zf:
        if name not in zf.namelist():
            return None
        with zf.open(name) as fh:
            return pd.read_csv(fh, **kwargs)


def _table_columns(source, name):
    """Colonne presenti in una tabella GTFS senza caricarne i dati."""
    _require_pandas()
    if os.path.isdir(source):
        path = os.path.join(source, name)
        if not os.path.exists(path):
            return None
        return list(pd.read_csv(path, nrows=0).columns)
    with zipfile.ZipFile(source) as zf:
        if name not in zf.namelist():
            return None
        with zf.open(name) as fh:
            return list(pd.read_csv(fh, nrows=0).columns)


def _read_subset(source, name, needed):
    """Legge solo le colonne richieste (se presenti) per ridurre la memoria."""
    cols = _table_columns(source, name)
    if cols is None:
        return None
    use = [c for c in needed if c in cols]
    return _read_table(source, name, usecols=use or None)


def list_routes(source):
    """Elenco delle linee del feed (per il filtro pre-caricamento).

    Legge solo routes.txt (file piccolo): [{route_id, short_name, long_name}].
    """
    routes = _read_table(source, "routes.txt")
    if routes is None:
        return []
    out = []
    for r in routes.itertuples(index=False):
        out.append({
            "route_id": r.route_id,
            "short_name": getattr(r, "route_short_name", ""),
            "long_name": getattr(r, "route_long_name", ""),
        })
    out.sort(key=lambda d: (d["short_name"] or d["route_id"]))
    return out


_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday",
             "saturday", "sunday"]
REQUIRED_FILES = ["agency.txt", "stops.txt", "routes.txt", "trips.txt",
                  "stop_times.txt"]


def active_services(source, service_date):
    """Set di service_id attivi in una data (YYYYMMDD).

    Combina calendar.txt (giorno della settimana + intervallo di validità) e
    calendar_dates.txt (eccezioni: 1=aggiunto, 2=rimosso). Ritorna None se non
    c'è alcun calendario (il chiamante userà il giorno di servizio dominante).
    """
    import datetime
    s = str(service_date)
    if len(s) != 8 or not s.isdigit():
        return None
    try:
        d = datetime.date(int(s[0:4]), int(s[4:6]), int(s[6:8]))
    except ValueError:
        return None
    wcol = _WEEKDAYS[d.weekday()]
    cal = _read_table(source, "calendar.txt")
    cd = _read_table(source, "calendar_dates.txt")
    if (cal is None or cal.empty) and (cd is None or cd.empty):
        return None
    active = set()
    if cal is not None and not cal.empty and wcol in cal.columns:
        for r in cal.itertuples(index=False):
            if str(getattr(r, wcol, "0")) != "1":
                continue
            sd = str(getattr(r, "start_date", "") or "")
            ed = str(getattr(r, "end_date", "") or "")
            if (not sd or sd <= s) and (not ed or s <= ed):
                active.add(getattr(r, "service_id"))
    if cd is not None and not cd.empty and "date" in cd.columns:
        for r in cd.itertuples(index=False):
            if str(getattr(r, "date", "")) != s:
                continue
            sid = getattr(r, "service_id")
            et = str(getattr(r, "exception_type", ""))
            if et == "1":
                active.add(sid)
            elif et == "2":
                active.discard(sid)
    return active


def select_trips(trips, source, service_date=None):
    """Filtra il DataFrame trips per data reale (calendario) o giorno dominante.

    :return: (trips_filtrato, descrizione testuale del criterio).
    """
    if service_date:
        active = active_services(source, service_date)
        if active is not None and "service_id" in trips.columns:
            sub = trips[trips["service_id"].isin(active)]
            if not sub.empty:
                return sub, "data %s (%d servizi attivi)" % (
                    service_date, len(active))
    if "service_id" in trips.columns and not trips["service_id"].empty:
        dominant = trips["service_id"].value_counts().idxmax()
        return (trips[trips["service_id"] == dominant],
                "giorno di servizio dominante")
    return trips, "tutti i servizi"


def validate_feed(source):
    """Controlli base sul feed GTFS. Ritorna (ok, messaggi, info)."""
    msgs = []
    info = {}
    if os.path.isdir(source):
        present = set(os.listdir(source))
    else:
        try:
            with zipfile.ZipFile(source) as zf:
                present = set(zf.namelist())
        except Exception as exc:
            return False, ["Impossibile aprire il feed: %s" % exc], {}
    missing = [f for f in REQUIRED_FILES if f not in present]
    ok = not missing
    if missing:
        msgs.append("File richiesti mancanti: %s" % ", ".join(missing))
    has_cal = "calendar.txt" in present
    has_cd = "calendar_dates.txt" in present
    info["calendar"] = has_cal
    info["calendar_dates"] = has_cd
    if not has_cal and not has_cd:
        msgs.append("Né calendar.txt né calendar_dates.txt presenti: verrà "
                    "usato il giorno di servizio dominante.")
    cal = (_read_subset(source, "calendar.txt", ["start_date", "end_date"])
           if has_cal else None)
    if cal is not None and not cal.empty:
        try:
            info["date_min"] = min(cal["start_date"])
            info["date_max"] = max(cal["end_date"])
            msgs.append("Validità del servizio: %s – %s"
                        % (info["date_min"], info["date_max"]))
        except Exception:
            pass
    if ok and not missing:
        msgs.insert(0, "Feed valido (file richiesti presenti).")
    return ok, msgs, info


def _read_stop_times_filtered(source, use, allowed_trips, chunksize=400000):
    """Legge stop_times.txt a blocchi tenendo solo le righe dei trip ammessi.

    Tiene basso il picco di memoria: il file (anche centinaia di MB) viene
    letto a pezzi e di ciascuno si conserva solo il sottoinsieme filtrato.
    """
    frames = []

    def _consume(reader):
        for chunk in reader:
            sub = chunk[chunk["trip_id"].isin(allowed_trips)]
            if not sub.empty:
                frames.append(sub)

    if os.path.isdir(source):
        path = os.path.join(source, "stop_times.txt")
        _consume(pd.read_csv(path, dtype=str, keep_default_na=False,
                             usecols=use, chunksize=chunksize))
    else:
        with zipfile.ZipFile(source) as zf:
            with zf.open("stop_times.txt") as fh:
                _consume(pd.read_csv(fh, dtype=str, keep_default_na=False,
                                     usecols=use, chunksize=chunksize))
    if frames:
        return pd.concat(frames, ignore_index=True)
    return pd.DataFrame(columns=use)


def _time_to_seconds(value):
    """HH:MM:SS -> secondi (ammette ore >= 24); None se non valido."""
    if not value or value.count(":") != 2:
        return None
    try:
        h, m, s = value.split(":")
        return int(h) * 3600 + int(m) * 60 + int(s)
    except ValueError:
        return None


# ----------------------------------------------------------------- geometrie
def build_shapes(source):
    """{shape_id: [(lat, lon, dist|None), ...]} ordinato per sequenza."""
    shapes = _read_table(source, "shapes.txt")
    out = {}
    if shapes is None or shapes.empty:
        return out
    has_dist = "shape_dist_traveled" in shapes.columns
    shapes = shapes.copy()
    shapes["seq"] = pd.to_numeric(shapes["shape_pt_sequence"], errors="coerce")
    shapes["lat"] = pd.to_numeric(shapes["shape_pt_lat"], errors="coerce")
    shapes["lon"] = pd.to_numeric(shapes["shape_pt_lon"], errors="coerce")
    if has_dist:
        shapes["dist"] = pd.to_numeric(shapes["shape_dist_traveled"], errors="coerce")
    for sid, grp in shapes.groupby("shape_id"):
        grp = grp.sort_values("seq")
        if has_dist:
            out[sid] = list(zip(grp["lat"], grp["lon"],
                                [d if pd.notna(d) else None for d in grp["dist"]]))
        else:
            out[sid] = [(la, lo, None) for la, lo in zip(grp["lat"], grp["lon"])]
    return out


def _cut_shape(points, d0, d1):
    """Sotto-polilinea della shape tra le distanze d0 e d1 (interpola i capi).

    :return: lista di (lat, lon) oppure None se le distanze non sono usabili.
    """
    dists = [p[2] for p in points]
    if any(d is None for d in dists) or d0 is None or d1 is None:
        return None
    if d1 < d0:
        d0, d1 = d1, d0

    def interp(d):
        if d <= dists[0]:
            return points[0][0], points[0][1]
        if d >= dists[-1]:
            return points[-1][0], points[-1][1]
        for i in range(len(points) - 1):
            a, b = points[i], points[i + 1]
            if a[2] <= d <= b[2]:
                if b[2] == a[2]:
                    return a[0], a[1]
                t = (d - a[2]) / (b[2] - a[2])
                return a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])
        return points[-1][0], points[-1][1]

    coords = [interp(d0)]
    coords.extend((p[0], p[1]) for p in points if d0 < p[2] < d1)
    coords.append(interp(d1))
    return coords


def _geodesic_length(coords_latlon, da):
    """Lunghezza ellissoidale (m) di una polilinea [(lat, lon), ...]."""
    pts = [QgsPointXY(lon, lat) for lat, lon in coords_latlon]
    if len(pts) < 2:
        return 0.0
    return da.convertLengthMeasurement(
        da.measureLength(QgsGeometry.fromPolylineXY(pts)),
        QgsUnitTypes.DistanceMeters,
    )


# ------------------------------------------------------------------ pipeline
def analyze_static(source, route_ids=None, progress=None, is_canceled=None):
    """Analizza un feed GTFS (cartella o zip) e restituisce le strutture base.

    :param route_ids: se valorizzato, limita l'analisi a queste linee (route_id).
        Riduce drasticamente la memoria: stop_times viene letto a blocchi
        tenendo solo le corse delle linee scelte.
    :param progress: callable(pct 0-100) opzionale per il progresso.
    :param is_canceled: callable() -> bool opzionale per l'annullamento.
    :return: dict con chiavi
        routes, stops, shapes_geom, segments, trip_index, shape_routes,
        line_metrics, line_hourly_sched
    """
    def _progress(pct):
        if progress:
            progress(pct)

    def _check():
        if is_canceled and is_canceled():
            raise GtfsCancelled()

    da = _geod()
    routes = _read_table(source, "routes.txt")
    trips = _read_subset(source, "trips.txt",
                         ["trip_id", "route_id", "direction_id", "shape_id"])
    stops = _read_table(source, "stops.txt")
    if trips is None or stops is None:
        raise ValueError("Feed GTFS incompleto: servono trips.txt, "
                         "stop_times.txt e stops.txt.")

    # filtro per linea (riduce drasticamente i dati da elaborare)
    allowed_trips = None
    if route_ids:
        wanted = set(route_ids)
        trips = trips[trips["route_id"].isin(wanted)].copy()
        allowed_trips = set(trips["trip_id"])
        if not allowed_trips:
            raise ValueError("Nessuna corsa per le linee selezionate.")

    st_need = ["trip_id", "arrival_time", "departure_time",
               "stop_id", "stop_sequence", "shape_dist_traveled"]
    st_cols = _table_columns(source, "stop_times.txt")
    if st_cols is None:
        raise ValueError("Feed GTFS incompleto: manca stop_times.txt.")
    use = [c for c in st_need if c in st_cols]
    if allowed_trips is not None:
        # lettura a blocchi filtrata: poca memoria
        stop_times = _read_stop_times_filtered(source, use, allowed_trips)
    else:
        # dtype compatti: category sulle colonne ad alta ripetizione
        cat = {c: "category" for c in use
               if c in ("trip_id", "stop_id", "arrival_time",
                        "departure_time", "stop_sequence")}
        stop_times = _read_table(source, "stop_times.txt", usecols=use,
                                 dtype=cat or str)
    _check()
    _progress(15)

    shapes_geom = build_shapes(source)
    _check()
    _progress(25)

    # mappa fermate
    stops = stops.copy()
    stops["lat"] = pd.to_numeric(stops["stop_lat"], errors="coerce")
    stops["lon"] = pd.to_numeric(stops["stop_lon"], errors="coerce")
    name_col = "stop_name" if "stop_name" in stops.columns else "stop_id"
    stops_map = {r.stop_id: (r.lat, r.lon, getattr(r, name_col))
                 for r in stops.itertuples(index=False)}

    # mappe trip -> route/direction/shape (evita un merge pesante su milioni
    # di righe; le colonne risultanti restano compatte come category)
    if "direction_id" not in trips.columns:
        trips = trips.assign(direction_id="0")
    if "shape_id" not in trips.columns:
        trips = trips.assign(shape_id="")
    route_map = dict(zip(trips["trip_id"], trips["route_id"]))
    dir_map = dict(zip(trips["trip_id"], trips["direction_id"].astype(str)))
    shape_map = dict(zip(trips["trip_id"], trips["shape_id"]))

    # converte subito in dtype compatti (la sorgente e' category/str)
    st = stop_times
    st["seq"] = pd.to_numeric(st["stop_sequence"], errors="coerce").astype("float32")
    st["arr_s"] = st["arrival_time"].map(_time_to_seconds).astype("float32")
    st["dep_s"] = st["departure_time"].map(_time_to_seconds).astype("float32")
    if "shape_dist_traveled" in st.columns:
        st["sdt"] = pd.to_numeric(
            st["shape_dist_traveled"], errors="coerce").astype("float32")
    else:
        st["sdt"] = pd.Series(float("nan"), index=st.index, dtype="float32")
    st["route_id"] = st["trip_id"].map(route_map).astype("category")
    st["direction_id"] = st["trip_id"].map(dir_map).astype("category")
    st["shape_id"] = st["trip_id"].map(shape_map).astype("category")
    st = st[["trip_id", "stop_id", "seq", "arr_s", "dep_s", "sdt",
             "route_id", "direction_id", "shape_id"]].copy()
    del stop_times
    st = st.sort_values(["trip_id", "seq"])

    # coppie di fermate consecutive (shift dentro ogni trip)
    grp = st.groupby("trip_id", sort=False, observed=True)
    st["to_stop"] = grp["stop_id"].shift(-1)
    st["to_arr_s"] = grp["arr_s"].shift(-1)
    st["to_sdt"] = grp["sdt"].shift(-1)
    seg = st.dropna(subset=["to_stop"]).copy()
    seg["travel_s"] = seg["to_arr_s"] - seg["dep_s"]
    seg = seg[seg["travel_s"] > 0]
    del st, grp
    _check()
    _progress(45)

    trip_index = {r.trip_id: (r.route_id, str(r.direction_id))
                  for r in trips.itertuples(index=False)}

    # mappa shape -> route (per costruire il layer delle linee)
    shape_routes = {}
    for r in trips.itertuples(index=False):
        if r.shape_id and r.shape_id not in shape_routes:
            shape_routes[r.shape_id] = (r.route_id, str(r.direction_id))

    # con il filtro per linea, tieni solo le shape delle linee scelte
    if route_ids:
        shapes_geom = {sid: pts for sid, pts in shapes_geom.items()
                       if sid in shape_routes}

    routes_map = {}
    if routes is not None:
        rcols = routes.set_index("route_id")
        for rid, row in rcols.iterrows():
            routes_map[rid] = {
                "short_name": row.get("route_short_name", ""),
                "long_name": row.get("route_long_name", ""),
                "route_type": row.get("route_type", ""),
            }

    # ---- segmenti unici (route, direction, from_stop, to_stop) ----
    segments = {}
    seg["key"] = list(zip(seg["route_id"], seg["direction_id"].astype(str),
                          seg["stop_id"], seg["to_stop"]))
    agg = seg.groupby("key").agg(
        sched_time_s=("travel_s", "mean"),
        sched_time_std=("travel_s", "std"),
        n_trips=("travel_s", "count"),
        shape_id=("shape_id", "first"),
        sdt=("sdt", "first"),
        to_sdt=("to_sdt", "first"),
    )
    seg_len = {}
    n_seg = len(agg)
    for idx, (key, row) in enumerate(agg.iterrows()):
        if idx % 2000 == 0:
            _check()
            _progress(45 + int(45 * idx / n_seg) if n_seg else 90)
        route_id, direction_id, from_stop, to_stop = key
        coords = None
        shape_pts = shapes_geom.get(row["shape_id"])
        if shape_pts is not None:
            coords = _cut_shape(shape_pts, row["sdt"], row["to_sdt"])
        if coords is None:
            a = stops_map.get(from_stop)
            b = stops_map.get(to_stop)
            if a and b and pd.notna(a[0]) and pd.notna(b[0]):
                coords = [(a[0], a[1]), (b[0], b[1])]
            else:
                continue
        length_m = _geodesic_length(coords, da)
        if length_m <= 0:
            continue
        sched_time = float(row["sched_time_s"])
        seg_len[key] = length_m
        segments[key] = {
            "route_id": route_id,
            "direction_id": direction_id,
            "from_stop": from_stop,
            "to_stop": to_stop,
            "from_name": stops_map.get(from_stop, ("", "", from_stop))[2],
            "to_name": stops_map.get(to_stop, ("", "", to_stop))[2],
            "route_short_name": routes_map.get(route_id, {}).get("short_name", ""),
            "length_m": length_m,
            "sched_time_s": sched_time,
            "sched_speed_kmh": length_m / sched_time * 3.6 if sched_time > 0 else 0.0,
            "n_trips": int(row["n_trips"]),
            "coords": coords,
        }

    # ---- metriche di linea (commerciale / esercizio) ----
    seg["seg_len"] = seg["key"].map(seg_len)
    seg = seg.dropna(subset=["seg_len"])
    trip_stats = seg.groupby(["route_id", "direction_id", "trip_id"]).agg(
        total_len=("seg_len", "sum"),
        running_time=("travel_s", "sum"),
        first_dep=("dep_s", "min"),
        last_arr=("to_arr_s", "max"),
    ).reset_index()
    trip_stats["total_time"] = trip_stats["last_arr"] - trip_stats["first_dep"]
    trip_stats = trip_stats[(trip_stats["total_time"] > 0) &
                            (trip_stats["running_time"] > 0)]
    trip_stats["commercial_kmh"] = trip_stats["total_len"] / trip_stats["total_time"] * 3.6
    trip_stats["running_kmh"] = trip_stats["total_len"] / trip_stats["running_time"] * 3.6
    trip_stats["dwell_s"] = trip_stats["total_time"] - trip_stats["running_time"]

    line_metrics = {}
    for (rid, direction), grp2 in trip_stats.groupby(["route_id", "direction_id"]):
        line_metrics[(rid, str(direction))] = {
            "route_id": rid,
            "direction_id": str(direction),
            "route_short_name": routes_map.get(rid, {}).get("short_name", ""),
            "n_trips": int(len(grp2)),
            "mean_length_m": float(grp2["total_len"].mean()),
            "commercial_speed_kmh": float(grp2["commercial_kmh"].mean()),
            "running_speed_kmh": float(grp2["running_kmh"].mean()),
            "mean_dwell_s": float(grp2["dwell_s"].mean()),
        }

    # ---- velocita' programmata per linea e per ora di partenza ----
    # Definizione space-mean (sum lunghezze / sum tempi di percorrenza) per
    # confrontabilita' con l'osservato ricavato dai segmenti RT.
    ts = trip_stats.copy()
    ts["hour"] = (ts["first_dep"] // 3600 % 24).astype(int)
    line_hourly_sched = {}
    grp_h = ts.groupby(["route_id", "direction_id", "hour"]).agg(
        len_sum=("total_len", "sum"), time_sum=("running_time", "sum"))
    for (rid, direction, hour), row in grp_h.iterrows():
        if row["time_sum"] <= 0:
            continue
        speed = row["len_sum"] / row["time_sum"] * 3.6
        line_hourly_sched.setdefault((rid, str(direction)), {})[int(hour)] = speed
    _progress(100)

    return {
        "routes": routes_map,
        "stops": stops_map,
        "shapes_geom": shapes_geom,
        "segments": segments,
        "trip_index": trip_index,
        "shape_routes": shape_routes,
        "line_metrics": line_metrics,
        "line_hourly_sched": line_hourly_sched,
    }
