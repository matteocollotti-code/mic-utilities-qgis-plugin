# -*- coding: utf-8 -*-
"""Funzioni di analisi della rete stradale.

Tutte pure rispetto alla GUI: operano su QgsVectorLayer e restituiscono
strutture Python semplici, cosi da poter essere riusate (es. in un
algoritmo Processing) e testate in isolamento dalla console QGIS.
"""
from collections import defaultdict

from qgis.core import (
    QgsDistanceArea,
    QgsProject,
    QgsSpatialIndex,
    QgsUnitTypes,
    QgsWkbTypes,
)

UNCLASSIFIED = "(non classificato)"


def distance_area(layer):
    """QgsDistanceArea configurato per misure ellissoidali in metri."""
    da = QgsDistanceArea()
    da.setSourceCrs(layer.crs(), QgsProject.instance().transformContext())
    ellipsoid = QgsProject.instance().ellipsoid()
    if not ellipsoid or ellipsoid == "NONE":
        ellipsoid = layer.crs().ellipsoidAcronym() or "WGS84"
    da.setEllipsoid(ellipsoid)
    return da


def type_value(feature, type_field):
    """Valore di tipologia normalizzato (gestisce NULL e stringhe vuote)."""
    if not type_field:
        return UNCLASSIFIED
    val = feature[type_field]
    if val is None:
        return UNCLASSIFIED
    if isinstance(val, str) and val.strip() == "":
        return UNCLASSIFIED
    return str(val)


def compute_lengths_by_type(layer, type_field, da=None):
    """Somma la lunghezza ellissoidale (metri) raggruppata per tipologia.

    :return: dict {tipologia: lunghezza_metri}
    """
    da = da or distance_area(layer)
    lengths = defaultdict(float)
    for feat in layer.getFeatures():
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        length_m = da.convertLengthMeasurement(
            da.measureLength(geom), QgsUnitTypes.DistanceMeters
        )
        lengths[type_value(feat, type_field)] += length_m
    return dict(lengths)


def compute_intersection_matrix(layer, type_field):
    """Conta gli incroci tra le strade per coppia di tipologie.

    Per ogni coppia di feature che si intersecano vengono contati i punti
    di intersezione e aggiunti alla cella (t1, t2) con t1 <= t2.

    :return: (types, matrix, unique_nodes)
        - types: lista ordinata delle tipologie presenti
        - matrix: dict {(t1, t2): n_incroci}
        - unique_nodes: numero di posizioni di intersezione distinte
    """
    feats = {f.id(): f for f in layer.getFeatures()}
    index = QgsSpatialIndex()
    for feat in feats.values():
        index.addFeature(feat)

    ndigits = 7 if layer.crs().isGeographic() else 2  # ~cm su CRS proiettati

    matrix = defaultdict(int)
    unique = set()
    all_types = set()

    for fid, feat in feats.items():
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        t1 = type_value(feat, type_field)
        all_types.add(t1)
        for cand_id in index.intersects(geom.boundingBox()):
            if cand_id <= fid:
                continue  # ogni coppia una sola volta, salta se stessa
            other = feats[cand_id]
            ogeom = other.geometry()
            if ogeom is None or ogeom.isEmpty() or not geom.intersects(ogeom):
                continue
            inter = geom.intersection(ogeom)
            if inter is None or inter.isEmpty():
                continue
            if inter.type() != QgsWkbTypes.PointGeometry:
                continue  # sovrapposizioni di segmenti: non sono incroci
            points = inter.asMultiPoint() if inter.isMultipart() else [inter.asPoint()]
            t2 = type_value(other, type_field)
            matrix[tuple(sorted((t1, t2)))] += len(points)
            for pt in points:
                unique.add((round(pt.x(), ndigits), round(pt.y(), ndigits)))

    return sorted(all_types), dict(matrix), len(unique)


def compute_area(layer, da=None):
    """Area ellissoidale totale (m2) di un layer poligonale."""
    if layer is None:
        return 0.0
    da = da or distance_area(layer)
    total = 0.0
    for feat in layer.getFeatures():
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        total += da.convertAreaMeasurement(
            da.measureArea(geom), QgsUnitTypes.AreaSquareMeters
        )
    return total


def compute_ratios(lengths_by_type, total_intersections, area_m2):
    """Rapporti sintetici a partire dai risultati precedenti."""
    total_length_m = sum(lengths_by_type.values())
    ratios = {
        "total_length_m": total_length_m,
        "total_length_km": total_length_m / 1000.0,
        "area_m2": area_m2,
        "area_km2": area_m2 / 1_000_000.0 if area_m2 else 0.0,
    }
    if area_m2 and area_m2 > 0:
        area_km2 = area_m2 / 1_000_000.0
        ratios["density_km_per_km2"] = (total_length_m / 1000.0) / area_km2
        ratios["intersection_density_per_km2"] = total_intersections / area_km2
    return ratios
