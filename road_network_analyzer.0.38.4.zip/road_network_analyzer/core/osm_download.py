# -*- coding: utf-8 -*-
"""Scarico della rete stradale (OSM/Overpass) per l'estensione corrente.

`fetch_ways` fa solo I/O di rete e parsing (sicuro in un QgsTask di background);
`build_roads_layer` crea il QgsVectorLayer e va chiamato sul thread principale.
"""

OVERPASS_URLS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
]

# Overpass rifiuta (HTTP 406) gli User-Agent generici: ne serve uno esplicito.
OVERPASS_HEADERS = {"User-Agent": "MIC-Utilities-QGIS/1.0 (QGIS plugin)"}

# tipi highway da ESCLUDERE per modo di trasporto (regex Overpass).
# pedonale: niente autostrade/superstrade; bici: anche niente scale/marciapiedi
# stretti; veicolare: niente percorsi pedonali/ciclabili.
MODE_EXCLUDE = {
    "pedestrian": "motorway|motorway_link|trunk|trunk_link",
    "bicycle": "motorway|motorway_link|trunk|trunk_link|footway|steps|corridor",
    "vehicular": "footway|path|pedestrian|steps|cycleway|bridleway|corridor",
}

MODE_LABEL = {
    "pedestrian": "pedonale",
    "bicycle": "ciclabile",
    "vehicular": "veicolare",
    "all": "completa",
}


def build_query(south, west, north, east, mode="all"):
    """Query Overpass: le way highway nell'inquadratura, filtrate per modo."""
    bbox = "%.6f,%.6f,%.6f,%.6f" % (south, west, north, east)
    excl = MODE_EXCLUDE.get(mode)
    if excl:
        sel = '(way["highway"]["highway"!~"%s"](%s););' % (excl, bbox)
    else:
        sel = '(way["highway"](%s););' % bbox
    return "[out:json][timeout:90];%sout geom;" % sel


def fetch_ways(south, west, north, east, mode="all",
               progress=None, is_canceled=None):
    """Interroga Overpass e restituisce [(osm_id, highway, name, [(lon,lat),...])].

    `mode` filtra i tipi di strada (pedestrian/bicycle/vehicular/all).
    Nessun oggetto QGIS qui dentro: e' sicuro eseguirlo in background.
    """
    import requests

    query = build_query(south, west, north, east, mode)
    if progress:
        progress(10)
    last_err = None
    data = None
    for url in OVERPASS_URLS:
        if is_canceled and is_canceled():
            return []
        try:
            resp = requests.post(url, data={"data": query},
                                 headers=OVERPASS_HEADERS, timeout=120)
            resp.raise_for_status()
            data = resp.json()
            break
        except Exception as exc:  # mirror server / timeout -> prova il prossimo
            last_err = exc
            data = None
    if data is None:
        raise RuntimeError("Overpass non raggiungibile: %s" % last_err)
    if progress:
        progress(70)

    ways = []
    for el in data.get("elements", []):
        if el.get("type") != "way":
            continue
        geom = el.get("geometry")
        if not geom or len(geom) < 2:
            continue
        coords = [(p["lon"], p["lat"]) for p in geom
                  if p.get("lon") is not None and p.get("lat") is not None]
        if len(coords) < 2:
            continue
        tags = el.get("tags", {})
        ways.append((el.get("id"), tags.get("highway", ""),
                     tags.get("name", ""), coords,
                     _oneway_value(tags.get("oneway", ""))))
    if progress:
        progress(100)
    return ways


def _oneway_value(raw):
    """Normalizza il tag oneway OSM: 1=avanti, -1=indietro, 0=doppio senso."""
    v = str(raw).strip().lower()
    if v in ("yes", "true", "1"):
        return 1
    if v in ("-1", "reverse"):
        return -1
    return 0


def fetch_crossings(south, west, north, east, progress=None, is_canceled=None):
    """Scarica gli attraversamenti pedonali (node highway=crossing) nel bbox.

    Ritorna [(osm_id, lon, lat), ...]. Solo I/O+parsing: sicuro in background.
    """
    import requests

    bbox = "%.6f,%.6f,%.6f,%.6f" % (south, west, north, east)
    query = ("[out:json][timeout:90];"
             '(node["highway"="crossing"](%s);'
             'node["footway"="crossing"](%s););out;' % (bbox, bbox))
    if progress:
        progress(10)
    last_err = None
    data = None
    for url in OVERPASS_URLS:
        if is_canceled and is_canceled():
            return []
        try:
            resp = requests.post(url, data={"data": query},
                                 headers=OVERPASS_HEADERS, timeout=120)
            resp.raise_for_status()
            data = resp.json()
            break
        except Exception as exc:
            last_err = exc
            data = None
    if data is None:
        raise RuntimeError("Overpass non raggiungibile: %s" % last_err)
    if progress:
        progress(80)
    out = []
    for el in data.get("elements", []):
        if el.get("type") != "node":
            continue
        lon, lat = el.get("lon"), el.get("lat")
        if lon is not None and lat is not None:
            out.append((el.get("id"), lon, lat))
    if progress:
        progress(100)
    return out


def build_points_layer(points, name="OSM - Attraversamenti"):
    """Memory layer di punti (EPSG:4326) da [(osm_id, lon, lat), ...]."""
    from qgis.core import (
        QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField,
    )
    from qgis.PyQt.QtCore import QVariant

    layer = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    dp = layer.dataProvider()
    dp.addAttributes([QgsField("osm_id", QVariant.LongLong)])
    layer.updateFields()
    feats = []
    for osm_id, lon, lat in points:
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        f.setAttributes([osm_id])
        feats.append(f)
    dp.addFeatures(feats)
    layer.updateExtents()
    return layer


def build_roads_layer(ways, name="OSM - Rete stradale"):
    """Costruisce un memory layer di linee (EPSG:4326) dalle way scaricate.

    Da chiamare sul thread principale.
    """
    from qgis.core import (
        QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField,
    )
    from qgis.PyQt.QtCore import QVariant

    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    dp = layer.dataProvider()
    dp.addAttributes([
        QgsField("osm_id", QVariant.LongLong),
        QgsField("highway", QVariant.String),
        QgsField("name", QVariant.String),
        QgsField("oneway", QVariant.Int),
    ])
    layer.updateFields()
    fields = layer.fields()
    feats = []
    for row in ways:
        osm_id, hw, nm, coords = row[0], row[1], row[2], row[3]
        oneway = row[4] if len(row) > 4 else 0
        f = QgsFeature(fields)
        f.setGeometry(QgsGeometry.fromPolylineXY(
            [QgsPointXY(x, y) for x, y in coords]))
        f.setAttributes([osm_id, hw, nm, oneway])
        feats.append(f)
    dp.addFeatures(feats)
    layer.updateExtents()
    return layer
