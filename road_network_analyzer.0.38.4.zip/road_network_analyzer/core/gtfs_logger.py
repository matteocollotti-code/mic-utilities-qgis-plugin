# -*- coding: utf-8 -*-
"""Logger GTFS-Realtime: polling periodico dei TripUpdates e accumulo.

Per ogni coppia di fermate consecutive osservata nei TripUpdates calcola il
tempo di percorrenza previsto e lo associa al segmento statico corrispondente.
Accumulando su molte corse e molti poll si ottiene una velocita' effettiva per
segmento (e relativo scarto rispetto al programmato).
"""
from collections import defaultdict

from qgis.core import QgsApplication
from qgis.PyQt.QtCore import QObject, QTimer, pyqtSignal

from .gtfs_tasks import GtfsPollTask


def _event_time(event):
    return event.get("time") if event else None


def _event_delay(event):
    return event.get("delay") if event else None


class GtfsRealtimeLogger(QObject):
    """Esegue il polling di un feed GTFS-RT TripUpdates e accumula osservazioni.

    Segnali:
        polled(int n_poll, int n_obs, str msg)
        failed(str msg)
    """

    polled = pyqtSignal(int, int, str)
    failed = pyqtSignal(str)

    def __init__(self, url, interval_s, static_result, parent=None):
        super().__init__(parent)
        self.url = url
        self.static = static_result
        self.segments = static_result["segments"]
        self.trip_index = static_result["trip_index"]
        # obs[seg_key][trip_uid] = {"travel_s": float, "delay": int|None}
        self.obs = defaultdict(dict)
        self.poll_count = 0
        self._active_task = None
        self.timer = QTimer(self)
        self.timer.setInterval(max(10, int(interval_s)) * 1000)
        self.timer.timeout.connect(self.poll_once)

    # -------------------------------------------------------------- controllo
    def start(self):
        self.poll_once()  # primo poll immediato
        self.timer.start()

    def stop(self):
        self.timer.stop()

    def is_running(self):
        return self.timer.isActive()

    # --------------------------------------------------------------- polling
    def poll_once(self):
        if self._active_task is not None:
            return  # poll precedente ancora in corso, salta questo tick
        task = GtfsPollTask(self.url)
        self._active_task = task
        task.taskCompleted.connect(lambda t=task: self._on_poll_done(t))
        task.taskTerminated.connect(lambda t=task: self._on_poll_failed(t))
        QgsApplication.taskManager().addTask(task)

    def _on_poll_done(self, task):
        # eseguito nel thread principale: ingest sicuro
        self._active_task = None
        added = self._ingest(task.trip_updates or [])
        self.poll_count += 1
        total = sum(len(v) for v in self.obs.values())
        self.polled.emit(self.poll_count, total,
                         "poll #%d: %d nuove osservazioni, %d segmenti coperti"
                         % (self.poll_count, added, len(self.obs)))

    def _on_poll_failed(self, task):
        self._active_task = None
        self.failed.emit(str(task.exception) if task.exception else "poll annullato")

    def _ingest(self, trip_updates):
        added = 0
        for tu in trip_updates:
            trip = tu.get("trip", {})
            trip_id = trip.get("trip_id")
            route_id = trip.get("route_id")
            direction = trip.get("direction_id")
            if route_id is None and trip_id in self.trip_index:
                route_id, direction = self.trip_index[trip_id]
            if direction is None and trip_id in self.trip_index:
                direction = self.trip_index[trip_id][1]
            if route_id is None:
                continue
            direction = str(direction if direction is not None else "0")
            trip_uid = (trip_id, trip.get("start_date", ""))

            stus = tu.get("stop_time_updates", [])
            for i in range(len(stus) - 1):
                a, b = stus[i], stus[i + 1]
                sa, sb = a.get("stop_sequence"), b.get("stop_sequence")
                if sa is not None and sb is not None and sb - sa != 1:
                    continue  # fermate non adiacenti
                from_stop, to_stop = a.get("stop_id"), b.get("stop_id")
                if not from_stop or not to_stop:
                    continue
                key = (route_id, direction, from_stop, to_stop)
                if key not in self.segments:
                    continue
                dep = _event_time(a.get("departure")) or _event_time(a.get("arrival"))
                arr = _event_time(b.get("arrival")) or _event_time(b.get("departure"))
                if dep is None or arr is None:
                    continue
                travel = arr - dep
                if travel <= 0:
                    continue
                if trip_uid not in self.obs[key]:
                    added += 1
                self.obs[key][trip_uid] = {
                    "travel_s": float(travel),
                    "delay": _event_delay(b.get("arrival")),
                    "arr_time": arr,
                }
        return added

    # --------------------------------------------------------------- risultati
    def segment_results(self):
        """{seg_key: {eff_speed_kmh, dev_kmh, dev_pct, mean_delay_s, n_obs}}."""
        out = {}
        for key, trips in self.obs.items():
            seg = self.segments.get(key)
            if not seg or not trips:
                continue
            times = [o["travel_s"] for o in trips.values()]
            delays = [o["delay"] for o in trips.values() if o["delay"] is not None]
            mean_t = sum(times) / len(times)
            eff_speed = seg["length_m"] / mean_t * 3.6 if mean_t > 0 else 0.0
            sched = seg["sched_speed_kmh"]
            out[key] = {
                "eff_speed_kmh": eff_speed,
                "dev_kmh": eff_speed - sched,
                "dev_pct": (eff_speed - sched) / sched * 100 if sched > 0 else 0.0,
                "mean_delay_s": sum(delays) / len(delays) if delays else None,
                "n_obs": len(times),
            }
        return out

    def line_results(self):
        """Velocita' effettiva media per linea (pesata sulla lunghezza)."""
        seg_res = self.segment_results()
        acc = defaultdict(lambda: {"len": 0.0, "time": 0.0, "n": 0})
        for key, res in seg_res.items():
            seg = self.segments[key]
            rid, direction = key[0], key[1]
            eff = res["eff_speed_kmh"]
            if eff <= 0:
                continue
            a = acc[(rid, direction)]
            a["len"] += seg["length_m"]
            a["time"] += seg["length_m"] / (eff / 3.6)  # tempo effettivo
            a["n"] += 1
        out = {}
        for k, a in acc.items():
            if a["time"] > 0:
                out[k] = {
                    "eff_speed_kmh": a["len"] / a["time"] * 3.6,
                    "n_segments": a["n"],
                }
        return out

    def line_hourly(self):
        """Velocita' osservata per linea e per ora (space-mean sui segmenti).

        :return: {(route_id, direction): {hour: speed_kmh}}
        """
        from datetime import datetime
        acc = defaultdict(lambda: defaultdict(lambda: {"len": 0.0, "time": 0.0}))
        for key, trips in self.obs.items():
            seg = self.segments.get(key)
            if not seg:
                continue
            rid, direction = key[0], key[1]
            length = seg["length_m"]
            for o in trips.values():
                arr = o.get("arr_time")
                if not arr or o["travel_s"] <= 0:
                    continue
                hour = datetime.fromtimestamp(arr).hour
                cell = acc[(rid, direction)][hour]
                cell["len"] += length
                cell["time"] += o["travel_s"]
        out = {}
        for line_key, hours in acc.items():
            out[line_key] = {
                h: c["len"] / c["time"] * 3.6
                for h, c in hours.items() if c["time"] > 0
            }
        return out
