# -*- coding: utf-8 -*-
"""QgsTask per non bloccare la GUI di QGIS.

- GtfsLoadTask: esegue analyze_static() in un thread di lavoro (il GTFS di
  Roma ha stop_times.txt ~255 MB e richiede oltre un minuto).
- GtfsPollTask: scarica e decodifica un feed GTFS-RT in background; l'ingest
  nella struttura del logger avviene nel thread principale (slot collegato).
"""
try:  # requests è opzionale: serve a GTFS-RT e download OSM
    import requests
except ImportError:  # pragma: no cover
    requests = None

from qgis.core import QgsTask

from . import gtfs_static, gtfs_rt, map_matching, space_syntax

MESSAGE_CATEGORY = "AnalizzatoreReteStradale"


class GtfsLoadTask(QgsTask):
    """Carica e analizza un feed GTFS statico senza bloccare la GUI."""

    def __init__(self, source, route_ids=None):
        super().__init__("Caricamento GTFS statico", QgsTask.CanCancel)
        self.source = source
        self.route_ids = route_ids
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            self.result = gtfs_static.analyze_static(
                self.source,
                route_ids=self.route_ids,
                progress=self.setProgress,
                is_canceled=self.isCanceled,
            )
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:  # riportata nello slot finished
            self.exception = exc
            return False


class OsmRoadsTask(QgsTask):
    """Scarica la rete stradale OSM (Overpass) per un bbox, in background."""

    def __init__(self, bbox, mode="all", force=False):
        super().__init__("Download rete stradale OSM", QgsTask.CanCancel)
        self.bbox = bbox  # (south, west, north, east) in gradi WGS84
        self.mode = mode
        self.force = force
        self.from_cache = False
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            from . import osm_download, osm_cache
            if not self.force:
                c = osm_cache.get_cached("roads", self.bbox, self.mode)
                if c:
                    self.result = c["features"]
                    self.from_cache = True
                    self.setProgress(100)
                    return True
            self.result = osm_download.fetch_ways(
                *self.bbox, mode=self.mode, progress=self.setProgress,
                is_canceled=self.isCanceled)
            if self.isCanceled():
                self.cancelled = True
                return False
            osm_cache.put_cached("roads", self.bbox, self.mode, self.result)
            return True
        except Exception as exc:
            self.exception = exc
            return False


class OsmCrossingsTask(QgsTask):
    """Scarica gli attraversamenti pedonali OSM per un bbox, in background."""

    def __init__(self, bbox, force=False):
        super().__init__("Download attraversamenti OSM", QgsTask.CanCancel)
        self.bbox = bbox
        self.force = force
        self.from_cache = False
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            from . import osm_download, osm_cache
            if not self.force:
                c = osm_cache.get_cached("crossings", self.bbox, "all")
                if c:
                    self.result = c["features"]
                    self.from_cache = True
                    self.setProgress(100)
                    return True
            self.result = osm_download.fetch_crossings(
                *self.bbox, progress=self.setProgress,
                is_canceled=self.isCanceled)
            if self.isCanceled():
                self.cancelled = True
                return False
            osm_cache.put_cached("crossings", self.bbox, "all", self.result)
            return True
        except Exception as exc:
            self.exception = exc
            return False


class GtfsPollTask(QgsTask):
    """Scarica e decodifica un feed GTFS-RT TripUpdates (un singolo poll)."""

    def __init__(self, url, timeout=20):
        super().__init__("Poll GTFS-RT", QgsTask.CanCancel)
        self.url = url
        self.timeout = timeout
        self.trip_updates = None
        self.exception = None

    def run(self):
        try:
            if requests is None:
                raise RuntimeError("Il modulo 'requests' non è installato.")
            resp = requests.get(self.url, timeout=self.timeout)
            resp.raise_for_status()
            feed = gtfs_rt.parse_feed(resp.content)
            self.trip_updates = feed.get("trip_updates", [])
            return True
        except Exception as exc:
            self.exception = exc
            return False


class GtfsMatchTask(QgsTask):
    """Esegue il map-matching delle velocita' GTFS sulla rete stradale."""

    def __init__(self, segments, seg_eff, road_geoms, road_crs, transform_context,
                 tolerance_m, angle_tol_deg, spacing_m):
        super().__init__("Map-matching GTFS su rete stradale", QgsTask.CanCancel)
        self.segments = segments
        self.seg_eff = seg_eff
        self.road_geoms = road_geoms
        self.road_crs = road_crs
        self.transform_context = transform_context
        self.tolerance_m = tolerance_m
        self.angle_tol_deg = angle_tol_deg
        self.spacing_m = spacing_m
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            self.result = map_matching.match_gtfs_to_roads(
                self.segments, self.seg_eff, self.road_geoms, self.road_crs,
                self.transform_context, tolerance_m=self.tolerance_m,
                angle_tol_deg=self.angle_tol_deg, spacing_m=self.spacing_m,
                progress=self.setProgress, is_canceled=self.isCanceled)
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class SpaceSyntaxTask(QgsTask):
    """Calcola le metriche di space syntax su un'adiacenza precostruita."""

    def __init__(self, adjacency, radius=0):
        super().__init__("Space syntax", QgsTask.CanCancel)
        self.adjacency = adjacency
        self.radius = radius
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            self.result = space_syntax.compute_metrics(
                self.adjacency, radius=self.radius, progress=self.setProgress,
                is_canceled=self.isCanceled)
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class PtalTask(QgsTask):
    """Calcola le frequenze GTFS e il PTAL per i punti di analisi."""

    def __init__(self, source, points_latlon, params):
        super().__init__("PTAL", QgsTask.CanCancel)
        self.source = source
        self.points_latlon = points_latlon
        self.params = params
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import ptal
        try:
            roads = self.params.get("roads")
            # bands = lista di (label, start_h, end_h); default = fascia singola
            bands = self.params.get("bands") or [
                ("", self.params["start_h"], self.params["end_h"])]
            results = []
            nb = len(bands)
            for bi, (label, sh, eh) in enumerate(bands):
                base = int(100 * bi / nb)
                step = 100.0 / nb
                self.setProgress(base + int(step * 0.05))
                stop_routes, stops_xy = ptal.compute_stop_frequencies(
                    self.source, sh, eh,
                    service_date=self.params.get("service_date"))
                self.setProgress(base + int(step * 0.4))

                def _prog(p, base=base, step=step):
                    self.setProgress(base + int(step * (0.4 + 0.6 * p / 100.0)))

                if roads:
                    res = ptal.compute_ptal_network(
                        self.points_latlon, stop_routes, stops_xy, roads,
                        self.params, progress=_prog, is_canceled=self.isCanceled)
                else:
                    res = ptal.compute_ptal(
                        self.points_latlon, stop_routes, stops_xy, self.params,
                        progress=_prog, is_canceled=self.isCanceled)
                results.append((label, res))
            # risultato: lista di (label, results). Il primo e' il primario.
            self.result = results
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class GtfsIsoTask(QgsTask):
    """Isocrone in background: rete (net_iso) o trasporto pubblico (transit_iso).

    Con params["geom"] = {output_mode, access_m, dissolve, ctx} calcola nel
    worker anche le geometrie (buffer/unione, la parte pesante) in
    self.geoms; al main thread resta solo la creazione del layer.

    La rete può arrivare già pronta (params["roads"]) oppure come
    params["road"] = {source: QgsVectorLayerFeatureSource, crs, ctx, oneway}:
    allora lettura, pulizia, validazione e controllo di aggancio avvengono qui
    nel worker (su una rete grande richiedono secondi).
    """

    def __init__(self, mode, params):
        super().__init__("Isocrone", QgsTask.CanCancel)
        self.mode = mode
        self.params = params
        self.result = None
        self.n_snapped = None
        self.per_source = None
        self.geoms = None
        self.roads = None       # rete pulita letta nel task (per la cache)
        self.directions = None
        self.pre_msg = ""
        # fase corrente, letta dalla GUI per la barra di avanzamento
        self.phase = "avvio"
        self.exception = None
        self.cancelled = False

    def _stage(self, phase, lo, hi):
        """Imposta la fase e ritorna una callback progress 0-100 -> lo..hi."""
        self.phase = phase
        self.setProgress(lo)
        return lambda x: self.setProgress(lo + (hi - lo) * float(x) / 100.0)

    def _read_network(self, spec, preflight_coords=None, lo=1, hi=15):
        """Legge e pulisce la rete nel worker (avanzamento lo..hi). Solleva
        ValueError se la rete non è utilizzabile o se nessuna sorgente la
        aggancia."""
        from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform
        from . import net_iso, net_clean, network_diagnostics
        total = spec.get("count") or 0
        span = float(hi - lo)

        def on_read(n):
            # la fase mostra le strade lette: la barra non resta ferma
            if total > 0:
                self.phase = "lettura della rete (%d/%d strade)" % (n, total)
                self.setProgress(lo + 0.6 * span * min(1.0, n / float(total)))
            else:
                self.phase = "lettura della rete (%d strade)" % n
                self.setProgress(lo)

        self._stage("lettura della rete", lo, lo)
        ct = QgsCoordinateTransform(
            spec["crs"], QgsCoordinateReferenceSystem("EPSG:4326"), spec["ctx"])
        raw, rdirs = net_iso.read_roads(spec["source"].getFeatures(), ct,
                                        spec.get("oneway", False),
                                        progress=on_read,
                                        is_canceled=self.isCanceled)
        self._stage("pulizia della rete", lo + 0.6 * span, lo + 0.6 * span)
        roads, dirs, cstats = net_clean.clean_network(raw, 1.0, rdirs)
        ok, vmsg, _ = net_iso.validate_network(roads)
        if not ok:
            raise ValueError("Rete non valida: " + vmsg)
        if preflight_coords:
            self._stage("controllo aggancio delle sorgenti",
                        lo + 0.75 * span, lo + 0.75 * span)
            pf_ok, pf_msg = network_diagnostics.preflight(
                roads, dirs, preflight_coords)
            if not pf_ok:
                raise ValueError(pf_msg)
            self.pre_msg += pf_msg
        self.pre_msg += net_clean.clean_summary(cstats) + ". "
        self.roads, self.directions = roads, dirs
        return roads, dirs

    def run(self):
        try:
            p = self.params
            geom = p.get("geom")
            # fine del calcolo: il resto dell'avanzamento va alle geometrie
            top = 60 if geom else 100
            if self.mode == "net":
                from . import net_iso
                if "road" in p:
                    roads, dirs = self._read_network(p["road"], p["sources"],
                                                     1, 15)
                else:
                    roads, dirs = p["roads"], p.get("directions")
                if self.isCanceled():
                    self.cancelled = True
                    return False
                dissolve = bool(geom and geom.get("dissolve"))
                on_source = None
                if geom and not dissolve:
                    # sorgenti separate: poligoni subito, tratti scartati
                    # (memoria limitata a una sorgente alla volta)
                    from . import isochrones
                    self.geoms = []

                    def on_source(si, bands):
                        for t in sorted(bands, reverse=True):
                            g = isochrones._segments_to_geom(
                                bands[t], geom["output_mode"],
                                geom["access_m"], geom["ctx"],
                                is_canceled=self.isCanceled)
                            if g is not None:
                                self.geoms.append((si, t, g))
                self.result, self.n_snapped = net_iso.compute_reachable_segments(
                    roads, p["sources"], p["speed"], p["times"],
                    directions=dirs,
                    progress=self._stage(
                        "percorsi e poligoni per sorgente" if on_source
                        else "percorsi sulla rete", 15,
                        100 if on_source else top),
                    is_canceled=self.isCanceled, dissolve=dissolve,
                    on_source=on_source)
                if on_source:
                    # stesso ordine di band_geometries: fascia ampia prima
                    self.geoms.sort(key=lambda x: (-x[1], x[0]))
                else:
                    self.per_source = self.result
            else:
                from . import transit_iso
                max_t = max(p["times"])
                data = transit_iso.prepare_transit(
                    p["source_path"], p["start_h"], max_t, p["walk_speed"],
                    p.get("transfer_m", 200.0), p.get("service_date"),
                    progress=self._stage("lettura orari GTFS", 0,
                                         int(top * 0.5)),
                    is_canceled=self.isCanceled)
                out = []
                ns = len(p["sources"])
                prog = self._stage("trasporto pubblico (CSA)",
                                   int(top * 0.5), int(top * 0.8))
                for i, s in enumerate(p["sources"]):
                    if self.isCanceled():
                        self.cancelled = True
                        return False
                    prog(100.0 * i / ns)
                    out.append(transit_iso.reach_from(
                        data, s, access_speed_kmh=p.get("access_speed"),
                        egress_speed_kmh=p.get("egress_speed"),
                        max_access_m=p.get("max_access_m", 800.0),
                        transfer_penalty_s=p.get("transfer_penalty_s", 0.0)))
                self.result = out
                roads = p.get("egress_roads")
                if not roads and p.get("egress_road"):
                    roads, _dirs = self._read_network(
                        p["egress_road"], None, int(top * 0.8), int(top * 0.85))
                if roads:
                    # egress multimodale sulla rete pedonale (unione per fascia)
                    from . import net_iso
                    prog = self._stage("egress a piedi sulla rete",
                                       int(top * 0.85), top)
                    bands = {}
                    for k, t in enumerate(p["times"]):
                        if self.isCanceled():
                            self.cancelled = True
                            return False
                        bands[t] = net_iso.compute_union_reach(
                            roads, transit_iso.egress_budgets(
                                out, p["sources"], t))
                        prog(100.0 * (k + 1) / len(p["times"]))
                    self.per_source = [bands]
                elif geom:
                    # senza rete: bacini circolari attorno alle fermate
                    # raggiunte, uniti per fascia qui nel worker
                    from . import isochrones
                    per_band = {t: [] for t in p["times"]}
                    for src, res in zip(p["sources"], out):
                        earliest, stops_xy, start_s, egress_mps = res
                        for t in p["times"]:
                            per_band[t].extend(
                                transit_iso.transit_circles_for_band(
                                    earliest, stops_xy, start_s, egress_mps,
                                    src, t, p.get("egress_r", 800.0)))
                    self.geoms = isochrones.catchment_geoms(
                        [(t, per_band[t]) for t in p["times"]], geom["ctx"],
                        progress=self._stage("bacini attorno alle fermate",
                                             top, 100),
                        is_canceled=self.isCanceled)
            if geom and self.per_source is not None:
                from . import isochrones
                self.geoms = isochrones.band_geometries(
                    self.per_source, geom["output_mode"], geom["access_m"],
                    geom["dissolve"], geom["ctx"],
                    progress=self._stage("costruzione poligoni", top, 100),
                    is_canceled=self.isCanceled)
            self.phase = "fine"
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class AccessTask(QgsTask):
    """Accessibilita' cumulativa (rete o trasporto pubblico) in background."""

    def __init__(self, mode, params):
        super().__init__("Accessibilita", QgsTask.CanCancel)
        self.mode = mode
        self.params = params
        self.result = None
        self.times = None
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import accessibility as acc
        try:
            p = self.params
            if self.mode == "net":
                self.result, self.times = acc.accessibility_network(
                    p["origins"], p["dests"], p["roads"], p["speed"],
                    p["times"], directions=p.get("directions"),
                    progress=self.setProgress, is_canceled=self.isCanceled)
            else:
                self.result, self.times = acc.accessibility_transit(
                    p["origins"], p["dests"], p["source_path"], p["start_h"],
                    p["times"], p["walk_speed"], p.get("access_m", 800.0),
                    p.get("egress_m", 800.0),
                    access_speed_kmh=p.get("access_speed"),
                    egress_speed_kmh=p.get("egress_speed"),
                    transfer_penalty_s=p.get("transfer_penalty_s", 0.0),
                    service_date=p.get("service_date"),
                    progress=self.setProgress, is_canceled=self.isCanceled)
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class OdMatrixTask(QgsTask):
    """Matrice tempi OD via TP in background."""

    def __init__(self, zones, source_path, start_h, budget_min, walk_speed,
                 access_m=800.0, egress_m=800.0):
        super().__init__("Matrice OD TP", QgsTask.CanCancel)
        self.zones = zones
        self.source_path = source_path
        self.start_h = start_h
        self.budget_min = budget_min
        self.walk_speed = walk_speed
        self.access_m = access_m
        self.egress_m = egress_m
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import od_viz
        try:
            self.result = od_viz.compute_transit_od(
                self.zones, self.source_path, self.start_h, self.budget_min,
                self.walk_speed, self.access_m, self.egress_m,
                progress=self.setProgress, is_canceled=self.isCanceled)
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class ScenarioIsoTask(QgsTask):
    """Scenario isocrone A/B in background (calcolo geometrie, no layer).

    L'unione+buffer delle isocrone su due reti è pesante: si esegue nel worker
    e restituisce (ga, gb, n_snap_a, n_snap_b); il layer si costruisce poi sul
    thread principale via isochrones.build_isochrone_diff_layer.
    """

    def __init__(self, params):
        super().__init__("Scenario isocrone A/B", QgsTask.CanCancel)
        self.params = params
        self.geom_a = None
        self.geom_b = None
        self.n_snap_a = 0
        self.n_snap_b = 0
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import isochrones
        try:
            p = self.params
            ga, gb, na, nb = isochrones.isochrone_scenario_geoms(
                p["roads_a"], p["roads_b"], p["sources"], p["speed"],
                p["time_min"], access_m=p.get("access_m", 30.0),
                dir_a=p.get("dir_a"), dir_b=p.get("dir_b"),
                transform_context=p["ctx"],
                progress=self.setProgress, is_canceled=self.isCanceled)
            self.geom_a, self.geom_b = ga, gb
            self.n_snap_a, self.n_snap_b = na, nb
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False
