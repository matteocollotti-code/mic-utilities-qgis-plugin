# -*- coding: utf-8 -*-
"""Confronto di scenari: differenza tra due layer di risultati (B − A).

Tipico: PTAL/accessibilità calcolati su due feed GTFS (prima/dopo una modifica
al servizio). Allinea le feature per centroide più vicino e produce un layer con
val_a, val_b e delta, con stile divergente.
"""
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsSpatialIndex,
    QgsSymbol,
    QgsVectorLayer,
    QgsWkbTypes,
)

from . import style_util


def compute_difference(layer_a, field_a, layer_b, field_b, transform_context,
                       name="Confronto scenari (B − A)", max_dist_m=None):
    """Layer con la geometria di A e delta = B − A per feature corrispondente.

    L'abbinamento usa il centroide più vicino di B (assume griglie/punti
    sovrapponibili). Con `max_dist_m` le coppie più lontane di tale distanza non
    vengono abbinate (evita match errati tra layer non allineati).
    Ritorna (layer, n_abbinate, n_totali).
    """
    ct = QgsCoordinateTransform(layer_b.crs(), layer_a.crs(), transform_context)
    geographic = layer_a.crs().isGeographic()

    def _dist_m(p, q):
        if geographic:
            import math
            r = 6371000.0
            p1, p2 = math.radians(p.y()), math.radians(q.y())
            dphi = math.radians(q.y() - p.y())
            dl = math.radians(q.x() - p.x())
            a = (math.sin(dphi / 2) ** 2
                 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2)
            return 2 * r * math.asin(math.sqrt(a))
        return ((p.x() - q.x()) ** 2 + (p.y() - q.y()) ** 2) ** 0.5
    index = QgsSpatialIndex()
    b_vals = {}
    b_pts = {}
    for i, f in enumerate(layer_b.getFeatures()):
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        c = g.centroid()
        try:
            b_vals[i] = float(f[field_b])
        except (TypeError, ValueError):
            continue
        feat = QgsFeature(i)
        feat.setGeometry(c)
        b_pts[i] = c.asPoint()
        index.addFeature(feat)

    wkb = QgsWkbTypes.displayString(layer_a.wkbType()) or "Polygon"
    out = QgsVectorLayer("%s?crs=%s" % (wkb, layer_a.crs().authid()),
                         name, "memory")
    out.dataProvider().addAttributes([
        QgsField("val_a", QVariant.Double),
        QgsField("val_b", QVariant.Double),
        QgsField("delta", QVariant.Double),
    ])
    out.updateFields()
    feats = []
    matched = 0
    total = 0
    for f in layer_a.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        total += 1
        try:
            va = float(f[field_a])
        except (TypeError, ValueError):
            continue
        c = g.centroid().asPoint()
        near = index.nearestNeighbor(c, 1)
        if not near or near[0] not in b_vals:
            continue
        if max_dist_m and _dist_m(c, b_pts[near[0]]) > max_dist_m:
            continue
        vb = b_vals[near[0]]
        matched += 1
        nf = QgsFeature(out.fields())
        nf.setGeometry(g)
        nf.setAttributes([round(va, 3), round(vb, 3), round(vb - va, 3)])
        feats.append(nf)
    out.dataProvider().addFeatures(feats)
    out.updateExtents()
    _style_diverging(out, "delta")
    return out, matched, total


def _style_diverging(layer, field):
    values = [f[field] for f in layer.getFeatures() if f[field] is not None]
    if not values:
        return
    n = min(7, len(set(values)))
    if n < 1:
        return
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    # rosso (peggioramento) -> bianco -> blu (miglioramento)
    ramp = QgsGradientColorRamp(QColor(202, 0, 32), QColor(5, 113, 176))
    r = style_util.graduated_from(layer, field, n, symbol, ramp)
    if r and r.ranges():
        layer.setRenderer(r)
