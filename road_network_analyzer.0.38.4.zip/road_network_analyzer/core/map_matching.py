# -*- coding: utf-8 -*-
"""Map-matching delle velocita' GTFS sui segmenti della rete stradale.

Per ogni feature della rete stradale campiona punti lungo la geometria e cerca
i segmenti GTFS vicini entro una tolleranza e con direzione allineata (per non
agganciare strade perpendicolari). Alla strada vengono assegnate le velocita'
(programmata ed effettiva) dei segmenti di trasporto che la percorrono.

Tutto il calcolo avviene in un CRS metrico: si usa il CRS della rete stradale
se proiettato, altrimenti la zona UTM ricavata dall'estensione dei dati.
"""
import math

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsRectangle,
    QgsSpatialIndex,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


def _utm_crs_for(lon, lat):
    zone = int((lon + 180) / 6) + 1
    epsg = (32600 if lat >= 0 else 32700) + zone
    return QgsCoordinateReferenceSystem.fromEpsgId(epsg)


def _bearing(p1, p2):
    return math.degrees(math.atan2(p2.x() - p1.x(), p2.y() - p1.y())) % 360.0


def _angle_diff_undirected(a, b):
    d = abs(a - b) % 180.0
    return min(d, 180.0 - d)


def match_gtfs_to_roads(segments, seg_eff, road_geoms, road_crs, transform_context,
                        tolerance_m=20.0, angle_tol_deg=30.0, spacing_m=25.0,
                        progress=None, is_canceled=None):
    """Associa i segmenti GTFS alle feature stradali.

    :param segments: dict {seg_key: {coords (lat,lon), sched_speed_kmh,
                     route_short_name, route_id, ...}} dal GTFS statico.
    :param seg_eff:  dict {seg_key: {eff_speed_kmh, ...}} dal logger RT (o {}).
    :param road_geoms: lista [(fid, QgsGeometry)] nella CRS della rete stradale.
    :param road_crs: QgsCoordinateReferenceSystem della rete stradale.
    :param transform_context: QgsCoordinateTransformContext del progetto.
    :return: dict {fid: {v_sched, v_eff, dev, n_seg, n_routes, routes}}
    """
    def _progress(pct):
        if progress:
            progress(pct)

    def _check():
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()

    # --- CRS di lavoro (metrico) ---
    if road_crs.isGeographic():
        if road_geoms:
            c = road_geoms[0][1].boundingBox().center()
            work_crs = _utm_crs_for(c.x(), c.y())
        else:
            work_crs = _utm_crs_for(0, 0)
    else:
        work_crs = road_crs
    ct_gtfs = QgsCoordinateTransform(WGS84, work_crs, transform_context)
    ct_road = QgsCoordinateTransform(road_crs, work_crs, transform_context)

    # --- indice spaziale dei segmenti GTFS nel CRS di lavoro ---
    index = QgsSpatialIndex()
    gsegs = {}
    gid = 0
    for key, seg in segments.items():
        coords = seg.get("coords")
        if not coords or len(coords) < 2:
            continue
        g = QgsGeometry.fromPolylineXY([QgsPointXY(lon, lat) for lat, lon in coords])
        if g.transform(ct_gtfs) != 0:
            continue
        line = g.asPolyline()
        if len(line) < 2:
            continue
        f = QgsFeature(gid)
        f.setGeometry(g)
        index.addFeature(f)
        gsegs[gid] = {
            "geom": g,
            "line": line,
            "v_sched": seg.get("sched_speed_kmh", 0.0),
            "v_eff": seg_eff.get(key, {}).get("eff_speed_kmh"),
            "route": seg.get("route_short_name") or seg.get("route_id", ""),
        }
        gid += 1

    tol = float(tolerance_m)
    tol2 = tol * tol
    step = max(5.0, float(spacing_m))
    results = {}
    n_roads = len(road_geoms)

    for i, (fid, rgeom) in enumerate(road_geoms):
        if i % 200 == 0:
            _check()
            _progress(int(100 * i / n_roads) if n_roads else 100)
        g = QgsGeometry(rgeom)
        if g.transform(ct_road) != 0:
            continue
        length = g.length()
        if length <= 0:
            continue

        matched = {}
        d = 0.0
        while d <= length:
            pt = g.interpolate(d)
            if pt and not pt.isEmpty():
                p = pt.asPoint()
                nxt = g.interpolate(min(length, d + 5.0))
                rb = _bearing(p, nxt.asPoint()) if nxt and not nxt.isEmpty() else None
                rect = QgsRectangle(p.x() - tol, p.y() - tol, p.x() + tol, p.y() + tol)
                for cid in index.intersects(rect):
                    if cid in matched:
                        continue
                    cg = gsegs[cid]
                    sqdist, _near, after, _l = cg["geom"].closestSegmentWithContext(p)
                    if sqdist > tol2:
                        continue
                    line = cg["line"]
                    if 1 <= after < len(line):
                        gb = _bearing(line[after - 1], line[after])
                        if rb is None or _angle_diff_undirected(rb, gb) <= angle_tol_deg:
                            matched[cid] = True
            d += step

        if not matched:
            continue
        vs = [gsegs[c]["v_sched"] for c in matched]
        ve = [gsegs[c]["v_eff"] for c in matched if gsegs[c]["v_eff"] is not None]
        routes = sorted({gsegs[c]["route"] for c in matched})
        v_sched = sum(vs) / len(vs)
        v_eff = sum(ve) / len(ve) if ve else None
        results[fid] = {
            "v_sched": v_sched,
            "v_eff": v_eff,
            "dev": (v_eff - v_sched) if v_eff is not None else None,
            "n_seg": len(matched),
            "n_routes": len(routes),
            "routes": ",".join(routes),
        }
    _progress(100)
    return results
