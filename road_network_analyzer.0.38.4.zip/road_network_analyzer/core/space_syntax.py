# -*- coding: utf-8 -*-
"""Metriche di space syntax (segment analysis semplificata) sul grafo stradale.

Ogni tratto (feature lineare) e' un nodo; due tratti sono connessi se
condividono un estremo. Si calcolano connettivita', profondita' media,
integrazione (HH) e choice (betweenness). Il calcolo e' puro Python (nessun
oggetto QGIS) cosi' da poter girare in un QgsTask.
"""
import math
from collections import deque


def build_adjacency(line_layer, precision=6, snap_tol_m=1.0):
    """Costruisce l'adiacenza dei tratti dai loro estremi.

    Gli estremi vengono "puliti" con uno snap a `snap_tol_m` metri (così tratti
    che dovrebbero toccarsi ma differiscono per rumore di coordinate risultano
    connessi). Funziona sia con CRS geografici sia proiettati.

    :return: (fids, adjacency) con adjacency[i] = set di indici vicini.
    """
    import math
    geographic = line_layer.crs().isGeographic()
    cell = max(0.001, float(snap_tol_m))
    lat0 = line_layer.extent().center().y() if geographic else 0.0
    mlon = 111320.0 * math.cos(math.radians(lat0)) if geographic else 1.0
    mlat = 111320.0 if geographic else 1.0

    def snap(p):
        return (int(round(p.x() * mlon / cell)),
                int(round(p.y() * mlat / cell)))

    fids = []
    endpoints = []
    for f in line_layer.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        if g.isMultipart():
            parts = g.asMultiPolyline()
            if not parts:
                continue
            pts = parts[0] + parts[-1]
        else:
            pts = g.asPolyline()
        if len(pts) < 2:
            continue
        a = snap(pts[0])
        b = snap(pts[-1])
        fids.append(f.id())
        endpoints.append((a, b))

    coord_map = {}
    for idx, (a, b) in enumerate(endpoints):
        coord_map.setdefault(a, []).append(idx)
        coord_map.setdefault(b, []).append(idx)

    adjacency = [set() for _ in fids]
    for node_list in coord_map.values():
        if len(node_list) < 2:
            continue
        for i in node_list:
            for j in node_list:
                if i != j:
                    adjacency[i].add(j)
    return fids, [list(s) for s in adjacency]


def compute_metrics(adjacency, radius=0, progress=None, is_canceled=None):
    """Metriche di space syntax (globali con radius=0, locali con radius=n).

    :param radius: profondita' topologica massima (0 = globale, es. 3 = R3).
    :return: dict con liste allineate all'ordine dell'adiacenza:
        connectivity, mean_depth, total_depth, integration, choice,
        nain (integrazione normalizzata), nach (choice normalizzata).
    """
    n = len(adjacency)
    rmax = radius if radius and radius > 0 else None
    connectivity = [len(adjacency[i]) for i in range(n)]
    betweenness = [0.0] * n
    mean_depth = [0.0] * n
    total_depth = [0.0] * n
    node_count = [1] * n

    for s in range(n):
        if is_canceled and s % 64 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and s % 256 == 0 and n:
            progress(int(100 * s / n))

        stack = []
        pred = [[] for _ in range(n)]
        sigma = [0.0] * n
        dist = [-1] * n
        sigma[s] = 1.0
        dist[s] = 0
        queue = deque([s])
        while queue:
            v = queue.popleft()
            stack.append(v)
            dv = dist[v]
            if rmax is not None and dv >= rmax:
                continue  # non espandere oltre il raggio
            for w in adjacency[v]:
                if dist[w] < 0:
                    dist[w] = dv + 1
                    queue.append(w)
                if dist[w] == dv + 1:
                    sigma[w] += sigma[v]
                    pred[w].append(v)

        reach = [d for d in dist if d > 0]
        node_count[s] = len(reach) + 1
        total_depth[s] = float(sum(reach))
        mean_depth[s] = sum(reach) / len(reach) if reach else 0.0

        delta = [0.0] * n
        while stack:
            w = stack.pop()
            for v in pred[w]:
                delta[v] += (sigma[v] / sigma[w]) * (1.0 + delta[w])
            if w != s:
                betweenness[w] += delta[w]

    integration = [0.0] * n
    nain = [0.0] * n
    nach = [0.0] * n
    betweenness = [b / 2.0 for b in betweenness]  # non orientato
    for i in range(n):
        nn = node_count[i]
        if nn > 2 and mean_depth[i] > 0:
            ra = 2.0 * (mean_depth[i] - 1.0) / (nn - 2)
            dn = 2.0 * (nn * (math.log2((nn + 2) / 3.0) - 1.0) + 1.0) / \
                ((nn - 1) * (nn - 2))
            rra = ra / dn if dn > 0 else 0.0
            integration[i] = 1.0 / rra if rra > 0 else 0.0
        td = total_depth[i]
        if td > 0:
            nain[i] = (nn ** 1.2) / td
            nach[i] = math.log10(betweenness[i] + 1.0) / math.log10(td + 3.0)

    if progress:
        progress(100)
    return {
        "connectivity": connectivity,
        "mean_depth": mean_depth,
        "total_depth": total_depth,
        "integration": integration,
        "choice": betweenness,
        "nain": nain,
        "nach": nach,
    }
