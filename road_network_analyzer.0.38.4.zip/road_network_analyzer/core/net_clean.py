# -*- coding: utf-8 -*-
"""Pulizia/preparazione della rete stradale per le analisi su grafo.

Operazioni (v1, leggere e veloci):
- snap dei vertici vicini a una tolleranza (unisce estremi che dovrebbero
  coincidere ma differiscono per rumore di coordinate → migliora la
  connettività del grafo);
- rimozione dei segmenti di lunghezza nulla;
- rimozione dei segmenti duplicati (preservando i sensi unici).

Restituisce una lista di segmenti [[(lon,lat),(lon,lat)], ...], valida come
input per net_iso.build_metric_graph. Tutto in puro Python (thread-safe).

Raffinamenti futuri: noding alle intersezioni (split dei segmenti che si
incrociano senza condividere un vertice), aggancio dei tratti pendenti.
"""
import math


def clean_network(roads_lonlat, snap_tol_m=1.0, directions=None):
    """Pulisce la rete. Ritorna (segmenti, directions_out, stats).

    :param snap_tol_m: tolleranza di snap dei vertici (metri).
    :param directions: senso di marcia per polilinea (1/-1/0); se None,
        directions_out è None.
    :return: (segmenti lon/lat, directions allineate ai segmenti o None, stats).
    """
    polys = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    stats = {"segmenti_in": 0, "segmenti_out": 0, "nulli": 0,
             "duplicati": 0, "nodi": 0}
    if not polys:
        return [], (None if directions is None else []), stats

    lat0 = polys[0][0][1]
    mlat = 111320.0
    mlon = 111320.0 * math.cos(math.radians(lat0))
    cell = max(0.001, float(snap_tol_m))

    rep = {}

    def snap(pt):
        lon, lat = pt
        k = (int(round(lon * mlon / cell)), int(round(lat * mlat / cell)))
        if k not in rep:
            rep[k] = (lon, lat)
        return rep[k]

    out = []
    out_dirs = []
    seg_index = {}
    n_in = n_zero = n_dup = 0
    for ri, road in enumerate(polys):
        rd = directions[ri] if directions and ri < len(directions) else 0
        snapped = [snap(p) for p in road]
        for a, b in zip(snapped, snapped[1:]):
            n_in += 1
            if a == b:
                n_zero += 1
                continue
            uk = (a, b) if a <= b else (b, a)
            idx = seg_index.get(uk)
            if idx is not None:
                n_dup += 1
                ea, eb = out[idx][0], out[idx][1]
                # senso di questa occorrenza nell'orientamento esistente
                if a == ea and b == eb:
                    d_this = rd
                else:
                    d_this = -rd if rd in (1, -1) else 0
                if out_dirs[idx] != d_this:
                    out_dirs[idx] = 0  # sensi in conflitto → doppio senso
                continue
            seg_index[uk] = len(out)
            out.append([a, b])
            out_dirs.append(rd)

    stats.update({"segmenti_in": n_in, "segmenti_out": len(out),
                  "nulli": n_zero, "duplicati": n_dup, "nodi": len(rep)})
    return out, (None if directions is None else out_dirs), stats


def clean_summary(stats):
    """Riga di testo riassuntiva della pulizia."""
    return ("rete pulita: %d segmenti (−%d nulli, −%d duplicati), %d nodi"
            % (stats.get("segmenti_out", 0), stats.get("nulli", 0),
               stats.get("duplicati", 0), stats.get("nodi", 0)))
