# -*- coding: utf-8 -*-
"""Costruzione di un feed GTFS da un layer lineare con fermate.

Dato un layer di linee (le rotte) e un layer di punti (le fermate), genera un
feed GTFS minimale (agency, stops, routes, trips, stop_times, calendar,
shapes) chiedendo i parametri di servizio (velocita, frequenza, orari, sosta).
I tempi di percorrenza derivano dalla distanza lungo la linea / velocita.
"""
import csv
import io
import os
import zipfile

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGeometry,
    QgsPointXY,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


def _utm_crs_for(lon, lat):
    zone = int((lon + 180) / 6) + 1
    epsg = (32600 if lat >= 0 else 32700) + zone
    return QgsCoordinateReferenceSystem.fromEpsgId(epsg)


def _hhmmss(seconds):
    seconds = int(round(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return "%02d:%02d:%02d" % (h, m, s)


def build_gtfs_from_lines(line_layer, stops_layer, params, out_path,
                          transform_context):
    """Genera un feed GTFS (zip) da linee + fermate.

    params: dict con chiavi
        agency_name, route_type, speed_kmh, headway_min, start_h, end_h,
        dwell_s, snap_m, route_field (opz.), stop_name_field (opz.)
    :return: out_path
    """
    speed_mps = float(params["speed_kmh"]) * 1000.0 / 3600.0
    headway_s = float(params["headway_min"]) * 60.0
    start_s = float(params["start_h"]) * 3600.0
    end_s = float(params["end_h"]) * 3600.0
    dwell_s = float(params.get("dwell_s", 0))
    snap_m = float(params.get("snap_m", 50))
    route_type = str(params.get("route_type", "3"))
    route_field = params.get("route_field") or None
    stop_name_field = params.get("stop_name_field") or None
    if speed_mps <= 0 or headway_s <= 0 or end_s <= start_s:
        raise ValueError("Parametri non validi (velocita/frequenza/orari).")

    # estensione per la CRS metrica
    ext = line_layer.extent()
    c = ext.center()
    line_to_wgs = QgsCoordinateTransform(line_layer.crs(), WGS84, transform_context)
    cc = line_to_wgs.transform(c)
    utm = _utm_crs_for(cc.x(), cc.y())
    line_to_utm = QgsCoordinateTransform(line_layer.crs(), utm, transform_context)
    stop_to_utm = QgsCoordinateTransform(stops_layer.crs(), utm, transform_context)
    stop_to_wgs = QgsCoordinateTransform(stops_layer.crs(), WGS84, transform_context)
    utm_to_wgs = QgsCoordinateTransform(utm, WGS84, transform_context)

    # fermate: id, nome, geom (utm + wgs)
    stops = []
    for sf in stops_layer.getFeatures():
        g = sf.geometry()
        if g is None or g.isEmpty():
            continue
        gu = QgsGeometry(g)
        gu.transform(stop_to_utm)
        gw = QgsGeometry(g)
        gw.transform(stop_to_wgs)
        p = gw.asPoint()
        name = ""
        if stop_name_field and stop_name_field in stops_layer.fields().names():
            name = str(sf[stop_name_field])
        sid = "S%d" % sf.id()
        stops.append({"id": sid, "name": name or sid,
                      "lat": p.y(), "lon": p.x(), "utm": gu.asPoint()})

    stop_times_rows = []
    trips_rows = []
    routes_rows = []
    shapes_rows = []
    used_stop_ids = set()

    line_names = line_layer.fields().names()

    def _part_len(pp):
        return sum(((pp[i + 1].x() - pp[i].x()) ** 2
                    + (pp[i + 1].y() - pp[i].y()) ** 2) ** 0.5
                   for i in range(len(pp) - 1)) if len(pp) >= 2 else 0.0

    for idx, lf in enumerate(line_layer.getFeatures()):
        lg = lf.geometry()
        if lg is None or lg.isEmpty():
            continue
        lg_utm = QgsGeometry(lg)
        lg_utm.transform(line_to_utm)
        # multipart: usa la parte più lunga (evita shape vuote)
        if lg_utm.isMultipart():
            parts = lg_utm.asMultiPolyline()
            if not parts:
                continue
            longest = max(parts, key=_part_len)
            if len(longest) < 2:
                continue
            lg_utm = QgsGeometry.fromPolylineXY(longest)

        # ID univoci PER FEATURE (evita route/shape/trip duplicati)
        route_id = "R%d" % (idx + 1)
        shape_id = "shp_%d" % (idx + 1)
        if route_field and route_field in line_names:
            short_name = str(lf[route_field])
        else:
            short_name = route_id

        # ordina le fermate vicine alla linea per distanza lungo la linea
        along = []
        for st in stops:
            ptg = QgsGeometry.fromPointXY(st["utm"])
            if lg_utm.distance(ptg) > snap_m:
                continue
            d = lg_utm.lineLocatePoint(ptg)
            along.append((d, st))
        along.sort(key=lambda x: x[0])
        if len(along) < 2:
            continue
        # la route viene aggiunta SOLO ora (ha almeno 2 fermate -> avrà trips)
        routes_rows.append([route_id, "AG", short_name, "", route_type])

        # shape (vertici in WGS84 con distanza cumulata)
        line_pts = lg_utm.asPolyline()
        cum = 0.0
        prev = None
        for si, p in enumerate(line_pts):
            if prev is not None:
                cum += ((p.x() - prev.x()) ** 2 + (p.y() - prev.y()) ** 2) ** 0.5
            wp = utm_to_wgs.transform(p)
            shapes_rows.append([shape_id, "%.6f" % wp.y(), "%.6f" % wp.x(),
                                si + 1, "%.1f" % cum])
            prev = p

        # trips a frequenza costante
        n_trip = 0
        t0 = start_s
        while t0 <= end_s:
            trip_id = "%s_%05d" % (route_id, int(t0))
            trips_rows.append([route_id, "FULLW", trip_id, "0", shape_id])
            prev_d = along[0][0]
            dep = t0
            for seq, (d, st) in enumerate(along):
                if seq == 0:
                    arr = t0
                else:
                    arr = dep + (d - prev_d) / speed_mps
                departure = arr if seq == len(along) - 1 else arr + dwell_s
                stop_times_rows.append([
                    trip_id, _hhmmss(arr), _hhmmss(departure), st["id"],
                    seq + 1, "%.1f" % (d - along[0][0])])
                used_stop_ids.add(st["id"])
                prev_d = d
                dep = departure
            n_trip += 1
            t0 += headway_s

    if not trips_rows:
        raise ValueError("Nessuna corsa generata: controlla che le fermate "
                         "siano vicine alle linee (tolleranza snap).")

    # scrittura zip
    def _csv(header, rows):
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(header)
        w.writerows(rows)
        return buf.getvalue()

    stops_rows = [[s["id"], s["name"], "%.6f" % s["lat"], "%.6f" % s["lon"]]
                  for s in stops if s["id"] in used_stop_ids]

    files = {
        "agency.txt": _csv(
            ["agency_id", "agency_name", "agency_url", "agency_timezone"],
            [["AG", params.get("agency_name", "Agenzia"),
              "https://example.com", "Europe/Rome"]]),
        "stops.txt": _csv(
            ["stop_id", "stop_name", "stop_lat", "stop_lon"], stops_rows),
        "routes.txt": _csv(
            ["route_id", "agency_id", "route_short_name", "route_long_name",
             "route_type"], routes_rows),
        "calendar.txt": _csv(
            ["service_id", "monday", "tuesday", "wednesday", "thursday",
             "friday", "saturday", "sunday", "start_date", "end_date"],
            [["FULLW", "1", "1", "1", "1", "1", "1", "1",
              "20240101", "20271231"]]),
        "trips.txt": _csv(
            ["route_id", "service_id", "trip_id", "direction_id", "shape_id"],
            trips_rows),
        "stop_times.txt": _csv(
            ["trip_id", "arrival_time", "departure_time", "stop_id",
             "stop_sequence", "shape_dist_traveled"], stop_times_rows),
        "shapes.txt": _csv(
            ["shape_id", "shape_pt_lat", "shape_pt_lon", "shape_pt_sequence",
             "shape_dist_traveled"], shapes_rows),
    }
    if not out_path.lower().endswith(".zip"):
        out_path += ".zip"
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname, content in files.items():
            zf.writestr(fname, content)
    return out_path
