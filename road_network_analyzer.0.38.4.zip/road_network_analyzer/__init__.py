# -*- coding: utf-8 -*-
"""MIC - Utilities - QGIS plugin entry point.

Copyright (C) 2026 Matteo Collotti <matteo.collotti@gmail.com>

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details: see the
LICENSE file distributed with this plugin.

Il pacchetto include XlsxWriter (vendor/xlsxwriter, licenza BSD-2-Clause, vedi
vendor/xlsxwriter-3.2.9.dist-info/LICENSE.txt).

Il logo MIC Hub (icon.svg, icon.png) è un marchio di MIC Hub e non è coperto
dalla licenza GPL.
"""


def classFactory(iface):  # pylint: disable=invalid-name
    """Load RoadNetworkAnalyzer class.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .road_network_analyzer import RoadNetworkAnalyzer
    return RoadNetworkAnalyzer(iface)
