# -*- coding: utf-8 -*-
"""Testi di aiuto per ogni scheda.

Obiettivo: spiegare con chiarezza il SIGNIFICATO delle operazioni spaziali che
ogni funzione esegue (aggancio alla rete, distanze di rete, buffer, ecc.), non
solo l'elenco dei campi.
"""

# Nota condivisa sull'aggancio alla rete (riusata in più schede).
_SNAP = ("""
<p><b>Come vengono misurate le distanze sulla rete</b>: ogni punto (origine,
fermata, destinazione) viene <i>proiettato sull'arco stradale più vicino</i>
entro 500 m (non sul vertice più vicino, ma sul punto esatto del segmento). Da
lì il percorso più breve si calcola con l'algoritmo di Dijkstra sul grafo della
rete. Se due punti cadono sullo stesso arco la distanza è quella diretta lungo
l'arco. Un punto a più di 500 m da qualsiasi strada non viene agganciato e non
produce risultati: avvicinalo o usa una rete più fitta.</p>
""")

_OSM = ("""
<p><b>🌐 Rete da OSM (vista)</b>: scarica al volo da OpenStreetMap la rete
stradale contenuta nell'inquadratura corrente della mappa e la imposta in questo
campo. La rete è <i>filtrata per modo</i>: a piedi esclude autostrade/superstrade
e include marciapiedi/sentieri; in auto esclude i percorsi pedonali/ciclabili;
in bici una via di mezzo. Comodo quando non hai già un layer di strade.</p>
""")

HELP_TEXTS = {
    "road": ("Rete stradale · aiuto", """
<h3>Analisi della rete stradale</h3>
<p>Operazione spaziale: misura le lunghezze per tipologia e individua le
<b>intersezioni</b> come nodi condivisi tra archi (coppie di tipologie che si
toccano), poi rapporta tutto all'area di progetto.</p>
<ul>
<li><b>Rete stradale</b>: layer di linee da analizzare.</li>
<li><b>Campo tipologia</b>: classifica le strade (es. <i>highway</i>). Lunghezze
e matrice incroci sono raggruppate per questo campo.</li>
<li><b>Area di progetto</b>: poligono (opzionale) per le densità (km/km², n/km²);
le lunghezze sono ellissoidali (QgsDistanceArea).</li>
</ul>
""" + _OSM + """
<p>Output: tab Lunghezze, Matrice incroci, Rapporti (esportabili in CSV).</p>
<h4>Walkability index</h4>
<p>Indice 0-100 per <b>zona</b> (poligoni) o <b>griglia</b> automatica, da fino a
tre dimensioni (mediate):</p>
<ul>
<li><b>Design</b> (sempre): densità di incroci, densità stradale, link/nodi,
connettività media.</li>
<li><b>Destinazioni</b> (se dai un layer <b>POI</b>): amenità raggiungibili a
piedi con decadimento della distanza, <i>in linea d'aria</i> o <b>su rete</b>
(Dijkstra, opzione «Destinazioni su rete»); con un <i>campo categoria</i> premia
la diversità di servizi.</li>
<li><b>Pendenza</b> (se dai un <b>DEM</b>): grado medio delle strade; più ripido
= meno camminabile.</li>
<li><b>Attraversamenti</b> (se dai un layer di punti o usi «🌐 Attraversamenti
da OSM»): densità di attraversamenti pedonali per zona.</li>
</ul>
<p>Output: campi <i>walkability, design, destinazioni, pendenza, attraversam</i>
+ indicatori grezzi. Indice relativo (serve più di una zona). Raffinabile.</p>
<p><i>Pulizia rete:</i> tutte le analisi su rete stradale (isocrone,
accessibilità, PTAL su rete, space syntax, walkability) eseguono uno snap dei
vertici vicini e rimuovono segmenti nulli/duplicati per preparare il grafo.</p>
<h4>Preparazione & diagnostica rete</h4>
<ul>
<li><b>🔧 Prepara rete (noding)</b>: spezza le linee dove si incrociano senza un
vertice condiviso. <b>Indispensabile</b> se la rete non è già "noded": altrimenti
due strade che si incrociano restano scollegate nel grafo e isocrone/
accessibilità/PTAL risultano sottostimati. Apre una <b>procedura guidata</b> in 3
passi: (1) <i>diagnosi iniziale</i> della rete selezionata (segmenti, componenti,
incroci non noded); (2) <i>opzioni</i> (tolleranza snap, lunghezza minima,
noding); (3) <i>anteprima</i> con il numero di split e il miglioramento delle
componenti connesse, prima di applicare. Al termine imposta la rete preparata
come rete stradale corrente.</li>
<li><b>🩺 Diagnostica rete</b>: segnala componenti scollegate, % nella componente
principale, sorgenti non agganciate o isolate, e <b>incroci non noded</b>. Crea
layer diagnostici (componenti colorate, incroci, sorgenti isolate). Utile quando
un'analisi dà risultati nulli o strani.</li>
</ul>
"""),
    "gtfs": ("GTFS · aiuto", """
<h3>Caricamento GTFS e map-matching</h3>
<p>Il feed caricato qui è la <b>sorgente GTFS condivisa</b>: le schede PTAL,
Isochrones, Accessibilità e OD lo riusano senza doverlo reinserire.</p>
<ul>
<li><b>Percorso feed</b>: file .zip o cartella GTFS.</li>
<li><b>Linea</b> + <i>Leggi linee</i>: per feed grandi scegli una sola linea
(caricamento leggero). «Tutte le linee» richiede molta RAM.</li>
<li><b>Data servizio</b> (YYYYMMDD, opz.): seleziona i servizi attivi quel giorno
da <i>calendar.txt</i>/<i>calendar_dates.txt</i>; vuoto = giorno di servizio
dominante. Vale per PTAL, isocrone TP, accessibilità TP e matrice OD.</li>
<li><b>Valida feed</b>: controlla i file richiesti e la copertura del calendario.</li>
<li><b>Carica GTFS</b>: ricostruisce le geometrie delle linee dalle <i>shapes</i>
e aggiorna i layer <i>GTFS - Linee</i> e <i>GTFS - Metriche linee</i>. Ogni linea
caricata si accumula.</li>
<li><b>Crea layer segmenti</b>: geometrie stop-to-stop con velocità programmate.</li>
</ul>
<h4>Map-matching su rete (operazione spaziale)</h4>
<p>Campiona punti lungo le strade e <i>aggancia</i> ad ogni tratto stradale i
segmenti GTFS vicini, accettando l'abbinamento solo se la strada è entro la
<b>tolleranza</b> e con direzione simile (entro l'<b>angolo</b>); il <b>passo</b>
è la spaziatura di campionamento. Proietta così le velocità del trasporto sulla
rete stradale.</p>
"""),
    "gtfs_live": ("GTFS live · aiuto", """
<h3>Confronto con il GTFS realtime</h3>
<p>Operazione: confronta la velocità <i>programmata</i> di ogni segmento
stop-to-stop con quella <i>osservata</i> ricavata dai TripUpdates in tempo reale.</p>
<ul>
<li><b>URL feed TripUpdates</b>: endpoint protobuf GTFS-RT.</li>
<li><b>Intervallo</b>: ogni quanti secondi interrogare il feed.</li>
<li><b>Avvia / Ferma logging</b>: raccolta continua delle osservazioni.</li>
<li><b>Scansione programmata</b>: imposta ora di inizio e durata; la raccolta
parte da sola e si ferma dopo la durata (utile per una fascia oraria).</li>
<li><b>Top N</b> + <i>Evidenzia divari</i>: colora i segmenti per scarto
osservato vs teorico e seleziona i N con il divario maggiore.</li>
<li><b>Esporta Excel</b>: report con curve velocità per linea per fascia oraria.</li>
</ul>
"""),
    "lines2gtfs": ("Da linee a GTFS · aiuto", """
<h3>Genera un GTFS da linee e fermate</h3>
<p>Operazione spaziale: <i>aggancia</i> le fermate alle linee (entro la
tolleranza), le <b>ordina lungo la linea</b> (posizione progressiva calcolata in
metri), e deriva i tempi di percorrenza da distanza/velocità.</p>
<ul>
<li><b>Linee (rotte)</b>: layer lineare; ogni feature è una rotta.</li>
<li><b>Fermate</b>: layer puntuale agganciato alle linee e ordinato.</li>
<li><b>Tipo / Velocità / Frequenza / Orario / Sosta</b>: parametri del servizio.</li>
<li><b>Tolleranza fermate</b>: distanza massima fermata-linea per l'aggancio.</li>
</ul>
<p>Output: un feed GTFS .zip, impostato anche come sorgente nella scheda GTFS.</p>
"""),
    "isochrones": ("Isochrones · aiuto", """
<h3>Isocrone su rete stradale</h3>
<p>Operazione spaziale: dalla sorgente si percorre la rete con Dijkstra fino al
budget di tempo di ogni fascia (distanza = velocità × tempo); l'insieme dei
tratti raggiunti definisce l'area servita.</p>
<ul>
<li><b>Sorgenti</b>: layer di punti, oppure <i>Scegli punti sulla mappa</i>,
oppure <i>Usa fermate GTFS caricate</i>.</li>
<li><b>Rete stradale</b>: layer di linee su cui si calcolano i percorsi.</li>
<li><b>Mezzo / Velocità</b> e <b>Tempi (min)</b> (es. 5,10,15): definiscono le
fasce. La legenda mostra «5 min / 10 min / 15 min».</li>
<li><b>Modalità output</b>:
  <i>Concavo</i> = buffer dei tratti raggiunti (segue le strade, include gli
  edifici vicini, esclude le aree senza accesso);
  <i>Poligono</i> = inviluppo convesso (blob grossolano);
  <i>Lineare</i> = i soli tratti stradali raggiunti.</li>
<li><b>Dissolvi</b>: unisce le sorgenti in un'unica isocrona per fascia.</li>
<li><b>Avanzate · Allargamento</b>: larghezza del buffer attorno alla rete
(modalità concavo/poligono).</li>
<li><b>Rispetta i sensi unici</b>: se la rete ha un campo <i>oneway</i>
(1 = avanti, -1 = indietro, 0 = doppio senso) il routing diventa orientato
(utile in auto). La rete da OSM porta già questo campo.</li>
<li><b>POI/popolazione (opz.)</b>: un layer di punti (con campo peso opzionale, es.
popolazione): a fine calcolo conta quante opportunità cadono in ogni isocrona e
aggiunge i campi <i>n_poi</i> e <i>peso_poi</i> (solo per output poligonali).</li>
<li><b>Modalità interattiva</b>: con una rete selezionata (modo rete), ogni click
sulla mappa ricalcola l'isocrona aggiornando un unico layer «MIC - Isocrona
interattiva»; avvisa se il punto non aggancia la rete o è su una componente
isolata. Il calcolo è in background: un nuovo click annulla quello in corso.</li>
<li><b>Barra di avanzamento</b>: durante il calcolo mostra la fase (lettura
della rete, percorsi, costruzione poligoni…) e la percentuale; <i>Annulla</i>
interrompe il calcolo. QGIS resta utilizzabile nel frattempo. Su reti grandi
in auto (tutta la rete raggiunta) la costruzione dei poligoni può richiedere
decine di secondi.</li>
<li><b>Sistemi di riferimento</b>: sorgenti e rete possono avere CRS diversi
(vengono riproiettati automaticamente), purché il CRS assegnato a ogni layer
sia corretto.</li>
</ul>
<p><b>Trasporto pubblico (GTFS)</b> come mezzo: la raggiungibilità si calcola con
il Connection Scan Algorithm (orari reali del feed). Sono configurabili il modo
di <b>accesso</b> (sorgente→fermata) e di <b>egress</b> (fermata→destinazione),
a piedi o in bici (la bici allarga i bacini), più una <b>penalità di
trasferimento</b> (minuti per cambio). Con una rete pedonale selezionata l'egress
segue le strade.</p>
""" + _SNAP + _OSM),
    "ptal": ("PTAL · aiuto", """
<h3>PTAL · Public Transport Accessibility Level (TfL)</h3>
<p>Operazione spaziale: per ogni punto si cercano le fermate raggiungibili a
piedi entro la soglia di cammino del modo; con una rete pedonale le distanze
sono <i>di rete</i> (Dijkstra), altrimenti in linea d'aria.</p>
<ul>
<li><b>GTFS</b>: di default il feed caricato nella scheda GTFS (frequenze per
fermata e rotta).</li>
<li><b>Modalità</b>: <i>PTAL (TfL standard)</i> = distanza <b>in linea d'aria</b>
(metodo ufficiale TfL, default); <i>PTAL su rete pedonale</i> = distanza a piedi
<b>di rete</b> (Dijkstra), più realistica ma <b>non-standard</b> — richiede una
rete pedonale (anche via «Rete da OSM»).</li>
<li><b>Punti di analisi</b> o <b>griglia</b> (esagoni/quadrati) da valutare.</li>
<li><b>Fascia oraria</b>: ore su cui calcolare le frequenze (es. 7-10).</li>
<li><b>Profili orari AM/interpeak/PM</b>: calcola PTAL per le tre fasce standard
(7-10 / 10-16 / 16-19) e aggiunge i campi <i>ai_am, ptal_am, ai_ip, ...</i>; lo
stile usa la fascia AM come primaria.</li>
</ul>
<h4>Calcolo (per ogni punto)</h4>
<p>Tempo di accesso alla fermata = cammino + attesa (30/frequenza) +
<b>affidabilità</b>; EDF = 30/accesso; la rotta migliore pesa 1, le altre 0.5; la
somma è l'Accessibility Index, mappato sulle fasce PTAL 0..6b (tutte in legenda).</p>
<h4>Avanzate · aree di influenza</h4>
<p>Per ogni modo (bus/tram/metro/treno) puoi cambiare <b>soglia di cammino</b>
(TfL: 640 m bus/tram, 960 m rail) e <b>affidabilità</b> (minuti di margine).</p>
<h4>Gap analysis</h4>
<p>Incrocia il PTAL a celle con la popolazione: gap = popolazione × (8 − livello
PTAL)/8 → evidenzia dove c'è molta gente con poca accessibilità.</p>
""" + _SNAP),
    "spacesyntax": ("Space syntax · aiuto", """
<h3>Space syntax sul grafo stradale</h3>
<p>Operazione: ogni tratto diventa un nodo, collegato ai tratti che condividono
un estremo; su questo grafo si calcolano le misure topologiche.</p>
<ul>
<li><b>Connettività</b>: numero di tratti connessi a ciascun tratto.</li>
<li><b>Profondità media/totale</b>: distanza topologica (numero di passi) dagli
altri tratti.</li>
<li><b>Integrazione (HH)</b>: centralità/accessibilità del tratto (inverso di
RRA, normalizzazione Hillier-Hanson).</li>
<li><b>Choice (betweenness)</b>: quanti percorsi più brevi attraversano il tratto
(potenziale di attraversamento, algoritmo di Brandes).</li>
<li><b>NAIN / NACH</b>: integrazione e choice normalizzate per angolo.</li>
<li><b>Raggio</b>: R0 = globale (Rn), un valore = analisi locale entro quel
numero di passi topologici.</li>
</ul>
<p>Output: copia della rete con i campi calcolati, stile per integrazione.</p>
"""),
    "access": ("Accessibilità · aiuto", """
<h3>Accessibilità cumulativa alle opportunità</h3>
<p>Operazione spaziale: per ogni origine conta quante destinazioni (o quanto
peso) sono raggiungibili entro ciascuna soglia di tempo.</p>
<ul>
<li><b>Origini</b>: punti (o griglia) da valutare.</li>
<li><b>Destinazioni</b>: punti/poligoni (POI, popolazione, posti di lavoro). Con
<b>Campo peso</b> si sommano i pesi, altrimenti si contano.</li>
<li><b>Modo</b>: a piedi/bici/auto sulla <b>rete</b> (Dijkstra), oppure
<b>Trasporto pubblico</b> via GTFS (Connection Scan). In TP si scelgono accesso/
egress a piedi o in bici e una penalità di trasferimento (opzioni multimodali).</li>
<li><b>Tempi (min)</b>: una colonna <i>acc_Xmin</i> per ogni soglia.</li>
<li><b>Rispetta i sensi unici</b>: per i modi su strada, usa il campo
<i>oneway</i> della rete per un routing orientato.</li>
</ul>
<h4>Metriche di sintesi & equità</h4>
<p>Su un layer di accessibilità/PTAL (campo valore) eventualmente pesato per la
popolazione: <b>media/mediana pesate</b>, <b>% «servita»</b> (quota di peso con
valore ≥ soglia), <b>indice di Gini</b> e <b>curva di Lorenz</b>
dell'accessibilità (grafico a video o export Excel). Gini 0 = perfetta
uguaglianza, valori alti = forte disuguaglianza.</p>
<h4>Confronto scenari (B − A)</h4>
<p>Differenza tra due layer di risultati con la stessa geometria (es. PTAL prima/
dopo una modifica al servizio): produce un layer <i>delta = B − A</i> con stile
divergente (rosso = peggioramento, blu = miglioramento).</p>
<h4>Scenario A/B — confronto fra due reti</h4>
<p>Confronta due reti stradali (A = attuale, B = progetto: nuova strada,
passerella, strada chiusa) usando Origini/Destinazioni/Modo/Tempi della sezione
Accessibilità. Due tipi di confronto:</p>
<ul>
<li><b>Accessibilità (origini → destinazioni)</b>: calcola l'accessibilità
cumulativa sulle stesse origini con le due reti e produce il delta per origine
(classe gain/loss/unchanged) con sintesi delle origini migliorate/peggiorate.</li>
<li><b>Isocrone (differenza geometrica)</b>: calcola l'<i>area raggiungibile</i>
(isocrona su rete, modo concavo) dalle origini alla soglia massima dei Tempi su
entrambe le reti e ne fa la <b>differenza geometrica</b>: poligoni
<i>guadagno</i> (B−A, area raggiungibile solo nel progetto), <i>perdita</i>
(A−B) e <i>comune</i> (A∩B), con aree in ettari. Il calcolo gira in background
(la barra di stato mostra l'avanzamento); con molte origini l'unione delle aree
può richiedere un po': per scenari puntuali usa <b>poche sorgenti</b>.</li>
</ul>
""" + _SNAP + _OSM),
    "od": ("OD · aiuto", """
<h3>Origine-Destinazione</h3>
<p>Operazione spaziale: traccia <b>desire lines</b> tra i centroidi delle zone,
con spessore proporzionale al flusso; in alternativa calcola la matrice dei
<b>tempi di viaggio</b> zona-zona via trasporto pubblico.</p>
<ul>
<li><b>Zone</b>: punti o poligoni con un identificativo (per i poligoni si usa il
centroide).</li>
<li><b>Campo ID zona</b>: deve corrispondere agli id nella matrice OD.</li>
<li><b>Matrice OD (CSV)</b>: colonne origine, destinazione, valore.</li>
<li><b>Filtri</b>: flusso minimo, top N, singola origine/destinazione.</li>
<li><b>Linee arcuate</b>: traccia le desire lines come archi (Bézier) anziché
rette; la curva piega sempre dallo stesso lato, così andata e ritorno fra due
zone non si sovrappongono e i flussi sovrapposti restano leggibili.</li>
</ul>
<h4>Matrice tempi via trasporto pubblico</h4>
<p>Per ogni coppia di zone calcola il tempo minimo di viaggio in trasporto
pubblico (Connection Scan) entro il budget; di default usa il GTFS caricato.</p>
"""),
}
