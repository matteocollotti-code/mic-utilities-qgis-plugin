# -*- coding: utf-8 -*-
"""Dock widget del plugin: input, esecuzione analisi e visualizzazione."""
import csv

from qgis.PyQt.QtCore import Qt, QTime, QTimer, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDockWidget,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QTimeEdit,
    QVBoxLayout,
    QWidget,
    QWizard,
    QWizardPage,
)
from qgis.core import (
    QgsApplication,
    QgsCoordinateTransform,
    QgsGeometry,
    QgsMapLayerProxyModel,
    QgsProject,
    QgsRectangle,
    QgsVectorLayerFeatureSource,
)
from qgis.gui import (
    QgsFieldComboBox, QgsMapLayerComboBox, QgsMapToolEmitPoint,
)

from .core import analysis
from .core import (
    gtfs_static, gtfs_layers, excel_report, isochrones, gtfs_builder,
    space_syntax, od_viz, ptal, grid_gen, net_iso, gap as gap_mod, equity,
    compare, net_clean, opportunities, walkability, network_prepare,
    network_diagnostics, net_layers, scenarios, osm_cache,
)
from .core.gtfs_logger import GtfsRealtimeLogger
from .core.gtfs_tasks import (
    GtfsLoadTask, GtfsMatchTask, SpaceSyntaxTask, PtalTask, GtfsIsoTask,
    AccessTask, OdMatrixTask, OsmRoadsTask, OsmCrossingsTask, ScenarioIsoTask,
)
from .core import osm_download

from .help_texts import HELP_TEXTS
from .style import MIC_STYLE

RATIO_LABELS = [
    ("total_length_m", "Lunghezza totale (m)"),
    ("total_length_km", "Lunghezza totale (km)"),
    ("total_intersections_pairwise", "Incroci (conteggio per coppie)"),
    ("unique_intersection_nodes", "Nodi di intersezione unici"),
    ("area_m2", "Area di progetto (m2)"),
    ("area_km2", "Area di progetto (km2)"),
    ("density_km_per_km2", "Densità stradale (km/km²)"),
    ("intersection_density_per_km2", "Densità incroci (n/km²)"),
]


class _PrepPage(QWizardPage):
    """Pagina del wizard di preparazione rete con callback di inizializzazione.

    `on_init(page)` viene eseguito quando la pagina è mostrata; `is_complete()`
    abilita il pulsante Avanti/Fine (es. solo se l'anteprima è pronta).
    """

    def __init__(self, title, subtitle="", on_init=None, is_complete=None,
                 parent=None):
        super().__init__(parent)
        self.setTitle(title)
        if subtitle:
            self.setSubTitle(subtitle)
        self._on_init = on_init
        self._is_complete = is_complete

    def initializePage(self):  # noqa: N802 (API Qt)
        if self._on_init:
            self._on_init(self)

    def isComplete(self):  # noqa: N802 (API Qt)
        if self._is_complete is not None:
            return self._is_complete()
        return True


class AnalyzerDockWidget(QDockWidget):
    """Pannello agganciabile per l'analisi della rete stradale."""

    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("MIC - Utilities")
        self._results = None
        self._scan_timer = None
        self._gtfs = None
        self._logger = None
        self._load_task = None
        self._match_task = None
        self._gtfs_seg_layer = None
        # accumulatore: linee/metriche restano in un unico layer aggiornato
        self._acc = {"shapes": {}, "shape_routes": {}, "routes": {},
                     "line_metrics": {}}
        self._lines_layer_id = None
        self._metrics_layer_id = None
        self._isoa_picked = []
        self._isoa_tool = None
        self._isoa_task = None
        self._ptal_cells = None
        self._ptal_points = None
        self._ptal_grid_layer_id = None
        self._osm_task = None
        self._osm_target = None
        self._osm_mode = "all"
        self._osm_cross_task = None
        self._build_ui()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        # pannello «MIC - Utilities» con le schede raggruppate in 3 categorie
        # (tab annidati); ogni scheda è avvolta in uno scroll.
        self.mainTabs = QTabWidget()

        tp = QTabWidget()
        tp.addTab(self._scroll(self._build_gtfs_tab()), "GTFS")
        tp.addTab(self._scroll(self._build_gtfs_live_tab()), "GTFS live")
        tp.addTab(self._scroll(self._build_lines2gtfs_tab()), "Da linee a GTFS")
        tp.addTab(self._scroll(self._build_ptal_tab()), "PTAL")

        rn = QTabWidget()
        rn.addTab(self._scroll(self._build_road_tab()), "Analisi rete")
        rn.addTab(self._scroll(self._build_spacesyntax_tab()), "Space syntax")

        ac = QTabWidget()
        ac.addTab(self._scroll(self._build_isochrones_tab()), "Isochrones")
        ac.addTab(self._scroll(self._build_access_tab()), "Accessibilità")
        ac.addTab(self._scroll(self._build_od_tab()), "OD")

        self.mainTabs.addTab(tp, "Trasporto pubblico")
        self.mainTabs.addTab(rn, "Rete stradale")
        self.mainTabs.addTab(ac, "Accessibilità")
        self.setWidget(self.mainTabs)
        self.mainTabs.setStyleSheet(MIC_STYLE)
        self.setStyleSheet(MIC_STYLE)

    @staticmethod
    def _scroll(widget):
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QScrollArea.NoFrame)
        sa.setWidget(widget)
        return sa

    def _help_button(self, key):
        btn = QPushButton("❓ Spiegazione campi")
        btn.setFlat(True)
        btn.clicked.connect(lambda: self._show_help(key))
        return btn

    def _show_help(self, key):
        title, html = HELP_TEXTS.get(key, ("Aiuto", ""))
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.resize(500, 440)
        lay = QVBoxLayout(dlg)
        tb = QTextBrowser()
        tb.setHtml(html)
        tb.setOpenExternalLinks(True)
        lay.addWidget(tb)
        close = QPushButton("Chiudi")
        close.clicked.connect(dlg.accept)
        lay.addWidget(close)
        dlg.exec_()

    def _build_road_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("road"))

        form = QFormLayout()
        self.roadLayerCombo = QgsMapLayerComboBox()
        self.roadLayerCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Rete stradale:", self._combo_with_osm(self.roadLayerCombo))

        self.typeFieldCombo = QgsFieldComboBox()
        self.typeFieldCombo.setAllowEmptyFieldName(True)
        form.addRow("Campo tipologia:", self.typeFieldCombo)

        self.areaLayerCombo = QgsMapLayerComboBox()
        self.areaLayerCombo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.areaLayerCombo.setAllowEmptyLayer(True)
        form.addRow("Area di progetto:", self.areaLayerCombo)
        layout.addLayout(form)

        btn_row = QHBoxLayout()
        self.runButton = QPushButton("Calcola")
        self.exportButton = QPushButton("Esporta CSV")
        self.exportButton.setEnabled(False)
        btn_row.addWidget(self.runButton)
        btn_row.addWidget(self.exportButton)
        layout.addLayout(btn_row)

        self.tabs = QTabWidget()
        self.lengthTable = self._make_table()
        self.matrixTable = self._make_table()
        self.ratiosTable = self._make_table()
        self.tabs.addTab(self.lengthTable, "Lunghezze")
        self.tabs.addTab(self.matrixTable, "Matrice incroci")
        self.tabs.addTab(self.ratiosTable, "Rapporti")
        layout.addWidget(self.tabs)

        walk_box = QGroupBox("Walkability index (morfologia rete)")
        wf = QFormLayout(walk_box)
        self.walkZones = QgsMapLayerComboBox()
        self.walkZones.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.walkZones.setAllowEmptyLayer(True)
        wf.addRow("Zone (vuoto = griglia):", self.walkZones)
        wgrid = QHBoxLayout()
        self.walkGridSize = QSpinBox()
        self.walkGridSize.setRange(50, 5000)
        self.walkGridSize.setValue(300)
        self.walkGridSize.setSuffix(" m")
        wgrid.addWidget(QLabel("cella griglia:"))
        wgrid.addWidget(self.walkGridSize)
        wgrid.addStretch()
        wf.addRow("Griglia:", self._wrap(wgrid))
        self.walkPoi = QgsMapLayerComboBox()
        self.walkPoi.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.walkPoi.setAllowEmptyLayer(True)
        wf.addRow("POI/destinazioni (opz.):", self.walkPoi)
        self.walkPoiCat = QgsFieldComboBox()
        self.walkPoiCat.setAllowEmptyFieldName(True)
        self.walkPoi.layerChanged.connect(self.walkPoiCat.setLayer)
        self.walkPoiCat.setLayer(self.walkPoi.currentLayer())
        wf.addRow("Campo categoria (opz.):", self.walkPoiCat)
        self.walkDestM = QSpinBox()
        self.walkDestM.setRange(100, 5000)
        self.walkDestM.setValue(800)
        self.walkDestM.setSuffix(" m")
        wf.addRow("Distanza max destinazioni:", self.walkDestM)
        self.walkDestNet = QCheckBox("Destinazioni su rete (Dijkstra) "
                                     "invece che in linea d'aria")
        wf.addRow("", self.walkDestNet)
        cross_row = QHBoxLayout()
        self.walkCross = QgsMapLayerComboBox()
        self.walkCross.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.walkCross.setAllowEmptyLayer(True)
        cross_row.addWidget(self.walkCross, 1)
        self.walkCrossOsm = QPushButton("🌐 Attraversamenti da OSM")
        self.walkCrossOsm.clicked.connect(self._download_osm_crossings)
        cross_row.addWidget(self.walkCrossOsm)
        wf.addRow("Attraversamenti (opz.):", self._wrap(cross_row))
        self.walkDem = QgsMapLayerComboBox()
        self.walkDem.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.walkDem.setAllowEmptyLayer(True)
        wf.addRow("DEM per pendenza (opz.):", self.walkDem)
        self.walkButton = QPushButton("Calcola walkability")
        self.walkButton.clicked.connect(self._walk_run)
        wf.addRow(self.walkButton)
        self.walkStatus = QLabel("")
        self.walkStatus.setWordWrap(True)
        wf.addRow(self.walkStatus)
        layout.addWidget(walk_box)

        prep_box = QGroupBox("Preparazione & diagnostica rete")
        pf = QVBoxLayout(prep_box)
        pf.addWidget(QLabel(
            "Usa la <b>Rete stradale</b> in alto. <i>Prepara</i> spezza le linee "
            "agli incroci (noding) per analisi corrette; <i>Diagnostica</i> "
            "segnala componenti scollegate, sorgenti isolate e incroci non noded."))
        prow = QHBoxLayout()
        self.prepButton = QPushButton("🔧 Prepara rete (noding)")
        self.prepButton.clicked.connect(self._prepare_run)
        self.diagButton = QPushButton("🩺 Diagnostica rete")
        self.diagButton.clicked.connect(self._diag_run)
        prow.addWidget(self.prepButton)
        prow.addWidget(self.diagButton)
        pf.addLayout(prow)
        drow = QHBoxLayout()
        drow.addWidget(QLabel("Sorgenti per diagnostica (opz.):"))
        self.diagSources = QgsMapLayerComboBox()
        self.diagSources.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.diagSources.setAllowEmptyLayer(True)
        drow.addWidget(self.diagSources, 1)
        pf.addLayout(drow)
        self.presetButton = QPushButton("📍 Preset area OSM…")
        self.presetButton.setToolTip("Salva/richiama un'area (bbox) per i "
                                     "download OSM riproducibili.")
        self.presetButton.clicked.connect(self._osm_presets_dialog)
        pf.addWidget(self.presetButton)
        self.prepStatus = QLabel("")
        self.prepStatus.setWordWrap(True)
        pf.addWidget(self.prepStatus)
        layout.addWidget(prep_box)

        self.statusLabel = QLabel("")
        self.statusLabel.setWordWrap(True)
        layout.addWidget(self.statusLabel)

        self.roadLayerCombo.layerChanged.connect(self.typeFieldCombo.setLayer)
        self.typeFieldCombo.setLayer(self.roadLayerCombo.currentLayer())
        self.runButton.clicked.connect(self.run_analysis)
        self.exportButton.clicked.connect(self.export_csv)
        return container

    # -------------------------------------------------------------- GTFS UI
    def _build_gtfs_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("gtfs"))

        # --- dati statici ---
        static_box = QGroupBox("Dati statici (GTFS zip o cartella)")
        sb = QVBoxLayout(static_box)
        src_row = QHBoxLayout()
        self.gtfsSourceEdit = QLineEdit()
        self.gtfsSourceEdit.setPlaceholderText("Percorso del feed GTFS (.zip o cartella)")
        btn_zip = QPushButton("Zip...")
        btn_dir = QPushButton("Cartella...")
        btn_zip.clicked.connect(self._gtfs_browse_zip)
        btn_dir.clicked.connect(self._gtfs_browse_folder)
        src_row.addWidget(self.gtfsSourceEdit)
        src_row.addWidget(btn_zip)
        src_row.addWidget(btn_dir)
        sb.addLayout(src_row)
        route_row = QHBoxLayout()
        route_row.addWidget(QLabel("Linea:"))
        self.gtfsRouteCombo = QComboBox()
        self.gtfsRouteCombo.addItem("Tutte le linee", None)
        route_row.addWidget(self.gtfsRouteCombo, 1)
        self.gtfsReadRoutesButton = QPushButton("Leggi linee")
        self.gtfsReadRoutesButton.clicked.connect(self._gtfs_read_routes)
        route_row.addWidget(self.gtfsReadRoutesButton)
        sb.addLayout(route_row)

        date_row = QHBoxLayout()
        date_row.addWidget(QLabel("Data servizio (YYYYMMDD, opz.):"))
        self.gtfsServiceDate = QLineEdit()
        self.gtfsServiceDate.setPlaceholderText("vuoto = giorno di servizio dominante")
        self.gtfsServiceDate.setMaximumWidth(180)
        date_row.addWidget(self.gtfsServiceDate)
        self.gtfsValidateButton = QPushButton("Valida feed")
        self.gtfsValidateButton.clicked.connect(self._gtfs_validate)
        date_row.addWidget(self.gtfsValidateButton)
        date_row.addStretch()
        sb.addLayout(date_row)

        act_row = QHBoxLayout()
        self.gtfsLoadButton = QPushButton("Carica GTFS (+ layer linee)")
        self.gtfsSegButton = QPushButton("Crea layer segmenti")
        self.gtfsSegButton.setEnabled(False)
        self.gtfsLoadButton.clicked.connect(self._gtfs_load)
        self.gtfsSegButton.clicked.connect(self._gtfs_create_segments)
        act_row.addWidget(self.gtfsLoadButton)
        act_row.addWidget(self.gtfsSegButton)
        sb.addLayout(act_row)
        layout.addWidget(static_box)

        # --- map-matching sulla rete stradale ---
        mm_box = QGroupBox("Map-matching su rete stradale")
        mm = QVBoxLayout(mm_box)
        mm_row1 = QHBoxLayout()
        mm_row1.addWidget(QLabel("Rete stradale:"))
        self.mmRoadCombo = QgsMapLayerComboBox()
        self.mmRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        mm_row1.addWidget(self.mmRoadCombo, 1)
        mm_row1.addWidget(self._osm_button(self.mmRoadCombo, "vehicular"))
        mm.addLayout(mm_row1)
        mm_adv = QGroupBox("Avanzate · parametri di aggancio")
        mm_af = QFormLayout(mm_adv)
        self.mmTolSpin = QSpinBox()
        self.mmTolSpin.setRange(1, 200)
        self.mmTolSpin.setValue(20)
        self.mmTolSpin.setSuffix(" m")
        mm_af.addRow("Tolleranza (distanza max strada-linea):", self.mmTolSpin)
        self.mmAngleSpin = QSpinBox()
        self.mmAngleSpin.setRange(5, 90)
        self.mmAngleSpin.setValue(30)
        self.mmAngleSpin.setSuffix("°")
        mm_af.addRow("Angolo (differenza max di direzione):", self.mmAngleSpin)
        self.mmSpacingSpin = QSpinBox()
        self.mmSpacingSpin.setRange(5, 200)
        self.mmSpacingSpin.setValue(25)
        self.mmSpacingSpin.setSuffix(" m")
        mm_af.addRow("Passo (spaziatura di campionamento):", self.mmSpacingSpin)
        self._make_collapsible(mm_adv, collapsed=True)
        mm.addWidget(mm_adv)
        self.mmRunButton = QPushButton("Esegui map-matching")
        self.mmRunButton.setEnabled(False)
        self.mmRunButton.clicked.connect(self._gtfs_map_match)
        mm.addWidget(self.mmRunButton)
        layout.addWidget(mm_box)

        cov = QLabel("ℹ️ Per le isocrone delle fermate usa la scheda "
                     "<b>Isochrones</b> (opzione «usa fermate GTFS "
                     "caricate»): calcolo su rete in background, "
                     "concavo/poligono/lineare e modo trasporto pubblico.")
        cov.setWordWrap(True)
        layout.addWidget(cov)

        self.gtfsStatus = QLabel("")
        self.gtfsStatus.setWordWrap(True)
        layout.addWidget(self.gtfsStatus)
        layout.addStretch()
        return container

    # ---------------------------------------------------------- GTFS live UI
    def _build_gtfs_live_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("gtfs_live"))

        # --- realtime ---
        rt_box = QGroupBox("Realtime (GTFS-RT TripUpdates)")
        rb = QVBoxLayout(rt_box)
        self.gtfsRtUrlEdit = QLineEdit()
        self.gtfsRtUrlEdit.setPlaceholderText("URL del feed TripUpdates (protobuf)")
        rb.addWidget(self.gtfsRtUrlEdit)
        rt_row = QHBoxLayout()
        rt_row.addWidget(QLabel("Intervallo:"))
        self.gtfsIntervalSpin = QSpinBox()
        self.gtfsIntervalSpin.setRange(10, 3600)
        self.gtfsIntervalSpin.setValue(30)
        self.gtfsIntervalSpin.setSuffix(" s")
        rt_row.addWidget(self.gtfsIntervalSpin)
        self.gtfsStartButton = QPushButton("Avvia logging")
        self.gtfsStopButton = QPushButton("Ferma")
        self.gtfsStartButton.setEnabled(False)
        self.gtfsStopButton.setEnabled(False)
        self.gtfsStartButton.clicked.connect(self._gtfs_start_logging)
        self.gtfsStopButton.clicked.connect(self._gtfs_stop_logging)
        rt_row.addWidget(self.gtfsStartButton)
        rt_row.addWidget(self.gtfsStopButton)
        rt_row.addStretch()
        rb.addLayout(rt_row)

        sched_row = QHBoxLayout()
        sched_row.addWidget(QLabel("Scansione programmata - ora:"))
        self.gtfsScanTime = QTimeEdit()
        self.gtfsScanTime.setDisplayFormat("HH:mm")
        self.gtfsScanTime.setTime(QTime(8, 0))
        sched_row.addWidget(self.gtfsScanTime)
        sched_row.addWidget(QLabel("durata:"))
        self.gtfsScanDur = QSpinBox()
        self.gtfsScanDur.setRange(1, 1440)
        self.gtfsScanDur.setValue(30)
        self.gtfsScanDur.setSuffix(" min")
        sched_row.addWidget(self.gtfsScanDur)
        self.gtfsScanButton = QPushButton("Programma scansione")
        self.gtfsScanButton.setEnabled(False)
        self.gtfsScanButton.clicked.connect(self._gtfs_schedule_scan)
        self.gtfsScanCancel = QPushButton("Annulla")
        self.gtfsScanCancel.setEnabled(False)
        self.gtfsScanCancel.clicked.connect(self._gtfs_cancel_scan)
        sched_row.addWidget(self.gtfsScanButton)
        sched_row.addWidget(self.gtfsScanCancel)
        sched_row.addStretch()
        rb.addLayout(sched_row)

        self.gtfsRtStatus = QLabel("Logging non attivo.")
        self.gtfsRtStatus.setWordWrap(True)
        rb.addWidget(self.gtfsRtStatus)
        layout.addWidget(rt_box)

        # --- analisi & export ---
        an_box = QGroupBox("Analisi divari ed export")
        ab = QHBoxLayout(an_box)
        ab.addWidget(QLabel("Top N:"))
        self.gtfsTopNSpin = QSpinBox()
        self.gtfsTopNSpin.setRange(1, 500)
        self.gtfsTopNSpin.setValue(20)
        ab.addWidget(self.gtfsTopNSpin)
        self.gtfsHighlightButton = QPushButton("Evidenzia divari")
        self.gtfsExcelButton = QPushButton("Esporta Excel velocità")
        self.gtfsHighlightButton.setEnabled(False)
        self.gtfsExcelButton.setEnabled(False)
        self.gtfsHighlightButton.clicked.connect(self._gtfs_highlight)
        self.gtfsExcelButton.clicked.connect(self._gtfs_export_excel)
        ab.addWidget(self.gtfsHighlightButton)
        ab.addWidget(self.gtfsExcelButton)
        ab.addStretch()
        layout.addWidget(an_box)

        self.gtfsLineTable = self._make_table()
        layout.addWidget(QLabel("Metriche per linea (teorico vs osservato):"))
        layout.addWidget(self.gtfsLineTable)

        self.gtfsLiveStatus = QLabel("")
        self.gtfsLiveStatus.setWordWrap(True)
        layout.addWidget(self.gtfsLiveStatus)
        return container

    # ----------------------------------------------------- Da linee a GTFS
    def _build_lines2gtfs_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("lines2gtfs"))

        in_box = QGroupBox("Input")
        form = QFormLayout(in_box)
        self.l2gLineCombo = QgsMapLayerComboBox()
        self.l2gLineCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Linee (rotte):", self.l2gLineCombo)
        self.l2gRouteField = QgsFieldComboBox()
        self.l2gRouteField.setAllowEmptyFieldName(True)
        self.l2gLineCombo.layerChanged.connect(self.l2gRouteField.setLayer)
        self.l2gRouteField.setLayer(self.l2gLineCombo.currentLayer())
        form.addRow("Campo nome linea:", self.l2gRouteField)
        self.l2gStopsCombo = QgsMapLayerComboBox()
        self.l2gStopsCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        form.addRow("Fermate:", self.l2gStopsCombo)
        self.l2gStopField = QgsFieldComboBox()
        self.l2gStopField.setAllowEmptyFieldName(True)
        self.l2gStopsCombo.layerChanged.connect(self.l2gStopField.setLayer)
        self.l2gStopField.setLayer(self.l2gStopsCombo.currentLayer())
        form.addRow("Campo nome fermata:", self.l2gStopField)
        layout.addWidget(in_box)

        par_box = QGroupBox("Parametri di servizio")
        pf = QFormLayout(par_box)
        self.l2gTypeCombo = QComboBox()
        self.l2gTypeCombo.addItem("Bus", "3")
        self.l2gTypeCombo.addItem("Tram", "0")
        self.l2gTypeCombo.addItem("Metro", "1")
        self.l2gTypeCombo.addItem("Treno", "2")
        pf.addRow("Tipo:", self.l2gTypeCombo)
        self.l2gSpeed = QSpinBox()
        self.l2gSpeed.setRange(1, 200)
        self.l2gSpeed.setValue(20)
        self.l2gSpeed.setSuffix(" km/h")
        pf.addRow("Velocità:", self.l2gSpeed)
        self.l2gHeadway = QSpinBox()
        self.l2gHeadway.setRange(1, 240)
        self.l2gHeadway.setValue(10)
        self.l2gHeadway.setSuffix(" min")
        pf.addRow("Frequenza:", self.l2gHeadway)
        hours = QHBoxLayout()
        self.l2gStart = QSpinBox()
        self.l2gStart.setRange(0, 23)
        self.l2gStart.setValue(6)
        self.l2gEnd = QSpinBox()
        self.l2gEnd.setRange(1, 30)
        self.l2gEnd.setValue(22)
        hours.addWidget(QLabel("dalle"))
        hours.addWidget(self.l2gStart)
        hours.addWidget(QLabel("alle"))
        hours.addWidget(self.l2gEnd)
        hours.addWidget(QLabel("(h)"))
        hours.addStretch()
        pf.addRow("Orario:", self._wrap(hours))
        self.l2gDwell = QSpinBox()
        self.l2gDwell.setRange(0, 600)
        self.l2gDwell.setValue(20)
        self.l2gDwell.setSuffix(" s")
        pf.addRow("Sosta/fermata:", self.l2gDwell)
        self.l2gSnap = QSpinBox()
        self.l2gSnap.setRange(1, 500)
        self.l2gSnap.setValue(50)
        self.l2gSnap.setSuffix(" m")
        pf.addRow("Tolleranza fermate:", self.l2gSnap)
        self.l2gAgency = QLineEdit("Agenzia")
        pf.addRow("Agenzia:", self.l2gAgency)
        layout.addWidget(par_box)

        out_row = QHBoxLayout()
        self.l2gOutEdit = QLineEdit()
        self.l2gOutEdit.setPlaceholderText("File GTFS di output (.zip)")
        out_btn = QPushButton("...")
        out_btn.clicked.connect(self._l2g_browse_out)
        out_row.addWidget(self.l2gOutEdit, 1)
        out_row.addWidget(out_btn)
        layout.addLayout(out_row)
        self.l2gRunButton = QPushButton("Genera GTFS")
        self.l2gRunButton.clicked.connect(self._l2g_generate)
        layout.addWidget(self.l2gRunButton)
        self.l2gStatus = QLabel("")
        self.l2gStatus.setWordWrap(True)
        layout.addWidget(self.l2gStatus)
        layout.addStretch()
        return container

    # ------------------------------------------------------ schede nuove
    def _build_isochrones_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("isochrones"))
        form = QFormLayout()
        self.isoaSourceCombo = QgsMapLayerComboBox()
        self.isoaSourceCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.isoaSourceCombo.setAllowEmptyLayer(True)
        form.addRow("Sorgenti (punti):", self.isoaSourceCombo)
        self.isoaUseGtfs = QPushButton("Usa fermate GTFS caricate")
        self.isoaUseGtfs.setCheckable(True)
        form.addRow("", self.isoaUseGtfs)
        pick_row = QHBoxLayout()
        self.isoaPickButton = QPushButton("Scegli punti sulla mappa")
        self.isoaPickButton.setCheckable(True)
        self.isoaPickButton.toggled.connect(self._isoa_toggle_pick)
        self.isoaPickClear = QPushButton("Cancella")
        self.isoaPickClear.clicked.connect(self._isoa_clear_pick)
        self.isoaPickLabel = QLabel("0 punti scelti")
        pick_row.addWidget(self.isoaPickButton)
        pick_row.addWidget(self.isoaPickClear)
        pick_row.addWidget(self.isoaPickLabel)
        form.addRow("Sulla mappa:", self._wrap(pick_row))
        self.isoaRoadCombo = QgsMapLayerComboBox()
        self.isoaRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.isoaRoadCombo.setAllowEmptyLayer(True)
        form.addRow("Rete stradale:",
                    self._combo_with_osm(self.isoaRoadCombo, self._iso_osm_mode))
        self.isoaModeCombo = QComboBox()
        self.isoaModeCombo.addItem("Piedi", 4.5)
        self.isoaModeCombo.addItem("Bici", 15.0)
        self.isoaModeCombo.addItem("Auto", 30.0)
        self.isoaModeCombo.addItem("Trasporto pubblico (GTFS)", "pt")
        self.isoaModeCombo.currentIndexChanged.connect(self._isoa_mode_changed)
        form.addRow("Mezzo:", self.isoaModeCombo)
        self.isoaSpeed = QDoubleSpinBox()
        self.isoaSpeed.setDecimals(1)
        self.isoaSpeed.setRange(0.5, 200.0)
        self.isoaSpeed.setSingleStep(0.5)
        self.isoaSpeed.setValue(4.5)
        self.isoaSpeed.setSuffix(" km/h")
        form.addRow("Velocità:", self.isoaSpeed)
        self.isoaTimes = QLineEdit("5,10,15")
        form.addRow("Tempi (min):", self.isoaTimes)
        self.isoaOutput = QComboBox()
        self.isoaOutput.addItem("Concavo (buffer su rete)", "concave")
        self.isoaOutput.addItem("Poligono (inviluppo convesso)", "polygon")
        self.isoaOutput.addItem("Lineare (segmenti)", "linear")
        form.addRow("Modalità output:", self.isoaOutput)
        self.isoaDissolve = QCheckBox("Dissolvi il risultato (unisci le sorgenti)")
        self.isoaDissolve.setChecked(True)
        form.addRow("", self.isoaDissolve)
        self.isoaOneway = QCheckBox("Rispetta i sensi unici (campo «oneway»)")
        form.addRow("", self.isoaOneway)
        self.isoaPoiCombo = QgsMapLayerComboBox()
        self.isoaPoiCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.isoaPoiCombo.setAllowEmptyLayer(True)
        form.addRow("POI/popolazione (opz.):", self.isoaPoiCombo)
        self.isoaPoiWeight = QgsFieldComboBox()
        self.isoaPoiWeight.setAllowEmptyFieldName(True)
        self.isoaPoiCombo.layerChanged.connect(self.isoaPoiWeight.setLayer)
        self.isoaPoiWeight.setLayer(self.isoaPoiCombo.currentLayer())
        form.addRow("Campo peso (opz.):", self.isoaPoiWeight)
        self.isoaInteractive = QCheckBox(
            "Modalità interattiva: calcola al click sulla mappa (un solo layer, "
            "solo modo rete)")
        self.isoaInteractive.toggled.connect(self._isoa_interactive_toggled)
        form.addRow("", self.isoaInteractive)
        layout.addLayout(form)

        iso_adv = QGroupBox("Avanzate · parametri di calcolo")
        ia_f = QFormLayout(iso_adv)
        self.isoaAccess = QSpinBox()
        self.isoaAccess.setRange(1, 500)
        self.isoaAccess.setValue(30)
        self.isoaAccess.setSuffix(" m")
        ia_f.addRow("Allargamento (larghezza buffer attorno alla rete):",
                    self.isoaAccess)
        self._make_collapsible(iso_adv, collapsed=True)
        layout.addWidget(iso_adv)

        # --- opzioni Trasporto pubblico: visibili solo in modo TP ---
        self.isoaPtBox = QGroupBox("Opzioni trasporto pubblico (GTFS)")
        ptf = QFormLayout(self.isoaPtBox)
        pt_row = QHBoxLayout()
        self.isoaGtfsEdit = QLineEdit()
        self.isoaGtfsEdit.setPlaceholderText(
            "(vuoto = usa il GTFS caricato nella scheda GTFS)")
        isoa_gtfs_btn = QPushButton("Sfoglia...")
        isoa_gtfs_btn.clicked.connect(self._isoa_browse_gtfs)
        pt_row.addWidget(self.isoaGtfsEdit, 1)
        pt_row.addWidget(isoa_gtfs_btn)
        ptf.addRow("GTFS (TP):", self._wrap(pt_row))
        self.isoaStartH = QSpinBox()
        self.isoaStartH.setRange(0, 23)
        self.isoaStartH.setValue(8)
        self.isoaStartH.setSuffix(":00 partenza")
        ptf.addRow("Ora (TP):", self.isoaStartH)
        self.isoaAccessMode = self._pt_leg_combo()
        ptf.addRow("Accesso alle fermate:", self.isoaAccessMode)
        self.isoaEgressMode = self._pt_leg_combo()
        ptf.addRow("Egress dalle fermate:", self.isoaEgressMode)
        self.isoaTransferPen = QSpinBox()
        self.isoaTransferPen.setRange(0, 30)
        self.isoaTransferPen.setValue(0)
        self.isoaTransferPen.setSuffix(" min")
        ptf.addRow("Penalità trasferimento:", self.isoaTransferPen)
        self.isoaPtBox.setVisible(False)
        layout.addWidget(self.isoaPtBox)

        self.isoaRunButton = QPushButton("Crea isocrone")
        self.isoaRunButton.clicked.connect(self._isoa_run)
        layout.addWidget(self.isoaRunButton)
        # barra di avanzamento (visibile solo durante il calcolo) + Annulla
        prog_row = QHBoxLayout()
        self.isoaProgress = QProgressBar()
        self.isoaProgress.setRange(0, 100)
        self.isoaProgress.setTextVisible(True)
        self.isoaCancel = QPushButton("Annulla")
        self.isoaCancel.clicked.connect(self._isoa_cancel)
        prog_row.addWidget(self.isoaProgress, 1)
        prog_row.addWidget(self.isoaCancel)
        self.isoaProgressRow = self._wrap(prog_row)
        self.isoaProgressRow.setVisible(False)
        layout.addWidget(self.isoaProgressRow)
        self.isoaStatus = QLabel("")
        self.isoaStatus.setWordWrap(True)
        layout.addWidget(self.isoaStatus)
        layout.addStretch()
        return container

    def _isoa_mode_changed(self):
        data = self.isoaModeCombo.currentData()
        is_pt = (data == "pt")
        self.isoaPtBox.setVisible(is_pt)
        if isinstance(data, (int, float)):
            self.isoaSpeed.setValue(float(data))
        elif is_pt:
            # in modo TP la velocità è quella a piedi dei trasbordi fra fermate
            self.isoaSpeed.setValue(4.5)

    def _isoa_browse_gtfs(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.isoaGtfsEdit.setText(path)

    def _build_ptal_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("ptal"))
        form = QFormLayout()
        self.ptalSourceEdit = QLineEdit()
        form.addRow(QLabel("Sorgente: <b>GTFS caricato</b> (scheda GTFS)."))
        self.ptalDistCombo = QComboBox()
        self.ptalDistCombo.addItem(
            "PTAL (TfL standard) · linea d'aria", "standard")
        self.ptalDistCombo.addItem("PTAL su rete pedonale", "network")
        self.ptalDistCombo.currentIndexChanged.connect(self._ptal_mode_changed)
        form.addRow("Modalità:", self.ptalDistCombo)
        self.ptalPointsCombo = QgsMapLayerComboBox()
        self.ptalPointsCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.ptalPointsCombo.setAllowEmptyLayer(True)
        form.addRow("Punti di analisi:", self.ptalPointsCombo)
        self.ptalGridCheck = QCheckBox("Genera griglia automatica (output a celle)")
        self.ptalGridCheck.setChecked(True)
        form.addRow("", self.ptalGridCheck)
        grid_row = QHBoxLayout()
        self.ptalGridShape = QComboBox()
        self.ptalGridShape.addItem("Esagoni", "hex")
        self.ptalGridShape.addItem("Quadrati", "square")
        grid_row.addWidget(self.ptalGridShape)
        grid_row.addWidget(QLabel("cella:"))
        self.ptalGridSize = QSpinBox()
        self.ptalGridSize.setRange(20, 5000)
        self.ptalGridSize.setValue(200)
        self.ptalGridSize.setSuffix(" m")
        grid_row.addWidget(self.ptalGridSize)
        grid_row.addStretch()
        form.addRow("Griglia:", self._wrap(grid_row))
        self.ptalExtentCombo = QgsMapLayerComboBox()
        self.ptalExtentCombo.setAllowEmptyLayer(True)
        form.addRow("Estensione (vuoto=vista):", self.ptalExtentCombo)
        hours = QHBoxLayout()
        self.ptalStart = QSpinBox()
        self.ptalStart.setRange(0, 23)
        self.ptalStart.setValue(7)
        self.ptalEnd = QSpinBox()
        self.ptalEnd.setRange(1, 30)
        self.ptalEnd.setValue(10)
        hours.addWidget(QLabel("dalle"))
        hours.addWidget(self.ptalStart)
        hours.addWidget(QLabel("alle"))
        hours.addWidget(self.ptalEnd)
        hours.addStretch()
        self.ptalHoursWidget = self._wrap(hours)
        form.addRow("Fascia oraria:", self.ptalHoursWidget)
        self.ptalProfilesCheck = QCheckBox(
            "Profili orari AM / interpeak / PM (ignora la fascia sopra)")
        self.ptalProfilesCheck.toggled.connect(
            lambda on: self.ptalHoursWidget.setEnabled(not on))
        form.addRow("", self.ptalProfilesCheck)
        layout.addLayout(form)
        layout.addWidget(self._gtfs_override_box(
            self.ptalSourceEdit, self._ptal_browse))

        adv = QGroupBox("Avanzate · aree di influenza e affidabilità per mezzo")
        af = QFormLayout(adv)
        self.ptalWalk = QSpinBox()
        self.ptalWalk.setRange(1, 100)
        self.ptalWalk.setValue(48)
        af.addRow("Velocità cammino (km/h ×10):", self.ptalWalk)
        af.addRow(QLabel("<b>Per mezzo: soglia cammino (m) + affidabilita "
                         "(x10 min)</b>"))
        self.ptalModeWidgets = {}
        for label, rtype, thr, rel in [
                ("Bus", "3", 640, 20), ("Tram", "0", 640, 15),
                ("Metro", "1", 960, 8), ("Treno", "2", 960, 8)]:
            row = QHBoxLayout()
            sthr = QSpinBox()
            sthr.setRange(50, 5000)
            sthr.setValue(thr)
            sthr.setSuffix(" m")
            srel = QSpinBox()
            srel.setRange(0, 600)
            srel.setValue(rel)
            row.addWidget(QLabel("soglia"))
            row.addWidget(sthr)
            row.addWidget(QLabel("affid."))
            row.addWidget(srel)
            row.addStretch()
            af.addRow(label + ":", self._wrap(row))
            self.ptalModeWidgets[rtype] = (sthr, srel)
        self._make_collapsible(adv, collapsed=True)
        layout.addWidget(adv)

        self.ptalPedBox = QGroupBox("Rete pedonale (per la modalità su rete)")
        pedf = QVBoxLayout(self.ptalPedBox)
        ped = QHBoxLayout()
        self.ptalRoadCombo = QgsMapLayerComboBox()
        self.ptalRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.ptalRoadCombo.setAllowEmptyLayer(True)
        ped.addWidget(self.ptalRoadCombo, 1)
        ped.addWidget(self._osm_button(self.ptalRoadCombo, "pedestrian"))
        pedf.addLayout(ped)
        note = QLabel("Distanze a piedi reali sulla rete. <i>Nota:</i> non "
                      "conforme allo standard TfL (linea d'aria).")
        note.setWordWrap(True)
        pedf.addWidget(note)
        self.ptalPedBox.setVisible(False)
        layout.addWidget(self.ptalPedBox)
        self.ptalRunButton = QPushButton("Calcola PTAL")
        self.ptalRunButton.clicked.connect(self._ptal_run)
        layout.addWidget(self.ptalRunButton)

        gap_box = QGroupBox("Gap analysis (PTAL basso + popolazione alta)")
        gf = QFormLayout(gap_box)
        self.gapPopCombo = QgsMapLayerComboBox()
        self.gapPopCombo.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        gf.addRow("Popolazione:", self.gapPopCombo)
        self.gapPopField = QgsFieldComboBox()
        self.gapPopField.setAllowEmptyFieldName(True)
        self.gapPopCombo.layerChanged.connect(self.gapPopField.setLayer)
        self.gapPopField.setLayer(self.gapPopCombo.currentLayer())
        gf.addRow("Campo popolazione:", self.gapPopField)
        self.gapButton = QPushButton("Gap analysis (sull'ultimo PTAL a celle)")
        self.gapButton.clicked.connect(self._gap_run)
        gf.addRow(self.gapButton)
        layout.addWidget(gap_box)

        self.ptalStatus = QLabel("")
        self.ptalStatus.setWordWrap(True)
        layout.addWidget(self.ptalStatus)
        layout.addStretch()
        return container

    def _build_spacesyntax_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("spacesyntax"))
        form = QFormLayout()
        self.ssRoadCombo = QgsMapLayerComboBox()
        self.ssRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Rete stradale:", self._combo_with_osm(self.ssRoadCombo))
        self.ssRadius = QSpinBox()
        self.ssRadius.setRange(0, 50)
        self.ssRadius.setValue(0)
        self.ssRadius.setSpecialValueText("Globale (Rn)")
        self.ssRadius.setPrefix("R")
        form.addRow("Raggio:", self.ssRadius)
        layout.addLayout(form)
        msg = QLabel("Calcola: connettivita, profondita media/totale, "
                     "integrazione (HH), choice, NAIN, NACH.")
        msg.setWordWrap(True)
        layout.addWidget(msg)
        self.ssRunButton = QPushButton("Calcola space syntax")
        self.ssRunButton.clicked.connect(self._ss_run)
        layout.addWidget(self.ssRunButton)
        self.ssStatus = QLabel("")
        self.ssStatus.setWordWrap(True)
        layout.addWidget(self.ssStatus)
        layout.addStretch()
        return container

    def _build_od_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("od"))
        form = QFormLayout()
        self.odZonesCombo = QgsMapLayerComboBox()
        self.odZonesCombo.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Zone:", self.odZonesCombo)
        self.odIdField = QgsFieldComboBox()
        self.odZonesCombo.layerChanged.connect(self.odIdField.setLayer)
        self.odIdField.setLayer(self.odZonesCombo.currentLayer())
        form.addRow("Campo ID zona:", self.odIdField)
        layout.addLayout(form)
        csv_row = QHBoxLayout()
        self.odCsvEdit = QLineEdit()
        self.odCsvEdit.setPlaceholderText("Matrice OD (CSV)")
        csv_btn = QPushButton("...")
        csv_btn.clicked.connect(self._od_browse_csv)
        csv_row.addWidget(self.odCsvEdit, 1)
        csv_row.addWidget(csv_btn)
        layout.addLayout(csv_row)
        cols = QFormLayout()
        self.odColO = QLineEdit("origin")
        self.odColD = QLineEdit("destination")
        self.odColV = QLineEdit("count")
        cols.addRow("Colonna origine:", self.odColO)
        cols.addRow("Colonna destinazione:", self.odColD)
        cols.addRow("Colonna valore:", self.odColV)
        layout.addLayout(cols)
        filt = QGroupBox("Filtri")
        ff = QFormLayout(filt)
        self.odMinFlow = QSpinBox()
        self.odMinFlow.setRange(0, 1000000)
        self.odMinFlow.setValue(0)
        ff.addRow("Flusso minimo:", self.odMinFlow)
        self.odTopN = QSpinBox()
        self.odTopN.setRange(0, 100000)
        self.odTopN.setValue(0)
        self.odTopN.setSpecialValueText("tutte")
        ff.addRow("Top N (per flusso):", self.odTopN)
        self.odFilterO = QLineEdit()
        self.odFilterO.setPlaceholderText("(opz.) solo da questa origine")
        ff.addRow("Solo origine:", self.odFilterO)
        self.odFilterD = QLineEdit()
        self.odFilterD.setPlaceholderText("(opz.) solo verso questa destinazione")
        ff.addRow("Solo destinazione:", self.odFilterD)
        layout.addWidget(filt)
        self.odArc = QCheckBox("Linee arcuate (curve, separano andata/ritorno)")
        self.odArc.setChecked(True)
        layout.addWidget(self.odArc)
        self.odRunButton = QPushButton("Crea desire lines")
        self.odRunButton.clicked.connect(self._od_run)
        layout.addWidget(self.odRunButton)

        tm = QGroupBox("Matrice tempi via trasporto pubblico (GTFS)")
        tf = QFormLayout(tm)
        tr = QHBoxLayout()
        self.odTmGtfs = QLineEdit()
        self.odTmGtfs.setPlaceholderText(
            "(vuoto = usa il GTFS caricato nella scheda GTFS)")
        tb = QPushButton("Sfoglia...")
        tb.clicked.connect(self._od_tm_browse)
        tr.addWidget(self.odTmGtfs, 1)
        tr.addWidget(tb)
        tf.addRow("GTFS:", self._wrap(tr))
        self.odTmStart = QSpinBox()
        self.odTmStart.setRange(0, 23)
        self.odTmStart.setValue(8)
        tf.addRow("Ora partenza:", self.odTmStart)
        self.odTmBudget = QSpinBox()
        self.odTmBudget.setRange(5, 240)
        self.odTmBudget.setValue(60)
        self.odTmBudget.setSuffix(" min")
        tf.addRow("Budget:", self.odTmBudget)
        self.odTmButton = QPushButton("Calcola matrice tempi TP")
        self.odTmButton.clicked.connect(self._od_matrix_run)
        tf.addRow(self.odTmButton)
        layout.addWidget(tm)

        self.odStatus = QLabel("")
        self.odStatus.setWordWrap(True)
        layout.addWidget(self.odStatus)
        layout.addStretch()
        return container

    def _build_access_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("access"))
        form = QFormLayout()
        self.accOriginCombo = QgsMapLayerComboBox()
        self.accOriginCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        form.addRow("Origini (punti):", self.accOriginCombo)
        self.accDestCombo = QgsMapLayerComboBox()
        self.accDestCombo.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Destinazioni:", self.accDestCombo)
        self.accWeightField = QgsFieldComboBox()
        self.accWeightField.setAllowEmptyFieldName(True)
        self.accDestCombo.layerChanged.connect(self.accWeightField.setLayer)
        self.accWeightField.setLayer(self.accDestCombo.currentLayer())
        form.addRow("Campo peso (opz.):", self.accWeightField)
        self.accModeCombo = QComboBox()
        self.accModeCombo.addItem("A piedi", 4.5)
        self.accModeCombo.addItem("Bici", 15.0)
        self.accModeCombo.addItem("Auto", 30.0)
        self.accModeCombo.addItem("Trasporto pubblico (GTFS)", "pt")
        form.addRow("Modo:", self.accModeCombo)
        self.accRoadCombo = QgsMapLayerComboBox()
        self.accRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.accRoadCombo.setAllowEmptyLayer(True)
        form.addRow("Rete (per modi su strada):",
                    self._combo_with_osm(self.accRoadCombo, self._acc_osm_mode))
        self.accOneway = QCheckBox("Rispetta i sensi unici (campo «oneway»)")
        form.addRow("", self.accOneway)
        gr = QHBoxLayout()
        self.accGtfsEdit = QLineEdit()
        self.accGtfsEdit.setPlaceholderText(
            "(vuoto = usa il GTFS caricato nella scheda GTFS)")
        gbtn = QPushButton("Sfoglia...")
        gbtn.clicked.connect(self._acc_browse_gtfs)
        gr.addWidget(self.accGtfsEdit, 1)
        gr.addWidget(gbtn)
        form.addRow("GTFS (TP):", self._wrap(gr))
        self.accStartH = QSpinBox()
        self.accStartH.setRange(0, 23)
        self.accStartH.setValue(8)
        form.addRow("Ora partenza (TP):", self.accStartH)
        self.accTimes = QLineEdit("15,30")
        form.addRow("Tempi (min):", self.accTimes)
        layout.addLayout(form)

        self.accPtBox = QGroupBox("Opzioni multimodali (TP)")
        apf = QFormLayout(self.accPtBox)
        self.accAccessMode = self._pt_leg_combo()
        apf.addRow("Accesso alle fermate:", self.accAccessMode)
        self.accEgressMode = self._pt_leg_combo()
        apf.addRow("Egress dalle fermate:", self.accEgressMode)
        self.accTransferPen = QSpinBox()
        self.accTransferPen.setRange(0, 30)
        self.accTransferPen.setValue(0)
        self.accTransferPen.setSuffix(" min")
        apf.addRow("Penalità trasferimento:", self.accTransferPen)
        self.accPtBox.setVisible(False)
        self.accModeCombo.currentIndexChanged.connect(self._acc_mode_changed)
        layout.addWidget(self.accPtBox)

        self.accRunButton = QPushButton("Calcola accessibilità")
        self.accRunButton.clicked.connect(self._acc_run)
        layout.addWidget(self.accRunButton)
        self.accStatus = QLabel("")
        self.accStatus.setWordWrap(True)
        layout.addWidget(self.accStatus)

        eq_box = QGroupBox("Metriche di sintesi & equità")
        eqf = QFormLayout(eq_box)
        self.eqLayerCombo = QgsMapLayerComboBox()
        self.eqLayerCombo.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        eqf.addRow("Layer (accessibilità/PTAL):", self.eqLayerCombo)
        self.eqValueField = QgsFieldComboBox()
        self.eqLayerCombo.layerChanged.connect(self.eqValueField.setLayer)
        self.eqValueField.setLayer(self.eqLayerCombo.currentLayer())
        eqf.addRow("Campo valore:", self.eqValueField)
        self.eqWeightField = QgsFieldComboBox()
        self.eqWeightField.setAllowEmptyFieldName(True)
        self.eqLayerCombo.layerChanged.connect(self.eqWeightField.setLayer)
        self.eqWeightField.setLayer(self.eqLayerCombo.currentLayer())
        eqf.addRow("Campo peso/popolazione (opz.):", self.eqWeightField)
        self.eqThreshold = QDoubleSpinBox()
        self.eqThreshold.setRange(0, 1e9)
        self.eqThreshold.setDecimals(2)
        self.eqThreshold.setValue(3)
        eqf.addRow("Soglia «servito» (valore ≥):", self.eqThreshold)
        eq_btns = QHBoxLayout()
        self.eqRunButton = QPushButton("Calcola metriche")
        self.eqRunButton.clicked.connect(self._eq_run)
        self.eqChartButton = QPushButton("Grafico Lorenz")
        self.eqChartButton.setEnabled(False)
        self.eqChartButton.clicked.connect(self._eq_chart)
        self.eqExportButton = QPushButton("Esporta Excel")
        self.eqExportButton.setEnabled(False)
        self.eqExportButton.clicked.connect(self._eq_export)
        eq_btns.addWidget(self.eqRunButton)
        eq_btns.addWidget(self.eqChartButton)
        eq_btns.addWidget(self.eqExportButton)
        eqf.addRow(self._wrap(eq_btns))
        self.eqTable = self._make_table()
        eqf.addRow(self.eqTable)
        eq_box.setLayout(eqf)
        layout.addWidget(eq_box)
        self.eqStatus = QLabel("")
        self.eqStatus.setWordWrap(True)
        layout.addWidget(self.eqStatus)

        cmp_box = QGroupBox("Confronto scenari (B − A)")
        cf = QFormLayout(cmp_box)
        self.cmpLayerA = QgsMapLayerComboBox()
        self.cmpLayerA.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        cf.addRow("Scenario A:", self.cmpLayerA)
        self.cmpFieldA = QgsFieldComboBox()
        self.cmpLayerA.layerChanged.connect(self.cmpFieldA.setLayer)
        self.cmpFieldA.setLayer(self.cmpLayerA.currentLayer())
        cf.addRow("Campo A:", self.cmpFieldA)
        self.cmpLayerB = QgsMapLayerComboBox()
        self.cmpLayerB.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        cf.addRow("Scenario B:", self.cmpLayerB)
        self.cmpFieldB = QgsFieldComboBox()
        self.cmpLayerB.layerChanged.connect(self.cmpFieldB.setLayer)
        self.cmpFieldB.setLayer(self.cmpLayerB.currentLayer())
        cf.addRow("Campo B:", self.cmpFieldB)
        self.cmpMaxDist = QDoubleSpinBox()
        self.cmpMaxDist.setRange(0, 1e6)
        self.cmpMaxDist.setValue(0)
        self.cmpMaxDist.setSuffix(" m")
        self.cmpMaxDist.setSpecialValueText("nessun limite")
        cf.addRow("Distanza max abbinamento:", self.cmpMaxDist)
        self.cmpButton = QPushButton("Calcola differenza (B − A)")
        self.cmpButton.clicked.connect(self._cmp_run)
        cf.addRow(self.cmpButton)
        self.cmpStatus = QLabel("")
        self.cmpStatus.setWordWrap(True)
        cf.addRow(self.cmpStatus)
        layout.addWidget(cmp_box)

        scn_box = QGroupBox("Scenario A/B — confronto fra due reti")
        sf = QFormLayout(scn_box)
        sf.addRow(QLabel("Usa Origini/Destinazioni/Modo/Tempi qui sopra. "
                         "Confronta due reti (es. stato attuale vs progetto)."))
        self.scnKind = QComboBox()
        self.scnKind.addItem("Accessibilità (origini → destinazioni)", "acc")
        self.scnKind.addItem("Isocrone (area raggiungibile, differenza "
                             "geometrica)", "iso")
        sf.addRow("Tipo confronto:", self.scnKind)
        self.scnRoadA = QgsMapLayerComboBox()
        self.scnRoadA.setFilters(QgsMapLayerProxyModel.LineLayer)
        sf.addRow("Rete A (attuale):", self._combo_with_osm(self.scnRoadA, "all"))
        self.scnRoadB = QgsMapLayerComboBox()
        self.scnRoadB.setFilters(QgsMapLayerProxyModel.LineLayer)
        sf.addRow("Rete B (progetto):", self._combo_with_osm(self.scnRoadB, "all"))
        self.scnButton = QPushButton("Confronta scenari A/B")
        self.scnButton.clicked.connect(self._scn_run)
        sf.addRow(self.scnButton)
        self.scnStatus = QLabel("")
        self.scnStatus.setWordWrap(True)
        sf.addRow(self.scnStatus)
        layout.addWidget(scn_box)
        layout.addStretch()
        return container

    @staticmethod
    def _wrap(layout):
        w = QWidget()
        w.setLayout(layout)
        return w

    @staticmethod
    def _pt_leg_combo():
        c = QComboBox()
        c.addItem("A piedi", 4.5)
        c.addItem("In bici", 15.0)
        return c

    @staticmethod
    def _pt_leg_params(combo):
        """(velocità km/h, raggio max m) del modo di accesso/egress al TP."""
        speed = float(combo.currentData())
        radius = 3000.0 if speed >= 15 else 800.0
        return speed, radius

    def _preflight_net(self, roads, directions, coords):
        """Controllo rapido prima delle analisi su rete.

        :return: (ok_to_run, messaggio). Blocca se NESSUNA sorgente aggancia la
            rete; avvisa (senza bloccare) se alcune non agganciano o sono su una
            componente isolata. Saltato su reti molto grandi.
        """
        return network_diagnostics.preflight(roads, directions, coords)

    @staticmethod
    def _road_spec(layer, ctx, respect_oneway=False, clip_wgs=None,
                   radius_m=0.0):
        """Rete da leggere in un task (GtfsIsoTask): sorgente di feature
        thread-safe + CRS + contesto di trasformazione + sensi unici.

        Con `clip_wgs` (ovest, sud, est, nord) il task legge solo le strade
        nel riquadro raggiungibile: riduce la rete alla parte utile invece di
        leggere e pulire tutto il layer (es. una città intera).
        """
        n_layer = max(0, layer.featureCount())
        spec = {"source": QgsVectorLayerFeatureSource(layer),
                "crs": layer.crs(), "ctx": ctx, "count": n_layer,
                "layer_count": n_layer, "radius_m": radius_m,
                "oneway": bool(respect_oneway
                               and "oneway" in layer.fields().names())}
        if clip_wgs is not None:
            try:
                rect = QgsCoordinateTransform(
                    isochrones.WGS84, layer.crs(), ctx).transformBoundingBox(
                    QgsRectangle(*clip_wgs))
            except Exception:
                rect = None  # CRS non trasformabile: si legge tutto
            if rect is not None:
                ext = layer.extent()
                inter = rect.intersect(ext)
                frac = (inter.area() / ext.area()) if ext.area() > 0 else 1.0
                spec["rect"] = rect
                # stima delle strade da leggere, solo per la barra
                spec["count"] = max(1, int(n_layer * min(1.0, frac)))
        return spec

    def _extract_roads(self, layer, ctx, respect_oneway=False, clean=True,
                       snap_tol_m=1.0):
        """Polilinee (lon,lat) di una rete + sensi unici + pulizia.

        Tutte le analisi su road network passano da qui: di default la rete
        viene PULITA (snap vertici, rimozione segmenti nulli/duplicati).

        :return: (roads, directions, stats) dove directions è None se non si
            rispettano i sensi unici; stats = dict di pulizia (o None).
        """
        ct = QgsCoordinateTransform(layer.crs(), isochrones.WGS84, ctx)
        has_ow = respect_oneway and ("oneway" in layer.fields().names())
        roads = []
        directions = [] if has_ow else None
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            d = 0
            if has_ow:
                # normalizza valori OSM testuali (yes/no/-1/reverse) e numerici
                d = osm_download._oneway_value(f["oneway"])
            if g.isMultipart():
                for part in g.asMultiPolyline():
                    roads.append([(p.x(), p.y()) for p in part])
                    if has_ow:
                        directions.append(d)
            else:
                roads.append([(p.x(), p.y()) for p in g.asPolyline()])
                if has_ow:
                    directions.append(d)
        if clean:
            roads, directions, stats = net_clean.clean_network(
                roads, snap_tol_m, directions)
            return roads, directions, stats
        return roads, directions, None

    # ------------------------------------------------------- rete da OSM
    def _osm_button(self, target_combo, mode="all"):
        """Bottone che scarica la rete stradale dell'inquadratura da OSM.

        `mode` puo' essere una stringa (all/pedestrian/bicycle/vehicular) o una
        callable che la restituisce (per modo dinamico in base al mezzo scelto).
        """
        btn = QPushButton("🌐 Rete da OSM (vista)")
        btn.setToolTip("Scarica dall'inquadratura corrente la rete stradale "
                       "da OpenStreetMap (filtrata per modo) e la imposta qui.")
        btn.clicked.connect(lambda: self._download_osm_roads(target_combo, mode))
        return btn

    def _combo_with_osm(self, combo, mode="all"):
        """Riga: combo layer + bottone 'Rete da OSM'."""
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(combo, 1)
        row.addWidget(self._osm_button(combo, mode))
        return self._wrap(row)

    def _iso_osm_mode(self):
        d = self.isoaModeCombo.currentData()
        if d == "pt":
            return "pedestrian"
        return {4.5: "pedestrian", 15.0: "bicycle",
                30.0: "vehicular"}.get(d, "all")

    def _acc_osm_mode(self):
        d = self.accModeCombo.currentData()
        if d == "pt":
            return "pedestrian"
        return {4.5: "pedestrian", 15.0: "bicycle",
                30.0: "vehicular"}.get(d, "all")

    def _download_osm_roads(self, target_combo, mode="all"):
        if self._osm_task is not None:
            self.iface.messageBar().pushInfo(
                "OSM", "Download della rete gia' in corso.")
            return
        mode = mode() if callable(mode) else mode
        canvas = self.iface.mapCanvas()
        ext = canvas.extent()
        crs = canvas.mapSettings().destinationCrs()
        ct = QgsCoordinateTransform(crs, isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        r = ct.transformBoundingBox(ext)
        south, west = r.yMinimum(), r.xMinimum()
        north, east = r.yMaximum(), r.xMaximum()
        if (north - south) * (east - west) > 0.25:
            res = QMessageBox.question(
                self, "Inquadratura ampia",
                "L'inquadratura e' molto ampia: il download da OSM puo' essere "
                "lento o fallire. Conviene zoomare di piu'.\n\nContinuare comunque?")
            if res != QMessageBox.Yes:
                return
        self._osm_target = target_combo
        self._osm_mode = mode
        task = OsmRoadsTask((south, west, north, east), mode)
        self._osm_task = task
        task.taskCompleted.connect(lambda t=task: self._osm_done(t))
        task.taskTerminated.connect(lambda t=task: self._osm_failed(t))
        label = osm_download.MODE_LABEL.get(mode, "completa")
        self.iface.messageBar().pushInfo(
            "OSM", "Scarico la rete stradale (%s) dell'inquadratura..." % label)
        QgsApplication.taskManager().addTask(task)

    def _osm_done(self, task):
        target = self._osm_target
        mode = getattr(self, "_osm_mode", "all")
        self._osm_task = None
        self._osm_target = None
        ways = task.result or []
        if not ways:
            self.iface.messageBar().pushWarning(
                "OSM", "Nessuna strada trovata nell'inquadratura.")
            return
        label = osm_download.MODE_LABEL.get(mode, "completa")
        layer = osm_download.build_roads_layer(
            ways, name="OSM - Rete %s" % label)
        self._add_output(layer)
        if target is not None:
            target.setLayer(layer)
        src = "da cache" if getattr(task, "from_cache", False) else "scaricata"
        self.iface.messageBar().pushSuccess(
            "OSM", "Rete %s OSM %s: %d strade." % (label, src, len(ways)))

    def _osm_failed(self, task):
        self._osm_task = None
        self._osm_target = None
        if getattr(task, "cancelled", False):
            self.iface.messageBar().pushInfo("OSM", "Download annullato.")
        else:
            self.iface.messageBar().pushWarning(
                "OSM", "Errore download OSM: %s" % task.exception)

    def _download_osm_crossings(self):
        if self._osm_cross_task is not None:
            self.iface.messageBar().pushInfo("OSM", "Download gia' in corso.")
            return
        canvas = self.iface.mapCanvas()
        ct = QgsCoordinateTransform(
            canvas.mapSettings().destinationCrs(), isochrones.WGS84,
            QgsProject.instance().transformContext())
        r = ct.transformBoundingBox(canvas.extent())
        if (r.yMaximum() - r.yMinimum()) * (r.xMaximum() - r.xMinimum()) > 0.25:
            if QMessageBox.question(
                    self, "Inquadratura ampia",
                    "L'inquadratura e' molto ampia: il download da OSM puo' "
                    "essere lento o fallire.\n\nContinuare comunque?"
                    ) != QMessageBox.Yes:
                return
        task = OsmCrossingsTask((r.yMinimum(), r.xMinimum(),
                                 r.yMaximum(), r.xMaximum()))
        self._osm_cross_task = task
        task.taskCompleted.connect(lambda t=task: self._osm_cross_done(t))
        task.taskTerminated.connect(lambda t=task: self._osm_cross_failed(t))
        self.iface.messageBar().pushInfo(
            "OSM", "Scarico gli attraversamenti pedonali dell'inquadratura...")
        QgsApplication.taskManager().addTask(task)

    def _osm_cross_done(self, task):
        self._osm_cross_task = None
        pts = task.result or []
        if not pts:
            self.iface.messageBar().pushWarning(
                "OSM", "Nessun attraversamento trovato nell'inquadratura.")
            return
        layer = osm_download.build_points_layer(pts)
        self._add_output(layer, zoom=False)
        self.walkCross.setLayer(layer)
        src = "da cache" if getattr(task, "from_cache", False) else "scaricati"
        self.iface.messageBar().pushSuccess(
            "OSM", "Attraversamenti OSM %s: %d." % (src, len(pts)))

    def _osm_cross_failed(self, task):
        self._osm_cross_task = None
        if getattr(task, "cancelled", False):
            self.iface.messageBar().pushInfo("OSM", "Download annullato.")
        else:
            self.iface.messageBar().pushWarning(
                "OSM", "Errore download attraversamenti: %s" % task.exception)

    def _make_collapsible(self, groupbox, collapsed=True):
        """Rende un QGroupBox checkable che nasconde il contenuto quando off."""
        groupbox.setCheckable(True)

        def _toggle(on):
            for child in groupbox.findChildren(QWidget):
                child.setVisible(on)

        groupbox.toggled.connect(_toggle)
        groupbox.setChecked(not collapsed)
        if collapsed:
            _toggle(False)
        return groupbox

    # ------------------------------------------------- output (gruppo + zoom)
    OUTPUT_GROUP = "MIC - Utilities"

    def _add_output(self, layer, zoom=True):
        """Aggiunge un layer di risultato al gruppo 'MIC - Utilities' e zooma."""
        proj = QgsProject.instance()
        proj.addMapLayer(layer, False)
        root = proj.layerTreeRoot()
        grp = root.findGroup(self.OUTPUT_GROUP)
        if grp is None:
            grp = root.insertGroup(0, self.OUTPUT_GROUP)
        grp.insertLayer(0, layer)
        if zoom:
            self._zoom_to(layer)
        return layer

    def _zoom_to(self, layer):
        try:
            from qgis.core import QgsWkbTypes
            if layer.geometryType() == QgsWkbTypes.NullGeometry:
                return
            ext = layer.extent()
            if ext is None or ext.isEmpty() or ext.isNull():
                return
            canvas = self.iface.mapCanvas()
            ct = QgsCoordinateTransform(
                layer.crs(), canvas.mapSettings().destinationCrs(),
                QgsProject.instance().transformContext())
            canvas.setExtent(ct.transformBoundingBox(ext))
            canvas.refresh()
        except Exception:
            pass

    def _global_gtfs(self):
        """Sorgente GTFS globale (impostata nella scheda GTFS)."""
        return self.gtfsSourceEdit.text().strip()

    def _service_date(self):
        """Data servizio globale (YYYYMMDD) o None."""
        s = self.gtfsServiceDate.text().strip()
        return s if (len(s) == 8 and s.isdigit()) else None

    def _gtfs_validate(self):
        source = self._global_gtfs()
        if not source:
            self._gtfs_set_status("Indica un feed GTFS da validare.", error=True)
            return
        try:
            ok, msgs, _info = gtfs_static.validate_feed(source)
        except Exception as exc:
            self._gtfs_set_status(f"Errore validazione: {exc}", error=True)
            return
        self._gtfs_set_status(("✅ " if ok else "⚠️ ") + " ".join(msgs),
                              error=not ok)

    def _gtfs_override_box(self, edit, browse_cb):
        """Box collassato per puntare a un feed GTFS diverso dal globale."""
        box = QGroupBox("Sorgente GTFS alternativa")
        f = QFormLayout(box)
        note = QLabel("Di default si usa il feed GTFS caricato nella scheda "
                      "<b>GTFS</b>. Imposta qui un feed diverso solo se serve.")
        note.setWordWrap(True)
        f.addRow(note)
        row = QHBoxLayout()
        row.addWidget(edit, 1)
        b = QPushButton("Sfoglia...")
        b.clicked.connect(browse_cb)
        row.addWidget(b)
        f.addRow("Feed (.zip):", self._wrap(row))
        self._make_collapsible(box, collapsed=True)
        return box

    @staticmethod
    def _make_table():
        table = QTableWidget()
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.horizontalHeader().setStretchLastSection(True)
        return table

    def _status(self, text, error=False):
        color = "#b00020" if error else "#1b5e20"
        self.statusLabel.setStyleSheet(f"color: {color};")
        self.statusLabel.setText(text)

    # ------------------------------------------------------------- analisi
    def run_analysis(self):
        layer = self.roadLayerCombo.currentLayer()
        if layer is None:
            self._status("Seleziona un layer di rete stradale.", error=True)
            return

        type_field = self.typeFieldCombo.currentField() or None
        area_layer = self.areaLayerCombo.currentLayer()

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            da = analysis.distance_area(layer)
            lengths = analysis.compute_lengths_by_type(layer, type_field, da)
            types, matrix, unique_nodes = analysis.compute_intersection_matrix(
                layer, type_field
            )
            area_m2 = analysis.compute_area(area_layer)
            total_inter = sum(matrix.values())
            ratios = analysis.compute_ratios(lengths, total_inter, area_m2)
            ratios["total_intersections_pairwise"] = total_inter
            ratios["unique_intersection_nodes"] = unique_nodes
        except Exception as exc:  # pragma: no cover - feedback all'utente
            self._status(f"Errore durante l'analisi: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()

        all_types = sorted(set(lengths) | set(types))
        self._results = {
            "lengths": lengths,
            "types": all_types,
            "matrix": matrix,
            "ratios": ratios,
        }
        self._populate_lengths(lengths)
        self._populate_matrix(all_types, matrix)
        self._populate_ratios(ratios)
        self.exportButton.setEnabled(True)
        self._status(
            f"Analisi completata: {len(all_types)} tipologie, "
            f"{total_inter} incroci ({unique_nodes} nodi unici)."
        )

    # --------------------------------------------------------- popolamento
    def _populate_lengths(self, lengths):
        total = sum(lengths.values()) or 1.0
        table = self.lengthTable
        table.clear()
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(
            ["Tipologia", "Lunghezza (m)", "Lunghezza (km)", "% sul totale"]
        )
        rows = sorted(lengths.items(), key=lambda kv: kv[1], reverse=True)
        table.setRowCount(len(rows) + 1)
        for r, (typ, length_m) in enumerate(rows):
            table.setItem(r, 0, QTableWidgetItem(str(typ)))
            table.setItem(r, 1, self._num(length_m))
            table.setItem(r, 2, self._num(length_m / 1000.0))
            table.setItem(r, 3, self._num(100.0 * length_m / total, suffix=" %"))
        last = len(rows)
        table.setItem(last, 0, QTableWidgetItem("TOTALE"))
        table.setItem(last, 1, self._num(sum(lengths.values())))
        table.setItem(last, 2, self._num(sum(lengths.values()) / 1000.0))
        table.setItem(last, 3, self._num(100.0))
        table.resizeColumnsToContents()

    def _populate_matrix(self, types, matrix):
        table = self.matrixTable
        table.clear()
        n = len(types)
        table.setColumnCount(n)
        table.setRowCount(n)
        table.setHorizontalHeaderLabels(types)
        table.setVerticalHeaderLabels(types)
        for i, t1 in enumerate(types):
            for j, t2 in enumerate(types):
                count = matrix.get(tuple(sorted((t1, t2))), 0)
                item = QTableWidgetItem(str(count))
                item.setTextAlignment(Qt.AlignCenter)
                table.setItem(i, j, item)
        table.resizeColumnsToContents()

    def _populate_ratios(self, ratios):
        table = self.ratiosTable
        table.clear()
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(["Indicatore", "Valore"])
        present = [(k, lbl) for k, lbl in RATIO_LABELS if k in ratios]
        table.setRowCount(len(present))
        for r, (key, label) in enumerate(present):
            table.setItem(r, 0, QTableWidgetItem(label))
            value = ratios[key]
            decimals = 0 if key in (
                "total_intersections_pairwise",
                "unique_intersection_nodes",
            ) else 2
            table.setItem(r, 1, self._num(value, decimals=decimals))
        table.resizeColumnsToContents()

    @staticmethod
    def _num(value, decimals=2, suffix=""):
        item = QTableWidgetItem(f"{value:,.{decimals}f}{suffix}")
        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        return item

    # ----------------------------------------------------------- esporta
    def export_csv(self):
        if not self._results:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Esporta risultati", "analisi_rete_stradale.csv", "CSV (*.csv)"
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as fh:
                writer = csv.writer(fh, delimiter=";")

                writer.writerow(["# LUNGHEZZE PER TIPOLOGIA"])
                writer.writerow(["Tipologia", "Lunghezza_m", "Lunghezza_km"])
                for typ, length_m in sorted(self._results["lengths"].items()):
                    writer.writerow([typ, f"{length_m:.2f}", f"{length_m / 1000.0:.3f}"])

                writer.writerow([])
                writer.writerow(["# MATRICE INCROCI"])
                types = self._results["types"]
                writer.writerow([""] + types)
                for t1 in types:
                    row = [self._results["matrix"].get(tuple(sorted((t1, t2))), 0)
                           for t2 in types]
                    writer.writerow([t1] + row)

                writer.writerow([])
                writer.writerow(["# RAPPORTI"])
                for key, label in RATIO_LABELS:
                    if key in self._results["ratios"]:
                        writer.writerow([label, self._results["ratios"][key]])
            self._status(f"Risultati esportati in: {path}")
        except OSError as exc:
            QMessageBox.warning(self, "Errore esportazione", str(exc))

    # ------------------------------------------- preparazione & diagnostica
    def _prep_status(self, text, error=False):
        self.prepStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.prepStatus.setText(text)

    def _prepare_wizard(self, raw, dirs):
        """Procedura guidata: diagnosi → opzioni → anteprima/conferma.

        Calcola l'anteprima (noding) nello step 3 e la riusa al termine, così
        il noding viene eseguito una sola volta. Ritorna (seg, sdir, stats)
        oppure None se annullata.
        """
        wiz = QWizard(self)
        wiz.setWindowTitle("Prepara rete — procedura guidata")
        wiz.setWizardStyle(QWizard.ModernStyle)
        wiz.setOption(QWizard.NoBackButtonOnStartPage, True)
        state = {}

        # opzioni (condivise, mostrate nello step 2)
        snap = QDoubleSpinBox()
        snap.setRange(0.0, 50.0)
        snap.setValue(1.0)
        snap.setSuffix(" m")
        mseg = QDoubleSpinBox()
        mseg.setRange(0.0, 50.0)
        mseg.setValue(0.2)
        mseg.setSuffix(" m")
        split = QCheckBox("Noding alle intersezioni (consigliato)")
        split.setChecked(True)

        # --- step 1: diagnosi iniziale ---
        diag_lbl = QLabel("Analisi della rete in corso…")
        diag_lbl.setWordWrap(True)
        diag_lbl.setTextFormat(Qt.RichText)

        def _init_diag(_page):
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                rep = network_diagnostics.diagnose_network(raw, directions=dirs)
            except Exception as exc:
                QApplication.restoreOverrideCursor()
                diag_lbl.setText("Diagnosi non riuscita: %s" % exc)
                return
            QApplication.restoreOverrideCursor()
            st = rep["stats"]
            state["diag_before"] = st
            txt = ("<b>Stato attuale della rete</b><br>"
                   "Segmenti: %d &nbsp;·&nbsp; Nodi: %d<br>"
                   "Componenti connesse: <b>%d</b> (principale %.0f%%)<br>"
                   "Incroci non noded: %d &nbsp;·&nbsp; Vicoli ciechi: %d"
                   % (st["segmenti"], st["nodi"], st["componenti"],
                      st["pct_principale"], len(rep.get("crossings", [])),
                      len(rep.get("dead_ends", []))))
            if rep["issues"]:
                txt += ("<br><br>⚠️ "
                        + "<br>⚠️ ".join(i["message"] for i in rep["issues"]))
            else:
                txt += "<br><br>✅ Nessun problema rilevato."
            diag_lbl.setText(txt)

        p1 = _PrepPage(
            "1 · Diagnosi iniziale",
            "Controllo della rete selezionata prima della preparazione.",
            on_init=_init_diag)
        l1 = QVBoxLayout(p1)
        l1.addWidget(diag_lbl)
        l1.addStretch()
        wiz.addPage(p1)

        # --- step 2: opzioni ---
        p2 = _PrepPage("2 · Opzioni",
                       "Tolleranza di snap e noding alle intersezioni.")
        f2 = QFormLayout(p2)
        f2.addRow("Tolleranza snap:", snap)
        f2.addRow("Lunghezza minima segmento:", mseg)
        f2.addRow("", split)
        wiz.addPage(p2)

        # --- step 3: anteprima e conferma ---
        prev_lbl = QLabel("")
        prev_lbl.setWordWrap(True)
        prev_lbl.setTextFormat(Qt.RichText)

        def _init_prev(page):
            state.pop("prepared", None)
            page.completeChanged.emit()
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                seg, sdir, stats = network_prepare.node_network(
                    raw, snap.value(), mseg.value(), dirs,
                    split=split.isChecked())
                rep2 = network_diagnostics.diagnose_network(seg,
                                                            directions=sdir)
            except Exception as exc:
                QApplication.restoreOverrideCursor()
                prev_lbl.setText("Anteprima non riuscita: %s" % exc)
                page.completeChanged.emit()
                return
            QApplication.restoreOverrideCursor()
            state["prepared"] = (seg, sdir, stats)
            before = state.get("diag_before", {})
            st2 = rep2["stats"]
            prev_lbl.setText(
                network_prepare.prepare_summary(stats) + "<br><br>"
                "<b>Componenti connesse:</b> %s → <b>%d</b> "
                "(principale %.0f%%)<br><br>"
                "Premi <b>Fine</b> per creare la rete preparata e impostarla "
                "come rete stradale corrente."
                % (before.get("componenti", "?"), st2["componenti"],
                   st2["pct_principale"]))
            page.completeChanged.emit()

        p3 = _PrepPage("3 · Anteprima e conferma",
                       "Risultato del noding prima di applicarlo alla mappa.",
                       on_init=_init_prev,
                       is_complete=lambda: "prepared" in state)
        l3 = QVBoxLayout(p3)
        l3.addWidget(prev_lbl)
        l3.addStretch()
        wiz.addPage(p3)
        wiz.setButtonText(QWizard.FinishButton, "Fine — crea rete preparata")

        if wiz.exec_() != QWizard.Accepted:
            return None
        return state.get("prepared")

    def _prepare_run(self):
        road = self.roadLayerCombo.currentLayer()
        if road is None:
            self._prep_status("Seleziona la rete stradale in alto.", error=True)
            return
        if road.featureCount() > 60000:
            if QMessageBox.question(
                    self, "Rete grande",
                    "La rete ha %d feature: il noding può essere lento. "
                    "Continuare?" % road.featureCount()) != QMessageBox.Yes:
                return
        ctx = QgsProject.instance().transformContext()
        raw, dirs, _ = self._extract_roads(road, ctx, respect_oneway=True,
                                           clean=False)
        prepared = self._prepare_wizard(raw, dirs)
        if prepared is None:
            return
        seg, sdir, stats = prepared
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            layer = net_layers.build_prepared_layer(seg, sdir)
        except Exception as exc:
            self._prep_status(f"Errore preparazione: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._add_output(layer)
        # imposta la rete preparata nei combo della categoria Rete stradale
        self.roadLayerCombo.setLayer(layer)
        self.ssRoadCombo.setLayer(layer)
        self._prep_status(network_prepare.prepare_summary(stats)
                          + " — impostata come rete stradale.")

    def _diag_run(self):
        road = self.roadLayerCombo.currentLayer()
        if road is None:
            self._prep_status("Seleziona la rete stradale in alto.", error=True)
            return
        ctx = QgsProject.instance().transformContext()
        raw, dirs, _ = self._extract_roads(road, ctx, respect_oneway=True,
                                           clean=False)
        sources = None
        slayer = self.diagSources.currentLayer()
        if slayer is not None:
            sources = [(la, lo) for la, lo, _ in self._acc_pts(slayer)]
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            rep = network_diagnostics.diagnose_network(
                raw, sources_latlon=sources, directions=dirs)
            comp = net_layers.build_components_layer(
                rep["segments"], rep["comp_of_seg"], rep["main_comp"])
            self._add_output(comp, zoom=False)
            if rep["crossings"]:
                cross = net_layers.build_points_diag_layer(
                    [(la, lo, {}) for la, lo in rep["crossings"]],
                    "MIC diagnostic - incroci non noded")
                self._add_output(cross, zoom=False)
            if sources and rep["snaps"].get("sources"):
                iso = [(s["lat"], s["lon"], {"component": s["component"]})
                       for s in rep["snaps"]["sources"]
                       if not s["snapped"] or s["component"] != rep["main_comp"]]
                if iso:
                    from qgis.PyQt.QtCore import QVariant
                    sl = net_layers.build_points_diag_layer(
                        iso, "MIC diagnostic - sorgenti isolate",
                        [("component", QVariant.Int)])
                    self._add_output(sl, zoom=False)
        except Exception as exc:
            self._prep_status(f"Errore diagnostica: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        st = rep["stats"]
        msg = ("Rete: %d segmenti, %d componenti (principale %.0f%%)."
               % (st["segmenti"], st["componenti"], st["pct_principale"]))
        if rep["issues"]:
            msg += " ⚠️ " + " ".join(i["message"] for i in rep["issues"])
        self._prep_status(msg, error=not rep["ok"])

    def _osm_presets_dialog(self):
        from qgis.core import QgsCoordinateTransform, QgsRectangle
        dlg = QDialog(self)
        dlg.setWindowTitle("Preset area OSM")
        lay = QVBoxLayout(dlg)
        combo = QComboBox()

        def _fill():
            combo.clear()
            for p in osm_cache.list_presets():
                combo.addItem("%s [%s]" % (p["name"], p.get("mode", "all")), p)
        _fill()
        row = QHBoxLayout()
        row.addWidget(QLabel("Preset:"))
        row.addWidget(combo, 1)
        go_btn = QPushButton("Vai")
        del_btn = QPushButton("Elimina")
        row.addWidget(go_btn)
        row.addWidget(del_btn)
        lay.addLayout(row)
        lay.addWidget(QLabel("Salva la vista corrente come:"))
        srow = QHBoxLayout()
        name_edit = QLineEdit()
        save_btn = QPushButton("Salva")
        srow.addWidget(name_edit, 1)
        srow.addWidget(save_btn)
        lay.addLayout(srow)
        close_btn = QPushButton("Chiudi")
        close_btn.clicked.connect(dlg.accept)
        lay.addWidget(close_btn)

        canvas = self.iface.mapCanvas()
        ctx = QgsProject.instance().transformContext()

        def _go():
            p = combo.currentData()
            if not p:
                return
            s, w, n, e = p["bbox"]
            ct = QgsCoordinateTransform(isochrones.WGS84,
                                        canvas.mapSettings().destinationCrs(), ctx)
            canvas.setExtent(ct.transformBoundingBox(QgsRectangle(w, s, e, n)))
            canvas.refresh()
            dlg.accept()

        def _save():
            nm = name_edit.text().strip()
            if not nm:
                return
            ct = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                        isochrones.WGS84, ctx)
            r = ct.transformBoundingBox(canvas.extent())
            osm_cache.save_preset(
                nm, (r.yMinimum(), r.xMinimum(), r.yMaximum(), r.xMaximum()))
            name_edit.clear()
            _fill()

        def _del():
            p = combo.currentData()
            if p:
                osm_cache.delete_preset(p["name"])
                _fill()

        go_btn.clicked.connect(_go)
        save_btn.clicked.connect(_save)
        del_btn.clicked.connect(_del)
        dlg.exec_()

    # ----------------------------------------------------------- walkability
    def _walk_status(self, text, error=False):
        self.walkStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.walkStatus.setText(text)

    def _walk_run(self):
        road = self.roadLayerCombo.currentLayer()
        if road is None:
            self._walk_status("Seleziona la rete stradale.", error=True)
            return
        ctx = QgsProject.instance().transformContext()
        roads, _d, cstats = self._extract_roads(road, ctx)
        ok, vmsg, info = net_iso.validate_network(roads)
        if not ok:
            self._walk_status("Rete non valida: " + vmsg, error=True)
            return
        zones = self.walkZones.currentLayer()
        zones_latlon = []
        if zones is not None:
            ct = QgsCoordinateTransform(zones.crs(), isochrones.WGS84, ctx)
            for f in zones.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ct)
                if g.isMultipart():
                    for poly in g.asMultiPolygon():
                        if poly:
                            zones_latlon.append([(p.y(), p.x()) for p in poly[0]])
                else:
                    poly = g.asPolygon()
                    if poly:
                        zones_latlon.append([(p.y(), p.x()) for p in poly[0]])
        else:
            s, w, n, e = info["bbox"]
            _cent, cells = grid_gen.build_grid(
                s, n, w, e, self.walkGridSize.value(), "square")
            zones_latlon = cells
        if not zones_latlon:
            self._walk_status("Nessuna zona valida.", error=True)
            return
        if len(zones_latlon) > 4000:
            self._walk_status("Troppe zone (%d): aumenta la cella o usa zone."
                              % len(zones_latlon), error=True)
            return
        # POI/destinazioni (opz.)
        pois = None
        poi_layer = self.walkPoi.currentLayer()
        if poi_layer is not None:
            catf = self.walkPoiCat.currentField() or None
            names = poi_layer.fields().names()
            ctp = QgsCoordinateTransform(poi_layer.crs(), isochrones.WGS84, ctx)
            pois = []
            for f in poi_layer.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ctp)
                p = g.centroid().asPoint()
                cat = (str(f[catf]) if catf and catf in names else None)
                pois.append((p.y(), p.x(), cat))
        # DEM per pendenza (opz.)
        elev_sampler = None
        dem = self.walkDem.currentLayer()
        if dem is not None:
            dp = dem.dataProvider()
            ctd = QgsCoordinateTransform(isochrones.WGS84, dem.crs(), ctx)

            def elev_sampler(lon, lat, _dp=dp, _ct=ctd):
                from qgis.core import QgsPointXY
                g = QgsGeometry.fromPointXY(QgsPointXY(lon, lat))
                g.transform(_ct)
                pt = g.asPoint()
                val, ok = _dp.sample(pt, 1)
                return val if ok else None

        # attraversamenti pedonali (opz.)
        crossings = None
        cross_layer = self.walkCross.currentLayer()
        if cross_layer is not None:
            ctc = QgsCoordinateTransform(cross_layer.crs(), isochrones.WGS84, ctx)
            crossings = []
            for f in cross_layer.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ctc)
                p = g.centroid().asPoint()
                crossings.append((p.y(), p.x()))
        dest_mode = "network" if self.walkDestNet.isChecked() else "crowfly"
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            results = walkability.compute_walkability(
                roads, zones_latlon, pois=pois,
                max_dest_m=self.walkDestM.value(), elev_sampler=elev_sampler,
                crossings=crossings, dest_mode=dest_mode)
            layer = gtfs_layers.build_walkability_layer(zones_latlon, results)
        except Exception as exc:
            self._walk_status(f"Errore walkability: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._add_output(layer)
        vals = [r["walkability"] for r in results]
        avg = sum(vals) / len(vals) if vals else 0.0
        dims = ["design"]
        if pois:
            dims.append("destinazioni" + (" su rete" if dest_mode == "network"
                                          else ""))
        if elev_sampler:
            dims.append("pendenza")
        if crossings:
            dims.append("attraversamenti")
        self._walk_status("Walkability su %d zone (media %.0f/100). Dimensioni: %s."
                          % (len(results), avg, " + ".join(dims)))

    # ===================================================================
    #                              GTFS
    # ===================================================================
    def _gtfs_set_status(self, text, error=False):
        self.gtfsStatus.setStyleSheet(f"color: {'#b00020' if error else '#1b5e20'};")
        self.gtfsStatus.setText(text)

    def _gtfs_live_status(self, text, error=False):
        self.gtfsLiveStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.gtfsLiveStatus.setText(text)

    def _gtfs_browse_zip(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleziona feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.gtfsSourceEdit.setText(path)

    def _gtfs_browse_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Seleziona cartella GTFS")
        if path:
            self.gtfsSourceEdit.setText(path)

    def _gtfs_read_routes(self):
        source = self.gtfsSourceEdit.text().strip()
        if not source:
            self._gtfs_set_status("Indica un feed GTFS (.zip o cartella).", error=True)
            return
        try:
            routes = gtfs_static.list_routes(source)
        except Exception as exc:
            self._gtfs_set_status(f"Errore lettura linee: {exc}", error=True)
            return
        self.gtfsRouteCombo.clear()
        self.gtfsRouteCombo.addItem("Tutte le linee", None)
        for r in routes:
            label = (r["short_name"] or r["route_id"])
            if r["long_name"]:
                label += " - " + r["long_name"]
            self.gtfsRouteCombo.addItem(label, r["route_id"])
        self._gtfs_set_status(
            "%d linee trovate. Scegline una per un caricamento leggero." % len(routes))

    def _gtfs_load(self):
        source = self.gtfsSourceEdit.text().strip()
        if not source:
            self._gtfs_set_status("Indica un feed GTFS (.zip o cartella).", error=True)
            return
        if self._load_task is not None:
            self._gtfs_set_status("Caricamento gia in corso...", error=True)
            return
        route_id = self.gtfsRouteCombo.currentData()
        route_ids = [route_id] if route_id else None
        task = GtfsLoadTask(source, route_ids=route_ids)
        self._load_task = task
        task.progressChanged.connect(self._gtfs_load_progress)
        task.taskCompleted.connect(lambda t=task: self._gtfs_load_done(t))
        task.taskTerminated.connect(lambda t=task: self._gtfs_load_terminated(t))
        self.gtfsLoadButton.setEnabled(False)
        self._gtfs_set_status("Caricamento GTFS in background... 0%")
        QgsApplication.taskManager().addTask(task)

    def _gtfs_load_progress(self, pct):
        self._gtfs_set_status("Caricamento GTFS in background... %d%%" % int(pct))

    def _gtfs_load_done(self, task):
        self._load_task = None
        self.gtfsLoadButton.setEnabled(True)
        self._gtfs = task.result
        self.gtfsSegButton.setEnabled(True)
        self.gtfsStartButton.setEnabled(True)
        self.gtfsScanButton.setEnabled(True)
        self.gtfsExcelButton.setEnabled(True)
        self.mmRunButton.setEnabled(True)
        # accumula nei layer unici (linee + metriche)
        self._acc["shapes"].update(self._gtfs["shapes_geom"])
        self._acc["shape_routes"].update(self._gtfs["shape_routes"])
        self._acc["routes"].update(self._gtfs["routes"])
        self._acc["line_metrics"].update(self._gtfs["line_metrics"])
        self._update_lines_layer()
        self._update_metrics_layer()
        self._populate_gtfs_lines()
        self._gtfs_set_status(
            "GTFS caricato e aggiunto: %d linee in totale, %d segmenti caricati."
            % (len(self._acc["line_metrics"]), len(self._gtfs["segments"])))

    def _update_lines_layer(self):
        layer = (QgsProject.instance().mapLayer(self._lines_layer_id)
                 if self._lines_layer_id else None)
        new = layer is None
        layer = gtfs_layers.update_lines_layer(layer, self._acc)
        if new:
            self._add_output(layer)
            self._lines_layer_id = layer.id()
        else:
            layer.triggerRepaint()

    def _update_metrics_layer(self):
        rt_lines = self._logger.line_results() if self._logger else {}
        layer = (QgsProject.instance().mapLayer(self._metrics_layer_id)
                 if self._metrics_layer_id else None)
        new = layer is None
        layer = gtfs_layers.update_metrics_layer(
            layer, self._acc["line_metrics"], rt_lines)
        if new:
            self._add_output(layer)
            self._metrics_layer_id = layer.id()

    def _gtfs_load_terminated(self, task):
        self._load_task = None
        self.gtfsLoadButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._gtfs_set_status("Caricamento GTFS annullato.")
        else:
            self._gtfs_set_status(
                f"Errore nel caricamento GTFS: {task.exception}", error=True)

    def _gtfs_create_segments(self):
        if not self._gtfs:
            return
        rt_stats = self._logger.segment_results() if self._logger else None
        if self._gtfs_seg_layer is not None:
            QgsProject.instance().removeMapLayer(self._gtfs_seg_layer)
        layer = gtfs_layers.build_segments_layer(self._gtfs, rt_stats)
        self._add_output(layer)
        self._gtfs_seg_layer = layer.id()
        self.gtfsHighlightButton.setEnabled(bool(rt_stats))
        suffix = " (con dati RT)" if rt_stats else ""
        self._gtfs_set_status(
            f"Layer segmenti creato ({layer.featureCount()} segmenti){suffix}.")

    def _gtfs_start_logging(self):
        if not self._gtfs:
            return
        url = self.gtfsRtUrlEdit.text().strip()
        if not url:
            self._gtfs_set_status("Indica l'URL del feed TripUpdates.", error=True)
            return
        self._logger = GtfsRealtimeLogger(
            url, self.gtfsIntervalSpin.value(), self._gtfs, self)
        self._logger.polled.connect(self._gtfs_on_poll)
        self._logger.failed.connect(self._gtfs_on_fail)
        self._logger.start()
        self.gtfsStartButton.setEnabled(False)
        self.gtfsStopButton.setEnabled(True)
        self.gtfsRtStatus.setText("Logging avviato...")

    def _gtfs_stop_logging(self):
        if self._logger:
            self._logger.stop()
        self.gtfsStartButton.setEnabled(True)
        self.gtfsStopButton.setEnabled(False)
        self.gtfsRtStatus.setText("Logging fermato.")

    def _gtfs_schedule_scan(self):
        if not self._gtfs:
            self.gtfsRtStatus.setText("Carica prima un GTFS.")
            return
        if not self.gtfsRtUrlEdit.text().strip():
            self.gtfsRtStatus.setStyleSheet("color: #b00020;")
            self.gtfsRtStatus.setText("Indica l'URL del feed TripUpdates.")
            return
        from qgis.PyQt.QtCore import QDateTime
        now = QDateTime.currentDateTime()
        target = QDateTime(now.date(), self.gtfsScanTime.time())
        if target <= now:
            target = target.addDays(1)  # se l'ora e' passata, domani
        ms = now.msecsTo(target)
        dur_min = self.gtfsScanDur.value()
        self._scan_timer = QTimer(self)
        self._scan_timer.setSingleShot(True)
        self._scan_timer.timeout.connect(lambda: self._gtfs_scan_fire(dur_min))
        self._scan_timer.start(ms)
        self.gtfsScanButton.setEnabled(False)
        self.gtfsScanCancel.setEnabled(True)
        self.gtfsRtStatus.setStyleSheet("color: #1b5e20;")
        self.gtfsRtStatus.setText(
            "Scansione programmata per %s (durata %d min)."
            % (target.toString("dd/MM HH:mm"), dur_min))

    def _gtfs_scan_fire(self, dur_min):
        self._gtfs_start_logging()
        stop_timer = QTimer(self)
        stop_timer.setSingleShot(True)
        stop_timer.timeout.connect(self._gtfs_stop_logging)
        stop_timer.start(int(dur_min) * 60 * 1000)
        self._scan_stop_timer = stop_timer
        self.gtfsScanButton.setEnabled(True)
        self.gtfsScanCancel.setEnabled(False)

    def _gtfs_cancel_scan(self):
        if self._scan_timer:
            self._scan_timer.stop()
        self.gtfsScanButton.setEnabled(True)
        self.gtfsScanCancel.setEnabled(False)
        self.gtfsRtStatus.setText("Scansione programmata annullata.")

    def _gtfs_on_poll(self, n_poll, n_obs, msg):
        self.gtfsRtStatus.setStyleSheet("color: #1b5e20;")
        self.gtfsRtStatus.setText(msg)
        self._populate_gtfs_lines()
        self._update_metrics_layer()

    def _gtfs_on_fail(self, msg):
        self.gtfsRtStatus.setStyleSheet("color: #b00020;")
        self.gtfsRtStatus.setText(f"Errore poll RT: {msg}")

    def _populate_gtfs_lines(self):
        metrics = self._acc["line_metrics"]
        if not metrics:
            return
        rt_lines = self._logger.line_results() if self._logger else {}
        table = self.gtfsLineTable
        table.clear()
        headers = ["Linea", "Dir", "Lunghezza (km)", "Commerciale prog. (km/h)",
                   "Esercizio prog. (km/h)", "Effettiva RT (km/h)",
                   "Sosta media (s)", "N corse"]
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        items = sorted(metrics.items())
        table.setRowCount(len(items))
        for r, (key, m) in enumerate(items):
            eff = rt_lines.get(key, {}).get("eff_speed_kmh")
            table.setItem(r, 0, QTableWidgetItem(str(m["route_short_name"] or m["route_id"])))
            table.setItem(r, 1, QTableWidgetItem(str(m["direction_id"])))
            table.setItem(r, 2, self._num(m["mean_length_m"] / 1000.0, decimals=2))
            table.setItem(r, 3, self._num(m["commercial_speed_kmh"]))
            table.setItem(r, 4, self._num(m["running_speed_kmh"]))
            table.setItem(r, 5, self._num(eff) if eff is not None
                          else QTableWidgetItem("-"))
            table.setItem(r, 6, self._num(m["mean_dwell_s"], decimals=0))
            table.setItem(r, 7, self._num(m["n_trips"], decimals=0))
        table.resizeColumnsToContents()

    def _gtfs_highlight(self):
        if self._gtfs_seg_layer is None:
            self._gtfs_live_status("Crea prima il layer segmenti con dati RT.", error=True)
            return
        layer = QgsProject.instance().mapLayer(self._gtfs_seg_layer)
        if layer is None:
            self._gtfs_live_status("Layer segmenti non trovato; ricrealo.", error=True)
            return
        styled = gtfs_layers.style_segments_by_deviation(layer)
        if styled == 0:
            self._gtfs_live_status(
                "Nessun segmento con dati RT: avvia il logging e ricrea il layer.",
                error=True)
            return
        selected = gtfs_layers.select_worst_segments(layer, self.gtfsTopNSpin.value())
        try:
            self.iface.layerTreeView().refreshLayerSymbology(layer.id())
        except Exception:
            pass
        self._gtfs_live_status(
            f"Evidenziati {styled} segmenti; selezionati i {selected} con divario "
            "maggiore (osservata << teorica).")

    def _gtfs_export_excel(self):
        if not self._gtfs:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Esporta Excel velocità", "velocita_linee.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        obs_hourly = self._logger.line_hourly() if self._logger else {}
        rt_lines = self._logger.line_results() if self._logger else {}
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            excel_report.write_line_speed_report(
                path, self._gtfs["line_metrics"], self._gtfs["line_hourly_sched"],
                obs_hourly, rt_lines)
        except Exception as exc:
            self._gtfs_live_status(f"Errore export Excel: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._gtfs_live_status(f"Excel esportato: {path}")

    def _gtfs_map_match(self):
        if not self._gtfs:
            return
        if self._match_task is not None:
            self._gtfs_set_status("Map-matching gia in corso...", error=True)
            return
        road_layer = self.mmRoadCombo.currentLayer()
        if road_layer is None:
            self._gtfs_set_status("Seleziona la rete stradale di destinazione.", error=True)
            return
        # letti nel thread principale e passati al task
        road_geoms = [(f.id(), QgsGeometry(f.geometry()))
                      for f in road_layer.getFeatures() if f.hasGeometry()]
        if not road_geoms:
            self._gtfs_set_status("La rete stradale non ha geometrie.", error=True)
            return
        seg_eff = self._logger.segment_results() if self._logger else {}
        task = GtfsMatchTask(
            self._gtfs["segments"], seg_eff, road_geoms, road_layer.crs(),
            QgsProject.instance().transformContext(),
            self.mmTolSpin.value(), self.mmAngleSpin.value(), self.mmSpacingSpin.value())
        self._match_task = task
        self._match_road_layer = road_layer
        task.progressChanged.connect(
            lambda p: self._gtfs_set_status("Map-matching... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._gtfs_match_done(t))
        task.taskTerminated.connect(lambda t=task: self._gtfs_match_failed(t))
        self.mmRunButton.setEnabled(False)
        self._gtfs_set_status("Map-matching in background... 0%")
        QgsApplication.taskManager().addTask(task)

    def _gtfs_match_done(self, task):
        self._match_task = None
        self.mmRunButton.setEnabled(True)
        results = task.result or {}
        layer = gtfs_layers.build_matched_roads_layer(self._match_road_layer, results)
        self._add_output(layer)
        n_rt = sum(1 for r in results.values() if r["v_eff"] is not None)
        self._gtfs_set_status(
            "Map-matching completato: %d strade con velocità trasporto "
            "(%d anche con dati RT)." % (len(results), n_rt))

    def _gtfs_match_failed(self, task):
        self._match_task = None
        self.mmRunButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._gtfs_set_status("Map-matching annullato.")
        else:
            self._gtfs_set_status(f"Errore map-matching: {task.exception}", error=True)

    # ----------------------------------------------------- Da linee a GTFS
    def _l2g_browse_out(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Salva GTFS", "gtfs_generato.zip", "GTFS zip (*.zip)")
        if path:
            self.l2gOutEdit.setText(path)

    def _l2g_generate(self):
        line_layer = self.l2gLineCombo.currentLayer()
        stops_layer = self.l2gStopsCombo.currentLayer()
        out_path = self.l2gOutEdit.text().strip()
        if line_layer is None or stops_layer is None:
            self._l2g_status("Seleziona il layer linee e il layer fermate.",
                             error=True)
            return
        if not out_path:
            self._l2g_status("Indica il file GTFS di output (.zip).", error=True)
            return
        params = {
            "agency_name": self.l2gAgency.text().strip() or "Agenzia",
            "route_type": self.l2gTypeCombo.currentData(),
            "speed_kmh": self.l2gSpeed.value(),
            "headway_min": self.l2gHeadway.value(),
            "start_h": self.l2gStart.value(),
            "end_h": self.l2gEnd.value(),
            "dwell_s": self.l2gDwell.value(),
            "snap_m": self.l2gSnap.value(),
            "route_field": self.l2gRouteField.currentField() or None,
            "stop_name_field": self.l2gStopField.currentField() or None,
        }
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            saved = gtfs_builder.build_gtfs_from_lines(
                line_layer, stops_layer, params, out_path,
                QgsProject.instance().transformContext())
        except Exception as exc:
            self._l2g_status(f"Errore generazione GTFS: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self.gtfsSourceEdit.setText(saved)
        self._l2g_status(
            f"GTFS generato: {saved}. Percorso impostato nella scheda GTFS.")

    def _l2g_status(self, text, error=False):
        self.l2gStatus.setStyleSheet(f"color: {'#b00020' if error else '#1b5e20'};")
        self.l2gStatus.setText(text)

    # ------------------------------------------------------- Space syntax
    def _ss_run(self):
        road_layer = self.ssRoadCombo.currentLayer()
        if road_layer is None:
            self._ss_status("Seleziona la rete stradale.", error=True)
            return
        nfeat = road_layer.featureCount()
        if nfeat > 6000:
            QMessageBox.warning(
                self, "Rete molto grande",
                "La rete ha %d tratti: il calcolo (betweenness) puo' essere "
                "molto lento. Conviene un'area piu' piccola." % nfeat)
        fids, adjacency = space_syntax.build_adjacency(road_layer)
        if not fids:
            self._ss_status("Nessun tratto valido nella rete.", error=True)
            return
        self._ss_road = road_layer
        self._ss_fids = fids
        task = SpaceSyntaxTask(adjacency, radius=self.ssRadius.value())
        self._ss_task = task
        task.progressChanged.connect(
            lambda p: self._ss_status("Calcolo space syntax... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._ss_done(t))
        task.taskTerminated.connect(lambda t=task: self._ss_failed(t))
        self.ssRunButton.setEnabled(False)
        self._ss_status("Calcolo space syntax in background... 0%%")
        QgsApplication.taskManager().addTask(task)

    def _ss_done(self, task):
        self.ssRunButton.setEnabled(True)
        layer = gtfs_layers.build_space_syntax_layer(
            self._ss_road, self._ss_fids, task.result)
        self._add_output(layer)
        self._ss_status(
            "Space syntax calcolato su %d tratti (campi: connettivita, "
            "profondita_media, integrazione, choice)." % len(self._ss_fids))

    def _ss_failed(self, task):
        self.ssRunButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._ss_status("Calcolo annullato.")
        else:
            self._ss_status(f"Errore space syntax: {task.exception}", error=True)

    def _ss_status(self, text, error=False):
        self.ssStatus.setStyleSheet(f"color: {'#b00020' if error else '#1b5e20'};")
        self.ssStatus.setText(text)

    # ---------------------------------------------------------------- OD
    def _od_browse_csv(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Matrice OD", "", "CSV (*.csv *.txt)")
        if path:
            self.odCsvEdit.setText(path)

    def _od_run(self):
        zones = self.odZonesCombo.currentLayer()
        idf = self.odIdField.currentField()
        csv_path = self.odCsvEdit.text().strip()
        if zones is None or not idf:
            self._od_status("Seleziona zone e campo ID.", error=True)
            return
        if not csv_path:
            self._od_status("Indica il file CSV della matrice OD.", error=True)
            return
        try:
            rows = self._od_read_csv(csv_path)
        except Exception as exc:
            self._od_status(f"Errore lettura CSV: {exc}", error=True)
            return
        rows = od_viz.filter_rows(
            rows, min_flow=self.odMinFlow.value(), top_n=self.odTopN.value(),
            origin=self.odFilterO.text().strip() or None,
            dest=self.odFilterD.text().strip() or None)
        if not rows:
            self._od_status("Nessuna riga OD valida (dopo i filtri).", error=True)
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            layer, n, missing = od_viz.build_desire_lines(
                zones, idf, rows, QgsProject.instance().transformContext(),
                arc=self.odArc.isChecked())
        except Exception as exc:
            self._od_status(f"Errore creazione desire lines: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._add_output(layer)
        self._od_status("Desire lines create: %d linee (%d coppie scartate)."
                        % (n, missing))

    def _od_read_csv(self, path):
        co = self.odColO.text().strip()
        cd = self.odColD.text().strip()
        cv = self.odColV.text().strip()
        rows = []
        with open(path, newline="", encoding="utf-8-sig") as fh:
            sample = fh.read(2048)
            fh.seek(0)
            delim = ";" if sample.count(";") > sample.count(",") else ","
            reader = csv.DictReader(fh, delimiter=delim)
            for r in reader:
                try:
                    rows.append((r[co], r[cd], float(str(r[cv]).replace(",", "."))))
                except (KeyError, ValueError, TypeError):
                    continue
        return rows

    def _od_status(self, text, error=False):
        self.odStatus.setStyleSheet(f"color: {'#b00020' if error else '#1b5e20'};")
        self.odStatus.setText(text)

    def _od_tm_browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.odTmGtfs.setText(path)

    def _od_matrix_run(self):
        zones = self.odZonesCombo.currentLayer()
        idf = self.odIdField.currentField()
        src = self.odTmGtfs.text().strip() or self.gtfsSourceEdit.text().strip()
        if zones is None or not idf:
            self._od_status("Seleziona zone e campo ID.", error=True)
            return
        if not src:
            self._od_status("Indica il feed GTFS.", error=True)
            return
        ct = QgsCoordinateTransform(zones.crs(), isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        zl = []
        for f in zones.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            p = g.centroid().asPoint()
            zl.append((str(f[idf]), p.y(), p.x()))
        if len(zl) < 2:
            self._od_status("Servono almeno due zone.", error=True)
            return
        self._od_zones_layer = zones
        self._od_zones_idf = idf
        task = OdMatrixTask(zl, src, self.odTmStart.value(),
                            self.odTmBudget.value(), 4.8)
        self._od_tm_task = task
        task.progressChanged.connect(
            lambda p: self._od_status("Matrice TP... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._od_matrix_done(t))
        task.taskTerminated.connect(lambda t=task: self._od_matrix_failed(t))
        self.odTmButton.setEnabled(False)
        self._od_status("Calcolo matrice TP in background... 0%%")
        QgsApplication.taskManager().addTask(task)

    def _od_matrix_done(self, task):
        self.odTmButton.setEnabled(True)
        layer, n = od_viz.build_od_time_lines(
            self._od_zones_layer, self._od_zones_idf, task.result,
            QgsProject.instance().transformContext())
        self._add_output(layer)
        self._od_status("Matrice TP: %d coppie raggiungibili." % n)

    def _od_matrix_failed(self, task):
        self.odTmButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._od_status("Calcolo annullato.")
        else:
            self._od_status(f"Errore matrice TP: {task.exception}", error=True)

    # ---------------------------------------------------- Isocrone avanzate
    def _isoa_toggle_pick(self, on):
        canvas = self.iface.mapCanvas()
        if on:
            if self._isoa_tool is None:
                self._isoa_tool = QgsMapToolEmitPoint(canvas)
                self._isoa_tool.canvasClicked.connect(self._isoa_on_click)
            canvas.setMapTool(self._isoa_tool)
            self._isoa_status("Clicca sulla mappa per aggiungere punti.")
        elif self._isoa_tool is not None:
            canvas.unsetMapTool(self._isoa_tool)

    def _isoa_on_click(self, point, button):
        from qgis.core import QgsCoordinateTransform
        ct = QgsCoordinateTransform(
            self.iface.mapCanvas().mapSettings().destinationCrs(),
            isochrones.WGS84, QgsProject.instance().transformContext())
        g = QgsGeometry.fromPointXY(point)
        g.transform(ct)
        p = g.asPoint()
        if self.isoaInteractive.isChecked():
            self._isoa_interactive_run((p.y(), p.x()))
            return
        self._isoa_picked.append((p.y(), p.x()))
        self.isoaPickLabel.setText("%d punti scelti" % len(self._isoa_picked))

    def _isoa_clear_pick(self):
        self._isoa_picked = []
        self.isoaPickLabel.setText("0 punti scelti")

    def _isoa_interactive_toggled(self, on):
        if on:
            self.isoaPickButton.setChecked(True)  # attiva lo strumento click
            self._isoa_status("Modalità interattiva attiva: clicca sulla mappa "
                              "(serve una rete stradale selezionata).")

    # ------------------------------------------- avanzamento e annullamento
    def _isoa_track(self, task):
        """Mostra la barra di avanzamento del task (fase + %) e Annulla."""
        self._isoa_task = task
        self.isoaProgress.setValue(0)
        self.isoaProgress.setFormat("%p% · avvio")
        self.isoaProgressRow.setVisible(True)
        self.isoaCancel.setEnabled(True)

        def on_progress(p, t=task):
            if self._isoa_task is t:
                self.isoaProgress.setValue(int(p))
                self.isoaProgress.setFormat(
                    "%p% · " + getattr(t, "phase", "calcolo"))

        task.progressChanged.connect(on_progress)

    def _isoa_untrack(self, task):
        """Nasconde la barra se il task concluso è quello mostrato."""
        if self._isoa_task is task:
            self._isoa_task = None
            self.isoaProgressRow.setVisible(False)

    def _isoa_cancel(self):
        task = getattr(self, "_isoa_task", None)
        if task is not None:
            self.isoaCancel.setEnabled(False)
            self.isoaProgress.setFormat("%p% · annullamento…")
            task.cancel()

    def _isoa_interactive_run(self, latlon):
        """Isocrona al click: calcolo in background (prima il blocco della GUI
        durava finché il calcolo non finiva, anche minuti su reti grandi).
        Un click durante un calcolo annulla il precedente: vale l'ultimo."""
        if self.isoaModeCombo.currentData() == "pt":
            self._isoa_status("La modalità interattiva è solo per il modo rete.",
                              error=True)
            return
        road = self.isoaRoadCombo.currentLayer()
        if road is None:
            self._isoa_status("Seleziona una rete stradale.", error=True)
            return
        try:
            times = [float(x) for x in self.isoaTimes.text().replace(";", ",")
                     .split(",") if x.strip()]
        except ValueError:
            self._isoa_status("Tempi non validi.", error=True)
            return
        if not times:
            return
        prev = getattr(self, "_isoa_task", None)
        if prev is not None:
            prev.cancel()
        ctx = QgsProject.instance().transformContext()
        key = (road.id(), self.isoaOneway.isChecked())
        radius = net_iso.reach_radius_m(self.isoaSpeed.value(), times)
        need = net_iso.reach_bbox([latlon], radius)
        params = {"sources": [latlon], "speed": self.isoaSpeed.value(),
                  "times": times,
                  "geom": {"output_mode": self.isoaOutput.currentData(),
                           "access_m": self.isoaAccess.value(),
                           "dissolve": True, "ctx": ctx}}
        cached = getattr(self, "_iso_roads_cache", None)
        if (getattr(self, "_iso_roads_key", None) == key and cached
                and net_iso.bbox_contains(cached[2], need)):
            # rete già letta e pulita da un click precedente, area coperta
            params["roads"], params["directions"] = cached[0], cached[1]
            clip = None
        else:
            # si legge un'area doppia: i click vicini riusano la cache
            clip = net_iso.reach_bbox([latlon], 2.0 * radius)
            params["road"] = self._road_spec(
                road, ctx, self.isoaOneway.isChecked(), clip, radius)
        task = GtfsIsoTask("net", params)
        task.taskCompleted.connect(
            lambda t=task, k=key, c=clip: self._isoa_interactive_done(t, k, c))
        task.taskTerminated.connect(lambda t=task: self._isoa_failed(t))
        self._isoa_track(task)
        self._isoa_status("Isocrona interattiva in calcolo…")
        QgsApplication.taskManager().addTask(task)

    def _isoa_interactive_done(self, task, key, clip=None):
        self._isoa_untrack(task)
        if task.roads is not None and clip is not None:
            self._iso_roads_key = key
            self._iso_roads_cache = (task.roads, task.directions, clip)
        if not task.n_snapped:
            self._isoa_status("Sorgente non agganciata alla rete entro 500 m "
                              "(o componente isolata).", error=True)
            return
        layer = isochrones.layer_from_band_geoms(
            task.geoms or [], self.isoaSpeed.value(), "interattivo",
            self.isoaOutput.currentData(), name="MIC - Isocrona interattiva")
        # rimpiazza il layer interattivo precedente
        old = getattr(self, "_isoa_interactive_id", None)
        if old and QgsProject.instance().mapLayer(old) is not None:
            QgsProject.instance().removeMapLayer(old)
        self._add_output(layer, zoom=False)
        self._isoa_interactive_id = layer.id()
        self._isoa_status("Isocrona interattiva aggiornata (%d fasce)."
                          % layer.featureCount())

    def _isoa_run(self):
        from qgis.core import QgsCoordinateTransform
        ctx = QgsProject.instance().transformContext()
        is_pt = (self.isoaModeCombo.currentData() == "pt")
        # sorgenti (priorità: punti scelti in mappa > fermate GTFS > layer)
        coords = []
        src_label = ""
        if self._isoa_picked:
            coords = list(self._isoa_picked)
            src_label = ("sorgenti = %d punti scelti sulla mappa (Cancella per "
                         "usare il layer). " % len(coords))
        elif self.isoaUseGtfs.isChecked() and self._gtfs:
            sm = self._gtfs["stops"]
            ids = set()
            for s in self._gtfs["segments"].values():
                ids.add(s["from_stop"])
                ids.add(s["to_stop"])
            coords = [(sm[i][0], sm[i][1]) for i in ids
                      if sm.get(i) and sm[i][0] is not None]
            src_label = "sorgenti = %d fermate GTFS. " % len(coords)
        else:
            pts = self.isoaSourceCombo.currentLayer()
            if pts is not None:
                ct = QgsCoordinateTransform(pts.crs(), isochrones.WGS84, ctx)
                for f in pts.getFeatures():
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    g = QgsGeometry(g)
                    g.transform(ct)
                    # MultiPoint: ogni parte è una sorgente
                    for p in (g.asMultiPoint() if g.isMultipart()
                              else [g.asPoint()]):
                        coords.append((p.y(), p.x()))
        if not coords:
            self._isoa_status("Nessuna sorgente (layer/mappa/fermate GTFS).",
                              error=True)
            return
        try:
            times = [float(x) for x in self.isoaTimes.text().replace(";", ",")
                     .split(",") if x.strip()]
        except ValueError:
            self._isoa_status("Tempi non validi.", error=True)
            return
        if not times:
            self._isoa_status("Indica almeno un tempo.", error=True)
            return

        # geometrie (buffer/unione, la parte pesante) calcolate nel task
        geom = {"output_mode": self.isoaOutput.currentData(),
                "access_m": self.isoaAccess.value(),
                "dissolve": self.isoaDissolve.isChecked(), "ctx": ctx}
        pre_msg = src_label
        egr_r = 800.0
        pt_label = ""
        if is_pt:
            source_path = (self.isoaGtfsEdit.text().strip()
                           or self.gtfsSourceEdit.text().strip())
            if not source_path:
                self._isoa_status("Per il TP indica un feed GTFS.", error=True)
                return
            acc_speed, acc_r = self._pt_leg_params(self.isoaAccessMode)
            egr_speed, egr_r = self._pt_leg_params(self.isoaEgressMode)
            # rete pedonale opzionale per l'egress multimodale (concavo):
            # letta e pulita nel task
            road = self.isoaRoadCombo.currentLayer()
            egress = self._road_spec(road, ctx) if road is not None else None
            task = GtfsIsoTask("pt", {
                "sources": coords, "times": times, "source_path": source_path,
                "start_h": self.isoaStartH.value(),
                "walk_speed": self.isoaSpeed.value(),
                "transfer_m": 200.0, "max_access_m": acc_r,
                "access_speed": acc_speed, "egress_speed": egr_speed,
                "transfer_penalty_s": self.isoaTransferPen.value() * 60.0,
                "service_date": self._service_date(),
                "egress_road": egress, "egress_r": egr_r,
                # l'egress TP è sempre dissolto (unione per fascia); senza
                # rete i bacini sono cerchi, uniti anch'essi nel task
                "geom": (dict(geom, dissolve=True) if egress
                         else dict(geom, dissolve=True,
                                   output_mode="concave"))})
            pt_label = "TP+rete" if egress else "TP"
        else:
            road = self.isoaRoadCombo.currentLayer()
            if road is None:
                self._isoa_status("Per la rete indica un layer stradale.",
                                  error=True)
                return
            # lettura (solo il riquadro raggiungibile), pulizia, validazione
            # e controllo di aggancio nel task: su reti grandi richiedono
            # secondi e bloccherebbero QGIS
            radius = net_iso.reach_radius_m(self.isoaSpeed.value(), times)
            task = GtfsIsoTask("net", {
                "road": self._road_spec(
                    road, ctx, self.isoaOneway.isChecked(),
                    net_iso.reach_bbox(coords, radius), radius),
                "sources": coords, "speed": self.isoaSpeed.value(),
                "times": times, "geom": geom})

        prev = getattr(self, "_isoa_task", None)
        if prev is not None:
            prev.cancel()
        self._isoa_cfg = {
            "is_pt": is_pt, "speed": self.isoaSpeed.value(),
            "mode_label": self.isoaModeCombo.currentText(),
            "output_mode": self.isoaOutput.currentData(),
            "access_m": self.isoaAccess.value(),
            "dissolve": self.isoaDissolve.isChecked(),
            "times": times, "sources": coords,
            "max_access_m": egr_r, "pre_msg": pre_msg, "pt_label": pt_label}
        task.taskCompleted.connect(lambda t=task: self._isoa_done(t))
        task.taskTerminated.connect(lambda t=task: self._isoa_failed(t))
        self._isoa_track(task)
        self.isoaRunButton.setEnabled(False)
        self._isoa_status("%sCalcolo in background: puoi continuare a usare "
                          "QGIS." % pre_msg)
        QgsApplication.taskManager().addTask(task)

    def _isoa_done(self, task):
        self._isoa_untrack(task)
        self.isoaRunButton.setEnabled(True)
        cfg = self._isoa_cfg
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # geometrie già calcolate nel task: qui solo la creazione del layer
            if cfg["is_pt"]:
                layer = isochrones.layer_from_band_geoms(
                    task.geoms or [], 0.0, cfg["pt_label"],
                    cfg["output_mode"] if cfg["pt_label"] == "TP+rete"
                    else "concave",
                    name="Isocrona TP" if cfg["pt_label"] == "TP"
                    else "Isocrone (rete)")
            else:
                layer = isochrones.layer_from_band_geoms(
                    task.geoms or [], cfg["speed"], cfg["mode_label"],
                    cfg["output_mode"])
        except Exception as exc:
            self._isoa_status(f"Errore costruzione layer: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        n_feat = layer.featureCount()
        if n_feat == 0:
            n_snap = getattr(task, "n_snapped", None)
            if not cfg["is_pt"] and n_snap == 0:
                self._isoa_status(
                    "Nessuna sorgente aggancia la rete entro 500 m: avvicina i "
                    "punti alle strade o scarica la rete con 'Rete da OSM'.",
                    error=True)
            else:
                self._isoa_status(
                    "Nessuna isocrona generata: aumenta i tempi/velocità o "
                    "verifica la rete stradale.", error=True)
            return
        poi_msg = ""
        poi = self.isoaPoiCombo.currentLayer()
        from qgis.core import QgsWkbTypes
        if poi is not None and layer.geometryType() == QgsWkbTypes.PolygonGeometry:
            try:
                opportunities.count_in_polygons(
                    layer, poi, self.isoaPoiWeight.currentField() or None,
                    QgsProject.instance().transformContext())
                # per fascia: le fasce sono annidate (15 min contiene 5 min),
                # quindi un totale su tutte le fasce conterebbe più volte
                by_t = {}
                for f in layer.getFeatures():
                    n, w = by_t.get(f["time_min"], (0, 0.0))
                    by_t[f["time_min"]] = (n + (f["n_poi"] or 0),
                                           w + (f["peso_poi"] or 0.0))
                poi_msg = " · opportunità per fascia: " + ", ".join(
                    "%g min %d (peso %.0f)" % (t, n, w)
                    for t, (n, w) in sorted(by_t.items()))
                if (not cfg["is_pt"] and not cfg["dissolve"]
                        and len(cfg["sources"]) > 1):
                    poi_msg += " (somma sulle sorgenti)"
            except Exception as exc:
                poi_msg = " · conteggio POI non riuscito: %s" % exc
        self._add_output(layer)
        extra = ""
        if not cfg["is_pt"] and getattr(task, "n_snapped", None) is not None:
            extra = " (%d/%d sorgenti agganciate)" % (
                task.n_snapped, len(cfg["sources"]))
        self._isoa_status("%sIsocrone create: %d sorgenti, %d geometrie.%s%s"
                          % (cfg.get("pre_msg", "") + task.pre_msg,
                             len(cfg["sources"]), n_feat, extra, poi_msg))

    def _isoa_failed(self, task):
        current = self._isoa_task is task
        self._isoa_untrack(task)
        self.isoaRunButton.setEnabled(True)
        if not current:
            return  # sostituito da un calcolo più recente (es. nuovo click)
        if getattr(task, "cancelled", False) or task.isCanceled():
            self._isoa_status("Calcolo annullato.")
        else:
            self._isoa_status(f"Errore isocrone: {task.exception}", error=True)

    def _isoa_status(self, text, error=False):
        self.isoaStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.isoaStatus.setText(text)

    # ------------------------------------------------------------------ PTAL
    def _ptal_browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.ptalSourceEdit.setText(path)

    def _ptal_mode_changed(self):
        self.ptalPedBox.setVisible(
            self.ptalDistCombo.currentData() == "network")

    def _ptal_run(self):
        source = self.ptalSourceEdit.text().strip() or self.gtfsSourceEdit.text().strip()
        if not source:
            self._ptal_status("Indica il feed GTFS.", error=True)
            return
        from qgis.core import QgsCoordinateTransform
        self._ptal_cells = None
        self._ptal_points = None
        # evita che la Gap analysis usi un vecchio PTAL a griglia
        self._ptal_grid_layer_id = None
        if self.ptalGridCheck.isChecked():
            # estensione in WGS84
            ext_layer = self.ptalExtentCombo.currentLayer()
            if ext_layer is not None:
                ext = ext_layer.extent()
                src_crs = ext_layer.crs()
            else:
                ext = self.iface.mapCanvas().extent()
                src_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
            ct = QgsCoordinateTransform(src_crs, isochrones.WGS84,
                                        QgsProject.instance().transformContext())
            r = ct.transformBoundingBox(ext)
            centroids, cells = grid_gen.build_grid(
                r.yMinimum(), r.yMaximum(), r.xMinimum(), r.xMaximum(),
                self.ptalGridSize.value(), self.ptalGridShape.currentData())
            if not centroids:
                self._ptal_status("Estensione/cella non valide.", error=True)
                return
            if len(centroids) > 8000:
                self._ptal_status("Troppe celle (%d): aumenta la dimensione "
                                  "cella o riduci l'estensione." % len(centroids),
                                  error=True)
                return
            pts_ll = centroids
            self._ptal_cells = cells
        else:
            points = self.ptalPointsCombo.currentLayer()
            if points is None:
                self._ptal_status("Indica i punti di analisi o usa la griglia.",
                                  error=True)
                return
            ct = QgsCoordinateTransform(points.crs(), isochrones.WGS84,
                                        QgsProject.instance().transformContext())
            pts_ll = []
            for f in points.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ct)
                p = g.asPoint()
                pts_ll.append((p.y(), p.x()))
            self._ptal_points = points
        if not pts_ll:
            self._ptal_status("Nessun punto valido.", error=True)
            return
        thresholds = {}
        reliability = {}
        for rtype, (sthr, srel) in self.ptalModeWidgets.items():
            thresholds[rtype] = sthr.value()
            reliability[rtype] = srel.value() / 10.0
        # route_type 4 (ferry) -> come treno
        thresholds.setdefault("4", thresholds.get("2", 960))
        reliability.setdefault("4", reliability.get("2", 0.75))
        params = {
            "start_h": self.ptalStart.value(),
            "end_h": self.ptalEnd.value(),
            "walk_speed_kmh": self.ptalWalk.value() / 10.0,
            "thresholds": thresholds,
            "reliability": reliability,
            "default_threshold": thresholds.get("3", 640),
            "default_reliability": reliability.get("3", 2.0),
            "weight_primary": 1.0, "weight_secondary": 0.5,
            "service_date": self._service_date(),
        }
        if self.ptalDistCombo.currentData() == "network":
            road_layer = self.ptalRoadCombo.currentLayer()
            if road_layer is None:
                self._ptal_status("Modalità su rete: seleziona una rete pedonale "
                                  "(o scaricala con 'Rete da OSM').", error=True)
                return
            roads, _dirs, _cs = self._extract_roads(
                road_layer, QgsProject.instance().transformContext())
            ok, vmsg, _ = net_iso.validate_network(roads)
            if not ok:
                self._ptal_status("Rete non valida: " + vmsg, error=True)
                return
            params["roads"] = roads
        if self.ptalProfilesCheck.isChecked():
            params["bands"] = [(lbl, sh, eh)
                               for lbl, sh, eh, _d in ptal.TIME_BANDS]
        task = PtalTask(source, pts_ll, params)
        self._ptal_task = task
        task.progressChanged.connect(
            lambda p: self._ptal_status("Calcolo PTAL... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._ptal_done(t))
        task.taskTerminated.connect(lambda t=task: self._ptal_failed(t))
        self.ptalRunButton.setEnabled(False)
        self._ptal_status("Calcolo PTAL in background... 0%%")
        QgsApplication.taskManager().addTask(task)

    def _ptal_done(self, task):
        self.ptalRunButton.setEnabled(True)
        results = task.result  # lista di (label, results_list); [0] = primario
        _plabel, primary = results[0]
        profiles = results if len(results) > 1 else None
        if self._ptal_cells is not None:
            layer = gtfs_layers.build_ptal_grid_layer(
                self._ptal_cells, primary, profiles=profiles)
            self._ptal_grid_layer_id = layer.id()
        else:
            layer = gtfs_layers.build_ptal_layer(
                self._ptal_points, primary, profiles=profiles)
        self._add_output(layer)
        bands = {}
        for r in primary:
            bands[r["band"]] = bands.get(r["band"], 0) + 1
        summary = ", ".join("%s:%d" % (b, bands[b]) for b in sorted(bands))
        extra = ""
        if profiles:
            extra = " · profili: " + ", ".join(lbl for lbl, _ in profiles)
        self._ptal_status("PTAL calcolato su %d punti%s. Fasce (primaria): %s"
                          % (len(primary), extra, summary))

    def _ptal_failed(self, task):
        self.ptalRunButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._ptal_status("Calcolo annullato.")
        else:
            self._ptal_status(f"Errore PTAL: {task.exception}", error=True)

    def _ptal_status(self, text, error=False):
        self.ptalStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.ptalStatus.setText(text)

    def _gap_run(self):
        lid = self._ptal_grid_layer_id
        ptal_layer = QgsProject.instance().mapLayer(lid) if lid else None
        if ptal_layer is None:
            self._ptal_status("Esegui prima un PTAL a celle (griglia).",
                              error=True)
            return
        pop = self.gapPopCombo.currentLayer()
        if pop is None:
            self._ptal_status("Seleziona il layer popolazione.", error=True)
            return
        field = self.gapPopField.currentField() or None
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            layer = gap_mod.compute_gap(
                ptal_layer, pop, field,
                QgsProject.instance().transformContext())
        except Exception as exc:
            self._ptal_status(f"Errore gap: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._add_output(layer)
        self._ptal_status("Gap analysis creata (campi popolazione, gap).")

    # --------------------------------------------------- Accessibilita
    def _acc_browse_gtfs(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.accGtfsEdit.setText(path)

    def _acc_mode_changed(self):
        self.accPtBox.setVisible(self.accModeCombo.currentData() == "pt")

    def _acc_pts(self, layer, weight_field=None):
        ct = QgsCoordinateTransform(layer.crs(), isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        out = []
        names = layer.fields().names()
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            p = g.centroid().asPoint()
            if weight_field and weight_field in names:
                try:
                    w = float(f[weight_field])
                except (TypeError, ValueError):
                    w = 1.0
            else:
                w = 1.0
            out.append((p.y(), p.x(), w))
        return out

    def _acc_run(self):
        origins = self.accOriginCombo.currentLayer()
        dests = self.accDestCombo.currentLayer()
        if origins is None or dests is None:
            self._acc_status("Seleziona origini e destinazioni.", error=True)
            return
        try:
            times = [float(x) for x in self.accTimes.text().replace(";", ",")
                     .split(",") if x.strip()]
        except ValueError:
            self._acc_status("Tempi non validi.", error=True)
            return
        if not times:
            self._acc_status("Indica almeno un tempo.", error=True)
            return
        origin_pts = [(la, lo) for la, lo, _ in self._acc_pts(origins)]
        dest_pts = self._acc_pts(dests, self.accWeightField.currentField() or None)
        if not origin_pts or not dest_pts:
            self._acc_status("Origini/destinazioni vuote.", error=True)
            return
        is_pt = (self.accModeCombo.currentData() == "pt")
        if is_pt:
            src = self.accGtfsEdit.text().strip() or self.gtfsSourceEdit.text().strip()
            if not src:
                self._acc_status("Per il TP indica un feed GTFS.", error=True)
                return
            acc_speed, acc_r = self._pt_leg_params(self.accAccessMode)
            egr_speed, egr_r = self._pt_leg_params(self.accEgressMode)
            task = AccessTask("pt", {
                "origins": origin_pts, "dests": dest_pts, "source_path": src,
                "start_h": self.accStartH.value(),
                "walk_speed": self.accModeCombo.itemData(0),
                "times": times, "access_m": acc_r, "egress_m": egr_r,
                "access_speed": acc_speed, "egress_speed": egr_speed,
                "transfer_penalty_s": self.accTransferPen.value() * 60.0,
                "service_date": self._service_date()})
        else:
            road = self.accRoadCombo.currentLayer()
            if road is None:
                self._acc_status("Per i modi su strada indica una rete.",
                                 error=True)
                return
            roads, directions, _cstats = self._extract_roads(
                road, QgsProject.instance().transformContext(),
                self.accOneway.isChecked())
            pf_ok, pf_msg = self._preflight_net(roads, directions, origin_pts)
            if not pf_ok:
                self._acc_status(pf_msg, error=True)
                return
            if pf_msg:
                self._acc_status(pf_msg + "Calcolo in corso...")
            task = AccessTask("net", {
                "origins": origin_pts, "dests": dest_pts, "roads": roads,
                "speed": self.accModeCombo.currentData(), "times": times,
                "directions": directions})
        self._acc_origin_layer = origins
        self._acc_task = task
        task.progressChanged.connect(
            lambda p: self._acc_status("Calcolo accessibilità... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._acc_done(t))
        task.taskTerminated.connect(lambda t=task: self._acc_failed(t))
        self.accRunButton.setEnabled(False)
        self._acc_status("Calcolo in background... 0%%")
        QgsApplication.taskManager().addTask(task)

    def _acc_done(self, task):
        self.accRunButton.setEnabled(True)
        layer = gtfs_layers.build_access_layer(
            self._acc_origin_layer, task.result, task.times)
        self._add_output(layer)
        self._acc_status("Accessibilità calcolata su %d origini (campi "
                         "acc_*min)." % len(task.result))

    def _acc_failed(self, task):
        self.accRunButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._acc_status("Calcolo annullato.")
        else:
            self._acc_status(f"Errore accessibilità: {task.exception}", error=True)

    def _acc_status(self, text, error=False):
        self.accStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.accStatus.setText(text)

    # --------------------------------------------- metriche sintesi & equità
    def _eq_status(self, text, error=False):
        self.eqStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.eqStatus.setText(text)

    def _eq_run(self):
        layer = self.eqLayerCombo.currentLayer()
        vfield = self.eqValueField.currentField()
        if layer is None or not vfield:
            self._eq_status("Seleziona layer e campo valore.", error=True)
            return
        wfield = self.eqWeightField.currentField() or None
        values, weights = [], []
        for f in layer.getFeatures():
            try:
                values.append(float(f[vfield]))
            except (TypeError, ValueError):
                continue
            if wfield:
                try:
                    weights.append(float(f[wfield]))
                except (TypeError, ValueError):
                    weights.append(0.0)
        if not values:
            self._eq_status("Nessun valore numerico nel campo scelto.",
                            error=True)
            return
        summary = equity.compute_equity(
            values, weights if wfield else None, self.eqThreshold.value())
        self._eq_summary = summary
        self._eq_value_name = vfield
        rows = [
            ("N. feature", "%d" % summary["n"]),
            ("Peso totale", "%.1f" % summary["peso_totale"]),
            ("Media pesata", "%.2f" % summary["media"]),
            ("Mediana pesata", "%.2f" % summary["mediana"]),
            ("Indice di Gini", "%.3f" % summary["gini"]),
        ]
        if summary["pct_servita"] is not None:
            rows.append(("%% servita (≥ %.2f)" % self.eqThreshold.value(),
                         "%.1f %%" % summary["pct_servita"]))
        t = self.eqTable
        t.clear()
        t.setColumnCount(2)
        t.setHorizontalHeaderLabels(["Metrica", "Valore"])
        t.setRowCount(len(rows))
        for r, (k, v) in enumerate(rows):
            t.setItem(r, 0, QTableWidgetItem(k))
            it = QTableWidgetItem(v)
            it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            t.setItem(r, 1, it)
        t.resizeColumnsToContents()
        self.eqExportButton.setEnabled(True)
        self.eqChartButton.setEnabled(True)
        wnote = "pesata per %s" % wfield if wfield else "non pesata"
        self._eq_status("Metriche calcolate (%s). Gini=%.3f."
                        % (wnote, summary["gini"]))

    def _eq_export(self):
        if not getattr(self, "_eq_summary", None):
            self._eq_status("Calcola prima le metriche.", error=True)
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Esporta equità", "equita_lorenz.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            excel_report.write_equity_report(
                path, self._eq_summary, self._eq_value_name)
        except Exception as exc:
            self._eq_status(f"Errore export: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._eq_status(f"Esportato: {path}")

    # ------------------------------------------------------------- grafici
    def _show_chart(self, title, plot_fn):
        """Mostra un grafico matplotlib in un dialog (se matplotlib è presente)."""
        try:
            from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
            from matplotlib.figure import Figure
        except Exception:
            QMessageBox.information(
                self, "Grafico",
                "matplotlib non è disponibile in questo Python di QGIS.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.resize(660, 500)
        lay = QVBoxLayout(dlg)
        fig = Figure(figsize=(6, 4.5))
        canvas = FigureCanvasQTAgg(fig)
        ax = fig.add_subplot(111)
        try:
            plot_fn(ax)
            fig.tight_layout()
        except Exception as exc:
            QMessageBox.warning(self, "Grafico", "Errore nel grafico: %s" % exc)
            return
        lay.addWidget(canvas)
        btn = QPushButton("Chiudi")
        btn.clicked.connect(dlg.accept)
        lay.addWidget(btn)
        dlg.exec_()

    def _eq_chart(self):
        s = getattr(self, "_eq_summary", None)
        if not s or not s.get("lorenz"):
            self._eq_status("Calcola prima le metriche.", error=True)
            return
        lor = s["lorenz"]
        gini = s["gini"]

        def plot(ax):
            xs = [p[0] for p in lor]
            ys = [p[1] for p in lor]
            ax.plot(xs, ys, "-", color="#2171b5", linewidth=2, label="Lorenz")
            ax.plot([0, 1], [0, 1], "--", color="#999", label="Uguaglianza")
            ax.fill_between(xs, ys, xs, color="#2171b5", alpha=0.15)
            ax.set_xlabel("Quota cumulata di popolazione")
            ax.set_ylabel("Quota cumulata di accessibilità")
            ax.set_title("Curva di Lorenz (Gini = %.3f)" % gini)
            ax.legend(loc="upper left")
            ax.grid(alpha=0.3)

        self._show_chart("Curva di Lorenz", plot)

    # ---------------------------------------------------- confronto scenari
    def _cmp_run(self):
        la = self.cmpLayerA.currentLayer()
        lb = self.cmpLayerB.currentLayer()
        fa = self.cmpFieldA.currentField()
        fb = self.cmpFieldB.currentField()
        if la is None or lb is None or not fa or not fb:
            self._cmp_status("Seleziona i due scenari e i rispettivi campi.",
                             error=True)
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            layer, matched, total = compare.compute_difference(
                la, fa, lb, fb, QgsProject.instance().transformContext(),
                max_dist_m=self.cmpMaxDist.value() or None)
        except Exception as exc:
            self._cmp_status(f"Errore confronto: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._add_output(layer)
        self._cmp_status("Differenza creata: %d/%d feature abbinate "
                         "(delta = B − A)." % (matched, total))

    def _cmp_status(self, text, error=False):
        self.cmpStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.cmpStatus.setText(text)

    # ----------------------------------------------------- scenario A/B rete
    def _scn_status(self, text, error=False):
        self.scnStatus.setStyleSheet(
            f"color: {'#b00020' if error else '#1b5e20'};")
        self.scnStatus.setText(text)

    def _scn_run(self):
        origins = self.accOriginCombo.currentLayer()
        dests = self.accDestCombo.currentLayer()
        ra_l = self.scnRoadA.currentLayer()
        rb_l = self.scnRoadB.currentLayer()
        if origins is None or dests is None or ra_l is None or rb_l is None:
            self._scn_status("Servono origini, destinazioni e le due reti A/B.",
                             error=True)
            return
        try:
            times = [float(x) for x in self.accTimes.text().replace(";", ",")
                     .split(",") if x.strip()]
        except ValueError:
            self._scn_status("Tempi non validi.", error=True)
            return
        if not times:
            self._scn_status("Indica almeno un tempo.", error=True)
            return
        speed = self.accModeCombo.currentData()
        if speed == "pt":
            speed = 4.5
        ctx = QgsProject.instance().transformContext()
        origin_pts = [(la, lo) for la, lo, _ in self._acc_pts(origins)]
        dest_pts = self._acc_pts(dests, self.accWeightField.currentField() or None)
        if not origin_pts or not dest_pts:
            self._scn_status("Origini/destinazioni vuote.", error=True)
            return
        ra, da, _a = self._extract_roads(ra_l, ctx)
        rb, db, _b = self._extract_roads(rb_l, ctx)
        kind = self.scnKind.currentData()
        if kind == "iso":
            # calcolo pesante (union+buffer ×2 reti) in background con progress
            t = max(times)
            task = ScenarioIsoTask({
                "roads_a": ra, "roads_b": rb, "sources": origin_pts,
                "speed": float(speed), "time_min": t, "dir_a": da, "dir_b": db,
                "ctx": ctx})
            self._scn_iso_time = t
            self.scnButton.setEnabled(False)
            task.progressChanged.connect(
                lambda p: self._scn_status("Scenario isocrone... %d%%" % int(p)))
            task.taskCompleted.connect(lambda tk=task: self._scn_iso_done(tk))
            task.taskTerminated.connect(lambda tk=task: self._scn_iso_failed(tk))
            self._scn_status("Calcolo scenario isocrone in background... 0%")
            QgsApplication.taskManager().addTask(task)
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            rows, t = scenarios.accessibility_ab(
                origin_pts, dest_pts, ra, rb, float(speed), times,
                dir_a=da, dir_b=db)
            layer = net_layers.build_scenario_layer(origins, rows)
        except Exception as exc:
            self._scn_status(f"Errore scenario: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._add_output(layer)
        s = scenarios.scenario_summary(rows)
        self._scn_status("A/B @%g min: %d migliorate, %d peggiorate, %d "
                         "invariate; delta medio %.2f."
                         % (t, s["migliorate"], s["peggiorate"],
                            s["invariate"], s["delta_medio"]))

    def _scn_iso_done(self, task):
        self.scnButton.setEnabled(True)
        if task.n_snap_a == 0 and task.n_snap_b == 0:
            self._scn_status("Nessuna sorgente agganciata alle reti entro 500 m.",
                             error=True)
            return
        t = getattr(self, "_scn_iso_time", 0)
        layer, summary = isochrones.build_isochrone_diff_layer(
            task.geom_a, task.geom_b, t,
            QgsProject.instance().transformContext())
        self._add_output(layer)
        self._scn_status(
            "Isocrone A/B @%g min: +%.2f ha (guadagno), −%.2f ha (perdita), "
            "%.2f ha in comune."
            % (t, summary["guadagno"] / 1e4, summary["perdita"] / 1e4,
               summary["comune"] / 1e4))

    def _scn_iso_failed(self, task):
        self.scnButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._scn_status("Scenario isocrone annullato.")
        else:
            self._scn_status("Errore scenario isocrone: %s" % task.exception,
                             error=True)

    def closeEvent(self, event):  # noqa: N802 (API Qt)
        if self._scan_timer:
            self._scan_timer.stop()
        if self._logger:
            self._logger.stop()
        self.closingPlugin.emit()
        event.accept()
