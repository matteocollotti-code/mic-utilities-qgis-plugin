# -*- coding: utf-8 -*-
"""QgsTask per non bloccare la GUI di QGIS.

- GtfsLoadTask: esegue analyze_static() in un thread di lavoro (il GTFS di
  Roma ha stop_times.txt ~255 MB e richiede oltre un minuto).
- GtfsPollTask: scarica e decodifica un feed GTFS-RT in background; l'ingest
  nella struttura del logger avviene nel thread principale (slot collegato).
"""
try:  # requests è opzionale: serve a GTFS-RT e download OSM
    import requests
except ImportError:  # pragma: no cover
    requests = None

from collections import defaultdict

from qgis.core import QgsTask

from . import gtfs_static, gtfs_rt, map_matching, space_syntax

MESSAGE_CATEGORY = "AnalizzatoreReteStradale"


class GtfsLoadTask(QgsTask):
    """Carica e analizza un feed GTFS statico senza bloccare la GUI."""

    def __init__(self, source, route_ids=None, service_date=None):
        super().__init__("Caricamento GTFS statico", QgsTask.CanCancel)
        self.source = source
        self.route_ids = route_ids
        self.service_date = service_date
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            self.result = gtfs_static.analyze_static(
                self.source,
                route_ids=self.route_ids,
                progress=self.setProgress,
                is_canceled=self.isCanceled,
                service_date=self.service_date,
            )
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:  # riportata nello slot finished
            self.exception = exc
            return False


class OsmRoadsTask(QgsTask):
    """Scarica la rete stradale OSM (Overpass) per un bbox, in background."""

    def __init__(self, bbox, mode="all", force=False):
        super().__init__("Download rete stradale OSM", QgsTask.CanCancel)
        self.bbox = bbox  # (south, west, north, east) in gradi WGS84
        self.mode = mode
        self.force = force
        self.from_cache = False
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            from . import osm_download, osm_cache
            if not self.force:
                c = osm_cache.get_cached("roads", self.bbox, self.mode)
                if c:
                    self.result = c["features"]
                    self.from_cache = True
                    self.setProgress(100)
                    return True
            self.result = osm_download.fetch_ways(
                *self.bbox, mode=self.mode, progress=self.setProgress,
                is_canceled=self.isCanceled)
            if self.isCanceled():
                self.cancelled = True
                return False
            if self.result:  # un risultato vuoto non va in cache
                osm_cache.put_cached("roads", self.bbox, self.mode, self.result)
            return True
        except Exception as exc:
            self.exception = exc
            return False


class OsmCrossingsTask(QgsTask):
    """Scarica gli attraversamenti pedonali OSM per un bbox, in background."""

    def __init__(self, bbox, force=False):
        super().__init__("Download attraversamenti OSM", QgsTask.CanCancel)
        self.bbox = bbox
        self.force = force
        self.from_cache = False
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            from . import osm_download, osm_cache
            if not self.force:
                c = osm_cache.get_cached("crossings", self.bbox, "all")
                if c:
                    self.result = c["features"]
                    self.from_cache = True
                    self.setProgress(100)
                    return True
            self.result = osm_download.fetch_crossings(
                *self.bbox, progress=self.setProgress,
                is_canceled=self.isCanceled)
            if self.isCanceled():
                self.cancelled = True
                return False
            if self.result:  # un risultato vuoto non va in cache
                osm_cache.put_cached("crossings", self.bbox, "all", self.result)
            return True
        except Exception as exc:
            self.exception = exc
            return False


class OsmServicesTask(QgsTask):
    """Scarica i servizi OSM (città dei 15 minuti) per un bbox, in
    background, con la stessa cache locale della rete."""

    def __init__(self, bbox, force=False):
        super().__init__("Download servizi OSM", QgsTask.CanCancel)
        self.bbox = bbox
        self.force = force
        self.from_cache = False
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            from . import fifteen, osm_cache
            if not self.force:
                c = osm_cache.get_cached("services", self.bbox, "all")
                if c:
                    self.result = [tuple(r) for r in c["features"]]
                    self.from_cache = True
                    self.setProgress(100)
                    return True
            self.result = fifteen.fetch_services(
                *self.bbox, progress=self.setProgress,
                is_canceled=self.isCanceled)
            if self.isCanceled():
                self.cancelled = True
                return False
            if self.result:
                osm_cache.put_cached("services", self.bbox, "all",
                                     self.result)
            return True
        except Exception as exc:
            self.exception = exc
            return False


class GtfsPollTask(QgsTask):
    """Scarica e decodifica un feed GTFS-RT TripUpdates (un singolo poll)."""

    def __init__(self, url, timeout=20):
        super().__init__("Poll GTFS-RT", QgsTask.CanCancel)
        self.url = url
        self.timeout = timeout
        self.trip_updates = None
        self.feed_timestamp = None
        self.exception = None

    def run(self):
        import time
        try:
            if requests is None:
                raise RuntimeError("Il modulo 'requests' non è installato.")
            resp = requests.get(self.url, timeout=self.timeout)
            resp.raise_for_status()
            feed = gtfs_rt.parse_feed(resp.content)
            self.trip_updates = feed.get("trip_updates", [])
            # istante del feed (header); senza, l'ora del download
            self.feed_timestamp = feed.get("timestamp") or int(time.time())
            return True
        except Exception as exc:
            self.exception = exc
            return False


class GtfsMatchTask(QgsTask):
    """Esegue il map-matching delle velocita' GTFS sulla rete stradale."""

    def __init__(self, segments, seg_eff, road_geoms, road_crs, transform_context,
                 tolerance_m, angle_tol_deg, spacing_m, min_cover=0.5):
        super().__init__("Map-matching GTFS su rete stradale", QgsTask.CanCancel)
        self.min_cover = min_cover
        self.segments = segments
        self.seg_eff = seg_eff
        self.road_geoms = road_geoms
        self.road_crs = road_crs
        self.transform_context = transform_context
        self.tolerance_m = tolerance_m
        self.angle_tol_deg = angle_tol_deg
        self.spacing_m = spacing_m
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        try:
            self.result = map_matching.match_gtfs_to_roads(
                self.segments, self.seg_eff, self.road_geoms, self.road_crs,
                self.transform_context, tolerance_m=self.tolerance_m,
                angle_tol_deg=self.angle_tol_deg, spacing_m=self.spacing_m,
                min_cover=self.min_cover,
                progress=self.setProgress, is_canceled=self.isCanceled)
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


def read_spec_roads(spec, task=None, lo=0, hi=100, ids=None, levels=None,
                    keep=None, speed_of=None, speeds=None):
    """Legge le strade di uno spec (_road_spec del pannello) in lon/lat.

    Thread-safe (sorgente QgsVectorLayerFeatureSource): da chiamare nel
    worker. Con `ids` / `levels` (liste) raccoglie id della feature e livello
    (ponte/tunnel/layer) per polilinea.
    :return: (roads, directions o None).
    """
    from qgis.core import (QgsCoordinateReferenceSystem,
                           QgsCoordinateTransform, QgsFeatureRequest)
    from . import net_iso
    total = spec.get("count") or 0

    def on_read(n):
        if task is not None:
            task.setProgress(lo + (hi - lo) * min(0.98, n / float(total))
                             if total else lo)

    ct = QgsCoordinateTransform(
        spec["crs"], QgsCoordinateReferenceSystem("EPSG:4326"), spec["ctx"])
    request = QgsFeatureRequest()
    if spec.get("rect") is not None:
        request.setFilterRect(spec["rect"])
    level_of = spec.get("level_of")
    roads, dirs = net_iso.read_roads(
        spec["source"].getFeatures(request), ct, spec.get("oneway", False),
        progress=on_read,
        is_canceled=task.isCanceled if task is not None else None,
        ids=ids, levels=levels if level_of else None, level_of=level_of,
        keep=keep, speed_of=speed_of, speeds=speeds)
    if levels is not None and not level_of:
        levels.extend([0] * len(roads))
    if task is not None:
        task.setProgress(hi)
    return roads, dirs


def edge_cost_job(raw, speeds, levels, cost, is_canceled=None):
    """Tempi per tratto e verso (travel_cost.edge_times) per le polilinee
    lette con read_roads. Thread-safe: da chiamare nel worker.

    :param cost: {"speed_of": f(feature) → m/s (auto, velocità per strada),
        "keep": f(feature) → bool, "default_mps": velocità in piano o di
        default, "dem": {"provider": copia del provider, "crs", "ctx",
        "band"}} (pendenza a piedi).
    :return: (tempi per polilinea, statistiche).
    """
    from . import travel_cost
    dem = None
    d = cost.get("dem")
    if d:
        lons = [x for r in raw for x, _y in r]
        lats = [y for r in raw for _x, y in r]
        if lons:
            dem = travel_cost.DemGrid(d["provider"], d["crs"], d["ctx"],
                                      (min(lons), min(lats), max(lons),
                                       max(lats)), band=d.get("band", 1))
            if not dem.ok:
                raise ValueError(
                    "Il DEM non copre la rete o non ha quote valide: "
                    "controlla il layer e il suo sistema di riferimento.")
    off = [lv != 0 for lv in levels] if (dem is not None and levels) else None
    return travel_cost.edge_times(raw, speeds, cost.get("default_mps", 1.25),
                                  dem, off, is_canceled=is_canceled)


def read_costed_network(spec, cost, task=None, lo=0, hi=100):
    """Rete pulita con i tempi di ogni tratto per verso (thread-safe).

    Lettura (solo il riquadro dello spec), esclusione delle strade non
    percorribili (cost["keep"]), velocità per strada, pendenza dal DEM,
    pulizia e validazione. Usata dalla matrice OD su strada e dalla città
    dei 15 minuti.
    :return: (segmenti, sensi o None, tempi per segmento, statistiche dei
        tempi, statistiche di pulizia).
    """
    from . import net_iso, net_clean, travel_cost
    speeds = [] if cost.get("speed_of") else None
    levels = [] if cost.get("dem") else None
    span = float(hi - lo)
    raw, rdirs = read_spec_roads(spec, task, lo, lo + 0.6 * span,
                                 levels=levels, keep=cost.get("keep"),
                                 speed_of=cost.get("speed_of"), speeds=speeds)
    if not raw:
        raise ValueError("Nessuna strada percorribile nell'area dei punti%s."
                         % (" (in auto: solo percorsi pedonali o ciclabili?)"
                            if cost.get("keep") else ""))
    is_canceled = task.isCanceled if task is not None else None
    raw_times, stats = edge_cost_job(raw, speeds, levels, cost, is_canceled)
    if task is not None:
        task.setProgress(lo + 0.8 * span)
    pairs = []
    roads, dirs, cstats = net_clean.clean_network(raw, 1.0, rdirs,
                                                  pairs_out=pairs)
    ok, vmsg, _i = net_iso.validate_network(roads)
    if not ok:
        raise ValueError("Rete non valida: " + vmsg)
    if task is not None:
        task.setProgress(hi)
    return (roads, dirs, travel_cost.costs_for_segments(raw_times, pairs),
            stats, cstats)


class FunctionTask(QgsTask):
    """Esegue fn(task) in background: risultato in .result, errore in
    .exception, annullamento (GtfsCancelled) in .cancelled."""

    def __init__(self, description, fn):
        super().__init__(description, QgsTask.CanCancel)
        self.fn = fn
        self.result = None
        self.exception = None
        self.cancelled = False
        self.phase = ""   # cosa sta facendo, per la barra di avanzamento

    def set_phase(self, text):
        """Fase in corso (la barra la mostra al prossimo avanzamento)."""
        self.phase = text or ""
        self.setProgress(self.progress())

    def run(self):
        try:
            self.result = self.fn(self)
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class SpaceSyntaxTask(QgsTask):
    """Space syntax in background: lettura della rete, segmenti tra incroci
    reali (segment map) e metriche."""

    def __init__(self, spec, radius=0):
        super().__init__("Space syntax", QgsTask.CanCancel)
        self.spec = spec
        self.radius = radius
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import net_iso
        try:
            ids = []
            roads, _d = read_spec_roads(self.spec, self, 0, 15, ids=ids)
            ok, vmsg, _info = net_iso.validate_network(roads)
            if not ok:
                raise ValueError(vmsg)
            topo, adjacency = space_syntax.segment_map(
                roads, sources=ids, is_canceled=self.isCanceled,
                progress=lambda p: self.setProgress(15 + 0.1 * p))
            if not topo.chains:
                raise ValueError("Nessun tratto valido nella rete.")
            metrics = space_syntax.compute_metrics(
                adjacency, radius=self.radius,
                progress=lambda p: self.setProgress(25 + 0.75 * p),
                is_canceled=self.isCanceled)
            self.result = space_syntax.attach_segments(metrics, topo,
                                                       len(set(ids)))
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class PtalTask(QgsTask):
    """Calcola le frequenze GTFS e il PTAL per i punti di analisi."""

    def __init__(self, source, points_latlon, params):
        super().__init__("PTAL", QgsTask.CanCancel)
        self.source = source
        self.points_latlon = points_latlon
        self.params = params
        self.result = None
        self.selection = ""   # giorno di servizio usato (per il messaggio)
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import ptal
        try:
            roads = self.params.get("roads")
            # bands = lista di (label, start_h, end_h); default = fascia singola
            bands = self.params.get("bands") or [
                ("", self.params["start_h"], self.params["end_h"])]
            results = []
            nb = len(bands)
            for bi, (label, sh, eh) in enumerate(bands):
                base = int(100 * bi / nb)
                step = 100.0 / nb
                self.setProgress(base + int(step * 0.05))
                if self.params.get("manual") is not None:
                    # servizio fornito dall'utente (niente GTFS)
                    stop_routes, stops_xy = self.params["manual"]
                    self.selection = "dati forniti (%d fermate)" % len(stops_xy)
                else:
                    info = {}
                    stop_routes, stops_xy = ptal.compute_stop_frequencies(
                        self.source, sh, eh,
                        service_date=self.params.get("service_date"),
                        info=info)
                    self.selection = info.get("selection", "")
                self.setProgress(base + int(step * 0.4))

                def _prog(p, base=base, step=step):
                    self.setProgress(base + int(step * (0.4 + 0.6 * p / 100.0)))

                if roads:
                    res = ptal.compute_ptal_network(
                        self.points_latlon, stop_routes, stops_xy, roads,
                        self.params, progress=_prog, is_canceled=self.isCanceled)
                else:
                    res = ptal.compute_ptal(
                        self.points_latlon, stop_routes, stops_xy, self.params,
                        progress=_prog, is_canceled=self.isCanceled)
                results.append((label, res))
            # risultato: lista di (label, results). Il primo e' il primario.
            self.result = results
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class GtfsIsoTask(QgsTask):
    """Isocrone in background: rete (net_iso) o trasporto pubblico (transit_iso).

    Con params["geom"] = {output_mode, access_m, dissolve, ctx} calcola nel
    worker anche le geometrie (buffer/unione, la parte pesante) in
    self.geoms; al main thread resta solo la creazione del layer.

    La rete può arrivare già pronta (params["roads"]) oppure come
    params["road"] = {source: QgsVectorLayerFeatureSource, crs, ctx, oneway}:
    allora lettura, pulizia, validazione e controllo di aggancio avvengono qui
    nel worker (su una rete grande richiedono secondi).
    """

    def __init__(self, mode, params):
        super().__init__("Isocrone", QgsTask.CanCancel)
        self.mode = mode
        self.params = params
        self.result = None
        self.n_snapped = None
        self.per_source = None
        self.geoms = None
        self.roads = None       # rete pulita letta nel task (per la cache)
        self.directions = None
        self.edge_costs = None  # tempi per tratto e verso (auto, pendenza)
        self.cost_stats = {}
        self.pre_msg = ""
        self.n_departures = 1       # TP: partenze nella finestra oraria
        self.n_lines = 0            # TP "Dividi per linea": linee trovate
        self.selection = ""         # TP: giorno di servizio usato
        self.n_crowfly_access = 0   # TP: sorgenti fuori rete (accesso in linea d'aria)
        # fase corrente, letta dalla GUI per la barra di avanzamento
        self.phase = "avvio"
        self.exception = None
        self.cancelled = False

    def _stage(self, phase, lo, hi):
        """Imposta la fase e ritorna una callback progress 0-100 -> lo..hi."""
        self.phase = phase
        self.setProgress(lo)
        return lambda x: self.setProgress(lo + (hi - lo) * float(x) / 100.0)

    def _read_network(self, spec, preflight_coords=None, lo=1, hi=15,
                      cost=None):
        """Legge e pulisce la rete nel worker (avanzamento lo..hi). Solleva
        ValueError se la rete non è utilizzabile o se nessuna sorgente la
        aggancia.

        Con `cost` (vedi edge_cost_job) calcola anche i tempi di ogni tratto
        per verso in self.edge_costs: velocità per strada (auto) e/o
        pendenza dal DEM (piedi)."""
        from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform
        from qgis.core import QgsFeatureRequest
        from . import net_iso, net_clean, network_diagnostics
        total = spec.get("count") or 0
        estimated = bool(spec.get("rect") is not None)
        span = float(hi - lo)

        def on_read(n):
            # la fase mostra le strade lette: la barra non resta ferma
            if total > 0 and not estimated:
                self.phase = "lettura della rete (%d/%d strade)" % (n, total)
            else:
                self.phase = "lettura della rete (%d strade)" % n
            if total > 0:
                self.setProgress(lo + 0.6 * span * min(0.98, n / float(total)))
            else:
                self.setProgress(lo)

        self._stage("lettura della rete", lo, lo)
        ct = QgsCoordinateTransform(
            spec["crs"], QgsCoordinateReferenceSystem("EPSG:4326"), spec["ctx"])
        # riduzione: solo le strade nel riquadro raggiungibile (indice spaziale)
        request = QgsFeatureRequest()
        if spec.get("rect") is not None:
            request.setFilterRect(spec["rect"])
        rstats = {}
        cost = cost or {}
        speeds = [] if cost.get("speed_of") else None
        levels = [] if cost.get("dem") else None
        raw, rdirs = net_iso.read_roads(spec["source"].getFeatures(request), ct,
                                        spec.get("oneway", False),
                                        progress=on_read,
                                        is_canceled=self.isCanceled,
                                        stats=rstats, keep=cost.get("keep"),
                                        speed_of=cost.get("speed_of"),
                                        speeds=speeds, levels=levels,
                                        level_of=spec.get("level_of"))
        if spec.get("rect") is not None:
            if not raw:
                raise ValueError(
                    "Nessuna strada della rete entro %.1f km dalle sorgenti: "
                    "la rete e i punti non si sovrappongono (controlla il "
                    "CRS dei due layer)." % (spec.get("radius_m", 0) / 1000.0))
            self.pre_msg += ("rete ridotta all'area raggiungibile (%.1f km "
                             "attorno alle sorgenti): %d di %d strade. "
                             % (spec.get("radius_m", 0) / 1000.0,
                                rstats.get("features", 0),
                                spec.get("layer_count", 0)))
        if cost.get("keep") and not raw:
            raise ValueError("Nessuna strada percorribile in auto nella rete "
                             "(solo percorsi pedonali o ciclabili?).")
        if cost:
            self._stage("tempi di percorrenza dei tratti",
                        lo + 0.6 * span, lo + 0.6 * span)
            raw_times, self.cost_stats = edge_cost_job(
                raw, speeds, levels, cost, self.isCanceled)
        self._stage("pulizia della rete", lo + 0.7 * span, lo + 0.7 * span)
        pairs = [] if cost else None
        roads, dirs, cstats = net_clean.clean_network(raw, 1.0, rdirs,
                                                      pairs_out=pairs)
        if cost:
            from . import travel_cost
            self.edge_costs = travel_cost.costs_for_segments(raw_times, pairs)
        ok, vmsg, _ = net_iso.validate_network(roads)
        if not ok:
            raise ValueError("Rete non valida: " + vmsg)
        if preflight_coords:
            self._stage("controllo aggancio delle sorgenti",
                        lo + 0.75 * span, lo + 0.75 * span)
            pf_ok, pf_msg = network_diagnostics.preflight(
                roads, dirs, preflight_coords)
            if not pf_ok:
                raise ValueError(pf_msg)
            self.pre_msg += pf_msg
        self.pre_msg += net_clean.clean_summary(cstats) + ". "
        self.roads, self.directions = roads, dirs
        return roads, dirs

    def _line_geoms(self, per_line, data, roads, p, geom, direct_mps, top):
        """Geometrie per linea ("Dividi per linea"): per ogni linea, l'area
        raggiunta usando solo quella linea, dissolta fra le sorgenti che
        serve. Ritorna [(0, t, geometria, etichetta_linea)]."""
        from . import isochrones, net_iso, transit_iso
        labels = data.get("route_label", {})
        order = sorted(per_line, key=lambda r: str(labels.get(r, r)))
        prog = self._stage("isocrone per linea (%d linee)" % len(order),
                           top, 100)
        items = []
        for k, r in enumerate(order):
            if self.isCanceled():
                from .gtfs_static import GtfsCancelled
                raise GtfsCancelled()
            srcs = [s for s, _res in per_line[r]]
            results = [res for _s, res in per_line[r]]
            label = str(labels.get(r, r))
            if roads:
                bands = {t: net_iso.compute_union_reach(
                    roads, transit_iso.egress_budgets(
                        results, srcs, t, max_egress_m=p.get("egress_r"),
                        direct_mps=direct_mps))
                    for t in p["times"]}
                geoms = isochrones.band_geometries(
                    [bands], geom["output_mode"], geom["access_m"], True,
                    geom["ctx"], is_canceled=self.isCanceled)
            else:
                per_band = {t: [] for t in p["times"]}
                for src, (earliest, stops_xy, start_s, egress_mps) in zip(
                        srcs, results):
                    for t in p["times"]:
                        per_band[t].extend(transit_iso.transit_circles_for_band(
                            earliest, stops_xy, start_s, egress_mps, src, t,
                            p.get("egress_r", 800.0), direct_mps=direct_mps))
                geoms = isochrones.catchment_geoms(
                    [(t, per_band[t]) for t in p["times"]], geom["ctx"],
                    is_canceled=self.isCanceled)
            items.extend((0, t, g, label) for _sid, t, g in geoms)
            prog(100.0 * (k + 1) / max(1, len(order)))
        # fascia più ampia prima (resta sotto nel disegno)
        items.sort(key=lambda x: (-x[1], x[3]))
        return items

    def run(self):
        try:
            p = self.params
            geom = p.get("geom")
            # fine del calcolo: il resto dell'avanzamento va alle geometrie
            top = 60 if geom else 100
            if self.mode == "net":
                from . import net_iso
                if "road" in p:
                    roads, dirs = self._read_network(p["road"], p["sources"],
                                                     1, 15, p.get("cost"))
                else:
                    roads, dirs = p["roads"], p.get("directions")
                    self.edge_costs = p.get("edge_costs")
                    self.cost_stats = p.get("cost_stats") or {}
                speed = p["speed"]
                if self.edge_costs is not None:
                    # fasce in tempo vero: la velocità serve solo a
                    # delimitare la rete (la più alta incontrata)
                    speed = max(0.5, 3.6 * self.cost_stats.get(
                        "vmax_mps", p["speed"] / 3.6))
                if self.isCanceled():
                    self.cancelled = True
                    return False
                dissolve = bool(geom and geom.get("dissolve"))
                on_source = None
                if geom and not dissolve:
                    # sorgenti separate: poligoni subito, tratti scartati
                    # (memoria limitata a una sorgente alla volta)
                    from . import isochrones
                    self.geoms = []

                    def on_source(si, bands):
                        for t in sorted(bands, reverse=True):
                            g = isochrones._segments_to_geom(
                                bands[t], geom["output_mode"],
                                geom["access_m"], geom["ctx"],
                                is_canceled=self.isCanceled)
                            if g is not None:
                                self.geoms.append((si, t, g))
                self.result, self.n_snapped = net_iso.compute_reachable_segments(
                    roads, p["sources"], speed, p["times"],
                    directions=dirs, edge_costs=self.edge_costs,
                    progress=self._stage(
                        "percorsi e poligoni per sorgente" if on_source
                        else "percorsi sulla rete", 15,
                        100 if on_source else top),
                    is_canceled=self.isCanceled, dissolve=dissolve,
                    on_source=on_source)
                if on_source:
                    # stesso ordine di band_geometries: fascia ampia prima
                    self.geoms.sort(key=lambda x: (-x[1], x[0]))
                else:
                    self.per_source = self.result
            else:
                from . import transit_iso, net_iso
                max_t = max(p["times"])
                window_s = float(p.get("window_min", 0)) * 60.0
                step_s = float(p.get("step_min", 5)) * 60.0
                max_access = p.get("max_access_m", 800.0)
                # spostamento diretto dall'origine con il mezzo di accesso
                direct_mps = (p.get("access_speed") or p["walk_speed"]) / 3.6
                # rete (se scelta): serve sia all'accesso sia all'egress
                roads = p.get("egress_roads")
                if not roads and p.get("egress_road"):
                    roads, _dirs = self._read_network(
                        p["egress_road"], None, 0, int(top * 0.15))
                data = transit_iso.prepare_transit(
                    p["source_path"], p["start_h"], max_t + window_s / 60.0,
                    p["walk_speed"], p.get("transfer_m", 200.0),
                    p.get("service_date"),
                    progress=self._stage("lettura orari GTFS",
                                         int(top * 0.15), int(top * 0.5)),
                    is_canceled=self.isCanceled)
                graph = None
                snap_cache = {}
                if roads:
                    # grafo pedonale attorno alle sorgenti per l'accesso
                    lat0 = sum(s[0] for s in p["sources"]) / len(p["sources"])
                    to_m, _ll = net_iso._projector(lat0)
                    pm = [to_m(lo, la) for la, lo in p["sources"]]
                    pad = max_access + 600.0
                    graph = net_iso.build_metric_graph(
                        roads, lat0, (min(x for x, _ in pm) - pad,
                                      min(y for _, y in pm) - pad,
                                      max(x for x, _ in pm) + pad,
                                      max(y for _, y in pm) + pad))
                out = []
                divide = bool(p.get("divide_lines")) and geom is not None
                per_line = defaultdict(list)   # route_id -> [(sorgente, reach)]
                self.n_crowfly_access = 0
                ns = len(p["sources"])
                n_dep = int(window_s // step_s) + 1 if window_s > 0 else 1
                prog = self._stage(
                    "trasporto pubblico (%d partenze)" % n_dep
                    if n_dep > 1 else "trasporto pubblico",
                    int(top * 0.5), int(top * 0.8))
                for i, s in enumerate(p["sources"]):
                    if self.isCanceled():
                        self.cancelled = True
                        return False
                    prog(100.0 * i / ns)
                    acc = None
                    if graph is not None:
                        acc = transit_iso.network_access(
                            graph, s, data["stops_xy"], max_access, snap_cache)
                        if acc is None:
                            self.n_crowfly_access += 1
                    kw = dict(access_speed_kmh=p.get("access_speed"),
                              egress_speed_kmh=p.get("egress_speed"),
                              max_access_m=max_access,
                              transfer_penalty_s=p.get("transfer_penalty_s", 0.0),
                              access_dist=acc)

                    def _reach(**extra):
                        if n_dep > 1:
                            return transit_iso.reach_window(
                                data, s, data["start_s"], window_s, step_s,
                                max_t * 60.0, **dict(kw, **extra))
                        return transit_iso.reach_from(
                            data, s, budget_s=max_t * 60.0, **dict(kw, **extra))

                    if divide:
                        # una isocrona per ogni linea che serve il punto
                        lines = transit_iso.routes_serving(
                            data, s, max_access, data["start_s"],
                            data["start_s"] + window_s + max_t * 60.0, acc)
                        for r in lines:
                            per_line[r].append((s, _reach(routes={r})))
                    else:
                        out.append(_reach())
                self.result = out
                self.n_departures = n_dep
                self.selection = data.get("selection", "")
                if divide:
                    self.geoms = self._line_geoms(
                        per_line, data, roads, p, geom, direct_mps, top)
                    self.n_lines = len(per_line)
                    self.phase = "fine"
                    return True
                if roads:
                    # egress multimodale sulla rete pedonale (unione per fascia)
                    prog = self._stage("egress a piedi sulla rete",
                                       int(top * 0.8), top)
                    bands = {}
                    for k, t in enumerate(p["times"]):
                        if self.isCanceled():
                            self.cancelled = True
                            return False
                        bands[t] = net_iso.compute_union_reach(
                            roads, transit_iso.egress_budgets(
                                out, p["sources"], t,
                                max_egress_m=p.get("egress_r"),
                                direct_mps=direct_mps))
                        prog(100.0 * (k + 1) / len(p["times"]))
                    self.per_source = [bands]
                elif geom:
                    # senza rete: bacini circolari attorno alle fermate
                    # raggiunte, uniti per fascia qui nel worker
                    from . import isochrones
                    per_band = {t: [] for t in p["times"]}
                    for src, res in zip(p["sources"], out):
                        earliest, stops_xy, start_s, egress_mps = res
                        for t in p["times"]:
                            per_band[t].extend(
                                transit_iso.transit_circles_for_band(
                                    earliest, stops_xy, start_s, egress_mps,
                                    src, t, p.get("egress_r", 800.0),
                                    direct_mps=direct_mps))
                    self.geoms = isochrones.catchment_geoms(
                        [(t, per_band[t]) for t in p["times"]], geom["ctx"],
                        progress=self._stage("bacini attorno alle fermate",
                                             top, 100),
                        is_canceled=self.isCanceled)
            if geom and self.per_source is not None:
                from . import isochrones
                self.geoms = isochrones.band_geometries(
                    self.per_source, geom["output_mode"], geom["access_m"],
                    geom["dissolve"], geom["ctx"],
                    progress=self._stage("costruzione poligoni", top, 100),
                    is_canceled=self.isCanceled)
            self.phase = "fine"
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class AccessTask(QgsTask):
    """Accessibilita' cumulativa (rete o trasporto pubblico) in background."""

    def __init__(self, mode, params):
        super().__init__("Accessibilita", QgsTask.CanCancel)
        self.mode = mode
        self.params = params
        self.result = None
        self.times = None
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import accessibility as acc
        try:
            p = self.params
            if self.mode == "net":
                self.result, self.times = acc.accessibility_network(
                    p["origins"], p["dests"], p["roads"], p["speed"],
                    p["times"], directions=p.get("directions"),
                    progress=self.setProgress, is_canceled=self.isCanceled)
            else:
                self.result, self.times = acc.accessibility_transit(
                    p["origins"], p["dests"], p["source_path"], p["start_h"],
                    p["times"], p["walk_speed"], p.get("access_m", 800.0),
                    p.get("egress_m", 800.0),
                    access_speed_kmh=p.get("access_speed"),
                    egress_speed_kmh=p.get("egress_speed"),
                    transfer_penalty_s=p.get("transfer_penalty_s", 0.0),
                    service_date=p.get("service_date"),
                    progress=self.setProgress, is_canceled=self.isCanceled)
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class OdMatrixTask(QgsTask):
    """Matrice tempi OD via TP in background."""

    def __init__(self, zones, source_path, start_h, budget_min, walk_speed,
                 access_m=800.0, egress_m=800.0, service_date=None):
        super().__init__("Matrice OD TP", QgsTask.CanCancel)
        self.zones = zones
        self.source_path = source_path
        self.start_h = start_h
        self.budget_min = budget_min
        self.walk_speed = walk_speed
        self.access_m = access_m
        self.egress_m = egress_m
        self.service_date = service_date
        self.result = None
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import od_viz
        try:
            self.result = od_viz.compute_transit_od(
                self.zones, self.source_path, self.start_h, self.budget_min,
                self.walk_speed, self.access_m, self.egress_m,
                service_date=self.service_date,
                progress=self.setProgress, is_canceled=self.isCanceled)
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False


class ScenarioIsoTask(QgsTask):
    """Scenario isocrone A/B in background (calcolo geometrie, no layer).

    L'unione+buffer delle isocrone su due reti è pesante: si esegue nel worker
    e restituisce (ga, gb, n_snap_a, n_snap_b); il layer si costruisce poi sul
    thread principale via isochrones.build_isochrone_diff_layer.
    """

    def __init__(self, params):
        super().__init__("Scenario isocrone A/B", QgsTask.CanCancel)
        self.params = params
        self.geom_a = None
        self.geom_b = None
        self.n_snap_a = 0
        self.n_snap_b = 0
        self.exception = None
        self.cancelled = False

    def run(self):
        from . import isochrones
        try:
            p = self.params
            ga, gb, na, nb = isochrones.isochrone_scenario_geoms(
                p["roads_a"], p["roads_b"], p["sources"], p["speed"],
                p["time_min"], access_m=p.get("access_m", 30.0),
                dir_a=p.get("dir_a"), dir_b=p.get("dir_b"),
                transform_context=p["ctx"],
                progress=self.setProgress, is_canceled=self.isCanceled)
            self.geom_a, self.geom_b = ga, gb
            self.n_snap_a, self.n_snap_b = na, nb
            return True
        except gtfs_static.GtfsCancelled:
            self.cancelled = True
            return False
        except Exception as exc:
            self.exception = exc
            return False
