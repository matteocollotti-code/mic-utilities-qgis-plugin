# -*- coding: utf-8 -*-
"""Censimento del Messico: INEGI, Censo de Población y Vivienda 2020, per
AGEB (Área Geoestadística Básica, l'equivalente delle sezioni di
censimento).

- AGEB urbane: confini dal Marco Geoestadístico 2020 (strato «a») e
  valori dai «Principales resultados por AGEB y manzana urbana» (righe
  «Total AGEB urbana»): circa 220 variabili su popolazione, età, lavoro,
  istruzione, salute, famiglie e abitazioni (anche auto, moto, bici,
  internet).
- AGEB rurali: confini dallo strato «ar»; valori = somma delle località
  rurali dell'ITER (risultati per località, con le coordinate) che cadono
  dentro l'AGEB. Le medie (scolarità, occupanti per abitazione…) si
  ricalcolano pesate.
- Si scarica uno Stato alla volta, una volta sola: del Marco
  Geoestadístico (30-230 MB per Stato) solo gli strati che servono, con
  richieste a intervalli; i risultati per AGEB (2-15 MB) e l'ITER (0,3-3
  MB) interi. Il GeoPackage in cache ha un layer «ageb» in EPSG:6372.

Licenza: Términos de libre uso de la información del INEGI (si cita la
fonte). Valori riservati per confidenzialità («*», «N/D») = NULL.
"""
import csv
import io
import json
import os
import re
import shutil
import time
import unicodedata
import zipfile

from . import istat
from .istat import Cancelled, _check, _ratio, _remove, _span, fmt

SITE = "INEGI"
EDITION = 2020
SCHEMA = 1
EPSG = 6372
SOURCE = ("INEGI – Censo de Población y Vivienda 2020 (principales "
          "resultados por AGEB urbana y por localidad) e Marco "
          "Geoestadístico 2020; Términos de libre uso de la información del "
          "INEGI")
LICENCE = "Términos de libre uso de la información del INEGI"
_BASE = "https://www.inegi.org.mx/contenidos/"
AGEB_URL = (_BASE + "programas/ccpv/2020/datosabiertos/ageb_manzana/"
            "ageb_mza_urbana_%02d_cpv2020_csv.zip")
ITER_URL = (_BASE + "programas/ccpv/2020/datosabiertos/iter/"
            "iter_%02d_cpv2020_csv.zip")
MG_URL = (_BASE + "productos/prod_serv/contenidos/espanol/bvinegi/productos/"
          "geografia/marcogeo/889463807469/%02d_%s.zip")

# codice: (nome, nome del file del Marco Geoestadístico)
STATES = {
    1: ("Aguascalientes", "aguascalientes"),
    2: ("Baja California", "bajacalifornia"),
    3: ("Baja California Sur", "bajacaliforniasur"),
    4: ("Campeche", "campeche"),
    5: ("Coahuila de Zaragoza", "coahuiladezaragoza"),
    6: ("Colima", "colima"),
    7: ("Chiapas", "chiapas"),
    8: ("Chihuahua", "chihuahua"),
    9: ("Ciudad de México", "ciudaddemexico"),
    10: ("Durango", "durango"),
    11: ("Guanajuato", "guanajuato"),
    12: ("Guerrero", "guerrero"),
    13: ("Hidalgo", "hidalgo"),
    14: ("Jalisco", "jalisco"),
    15: ("México", "mexico"),
    16: ("Michoacán de Ocampo", "michoacandeocampo"),
    17: ("Morelos", "morelos"),
    18: ("Nayarit", "nayarit"),
    19: ("Nuevo León", "nuevoleon"),
    20: ("Oaxaca", "oaxaca"),
    21: ("Puebla", "puebla"),
    22: ("Querétaro", "queretaro"),
    23: ("Quintana Roo", "quintanaroo"),
    24: ("San Luis Potosí", "sanluispotosi"),
    25: ("Sinaloa", "sinaloa"),
    26: ("Sonora", "sonora"),
    27: ("Tabasco", "tabasco"),
    28: ("Tamaulipas", "tamaulipas"),
    29: ("Tlaxcala", "tlaxcala"),
    30: ("Veracruz de Ignacio de la Llave", "veracruzignaciodelallave"),
    31: ("Yucatán", "yucatan"),
    32: ("Zacatecas", "zacatecas"),
}

# campi di base del layer «ageb» (poi le variabili del censimento)
BASE_FIELDS = ["CVEGEO", "MUN", "AMBITO", "N_LOC", "AREA_M2"]
_TEXT = {"CVEGEO", "AMBITO"}
_CODES = {"CVEGEO", "MUN", "AMBITO", "N_LOC"}
BASE_LABELS = {
    "CVEGEO": "Codice dell'AGEB (Stato, municipio, località, AGEB)",
    "MUN": "Codice del municipio (Stato × 1000 + municipio)",
    "MUNICIPIO": "Municipio",
    "AMBITO": "U = AGEB urbana, R = AGEB rurale",
    "N_LOC": "Località rurali sommate nell'AGEB",
    "AREA_M2": "Superficie (m²)",
    "AREA_HA": "Superficie (ettari)",
    "QUOTA": "Parte dell'AGEB dentro l'area (0-1)",
    "POBTOT": "Popolazione totale",
    "TVIVPARHAB": "Abitazioni private abitate",
}
# etichette in italiano delle variabili più usate (le altre hanno quella
# spagnola del dizionario INEGI)
VAR_IT = {
    "POBTOT": "Popolazione totale", "POBFEM": "Donne", "POBMAS": "Uomini",
    "POB0_14": "0-14 anni", "POB15_64": "15-64 anni",
    "POB65_MAS": "65 anni e più", "P_15YMAS": "15 anni e più",
    "GRAPROES": "Anni di scuola in media (15 anni e più)",
    "PEA": "Popolazione economicamente attiva (12 anni e più)",
    "POCUPADA": "Occupati", "PDESOCUP": "Disoccupati",
    "PSINDER": "Senza diritto a servizi sanitari",
    "PCON_DISC": "Con disabilità", "P3YM_HLI": "Parlano una lingua indigena",
    "TOTHOG": "Famiglie", "VIVTOT": "Abitazioni",
    "TVIVHAB": "Abitazioni abitate", "TVIVPAR": "Abitazioni private",
    "TVIVPARHAB": "Abitazioni private abitate",
    "VIVPAR_DES": "Abitazioni private disabitate",
    "OCUPVIVPAR": "Occupanti delle abitazioni private",
    "PROM_OCUP": "Occupanti per abitazione",
    "VPH_AUTOM": "Abitazioni con automobile",
    "VPH_MOTO": "Abitazioni con moto", "VPH_BICI": "Abitazioni con bicicletta",
    "VPH_INTER": "Abitazioni con internet",
}
# medie: si sommano pesate con il campo indicato (ricalcolate per le AGEB
# rurali e per i totali)
_AVG = {"GRAPROES": "P_15YMAS", "GRAPROES_F": "P_15YMAS_F",
        "GRAPROES_M": "P_15YMAS_M", "PROM_HNV": "P_12YMAS_F",
        "PROM_OCUP": "TVIVPARHAB", "PRO_OCUP_C": "TVIVPARHAB",
        "REL_H_M": "POBFEM"}


def _pct(num, den):
    def f(v):
        return _ratio(v.get(num), v.get(den), 100.0)
    return f


DERIVED = [
    ("DENS_HA", "Densità (abitanti per ettaro)", ("POBTOT", "AREA_M2"),
     lambda v: _ratio(v["POBTOT"], v["AREA_M2"], 1e4)),
    ("PCT_0_14", "0-14 anni (%)", ("POB0_14", "POBTOT"),
     _pct("POB0_14", "POBTOT")),
    ("PCT_65P", "65 anni e più (%)", ("POB65_MAS", "POBTOT"),
     _pct("POB65_MAS", "POBTOT")),
    ("IND_VECCH", "Indice di vecchiaia (65 e più ogni 100 di 0-14 anni)",
     ("POB65_MAS", "POB0_14"), _pct("POB65_MAS", "POB0_14")),
    ("SCOLAR", "Anni di scuola in media (15 anni e più)", ("GRAPROES",),
     lambda v: v["GRAPROES"]),
    ("TASSO_DIS", "Tasso di disoccupazione (%)", ("PDESOCUP", "PEA"),
     _pct("PDESOCUP", "PEA")),
    ("PCT_SINDER", "Senza servizi sanitari (%)", ("PSINDER", "POBTOT"),
     _pct("PSINDER", "POBTOT")),
    ("PCT_DISC", "Con disabilità (%)", ("PCON_DISC", "POBTOT"),
     _pct("PCON_DISC", "POBTOT")),
    ("PCT_HLI", "Parlano una lingua indigena (% di 3 anni e più)",
     ("P3YM_HLI", "P_3YMAS"), _pct("P3YM_HLI", "P_3YMAS")),
    ("PCT_AUTO", "Abitazioni con automobile (%)", ("VPH_AUTOM", "TVIVPARHAB"),
     _pct("VPH_AUTOM", "TVIVPARHAB")),
    ("PCT_MOTO", "Abitazioni con moto (%)", ("VPH_MOTO", "TVIVPARHAB"),
     _pct("VPH_MOTO", "TVIVPARHAB")),
    ("PCT_BICI", "Abitazioni con bicicletta (%)", ("VPH_BICI", "TVIVPARHAB"),
     _pct("VPH_BICI", "TVIVPARHAB")),
    ("PCT_INTER", "Abitazioni con internet (%)", ("VPH_INTER", "TVIVPARHAB"),
     _pct("VPH_INTER", "TVIVPARHAB")),
    ("PCT_DESHAB", "Abitazioni private disabitate (%)",
     ("VIVPAR_DES", "TVIVPAR"), _pct("VIVPAR_DES", "TVIVPAR")),
]
DERIVED_LABEL = {k: d for k, d, _n, _f in DERIVED}

# temi della mappa: (chiave, voce, campo, decimali, colore chiaro, scuro)
THEMES = [
    ("dens", "Densità (abitanti per ettaro)", "DENS_HA", 0,
     "#eef2ff", "#3730a3"),
    ("pop", "Abitanti per AGEB", "POBTOT", 0, "#eef2ff", "#3730a3"),
    ("auto", "Abitazioni con automobile (%)", "PCT_AUTO", 1,
     "#fef2f2", "#991b1b"),
    ("bici", "Abitazioni con bicicletta (%)", "PCT_BICI", 1,
     "#f0fdf4", "#166534"),
    ("moto", "Abitazioni con moto (%)", "PCT_MOTO", 1, "#fff7ed", "#9a3412"),
    ("p014", "0-14 anni (%)", "PCT_0_14", 1, "#f0fdf4", "#166534"),
    ("p65", "65 anni e più (%)", "PCT_65P", 1, "#fff7ed", "#9a3412"),
    ("scol", "Anni di scuola in media", "SCOLAR", 1, "#eff6ff", "#1e40af"),
    ("dis", "Tasso di disoccupazione (%)", "TASSO_DIS", 1,
     "#fefce8", "#854d0e"),
    ("sinder", "Senza servizi sanitari (%)", "PCT_SINDER", 1,
     "#fdf4ff", "#86198f"),
    ("inter", "Abitazioni con internet (%)", "PCT_INTER", 1,
     "#ecfeff", "#155e75"),
    ("deshab", "Abitazioni private disabitate (%)", "PCT_DESHAB", 1,
     "#fefce8", "#854d0e"),
]


# ---------------------------------------------------------------- cache
_CACHE_DIR = None


def set_cache_dir(path):
    global _CACHE_DIR
    _CACHE_DIR = path


def cache_dir():
    """Cartella della cache: accanto a quella dell'ISTAT (stessa cartella
    del profilo «MIC-Utilities»), in «inegi»."""
    d = _CACHE_DIR or os.path.join(os.path.dirname(istat.cache_dir()),
                                   "inegi")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def gpkg_path(code):
    return os.path.join(cache_dir(), "inegi%d_E%02d_v%d.gpkg" % (
        EDITION, code, SCHEMA))


def _meta_path(code):
    return gpkg_path(code)[:-5] + ".json"


def state_info(code):
    """Metadati dello Stato in cache (dict) o None se non c'è."""
    p, m = gpkg_path(code), _meta_path(code)
    if not (os.path.exists(p) and os.path.exists(m)):
        return None
    try:
        with open(m, encoding="utf-8") as fh:
            meta = json.load(fh)
    except Exception:
        return None
    meta["size"] = os.path.getsize(p)
    return meta


def cache_info():
    """[(codice, Stato, metadati)] degli Stati in cache."""
    return [(c, STATES[c][0], st) for c in sorted(STATES)
            for st in [state_info(c)] if st]


def clear_cache():
    """Cancella i dati INEGI scaricati; ritorna i byte liberati."""
    d = cache_dir()
    freed = 0
    for fn in os.listdir(d):
        p = os.path.join(d, fn)
        try:
            if os.path.isdir(p):
                if fn.startswith("tmp_E"):
                    shutil.rmtree(p, ignore_errors=True)
                continue
            if re.match(r"^(inegi\d{4}_E\d\d_v\d+(_build)?\.(gpkg|json)"
                        r"|ageb_\d\d\.zip|iter_\d\d\.zip|mg_\d\d\.zip)"
                        r"(\.part)?$", fn):
                size = os.path.getsize(p)
                os.remove(p)
                freed += size
        except Exception:
            pass
    return freed


# ----------------------------------------------------------- municipios
_MUN = None
_MUN_IDX = None


def _mun_path():
    return os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "data", "inegi_municipios_2020.csv")


def municipios():
    """Municipi del censimento 2020: dict con cve (Stato × 1000 +
    municipio), nome, entidad, ent, bbox (W, S, E, N WGS84), pop, lon, lat."""
    global _MUN
    if _MUN is None:
        out = []
        try:
            with open(_mun_path(), encoding="utf-8", newline="") as fh:
                for r in csv.DictReader(fh, delimiter=";"):
                    out.append({
                        "cve": int(r["CVE"]), "nome": r["MUNICIPIO"],
                        "entidad": r["ENTIDAD"], "ent": int(r["CVE_ENT"]),
                        "bbox": (float(r["W"]), float(r["S"]),
                                 float(r["E"]), float(r["N"])),
                        "pop": int(r["POB20"] or 0),
                        "lon": float(r["LON"]), "lat": float(r["LAT"])})
        except Exception:
            out = []
        _MUN = out
    return _MUN


def _mun_index():
    global _MUN_IDX
    if _MUN_IDX is None:
        _MUN_IDX = {m["cve"]: m for m in municipios()}
    return _MUN_IDX


def mun_label(m):
    return "%s (%s)" % (m["nome"], m["entidad"])


def _plain(text):
    """Minuscolo senza accenti: «Cuauhtemoc» trova «Cuauhtémoc»."""
    t = unicodedata.normalize("NFKD", " ".join((text or "").split()))
    return "".join(c for c in t if not unicodedata.combining(c)).lower()


def find_municipio(text):
    """Il municipio scritto come «Nome (Stato)» o col solo nome, se non è
    ambiguo (accenti facoltativi). Ritorna (municipio o None, errore)."""
    t = _plain(text)
    if not t:
        return None, "Scrivi il nome del municipio."
    rows = municipios()
    if not rows:
        return None, "Elenco dei municipi non disponibile."
    for m in rows:
        if _plain(mun_label(m)) == t:
            return m, ""
    same = [m for m in rows if _plain(m["nome"]) == t]
    if len(same) == 1:
        return same[0], ""
    if len(same) > 1:
        return None, ("Ci sono più municipi «%s»: scegli dall'elenco (%s)."
                      % (text.strip(), ", ".join(mun_label(m)
                                                 for m in same[:4])))
    return None, "Municipio «%s» non trovato: scegli dall'elenco." % \
        text.strip()


def states_for_bbox(w, s, e, n):
    """Codici degli Stati i cui municipi toccano il riquadro WGS84 (vuoto
    se il riquadro è fuori dal Messico)."""
    out = set()
    for m in municipios():
        mw, ms, me, mn = m["bbox"]
        if mw <= e and me >= w and ms <= n and mn >= s:
            out.add(m["ent"])
    return sorted(out)


# ------------------------------------------------------------- download
def _members(code, layers, tmp, step, is_canceled):
    """Gli shapefile `layers` (es. ["a", "ar"]) del Marco Geoestadístico
    dello Stato, scaricati con richieste a intervalli (o con tutto
    l'archivio se il server non le accetta). Ritorna {strato: .shp}."""
    url = MG_URL % (code, STATES[code][1])
    want = ["conjunto_de_datos/%02d%s.%s" % (code, lay, ext)
            for lay in layers for ext in ("shp", "shx", "dbf", "prj", "cpg")]
    try:
        d = istat._zip_directory(url, site=SITE)
        entries = [(m, d[m]) for m in want if m in d]
        total = float(sum(e[1] for _m, e in entries) or 1)
        done = 0.0
        for m, e in entries:
            _check(is_canceled)
            dst = os.path.join(tmp, os.path.basename(m))
            istat._fetch_member(url, e, dst,
                                lambda f, d0=done, sz=e[1]: step(
                                    (d0 + f * sz) / total),
                                is_canceled, site=SITE)
            done += e[1]
    except istat._NoRange:
        whole = os.path.join(cache_dir(), "mg_%02d.zip" % code)
        try:
            istat._download(url, whole, step, is_canceled, site=SITE)
            with zipfile.ZipFile(whole) as z:
                names = set(z.namelist())
                for m in want:
                    if m in names:
                        with z.open(m) as src, open(os.path.join(
                                tmp, os.path.basename(m)), "wb") as dst:
                            shutil.copyfileobj(src, dst)
        finally:
            _remove(whole)
    out = {}
    for lay in layers:
        p = os.path.join(tmp, "%02d%s.shp" % (code, lay))
        if os.path.exists(p):
            out[lay] = p
    return out


def _csv_member(zpath, pattern):
    """Righe del CSV dello zip il cui nome rispetta `pattern`."""
    with zipfile.ZipFile(zpath) as z:
        name = next((n for n in z.namelist()
                     if re.search(pattern, n, re.I)), None)
        if name is None:
            raise RuntimeError("archivio INEGI con una struttura inattesa "
                               "(manca %s)" % pattern)
        raw = z.read(name)
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    return list(csv.reader(io.StringIO(text)))


def _num(x):
    """Valore del CSV: numero o None (riservato «*», «N/D», vuoto)."""
    x = (x or "").strip()
    if not x or x in ("*", "N/D", "N/A"):
        return None
    try:
        return float(x)
    except ValueError:
        return None


_DMS = re.compile(r"(\d+)\D+(\d+)\D+([\d.]+)\D*([NSEWO])", re.I)


def _dms(text):
    """«102°17'45.768" W» → -102.296…; None se non si legge."""
    m = _DMS.search(text or "")
    if not m:
        return None
    v = float(m.group(1)) + float(m.group(2)) / 60.0 + \
        float(m.group(3)) / 3600.0
    return -v if m.group(4).upper() in ("S", "W", "O") else v


def _dictionary(zpath):
    """{variabile: etichetta spagnola} dal dizionario dei dati."""
    try:
        rows = _csv_member(zpath, r"diccionario.*\.csv$")
    except Exception:
        return {}
    head = None
    out = {}
    for r in rows:
        low = [c.strip().lower() for c in r]
        if head is None:
            if any(c.startswith("mnem") for c in low):
                head = low
                i_code = next(i for i, c in enumerate(low)
                              if c.startswith("mnem"))
                i_lab = next((i for i, c in enumerate(low)
                              if c.startswith("indicador")), 1)
            continue
        if len(r) > max(i_code, i_lab) and r[i_code].strip():
            out[r[i_code].strip()] = r[i_lab].strip()
    return out


# ------------------------------------------------------------ costruzione
def ensure_state(code, progress=None, is_canceled=None, status=None):
    """Mette in cache lo Stato (se manca) e ritorna (GeoPackage, nota).

    :raises Cancelled: annullato.
    """
    if code not in STATES:
        raise ValueError("codice di Stato non valido: %s" % code)
    path = gpkg_path(code)
    if state_info(code) is not None:
        if progress:
            progress(100)
        return path, ""
    say = status or (lambda _t: None)
    name = STATES[code][0]
    d = cache_dir()
    tmp = os.path.join(d, "tmp_E%02d" % code)
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    zageb = os.path.join(d, "ageb_%02d.zip" % code)
    ziter = os.path.join(d, "iter_%02d.zip" % code)
    build = path[:-5] + "_build.gpkg"
    try:
        say("confini delle AGEB di %s (Marco Geoestadístico, solo la prima "
            "volta)" % name)
        shps = _members(code, ["a", "ar"], tmp, _span(progress, 0, 40),
                        is_canceled)
        if "a" not in shps and "ar" not in shps:
            raise RuntimeError("confini delle AGEB non trovati "
                               "nell'archivio INEGI")
        say("risultati per AGEB di %s (solo la prima volta)" % name)
        istat._download(AGEB_URL % code, zageb, _span(progress, 40, 70),
                        is_canceled, site=SITE)
        say("risultati per località di %s (solo la prima volta)" % name)
        istat._download(ITER_URL % code, ziter, _span(progress, 70, 80),
                        is_canceled, site=SITE)
        say("archivio delle AGEB di %s" % name)
        meta = _build_gpkg(code, shps, zageb, ziter, build,
                           _span(progress, 80, 100), is_canceled)
        _remove(path)
        os.replace(build, path)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        for p in (zageb, ziter, build, build + "-journal"):
            _remove(p)
    meta.update({"code": code, "edition": EDITION, "ts": time.time()})
    with open(_meta_path(code), "w", encoding="utf-8") as fh:
        json.dump(meta, fh)
    if progress:
        progress(100)
    return path, ""


def _build_gpkg(code, shps, zageb, ziter, out, step, is_canceled):
    """AGEB urbane e rurali con le variabili del censimento in un
    GeoPackage (layer «ageb», tabella «variabili»). Ritorna i metadati."""
    from osgeo import gdal, ogr, osr
    rows = _csv_member(zageb, r"conjunto_de_datos_ageb_urbana.*\.csv$")
    head = [h.strip() for h in rows[0]]
    col = {h: i for i, h in enumerate(head)}
    for need in ("ENTIDAD", "MUN", "LOC", "AGEB", "MZA", "NOM_LOC",
                 "POBTOT"):
        if need not in col:
            raise RuntimeError("risultati INEGI senza la colonna %s" % need)
    variables = head[col["POBTOT"]:]
    urban = {}
    urban_locs = set()
    for r in rows[1:]:
        if len(r) < len(head):
            continue
        nl = r[col["NOM_LOC"]].strip().lower()
        if nl.startswith("total ageb urbana"):
            key = "%02d%03d%04d%s" % (int(r[col["ENTIDAD"]]),
                                      int(r[col["MUN"]]),
                                      int(r[col["LOC"]]),
                                      r[col["AGEB"]].strip().upper())
            urban[key] = [_num(r[col[v]]) for v in variables]
        elif nl.startswith("total de la localidad urbana"):
            urban_locs.add((int(r[col["MUN"]]), int(r[col["LOC"]])))
    labels = _dictionary(zageb)
    _check(is_canceled)
    it = _csv_member(ziter, r"conjunto_de_datos_iter.*\.csv$")
    ih = [h.strip() for h in it[0]]
    ic = {h: i for i, h in enumerate(ih)}
    state_pop = None
    rural = []      # (mun, lon, lat, valori)
    lost = 0
    for r in it[1:]:
        if len(r) < len(ih):
            continue
        mun, loc = int(r[ic["MUN"]]), int(r[ic["LOC"]])
        if mun == 0 and loc == 0:
            state_pop = _num(r[ic["POBTOT"]])
            continue
        if mun == 0 or loc in (0, 9998, 9999) or (mun, loc) in urban_locs:
            continue
        lon, lat = _dms(r[ic["LONGITUD"]]), _dms(r[ic["LATITUD"]])
        vals = [_num(r[ic[v]]) if v in ic else None for v in variables]
        if lon is None or lat is None:
            lost += vals[0] or 0
            continue
        rural.append((mun, lon, lat, vals))
    nv = len(variables)
    i_pop = 0
    # ---- poligoni
    gdal.PushErrorHandler("CPLQuietErrorHandler")
    try:
        polys = []    # [cvegeo, mun, ambito, geom, valori, n_loc]
        srs = None
        for lay_key, amb in (("a", "U"), ("ar", "R")):
            p = shps.get(lay_key)
            if not p:
                continue
            src = ogr.Open(p)
            sl = src.GetLayer(0)
            srs = srs or sl.GetSpatialRef().Clone()
            for f in sl:
                g = f.GetGeometryRef()
                if g is None or g.IsEmpty():
                    continue
                g = g.Clone()
                if not g.IsValid():
                    g = g.MakeValid()
                g = istat._multipolygon(g) if g is not None else None
                if g is None:
                    continue
                cve = (f.GetField("CVEGEO") or "").strip().upper()
                mun = int(f.GetField("CVE_MUN") or 0)
                if amb == "U":
                    vals = urban.pop(cve, None)
                    vals = list(vals) if vals else [None] * nv
                else:
                    vals = [None] * nv
                polys.append([cve, code * 1000 + mun, amb, g, vals, 0])
            src = None
        if srs is None:
            raise RuntimeError("confini INEGI senza sistema di riferimento")
        # AGEB urbane dei risultati che nel Marco sono rurali (la località
        # è rurale nei confini e urbana nei risultati): stesso Stato,
        # municipio e AGEB, poligono dello strato rurale
        rural_idx = {p[0]: k for k, p in enumerate(polys) if p[2] == "R"}
        for key in list(urban):
            k = rural_idx.get(key[:5] + key[9:])
            if k is not None and all(x is None for x in polys[k][4]):
                polys[k][4] = list(urban.pop(key))
        _check(is_canceled)
        # ---- località rurali dentro le AGEB (rurali prima, poi urbane;
        # fuori da tutte: la AGEB rurale più vicina dello stesso municipio)
        wgs = istat._traditional(osr.SpatialReference())
        wgs.ImportFromEPSG(4326)
        ct = osr.CoordinateTransformation(wgs, istat._traditional(
            srs.Clone()))
        # indice a griglia (celle di 5 km) dei riquadri delle AGEB
        cell = 5000.0
        grid = {}
        for k, p in enumerate(polys):
            minx, maxx, miny, maxy = p[3].GetEnvelope()
            for gx in range(int(minx // cell), int(maxx // cell) + 1):
                for gy in range(int(miny // cell), int(maxy // cell) + 1):
                    grid.setdefault((gx, gy), []).append(k)
        by_mun = {}
        for k, p in enumerate(polys):
            if p[2] == "R":
                by_mun.setdefault(p[1], []).append(k)
        sums = {}     # indice → (valori sommati, pesi delle medie)
        nearest = 0
        avg_idx = {variables.index(a): variables.index(w)
                   for a, w in _AVG.items()
                   if a in variables and w in variables}
        for n_done, (mun, lon, lat, vals) in enumerate(rural):
            if n_done % 500 == 0:
                _check(is_canceled)
                step(0.6 * n_done / max(1, len(rural)))
            x, y, _z = ct.TransformPoint(lon, lat)
            pt = ogr.Geometry(ogr.wkbPoint)
            pt.AddPoint_2D(x, y)
            hit = None
            near = grid.get((int(x // cell), int(y // cell)), [])
            for amb in ("R", "U"):
                for k in near:
                    if polys[k][2] == amb and polys[k][3].Contains(pt):
                        hit = k
                        break
                if hit is not None:
                    break
            if hit is None:
                cand = by_mun.get(code * 1000 + mun) or [
                    k for k, p in enumerate(polys) if p[2] == "R"]
                if not cand:
                    lost += vals[0] or 0
                    continue
                hit = min(cand, key=lambda k: polys[k][3].Distance(pt))
                nearest += 1
            acc = sums.setdefault(hit, [[None] * nv, {}])
            tot = acc[0]
            for i, v in enumerate(vals):
                if v is None:
                    continue
                if i in avg_idx:
                    w = vals[avg_idx[i]]
                    if w:
                        a = acc[1].setdefault(i, [0.0, 0.0])
                        a[0] += v * w
                        a[1] += w
                    continue
                tot[i] = v if tot[i] is None else tot[i] + v
            polys[hit][5] += 1
        for k, (tot, avgs) in sums.items():
            cur = polys[k][4]
            for i, v in enumerate(tot):
                if v is not None and i not in avg_idx:
                    cur[i] = v if cur[i] is None else cur[i] + v
            for i, (sw, w) in avgs.items():
                if polys[k][2] == "R" or cur[i] is None:
                    cur[i] = round(sw / w, 2) if w else None
            if "REL_H_M" in variables:
                im, iff = variables.index("POBMAS"), variables.index("POBFEM")
                if cur[im] is not None and cur[iff]:
                    cur[variables.index("REL_H_M")] = round(
                        100.0 * cur[im] / cur[iff], 2)
        # ---- GeoPackage
        _remove(out)
        dst = ogr.GetDriverByName("GPKG").CreateDataSource(out)
        if dst is None:
            raise RuntimeError("impossibile scrivere nella cache: %s" % out)
        dl = dst.CreateLayer("ageb", srs, ogr.wkbMultiPolygon)
        for name in BASE_FIELDS:
            dl.CreateField(ogr.FieldDefn(
                name, ogr.OFTString if name in _TEXT else ogr.OFTReal
                if name == "AREA_M2" else ogr.OFTInteger))
        for v in variables:
            dl.CreateField(ogr.FieldDefn(v, ogr.OFTReal))
        dd = dl.GetLayerDefn()
        pop = 0.0
        dl.StartTransaction()
        for k, (cve, mun, amb, g, vals, nloc) in enumerate(polys):
            if k % 500 == 0:
                _check(is_canceled)
                step(0.6 + 0.4 * k / max(1, len(polys)))
            o = ogr.Feature(dd)
            o.SetGeometry(g)
            o.SetField("CVEGEO", cve)
            o.SetField("MUN", mun)
            o.SetField("AMBITO", amb)
            o.SetField("N_LOC", nloc)
            o.SetField("AREA_M2", g.GetArea())
            for v, x in zip(variables, vals):
                if x is not None:
                    o.SetField(v, x)
            dl.CreateFeature(o)
            pop += vals[i_pop] or 0
        dl.CommitTransaction()
        dst.ExecuteSQL("CREATE INDEX idx_ageb_mun ON ageb (MUN)")
        dst.ExecuteSQL("CREATE TABLE variabili (codice TEXT PRIMARY KEY, "
                       "etichetta TEXT)")
        for v in variables:
            lab = labels.get(v, "").replace("'", "''")
            dst.ExecuteSQL("INSERT INTO variabili VALUES ('%s', '%s')"
                           % (v, lab))
        dl = None
        dst = None
    finally:
        gdal.PopErrorHandler()
    missing = sum((v[i_pop] or 0) for v in urban.values())
    return {"agebs_u": sum(1 for p in polys if p[2] == "U"),
            "agebs_r": sum(1 for p in polys if p[2] == "R"),
            "pop": pop, "pop_state": state_pop,
            "rural_locs": len(rural), "rural_nearest": nearest,
            "ageb_missing": len(urban), "pop_missing": missing + lost,
            "variables": len(variables)}


# --------------------------------------------------------------- lettura
def variables(code):
    """[(variabile, etichetta)] dello Stato in cache."""
    import sqlite3
    con = sqlite3.connect(gpkg_path(code))
    try:
        return list(con.execute("SELECT codice, etichetta FROM variabili"))
    except Exception:
        return []
    finally:
        con.close()


def read_agebs(code, rect=None, wkt=None, mun=None, wgs84=False,
               is_canceled=None):
    """AGEB dello Stato in cache: tutte quelle del municipio `mun` (codice
    Stato × 1000 + municipio), o quelle che toccano il poligono `wkt` o il
    riquadro `rect` (W, S, E, N) in WGS84.

    :return: (campi, righe) con righe = [(geometria, quota, valori)], come
        `istat.read_sections`: geometria WKB in EPSG:6372 (o WKT WGS84 con
        wgs84=True), quota = parte dell'AGEB dentro l'area.
    """
    from osgeo import ogr
    ds = ogr.Open(gpkg_path(code))
    lay = ds.GetLayerByName("ageb") if ds is not None else None
    if lay is None:
        raise RuntimeError("dati INEGI di %s non leggibili: svuota i dati "
                           "scaricati e riprova" % STATES[code][0])
    to_l, to_w = istat._transforms(lay.GetSpatialRef())
    area = None
    if mun is not None:
        codes = mun if isinstance(mun, (list, tuple, set)) else [mun]
        lay.SetAttributeFilter("MUN IN (%s)" % ",".join(
            str(int(c)) for c in codes))
    elif wkt:
        area = ogr.CreateGeometryFromWkt(wkt)
    elif rect:
        w, s, e, n = rect
        area = ogr.CreateGeometryFromWkt(
            "POLYGON((%r %r,%r %r,%r %r,%r %r,%r %r))" % (
                w, s, e, s, e, n, w, n, w, s))
    if area is not None:
        area.Segmentize(0.02)
        area.Transform(to_l)
        if not area.IsValid():
            area = area.MakeValid()
        lay.SetSpatialFilter(area)
    dd = lay.GetLayerDefn()
    fields = [dd.GetFieldDefn(i).GetName() for i in range(dd.GetFieldCount())]
    rows = []
    for k, f in enumerate(lay):
        if k % 500 == 0:
            _check(is_canceled)
        g = f.GetGeometryRef()
        if g is None:
            continue
        share = 1.0
        if area is not None:
            if not g.Intersects(area):
                continue
            a = g.GetArea()
            inter = g.Intersection(area)
            share = min(1.0, inter.GetArea() / a) if a > 0 and \
                inter is not None else 0.0
            if share <= 0:
                continue
        vals = [f.GetField(i) for i in range(len(fields))]
        if wgs84:
            g = g.Clone()
            g.Transform(to_w)
            geom = g.ExportToWkt()
        else:
            geom = bytes(g.ExportToWkb())
        rows.append((geom, share, vals))
    lay = None
    ds = None
    return fields, rows


def fetch(rect=None, wkt=None, mun=None, wgs84=False, progress=None,
          is_canceled=None, status=None):
    """Scarica gli Stati che servono (se non sono in cache) e legge le AGEB
    del municipio o dell'area.

    :return: dict con fields, rows, regions (codici degli Stati; vuoto se
        l'area è fuori dal Messico), notes, cached; None se annullato.
    """
    if mun is not None:
        m = _mun_index().get(int(mun))
        if m is None:
            raise ValueError("municipio %s sconosciuto" % mun)
        states = [m["ent"]]
    else:
        box = istat._bbox_of_wkt(wkt) if wkt else rect
        if box is None:
            raise ValueError("indica un municipio o un'area")
        states = states_for_bbox(*box)
    out = {"fields": list(BASE_FIELDS), "rows": [], "regions": states,
           "notes": [], "cached": True}
    try:
        for k, code in enumerate(states):
            if state_info(code) is None:
                out["cached"] = False
            sub = _span(progress, 100.0 * k / len(states),
                        100.0 * (k + 0.95) / len(states))
            _p, note = ensure_state(code, lambda p, f=sub: f(p / 100.0),
                                    is_canceled, status)
            if note:
                out["notes"].append(note)
            meta = state_info(code) or {}
            if meta.get("pop_missing"):
                out["notes"].append(
                    "%s: %s residenti senza AGEB (località senza coordinate "
                    "o AGEB senza confini) non sono sulla mappa"
                    % (STATES[code][0], fmt(meta["pop_missing"])))
            if status:
                status("lettura delle AGEB di %s" % STATES[code][0])
            fields, rows = read_agebs(code, rect, wkt, mun, wgs84,
                                      is_canceled)
            if out["rows"] and fields != out["fields"]:
                rows = _align(fields, rows, out["fields"])
            else:
                out["fields"] = fields
            out["rows"] += rows
    except Cancelled:
        return None
    if progress:
        progress(100)
    return out


def _align(fields, rows, target):
    idx = [fields.index(f) if f in fields else None for f in target]
    return [(g, q, [v[i] if i is not None else None for i in idx])
            for g, q, v in rows]


# -------------------------------------------------------------- riepilogo
def totals(data):
    """Somme pesate con la quota di ogni AGEB dentro l'area; le medie
    (scolarità, occupanti…) pesate con il loro campo. dict campo → totale,
    più «_sections», «_inhabited», «_urban», «_rural»."""
    fields = data["fields"]
    skip = {i for i, f in enumerate(fields) if f in _CODES}
    tot = [0.0] * len(fields)
    avg = {fields.index(a): fields.index(w) for a, w in _AVG.items()
           if a in fields and w in fields}
    wsum = {i: [0.0, 0.0] for i in avg}
    i_pop = fields.index("POBTOT")
    i_amb = fields.index("AMBITO") if "AMBITO" in fields else None
    inhabited = urban = 0
    for _g, q, v in data["rows"]:
        for i, x in enumerate(v):
            if x is None or i in skip:
                continue
            if i in avg:
                w = v[avg[i]]
                if w:
                    wsum[i][0] += q * w * x
                    wsum[i][1] += q * w
                continue
            tot[i] += q * x
        if v[i_pop]:
            inhabited += 1
        if i_amb is not None and v[i_amb] == "U":
            urban += 1
    for i, (sw, w) in wsum.items():
        tot[i] = sw / w if w else None
    out = {f: t for i, (f, t) in enumerate(zip(fields, tot)) if i not in skip}
    out["_sections"] = len(data["rows"])
    out["_inhabited"] = inhabited
    out["_urban"] = urban
    out["_rural"] = len(data["rows"]) - urban
    return out


def derive(values):
    out = {}
    for key, _d, needs, fn in DERIVED:
        if all(values.get(k) is not None for k in needs):
            try:
                out[key] = fn(values)
            except (TypeError, ZeroDivisionError):
                out[key] = None
    return out


def summary(data):
    """Riepilogo leggibile delle AGEB lette: [(voce, valore)]."""
    t = totals(data)
    d = derive(t)

    def pct(k):
        return "%s %%" % fmt(d.get(k), 1)
    rows = [("AGEB", "%s (%s urbane, %s rurali)" % (
        fmt(t["_sections"]), fmt(t["_urban"]), fmt(t["_rural"]))),
        ("Popolazione", fmt(t.get("POBTOT"))),
        ("Superficie", "%s km²" % fmt((t.get("AREA_M2") or 0) / 1e6, 2)),
        ("Densità", "%s ab./km²" % fmt(
            _ratio(t.get("POBTOT"), t.get("AREA_M2"), 1e6), 0)),
        ("Famiglie", fmt(t.get("TOTHOG"))),
        ("Abitazioni private abitate", fmt(t.get("TVIVPARHAB"))),
        ("Occupanti per abitazione", fmt(_ratio(
            t.get("OCUPVIVPAR"), t.get("TVIVPARHAB")), 2)),
        ("0-14 anni", pct("PCT_0_14")),
        ("65 anni e più", pct("PCT_65P")),
        ("Indice di vecchiaia", fmt(d.get("IND_VECCH"), 0)),
        ("Anni di scuola in media (15 e più)", fmt(d.get("SCOLAR"), 1)),
        ("Tasso di disoccupazione", pct("TASSO_DIS")),
        ("Senza servizi sanitari", pct("PCT_SINDER")),
        ("Con disabilità", pct("PCT_DISC")),
        ("Abitazioni con automobile", pct("PCT_AUTO")),
        ("Abitazioni con moto", pct("PCT_MOTO")),
        ("Abitazioni con bicicletta", pct("PCT_BICI")),
        ("Abitazioni con internet", pct("PCT_INTER")),
        ("Abitazioni private disabitate", pct("PCT_DESHAB"))]
    return rows


# -------------------------------------------------------- per il report
def report_data(rect, area_wkt=None, demo=True, progress=None,
                is_canceled=None, status=None):
    """Residenti INEGI per il report d'area, nello stesso formato di
    `istat.report_data`: pop [(wkt WGS84, abitanti)], regions, notes,
    demo (None: la pagina «Popolazione» per ora c'è solo con l'ISTAT) e
    demo_skip; None se annullato."""
    if status:
        status("residenti delle AGEB attorno all'area")
    data = fetch(rect=rect, wgs84=True, progress=progress,
                 is_canceled=is_canceled, status=status)
    if data is None:
        return None
    if not data["regions"]:
        return {"pop": [], "regions": [], "notes": [], "demo": None,
                "demo_skip": "l'area non è in Messico"}
    i = data["fields"].index("POBTOT")
    out = {"pop": [(g, float(v[i])) for g, _q, v in data["rows"]
                   if v[i] and v[i] > 0],
           "regions": data["regions"], "notes": list(data["notes"]),
           "demo": None, "demo_skip": ""}
    if not data["regions"]:
        out["demo_skip"] = "l'area non è in Messico"
    elif demo:
        out["demo_skip"] = ("la pagina «Popolazione» per ora c'è solo con "
                            "i dati ISTAT")
    return out


# ------------------------------------------------------------ layer QGIS
def _labels(code_list):
    out = {}
    for code in code_list:
        out.update({k: v for k, v in variables(code) if v})
    return out


def build_layer(data, name, theme="dens"):
    """Layer in memoria delle AGEB lette (EPSG:6372) con gli indicatori
    derivati, gli alias dei campi e il tema scelto. Thread principale."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import QgsFeature, QgsField, QgsGeometry, QgsVectorLayer
    lay = QgsVectorLayer("MultiPolygon?crs=EPSG:%d" % EPSG, name, "memory")
    fields = data["fields"]
    partial = any(q < 0.999 for _g, q, _v in data["rows"])
    var = [f for f in fields if f not in BASE_FIELDS]
    derived = [k for k, _d, needs, _f in DERIVED
               if all(n in fields for n in needs)]
    head = ["CVEGEO", "MUNICIPIO", "MUN", "AMBITO", "N_LOC", "POBTOT",
            "TVIVPARHAB", "AREA_HA"] + (["QUOTA"] if partial else [])
    defs = []
    for k in head:
        kind = (QVariant.String if k in ("CVEGEO", "MUNICIPIO", "AMBITO")
                else QVariant.Double if k in ("AREA_HA", "QUOTA") else
                QVariant.Int)
        defs.append(QgsField(k, kind))
    defs += [QgsField(k, QVariant.Double) for k in derived]
    defs += [QgsField(k, QVariant.Double) for k in var
             if k not in ("POBTOT", "TVIVPARHAB")]
    pr = lay.dataProvider()
    pr.addAttributes(defs)
    lay.updateFields()
    rest = [k for k in var if k not in ("POBTOT", "TVIVPARHAB")]
    names = _mun_index()
    feats = []
    for wkb, q, v in data["rows"]:
        row = dict(zip(fields, v))
        g = QgsGeometry()
        g.fromWkb(wkb)
        f = QgsFeature(lay.fields())
        f.setGeometry(g)
        m = names.get(row.get("MUN"))
        d = derive(row)
        attrs = []
        for k in head:
            if k == "MUNICIPIO":
                attrs.append(m["nome"] if m else None)
            elif k == "AREA_HA":
                attrs.append(round((row.get("AREA_M2") or 0) / 1e4, 3))
            elif k == "QUOTA":
                attrs.append(round(q, 4))
            elif k in ("POBTOT", "TVIVPARHAB") and row.get(k) is not None:
                attrs.append(int(row[k]))
            else:
                attrs.append(row.get(k))
        attrs += [None if d.get(k) is None else round(d[k], 2)
                  for k in derived]
        attrs += [row.get(k) for k in rest]
        f.setAttributes(attrs)
        feats.append(f)
    pr.addFeatures(feats)
    lay.updateExtents()
    es = _labels(data.get("regions") or [])
    for i, fld in enumerate(lay.fields()):
        k = fld.name()
        label = BASE_LABELS.get(k) or DERIVED_LABEL.get(k) or \
            VAR_IT.get(k) or es.get(k)
        if label:
            lay.setFieldAlias(i, "%s · %s" % (k, label))
    apply_theme(lay, theme)
    return lay


def points_of(data):
    """Un punto dentro ogni AGEB letta: [(lat, lon)] (righe in EPSG:6372,
    cioè senza wgs84=True)."""
    from osgeo import ogr, osr
    loc = osr.SpatialReference()
    loc.ImportFromEPSG(EPSG)
    _to_l, to_w = istat._transforms(loc)
    out = []
    for wkb, _q, _v in data["rows"]:
        g = ogr.CreateGeometryFromWkb(wkb)
        pt = g.PointOnSurface() if g is not None else None
        if pt is None or pt.IsEmpty():
            pt = g.Centroid()
        x, y, _z = to_w.TransformPoint(pt.GetX(), pt.GetY())
        out.append((y, x))
    return out


def build_points_layer(data, name):
    """Un punto per AGEB con residenti, peso POBTOT: per isocrone,
    accessibilità e gap del PTAL. Thread principale."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsFeature, QgsField, QgsGeometry, QgsMarkerSymbol,
                           QgsPointXY, QgsProperty, QgsSingleSymbolRenderer,
                           QgsSymbolLayer, QgsVectorLayer)
    lay = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    pr = lay.dataProvider()
    pr.addAttributes([QgsField("CVEGEO", QVariant.String),
                      QgsField("MUNICIPIO", QVariant.String),
                      QgsField("MUN", QVariant.Int),
                      QgsField("AMBITO", QVariant.String),
                      QgsField("POBTOT", QVariant.Int),
                      QgsField("TVIVPARHAB", QVariant.Int)])
    lay.updateFields()
    fields = data["fields"]
    ix = [fields.index(k) if k in fields else None
          for k in ("CVEGEO", "MUN", "AMBITO", "POBTOT", "TVIVPARHAB")]
    names = _mun_index()
    feats = []
    top = 1
    for (la, lo), (_g, _q, v) in zip(points_of(data), data["rows"]):
        cve, mun, amb, pop, viv = (v[i] if i is not None else None
                                   for i in ix)
        if not pop:
            continue
        m = names.get(mun)
        f = QgsFeature(lay.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lo, la)))
        f.setAttributes([cve, m["nome"] if m else None, mun, amb, int(pop),
                         int(viv) if viv is not None else None])
        feats.append(f)
        top = max(top, pop)
    pr.addFeatures(feats)
    lay.updateExtents()
    sym = QgsMarkerSymbol.createSimple({
        "name": "circle", "color": "79,70,229,170",
        "outline_color": "#ffffff", "outline_width": "0.15", "size": "1.4"})
    sym.symbolLayer(0).setDataDefinedProperty(
        QgsSymbolLayer.PropertySize, QgsProperty.fromExpression(
            'scale_linear(sqrt("POBTOT"), 0, %r, 0.7, 3.6)' % (top ** 0.5)))
    lay.setRenderer(QgsSingleSymbolRenderer(sym))
    for i, fld in enumerate(lay.fields()):
        label = BASE_LABELS.get(fld.name())
        if label:
            lay.setFieldAlias(i, "%s · %s" % (fld.name(), label))
    return lay


def theme_available(layer, key):
    return istat.theme_available(layer, key, THEMES)


def apply_theme(layer, key, classes=5):
    return istat.apply_theme(layer, key, classes, THEMES, "POBTOT")

