# -*- coding: utf-8 -*-
"""Classe principale del plugin: integra azioni, menu e dock widget."""
import os

from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsApplication

from .analyzer_dockwidget import AnalyzerDockWidget
from .processing_alg import MicProvider
from . import updater, report_idml

# logo MIC Hub (barra strumenti, menu Vettore, Processing)
ICON_PATH = os.path.join(os.path.dirname(__file__), "icon.svg")


class RoadNetworkAnalyzer:
    """Gestisce il ciclo di vita del plugin in QGIS."""

    def __init__(self, iface):
        self.iface = iface
        self.menu = "&MIC - Utilities"
        self.actions = []
        self.dockwidget = None
        self.provider = None
        self.updater = None

    def initProcessing(self):  # noqa: N802 (API QGIS)
        """Registra il provider Processing. Chiamato anche in modalità headless
        (qgis_process) grazie a hasProcessingProvider=yes nel metadata."""
        if self.provider is None:
            self.provider = MicProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):  # noqa: N802 (API QGIS)
        self.initProcessing()
        action = QAction(QIcon(ICON_PATH), "MIC - Utilities",
                         self.iface.mainWindow())
        action.triggered.connect(self.run)
        self.iface.addToolBarIcon(action)
        self.iface.addPluginToVectorMenu(self.menu, action)
        self.actions.append(action)
        news = QAction("Novità", self.iface.mainWindow())
        news.triggered.connect(
            lambda: updater.show_whats_new(self.iface.mainWindow()))
        self.iface.addPluginToVectorMenu(self.menu, news)
        self.actions.append(news)
        # compositore di stampa: «Esporta per InDesign (IDML)…» nel menu
        # Layout di ogni compositore, anche di quelli già aperti
        try:
            self.iface.layoutDesignerOpened.connect(self._designer_opened)
            for designer in self.iface.openLayoutDesigners():
                self._designer_opened(designer)
        except Exception:
            pass  # mai bloccare il caricamento del plugin
        # aggiornamenti: novità dopo un aggiornamento (decise prima di
        # ensure_repository, che imposta il flag usato per riconoscerlo),
        # repository nel gestore plugin (una volta) e controllo di una
        # versione nuova poco dopo l'avvio
        try:
            current, entries = updater.prepare_whats_new()
            if entries:
                QTimer.singleShot(3000, lambda: updater.notify_whats_new(
                    self.iface, current, entries))
        except Exception:
            pass  # mai bloccare il caricamento del plugin
        try:
            if updater.ensure_repository():
                self.iface.messageBar().pushInfo(
                    "MIC - Utilities",
                    "Aggiunto il repository del plugin: gli aggiornamenti "
                    "compariranno in Plugin → Gestisci e installa plugin.")
            self.updater = updater.UpdateChecker(self.iface)
            QTimer.singleShot(5000, self.updater.start)
        except Exception:
            self.updater = None  # mai bloccare il caricamento del plugin

    def _designer_opened(self, designer):
        try:
            report_idml.add_designer_action(designer, ICON_PATH)
        except Exception:
            pass

    def unload(self):
        try:
            self.iface.layoutDesignerOpened.disconnect(self._designer_opened)
        except Exception:
            pass
        try:
            for designer in self.iface.openLayoutDesigners():
                report_idml.remove_designer_action(designer)
        except Exception:
            pass
        for action in self.actions:
            self.iface.removePluginVectorMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)  # nessun effetto per «Novità»
        self.actions = []
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
        if self.dockwidget is not None:
            try:
                self.dockwidget.release_map_tools()
            except Exception:
                pass
            self.iface.removeDockWidget(self.dockwidget)
            self.dockwidget.deleteLater()
            self.dockwidget = None

    def run(self):
        if self.dockwidget is None:
            self.dockwidget = AnalyzerDockWidget(self.iface, self.iface.mainWindow())
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dockwidget)
        self.dockwidget.show()
        self.dockwidget.raise_()
