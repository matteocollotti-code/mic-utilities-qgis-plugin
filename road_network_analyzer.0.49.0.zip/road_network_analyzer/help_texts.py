# -*- coding: utf-8 -*-
"""Testi di aiuto per ogni scheda.

Obiettivo: spiegare con chiarezza il SIGNIFICATO delle operazioni spaziali che
ogni funzione esegue (aggancio alla rete, distanze di rete, buffer, ecc.), non
solo l'elenco dei campi.
"""

# Nota condivisa sull'aggancio alla rete (riusata in più schede).
_SNAP = ("""
<p><b>Come vengono misurate le distanze sulla rete</b>: ogni punto (origine,
fermata, destinazione) viene <i>proiettato sull'arco stradale più vicino</i>
entro 500 m (non sul vertice più vicino, ma sul punto esatto del segmento). Da
lì il percorso più breve si calcola con l'algoritmo di Dijkstra sul grafo della
rete. Se due punti cadono sullo stesso arco la distanza è quella diretta lungo
l'arco. Un punto a più di 500 m da qualsiasi strada non viene agganciato e non
produce risultati: avvicinalo o usa una rete più fitta.</p>
""")

_OSM = ("""
<p><b>🌐 Da OSM</b> (accanto alla rete stradale): scarica al volo da OpenStreetMap la rete
stradale contenuta nell'inquadratura corrente della mappa e la imposta in questo
campo. La rete è <i>filtrata per modo</i>: a piedi esclude autostrade/superstrade
e include marciapiedi/sentieri; in auto esclude i percorsi pedonali/ciclabili;
in bici una via di mezzo. Comodo quando non hai già un layer di strade.</p>
""")

SECTIONS_NOTE = ("""
<p><b>Sezioni</b>: le parti meno usate (opzioni avanzate, walkability,
equità, scenari, matrici) sono sezioni richiudibili: clic sul titolo con la
freccia per aprirle o chiuderle. Il nome completo di ogni scheda compare
passando il mouse sulla linguetta.</p>
""")

HELP_TEXTS = {
    "road": ("Rete stradale · aiuto", """
<h3>Analisi della rete stradale</h3>
<p>Misura le lunghezze per tipologia e conta gli <b>incroci reali</b>: i
vertici <b>condivisi</b> in cui si incontrano almeno tre bracci di strada. I
vertici che disegnano solo la forma della strada non contano, e due strade che
si attraversano senza vertice comune (ponte, sottopasso) non sono un
incrocio.</p>
<ul>
<li><b>Rete stradale</b>: layer di linee da analizzare.</li>
<li><b>Campo tipologia</b>: classifica le strade (es. <i>highway</i>). Lunghezze
e matrice incroci sono raggruppate per questo campo.</li>
<li><b>Area di progetto</b>: poligono (opzionale). Lunghezze, incroci e vicoli
ciechi vengono <b>ritagliati sull'area</b>, così le densità (km/km², n/km²) si
riferiscono alla stessa area; lunghezze ellissoidali (QgsDistanceArea).</li>
</ul>
<p><b>Matrice incroci</b>: la cella (A, B) conta gli incroci in cui si
incontrano strade di tipo A e B; la diagonale (A, A) quelli con almeno tre
bracci di tipo A (due strade di quel tipo). Un incrocio con più tipologie conta
in più celle, il totale degli incroci è nei Rapporti.</p>
<p><b>Rapporti</b>: incroci reali, vicoli ciechi, rapporto nodi connessi
(incroci / incroci + vicoli ciechi), densità. I punti dove due strade allo
<b>stesso livello</b> si attraversano senza vertice comune sono contati a parte
e mostrati in un layer: se sono incroci veri usa <i>Prepara rete</i>; se sono
ponti, tunnel o percorsi interni su piani diversi, il layer deve avere i campi
<i>bridge/tunnel/layer/level</i> (OSM) o <i>ponte/galleria/livello/piano</i>.</p>
""" + _OSM + """
<p>Output: tab Lunghezze, Matrice incroci, Rapporti (esportabili in CSV).
Il calcolo gira in background con barra e «Annulla».</p>
<h4>Walkability</h4>
<p>Indice 0-100 per <b>zona</b> (poligoni) o <b>griglia</b> automatica, da fino a
tre dimensioni (mediate):</p>
<ul>
<li><b>Design</b> (sempre): densità di incroci, densità stradale, link/nodi,
connettività media, calcolati sul grafo degli incroci reali (nodi = incroci e
vicoli ciechi, link = tratti tra due nodi): non dipendono da quanti vertici o
feature disegnano le strade.</li>
<li><b>Destinazioni</b> (se dai un layer <b>POI</b>): amenità raggiungibili a
piedi con decadimento della distanza, <i>in linea d'aria</i> o <b>su rete</b>
(Dijkstra, opzione «Destinazioni su rete»); con un <i>campo categoria</i> premia
la diversità di servizi (il più vicino per categoria), senza categoria somma
tutti i POI raggiungibili, in entrambe le modalità.</li>
<li><b>Pendenza</b> (se dai un <b>DEM</b>): grado medio delle strade; più ripido
= meno camminabile.</li>
<li><b>Attraversamenti</b> (se dai un layer di punti o usi «🌐 Attraversamenti
da OSM»): densità di attraversamenti pedonali per zona.</li>
</ul>
<p>Output: campi <i>walkability, design, destinazioni, pendenza, attraversam</i>
+ indicatori grezzi. Indice relativo (serve più di una zona). Raffinabile.</p>
<p><i>Pulizia rete:</i> tutte le analisi su rete stradale (isocrone,
accessibilità, PTAL su rete, space syntax, walkability) eseguono uno snap dei
vertici vicini e rimuovono segmenti nulli/duplicati per preparare il grafo.</p>
<h4>Prepara e controlla la rete</h4>
<ul>
<li><b>🔧 Prepara</b>: spezza le linee dove si incrociano senza un
vertice condiviso. <b>Indispensabile</b> se la rete non è già "noded": altrimenti
due strade che si incrociano restano scollegate nel grafo e isocrone/
accessibilità/PTAL risultano sottostimati. <b>Ponti e tunnel</b>: se il layer ha
i campi <i>bridge/tunnel/layer/level</i> (le reti scaricate con «Rete da OSM»
li hanno) o <i>ponte/galleria/livello/piano</i>, si collegano solo le strade
allo stesso livello: un cavalcavia non viene unito alla strada sotto, né un
corridoio interno a quello del piano di sopra. Ogni strada è divisa
<b>solo agli incroci</b> e conserva <b>tutti i suoi attributi</b> (più
<i>oneway</i> nel verso del tratto, <i>src_fid</i> e <i>mic_prepared</i>). La
<i>lunghezza minima</i> evita schegge: un taglio più vicino di così a un
vertice esistente si aggancia a quel vertice. Apre una <b>procedura guidata</b>
in 3 passi: (1) <i>diagnosi iniziale</i> (segmenti, componenti, incroci non
noded); (2) <i>opzioni</i> (tolleranza snap, lunghezza minima, noding); (3)
<i>anteprima</i> con il numero di split e il miglioramento delle componenti
connesse, prima di applicare. Al termine imposta la rete preparata come rete
stradale corrente.</li>
<li><b>🩺 Diagnostica rete</b>: segnala componenti scollegate, % nella componente
principale, sorgenti non agganciate o isolate, e <b>incroci non noded</b> (a X e
a T, solo tra strade allo stesso livello). Crea
layer diagnostici (componenti colorate, incroci, sorgenti isolate). Utile quando
un'analisi dà risultati nulli o strani.</li>
</ul>
"""),
    "gtfs": ("GTFS · aiuto", """
<h3>Caricamento GTFS e map-matching</h3>
<p>Il feed caricato qui è la <b>sorgente GTFS condivisa</b>: le schede PTAL,
Isocrone, Accessibilità e OD lo riusano senza doverlo reinserire.</p>
<ul>
<li><b>Percorso feed</b>: file .zip o cartella GTFS (anche con i file in una
sottocartella dello zip e con testi in codifica Latin-1/Windows).</li>
<li><b>Linea</b> + <i>Leggi</i>: per feed grandi scegli una sola linea
(caricamento leggero). «Tutte le linee» carica l'intero giorno di servizio
(Roma: circa 30 s e 0,7 GB di memoria).</li>
<li><b>Data</b> (AAAAMMGG, opz.): seleziona i servizi attivi quel giorno
da <i>calendar.txt</i>/<i>calendar_dates.txt</i>; vuoto = il giorno più carico
del calendario (tutti i servizi attivi quel giorno). Vale per il caricamento
GTFS, PTAL, isocrone TP, accessibilità TP e matrice OD; il messaggio finale dice
quale giorno è stato usato.</li>
<li><b>Valida</b>: file richiesti, periodo di validità (anche con il solo
calendar_dates.txt), giorno più carico, riferimenti fra tabelle (corse senza
linea o senza calendario, orari con fermate inesistenti), fermate senza
coordinate, orari mancanti, fuso orario e codifica dei testi.</li>
<li><b>Carica GTFS</b>: ricostruisce le geometrie delle linee dalle <i>shapes</i>
(senza shapes.txt, dalla sequenza delle fermate) e aggiorna i layer <i>GTFS -
Linee</i> e <i>GTFS - Metriche linee</i>. Le linee caricate dallo <b>stesso feed
e per lo stesso giorno</b> si sommano: segmenti, logging RT, Excel e
map-matching le usano tutte. Cambiando feed o giorno si riparte da zero (e il
logging in corso si ferma).</li>
<li><b>Crea layer segmenti</b>: geometrie stop-to-stop con velocità programmate.
I segmenti seguono la <i>shape</i> anche quando stop_times non ha
<i>shape_dist_traveled</i> (le fermate vengono proiettate sulla shape). Gli
orari mancanti (fermate non timepoint) e le coppie a tempo zero degli orari al
minuto vengono ricostruiti per distanza fra gli orari noti della corsa.</li>
</ul>
<h4>Map-matching su rete (operazione spaziale)</h4>
<p>Campiona punti lungo le strade (lontano dagli estremi) e <i>aggancia</i> ad
ogni tratto stradale i segmenti GTFS vicini, entro la <b>tolleranza</b> e con
direzione simile (entro l'<b>angolo</b>); il <b>passo</b> è la spaziatura di
campionamento. Una strada è abbinata solo se almeno la <b>copertura minima</b>
dei campioni sta lungo la linea, così le vie che la toccano solo in un incrocio
non prendono la velocità del bus. Sulle strade a <i>senso unico</i> (campo
oneway) conta il verso: le due carreggiate di un viale restano separate. Con un
campo <i>highway</i> (OSM) si escludono marciapiedi, ciclabili, scale e
banchine. Il calcolo è in metri reali (UTM se la rete è geografica o in Web
Mercator). Output: le strade con velocità programmata/effettiva, linee e
<i>copertura</i>.</p>
"""),
    "gtfs_live": ("GTFS live · aiuto", """
<h3>Confronto con il GTFS realtime</h3>
<p>Operazione: confronta la velocità <i>programmata</i> di ogni segmento
stop-to-stop con quella <i>osservata</i> ricavata dai TripUpdates in tempo reale.</p>
<ul>
<li><b>URL feed TripUpdates</b>: endpoint protobuf GTFS-RT.</li>
<li><b>Intervallo</b>: ogni quanti secondi interrogare il feed.</li>
<li><b>Avvia / Ferma logging</b>: raccolta continua delle osservazioni.</li>
<li><b>Scansione programmata</b>: imposta ora di inizio e durata; la raccolta
parte da sola e si ferma dopo la durata (utile per una fascia oraria).</li>
<li><b>Segmenti peggiori (top N)</b> + <i>Evidenzia</i>: colora i segmenti per scarto
osservato vs teorico e seleziona i N con il divario maggiore.</li>
<li><b>Esporta Excel</b>: report con curve della velocità di esercizio per linea
per ora di partenza della corsa.</li>
</ul>
<p><b>Come si conta un'osservazione.</b> Per ogni corsa si prendono le coppie
di fermate <i>consecutive nell'orario statico</i> (anche se stop_sequence salta
10, 20, 30… e anche senza stop_id). Valgono gli orari dichiarati o, se c'è solo
il ritardo, orario programmato + ritardo. Le fermate SKIPPED/NO_DATA e le corse
cancellate non contano. I TripUpdates sono <b>previsioni</b>: una coppia diventa
osservazione solo quando, secondo l'ultimo feed, la fermata d'arrivo è già
passata (il messaggio mostra le previsioni in attesa). Lo scarto è rispetto al
<b>programmato delle stesse corse</b> (campo <i>v_sched_obs</i>), confrontando
come con come (partenza→arrivo o arrivo→arrivo). Dopo 30 minuti le osservazioni
vengono riassunte: la memoria non cresce con la durata del logging.</p>
"""),
    "lines2gtfs": ("Da linee a GTFS · aiuto", """
<h3>Genera un GTFS da linee e fermate</h3>
<p>Operazione spaziale: <i>aggancia</i> le fermate alle linee (entro la
tolleranza), le <b>ordina lungo la linea</b> (posizione progressiva calcolata in
metri), e deriva i tempi di percorrenza da distanza/velocità.</p>
<ul>
<li><b>Linee (rotte)</b>: layer lineare; ogni feature è una rotta.</li>
<li><b>Fermate</b>: layer puntuale agganciato alle linee e ordinato.</li>
<li><b>Tipo / Velocità / Frequenza / Orario / Sosta</b>: parametri del servizio.</li>
<li><b>Tolleranza fermate</b>: distanza massima fermata-linea per l'aggancio.</li>
<li><b>Direzioni</b>: andata (verso di disegno) e ritorno (verso opposto), o
solo andata.</li>
<li><b>Fermate</b>: lato delle fermate rispetto al verso di marcia. Le fermate
ai due lati della strada vanno ciascuna alla sua direzione; quelle sulla linea
(entro 2 m) servono entrambe; se sono disegnate su un solo lato servono
entrambe le direzioni.</li>
<li><b>Fuso orario / Validità / Giorni</b>: scritti in agency.txt e
calendar.txt.</li>
</ul>
<p>Output: un feed GTFS .zip, impostato anche come sorgente nella scheda GTFS.
La generazione gira in background con barra e «Annulla».</p>
"""),
    "isochrones": ("Isocrone · aiuto", """
<h3>Isocrone su rete stradale</h3>
<p>Operazione spaziale: dalla sorgente si percorre la rete con Dijkstra fino al
budget di tempo di ogni fascia (distanza = velocità × tempo); l'insieme dei
tratti raggiunti definisce l'area servita.</p>
<ul>
<li><b>Sorgenti</b>: layer di punti, oppure <i>📍 Scegli</i> (clic sulla mappa),
oppure <i>Usa fermate GTFS caricate</i>.</li>
<li><b>Rete stradale</b>: layer di linee su cui si calcolano i percorsi.</li>
<li><b>Mezzo / Velocità</b> e <b>Tempi (min)</b> (es. 5,10,15): definiscono le
fasce. La legenda mostra «5 min / 10 min / 15 min».</li>
<li><b>Modalità output</b>:
  <i>Concavo</i> = buffer dei tratti raggiunti (segue le strade, include gli
  edifici vicini, esclude le aree senza accesso);
  <i>Poligono</i> = area che segue la rete: i tratti raggiunti allargati di
  80 m e poi ristretti, così gli isolati fra strade raggiunte sono pieni e le
  zone senza strade raggiunte (ferrovie, parchi chiusi, fiumi) restano fuori;
  buchi interni sotto 4 ha riempiti. Con più sorgenti le aree restano
  separate se non si toccano;
  <i>Lineare</i> = i soli tratti stradali raggiunti.</li>
<li><b>Unisci le sorgenti</b>: unisce le sorgenti in un'unica isocrona per fascia.</li>
<li><b>Avanzate · Allargamento attorno alla rete</b>: larghezza del buffer attorno alla rete
(modalità concavo/poligono).</li>
<li><b>Rispetta i sensi unici</b>: se la rete ha un campo <i>oneway</i>
(1 = avanti, -1 = indietro, 0 = doppio senso) il routing diventa orientato
(utile in auto). La rete da OSM porta già questo campo; rotatorie e autostrade
OSM sono a senso unico anche senza. Scegliendo «Auto» si attiva da solo.</li>
<li><b>Auto · velocità per strada</b> (solo in auto; «Limite di ogni strada» attivo di default):
ogni strada si percorre alla sua velocità, come nel percorso più veloce:
<i>campo velocità</i> se indicato, altrimenti limite OSM <i>maxspeed</i>,
altrimenti un valore tipico del tipo di strada (residenziale 30, principale
50, autostrada 130…); la <i>Velocità</i> sopra vale per le strade di tipo
sconosciuto. <i>Velocità effettiva</i>: quota del limite a cui si viaggia
davvero (in città spesso 60–70 %). Marciapiedi, sentieri e scale sono esclusi.
Le fasce sono in tempo vero: le strade veloci allungano l'isocrona.</li>
<li><b>A piedi · pendenza (DEM)</b> (opz.): un raster di quote in metri, in
qualsiasi sistema di riferimento. La velocità segue la pendenza (funzione di
Tobler): la <i>Velocità</i> è quella in piano; in salita al 10 % si va al 70 %,
al 20 % a metà; in leggera discesa un po' più veloci. Ogni tratto ha un
tempo per verso, quindi l'isocrona si allunga verso valle. Ponti e gallerie
seguono la pendenza fra i loro estremi, non il terreno. Le mappe di sfondo
(XYZ/WMS) non compaiono fra i DEM. Se parte della rete è fuori dal DEM il
messaggio lo segnala (lì pendenza zero).</li>
<li><b>POI/popolazione (opz.)</b>: un layer di punti (con campo peso opzionale, es.
popolazione): a fine calcolo conta quante opportunità cadono in ogni isocrona e
aggiunge i campi <i>n_poi</i> e <i>peso_poi</i> (solo per output poligonali).
<b>🌐 ISTAT</b> (menu) scarica per l'inquadratura (solo in Italia) i
<i>residenti 2021</i> (peso <i>POP21</i>) o gli <i>addetti 2011</i> (posti di
lavoro, peso <i>ADD_TOT</i>), un punto per sezione di censimento, e li
imposta qui: <i>peso_poi</i> diventa così il numero di residenti o di
posti di lavoro dentro ogni isocrona.</li>
<li><b>Interattiva: calcola al clic</b>: con una rete selezionata (modo rete), ogni click
sulla mappa ricalcola l'isocrona aggiornando un unico layer «MIC - Isocrona
interattiva»; avvisa se il punto non aggancia la rete o è su una componente
isolata. Il calcolo è in background: un nuovo click annulla quello in corso.</li>
<li><b>Barra di avanzamento</b>: durante il calcolo mostra la fase (lettura
della rete, percorsi, costruzione poligoni…) e la percentuale; <i>Annulla</i>
interrompe il calcolo. QGIS resta utilizzabile nel frattempo. Su reti grandi
in auto (tutta la rete raggiunta) la costruzione dei poligoni può richiedere
decine di secondi.</li>
<li><b>Sistemi di riferimento</b>: sorgenti e rete possono avere CRS diversi
(vengono riproiettati automaticamente), purché il CRS assegnato a ogni layer
sia corretto.</li>
</ul>
<p><b>Trasporto pubblico (GTFS)</b> come mezzo: la raggiungibilità si calcola con
il Connection Scan Algorithm (orari reali del feed, anche da
<i>frequencies.txt</i>). Sono configurabili il modo di <b>accesso</b>
(sorgente→fermata) e di <b>egress</b> (fermata→destinazione), a piedi o in bici,
più una <b>penalità di trasferimento</b> (minuti per ogni cambio di mezzo, anche
alla stessa fermata).</p>
<ul>
<li><b>Partenza / Finestra di partenza</b>: con una finestra (es. 30 min) il
calcolo si ripete ogni 5 minuti e per ogni fermata usa il tempo di viaggio
<i>mediano</i>: il risultato non dipende dal minuto esatto di partenza. 0 = una
sola partenza.</li>
<li><b>Rete stradale</b> (opzionale): accesso alle fermate ed egress seguono le
strade invece della linea d'aria.</li>
<li>Dalle fermate si prosegue al massimo per il raggio di egress (800 m a piedi,
3 km in bici); attorno all'origine c'è anche lo spostamento diretto.</li>
<li><b>Un'isocrona per ogni linea</b>: un'isocrona per ogni linea che serve il punto (con
una partenza nella finestra da una fermata raggiungibile a piedi), calcolata
usando solo quella linea, senza cambi. Il layer ha il campo <i>linea</i> e una
legenda per linea.</li>
</ul>
""" + _SNAP + _OSM),
    "ptal": ("PTAL · aiuto", """
<h3>PTAL · Public Transport Accessibility Level (TfL)</h3>
<p>Operazione spaziale: per ogni punto si cercano le fermate raggiungibili a
piedi entro la soglia di cammino del modo; con una rete pedonale le distanze
sono <i>di rete</i> (Dijkstra), altrimenti in linea d'aria.</p>
<p><b>Servizio senza GTFS</b>: con «Dati forniti» il PTAL usa un layer di
fermate al posto del feed. Ogni punto è una linea che serve una fermata nella
fascia di analisi, con il campo <i>corse/ora</i>; facoltativi il campo
<i>linea</i> (una linea alla stessa fermata conta una volta; senza, ogni
fermata conta come una linea diversa e il PTAL può risultare più alto), il
campo
<i>modo</i> (bus, tram, metro, treno, traghetto o il route_type GTFS: decide
soglia di cammino e affidabilità) e il <i>codice fermata</i>. Più linee alla
stessa fermata = più punti nella stessa posizione (entro 5 m) o con lo stesso
codice. Utile per scenari di progetto o reti senza GTFS.</p>
<ul>
<li><b>GTFS</b>: di default il feed caricato nella scheda GTFS (frequenze per
fermata e rotta).</li>
<li><b>Modalità</b>: <i>PTAL (TfL standard)</i> = distanza <b>in linea d'aria</b>
(metodo ufficiale TfL, default); <i>PTAL su rete pedonale</i> = distanza a piedi
<b>di rete</b> (Dijkstra), più realistica ma <b>non-standard</b> — richiede una
rete pedonale (anche via «Rete da OSM»).</li>
<li><b>Punti di analisi</b> o <b>griglia</b> (esagoni/quadrati) da valutare.</li>
<li><b>Fascia oraria</b>: orari su cui calcolare le frequenze; il metodo TfL
usa l'ora di punta 08:15–09:15 (predefinita).</li>
<li><b>Profili orari AM/interpeak/PM</b>: calcola PTAL per le tre fasce standard
(08:15-09:15 / 10-16 / 16-19) e aggiunge i campi <i>ai_am, ptal_am, ai_ip, ...</i>;
lo stile usa la fascia AM come primaria.</li>
</ul>
<h4>Calcolo (per ogni punto)</h4>
<p>Tempo di accesso a una linea = cammino fino alla fermata + attesa (30/frequenza)
+ <b>affidabilità</b>; EDF = 30/accesso. Ogni linea conta una volta sola, alla
fermata dove ha l'EDF più alto; per ogni modo (bus, tram, metro, treno) la linea
migliore pesa 1 e le altre 0,5; la somma sui modi è l'Accessibility Index, mappato
sulle fasce PTAL 0..6b (tutte in legenda).</p>
<h4>Avanzate · soglie per mezzo</h4>
<p>Per ogni modo (bus/tram/metro/treno) puoi cambiare <b>soglia di cammino</b>
(TfL: 640 m bus/tram, 960 m rail) e <b>affidabilità</b> (minuti di margine).</p>
<h4>Gap analysis</h4>
<p>Incrocia il PTAL a celle con la popolazione: gap = popolazione × (8 − livello
PTAL)/8 → evidenzia dove c'è molta gente con poca accessibilità. Ogni
centroide di popolazione va in una sola cella, anche se cade sul bordo.
Senza un proprio layer di popolazione, <b>🌐 ISTAT</b> scarica i residenti
2021 delle sezioni di censimento dell'inquadratura (solo in Italia) e li
imposta con il campo <i>POP21</i>.</p>
""" + _SNAP),
    "spacesyntax": ("Space syntax · aiuto", """
<h3>Space syntax sul grafo stradale</h3>
<p>Operazione: la rete viene divisa in <b>segmenti</b>, i tratti di strada tra
due incroci reali (vertici condivisi da almeno tre bracci) o tra un incrocio e
un vicolo cieco. Ogni segmento è un nodo, collegato ai segmenti che
condividono un incrocio. Il risultato <b>non dipende da come è disegnata la
rete</b>: una via in una sola feature o spezzata in dieci dà gli stessi
segmenti, e una strada che attraversa un incrocio viene comunque divisa lì.
Strade che si attraversano senza vertice comune (ponti, o rete non noded) non
sono collegate: in caso di dubbio usa prima <i>Prepara rete</i>.</p>
<ul>
<li><b>Connettività</b>: numero di segmenti connessi a ciascun segmento.</li>
<li><b>Profondità media/totale</b>: distanza topologica (numero di passi) dagli
altri tratti.</li>
<li><b>Integrazione (HH)</b>: centralità/accessibilità del tratto (inverso di
RRA, normalizzazione Hillier-Hanson).</li>
<li><b>Choice (betweenness)</b>: quanti percorsi più brevi attraversano il tratto
(potenziale di attraversamento, algoritmo di Brandes).</li>
<li><b>NAIN / NACH</b>: integrazione e choice normalizzate (Hillier, Yang,
Turner 2012) per confrontare reti di dimensioni diverse.</li>
<li><b>Raggio</b>: R0 = globale (Rn), un valore = analisi locale entro quel
numero di passi topologici (molto più veloce su reti grandi).</li>
</ul>
<p>Output: un tratto per segmento con gli attributi della strada d'origine
(quella che copre la maggior parte del segmento), i campi calcolati,
<i>lunghezza_m</i>, <i>n_feature</i> (feature d'origine unite) e
<i>src_fid</i>; stile per integrazione. Il calcolo gira in background e si può
annullare.</p>
"""),
    "routing": ("Percorsi · aiuto", """
<h3>Percorso più breve e più veloce</h3>
<p>Calcola il percorso su rete fra due o più punti: <b>in sequenza</b>
(1 → 2 → 3 …, utile per un giro con tappe) o fra <b>tutte le coppie</b> (in
entrambi i versi: con i sensi unici andata e ritorno possono differire).
Ogni punto si aggancia al punto più vicino della strada (entro 500 m) e il
percorso parte e arriva lì. Se i due punti stanno su pezzi di rete
scollegati, chi è fuori dalla rete principale si aggancia ad essa.</p>
<ul>
<li><b>Più breve</b>: distanza minima sulla rete così com'è (anche pedonale);
il tempo sui tratti solo pedonali è a passo d'uomo (4,5 km/h).</li>
<li><b>Più veloce</b>: tempo minimo in auto. La velocità di ogni strada è, in
ordine: il <i>campo velocità</i> indicato, il limite OSM <i>maxspeed</i> (anche
«IT:urban» = 50, «IT:rural» = 90, «mph», «knots»), un valore tipico per tipo
di strada
(<i>highway</i>: residenziale 30, principale 50, autostrada 130…), la velocità
di default. La <i>velocità effettiva</i> la riduce (es. 70 % per il traffico).
Marciapiedi, sentieri, ciclabili e scale sono esclusi.</li>
<li><b>Punti</b>: un layer (ordinato con il <i>campo ordine</i>, altrimenti
nell'ordine delle feature) oppure i clic sulla mappa, che hanno la
precedenza.</li>
<li><b>Sensi unici</b>: dal campo <i>oneway</i> (yes/no/-1 o 1/0/-1); rotatorie
e autostrade OSM sono a senso unico anche senza il campo.</li>
</ul>
""" + _OSM + """
<p>Output: un percorso per coppia con <i>lunghezza_m</i>, <i>tempo_min</i>,
<i>vel_kmh</i> (con il più breve il tempo è stimato con le stesse velocità,
a piedi sui tratti pedonali);
le coppie senza percorso hanno l'esito con il motivo. Anche in Processing:
<i>mic:shortestpath</i>.</p>
"""),
    "access": ("Accessibilità · aiuto", """
<h3>Accessibilità cumulativa alle opportunità</h3>
<p>Operazione spaziale: per ogni origine conta quante destinazioni (o quanto
peso) sono raggiungibili entro ciascuna soglia di tempo.</p>
<ul>
<li><b>Origini</b>: punti (o griglia) da valutare. <b>🌐 ISTAT</b> usa come
origini le sezioni di censimento dell'inquadratura (un punto per sezione
con residenti, solo in Italia): il risultato porta con sé gli attributi
delle origini, quindi nella <i>Sintesi ed equità</i> si può pesare con i
residenti (campo <i>POP21</i>).</li>
<li><b>Destinazioni</b>: punti/poligoni (POI, popolazione, posti di lavoro). Con
<b>Campo peso</b> si sommano i pesi, altrimenti si contano. <b>🌐 ISTAT</b>
(menu) usa come destinazioni gli <i>addetti 2011</i> dell'inquadratura (un
punto per sezione di censimento, peso <i>ADD_TOT</i>): il risultato è il
numero di posti di lavoro raggiungibili; dallo stesso menu anche i
residenti 2021.</li>
<li><b>Modo</b>: a piedi/bici/auto sulla <b>rete</b> (Dijkstra), oppure
<b>Trasporto pubblico</b> via GTFS (Connection Scan). In TP si scelgono accesso/
egress a piedi o in bici e una penalità di trasferimento (opzioni multimodali).</li>
<li><b>Tempi (min)</b>: una colonna <i>acc_Xmin</i> per ogni soglia.</li>
<li><b>Rispetta i sensi unici</b>: per i modi su strada, usa il campo
<i>oneway</i> della rete per un routing orientato (con i sensi unici impliciti
OSM di rotatorie e autostrade).</li>
</ul>
<h4>Sintesi ed equità</h4>
<p>Su un layer di accessibilità/PTAL (campo valore) eventualmente pesato per la
popolazione: <b>media/mediana pesate</b>, <b>% «servita»</b> (quota di peso con
valore ≥ soglia), <b>indice di Gini</b> e <b>curva di Lorenz</b>
dell'accessibilità (grafico a video o export Excel). Gini 0 = perfetta
uguaglianza, valori alti = forte disuguaglianza.</p>
<h4>Confronto scenari (B − A)</h4>
<p>Differenza tra due layer di risultati con la stessa geometria (es. PTAL prima/
dopo una modifica al servizio): produce un layer <i>delta = B − A</i> con stile
divergente (rosso = peggioramento, blu = miglioramento).</p>
<h4>Scenario A/B fra due reti</h4>
<p>Confronta due reti stradali (A = attuale, B = progetto: nuova strada,
passerella, strada chiusa) usando Origini/Destinazioni/Modo/Tempi della sezione
Accessibilità. Due tipi di confronto:</p>
<ul>
<li><b>Accessibilità (origini → destinazioni)</b>: calcola l'accessibilità
cumulativa sulle stesse origini con le due reti e produce il delta per origine
(classe gain/loss/unchanged) con sintesi delle origini migliorate/peggiorate.</li>
<li><b>Isocrone (differenza geometrica)</b>: calcola l'<i>area raggiungibile</i>
(isocrona su rete, modo concavo) dalle origini alla soglia massima dei Tempi su
entrambe le reti e ne fa la <b>differenza geometrica</b>: poligoni
<i>guadagno</i> (B−A, area raggiungibile solo nel progetto), <i>perdita</i>
(A−B) e <i>comune</i> (A∩B), con aree in ettari. Il calcolo gira in background
(la barra di stato mostra l'avanzamento); con molte origini l'unione delle aree
può richiedere un po': per scenari puntuali usa <b>poche sorgenti</b>.</li>
</ul>
""" + _SNAP + _OSM),
    "od": ("OD · aiuto", """
<p><i>Cerchi i flussi di pendolarismo fra comuni? Sono nella scheda
<b>ISTAT</b>, sezione «Pendolarismo fra comuni»: si scaricano da soli.</i></p>
<h3>Origine-Destinazione</h3>
<p>Operazione spaziale: traccia <b>desire lines</b> tra i centroidi delle zone,
con spessore proporzionale al flusso; in alternativa calcola la matrice dei
<b>tempi di viaggio</b> zona-zona via trasporto pubblico.</p>
<ul>
<li><b>Zone</b>: punti o poligoni con un identificativo (per i poligoni si usa il
centroide).</li>
<li><b>Campo ID zona</b>: deve corrispondere agli id nella matrice OD.</li>
<li><b>Matrice OD (CSV)</b>: colonne origine, destinazione, valore.</li>
<li><b>Filtri</b>: flusso minimo, top N, singola origine/destinazione.</li>
<li><b>Linee arcuate</b>: traccia le desire lines come archi (Bézier) anziché
rette; la curva piega sempre dallo stesso lato, così andata e ritorno fra due
zone non si sovrappongono e i flussi sovrapposti restano leggibili.</li>
</ul>
<h4>Matrice su strada (Excel)</h4>
<p>Tempo e distanza sulla rete fra ogni <b>origine</b> e ogni
<b>destinazione</b> (vuoto = le origini stesse), lungo il percorso più
veloce; la distanza è la lunghezza di quel percorso.</p>
<ul>
<li><b>Origini / Destinazioni</b>: punti o poligoni (centroide), con un
<i>campo ID</i> (vuoto = numero della feature).</li>
<li><b>Mezzo</b>: piedi o bici a velocità unica (a piedi anche con la
<i>pendenza dal DEM</i>: andata e ritorno possono differire), oppure auto con
il <i>limite di ogni strada</i> (campo, maxspeed OSM o tipo di strada) e la
velocità effettiva; in auto i sensi unici sono attivi.</li>
<li><b>Tempo massimo</b> (opz.): oltre, la coppia è «non raggiungibile» e il
calcolo è più rapido.</li>
<li>Il pulsante chiede dove salvare l'<b>Excel</b>: fogli <i>Tempi (min)</i>
e <i>Distanze (km)</i> (matrici colorate), <i>Coppie</i> (anche velocità
media) e <i>Parametri</i> (mezzo, rete, punti fuori rete o agganciati alla rete
principale). Facoltative le <b>linee</b> origine → destinazione sulla mappa,
colorate per tempo (fino a 20 000 coppie).</li>
<li>I punti si agganciano alla strada più vicina entro 500 m; chi è vicino
solo a un pezzo di rete isolato si aggancia alla rete principale.</li>
</ul>
<p>Molte coppie senza percorso in auto di solito sono sensi unici che escono
dalla rete scaricata: allarga la rete. Anche in Processing:
<i>mic:roadodmatrix</i>.</p>
""" + _OSM + """
<h4>Matrice tempi in TP (GTFS)</h4>
<p>Per ogni coppia di zone calcola il tempo minimo di viaggio in trasporto
pubblico (Connection Scan) entro il budget; di default usa il GTFS caricato.</p>
"""),
    "report": ("Report · aiuto", """
<h3>Report automatico di un'area</h3>
<p>Per un'area (un quartiere, un municipio, l'inquadratura) mette in fila
gli strumenti del plugin e produce in un colpo un <b>PDF</b> impaginato
(A4, una pagina per sezione), un <b>Excel</b> con tutti i numeri e i
<b>layer</b> delle mappe in un GeoPackage.</p>
<ul>
<li><b>Area</b>: i poligoni di un layer (le feature selezionate, o tutte;
più poligoni = la loro unione; il <i>campo nome</i> dà il titolo), un'area
<i>disegnata sulla mappa</i> (✏️ Disegna: clic sinistro per i vertici, clic
destro o doppio clic per chiudere, Backspace toglie l'ultimo vertice, Esc
annulla) o l'<i>inquadratura</i> della mappa.</li>
<li><b>Rete</b>: un layer di strade o, se vuoto, la rete completa scaricata
da OSM. Si legge l'area più un margine pari al percorso a piedi più lungo
che serve (soglia dei 15 minuti, isocrone): isocrone e 15 minuti non si
fermano al confine. <i>Campo tipo strada</i>: per la tabella delle
lunghezze (con l'highway di OSM la mappa raggruppa le strade in classi).</li>
<li><b>Popolazione · Dati ISTAT 2021</b>: con la casella spuntata il report
scarica dall'ISTAT le sezioni di censimento della regione dell'area (una
volta sola, poi restano sul computer) e ne usa i residenti; fuori
dall'Italia il report esce senza popolazione e lo dice. Senza la spunta
non si usa nessun dato ISTAT: in <i>Oppure layer</i> si può indicare un
proprio layer di poligoni con un campo di abitanti, o lasciare vuoto. La
popolazione si ripartisce per area di sovrapposizione (una sezione per
metà nell'area conta metà) e dà densità, quote di abitanti e servizi ogni
1 000 abitanti. Con i dati ISTAT il report ha anche la pagina
<b>Popolazione</b>: residenti, famiglie, quota di 65 anni e più e di
stranieri; la mappa delle sezioni di censimento per abitanti per ettaro; la
piramide delle età per sesso; il confronto con il comune in cui cade
l'area (densità, età, stranieri, titolo terziario, occupati, abitazioni
senza residenti); famiglie per componenti, titolo di studio, occupati per
sesso. Per questa pagina servono gli indicatori della regione: al primo
report il download dura circa un minuto in più, poi restano sul
computer.</li>
<li><b>Servizi</b>: un layer con un campo categoria o, se vuoto, i servizi
OSM in 9 categorie (come nella scheda 15 min).</li>
<li><b>GTFS</b> (opz.): per il PTAL; vuoto = il feed della scheda
Trasporti; senza feed la sezione si salta. <b>DEM</b> (opz.): pendenza a
piedi (Tobler) e pendenza media delle strade.</li>
<li><b>Mappe · Stile</b>: lo sfondo di tutte le mappe del report.
  <i>Carta chiara</i>: base disegnata dal plugin con i dati OSM (edifici,
  verde, acqua, ferrovie, strade bianche), nitida a ogni ingrandimento; si
  scarica una volta e resta in cache; su aree molto grandi esce senza
  edifici.
  <i>OpenStreetMap</i>: la mappa standard come sfondo, con i colori
  attenuati; serve internet a ogni report.
  <i>Satellite</i>: foto aerea (Esri World Imagery) con i temi in
  trasparenza; serve internet.
  Se la base non è raggiungibile il report esce lo stesso, con le sole
  strade di contesto, e lo dice nel messaggio.</li>
<li><b>Mappe · Nomi delle vie</b>: <i>Automatico</i> mette solo le vie
principali sulle mappe a celle e sulle isocrone e tutte le vie sulle mappe
della rete e dei servizi; oppure <i>Nessuno</i>, <i>Solo vie principali</i>,
<i>Tutte le vie</i>. <b>Dimensione dei nomi</b>: piccoli, medi, grandi. I
nomi vengono dal campo <i>name</i> della rete. Con lo stile OpenStreetMap i
nomi sono già nello sfondo e le due opzioni non servono.</li>
<li><b>Sezioni</b>: si possono togliere; quelle senza dati si saltano da
sole e il report dice perché. <b>Parametri</b>: dettaglio (celle da 70 m
per un quartiere, 250 m per una città), velocità a piedi, tempi delle
isocrone, soglia della città dei minuti, fascia oraria del PTAL.</li>
</ul>
<p><b>Il PDF</b>: copertina con mappa, numeri chiave e indice;
<i>sintesi</i> con punti di forza e criticità a parole, gli indicatori in
schede con il giudizio (Buono, Migliorabile, Critico rispetto a soglie
indicative) e il confronto visivo con le soglie; poi una pagina per
sezione — popolazione (con i dati ISTAT), rete stradale, camminabilità,
trasporto pubblico (PTAL e residenti serviti), accessibilità a piedi
(isocrone dal centro),
città dei 15 minuti, servizi —
ognuna con i numeri in alto, la mappa con la legenda e sotto tabelle e
barre; infine note, fonti e glossario. Nelle mappe l'area è in evidenza,
con le strade attorno in grigio per orientarsi; scala e nord compresi.</p>
<p><b>Dopo il calcolo</b>: accanto al PDF ci sono l'Excel (un foglio per
sezione, anche i valori di ogni cella) e il GeoPackage <i>_dati</i> con i
layer. Nel progetto compaiono il gruppo «Report – nome» (spento) e il
layout «Report – nome», che si può ritoccare in <i>Progetto → Layout</i>
(ogni scheda è un gruppo e si sposta in un pezzo) e riesportare.</p>
<h3>Crea layout: modificare il report prima di esportarlo</h3>
<p><b>Crea layout…</b> calcola lo stesso report di <b>Crea report…</b> —
stesse mappe, numeri, testi e pagine — ma non esporta nulla: chiede dove
salvare i dati (GeoPackage dei layer ed Excel) e apre il layout nel
<b>compositore di stampa</b> di QGIS. Lì si cambiano testi, colori,
mappe (anche gli strati e l'inquadratura), si spostano le schede, si
aggiungono o tolgono pagine (i numeri di pagina si aggiornano da soli);
poi si esporta dal menu <i>Layout</i>: <i>Esporta come PDF</i>, oppure
<i>Esporta per InDesign (IDML)…</i>.</p>
<p>Se nel progetto c'è già un layout con lo stesso nome (magari ritoccato)
il plugin chiede se <i>sostituirlo</i> o <i>tenerli entrambi</i> (il nuovo
prende un numero, i dati del vecchio restano com'erano).</p>
<h3>InDesign</h3>
<p>Con <b>Anche per InDesign (IDML)</b> spuntata, <i>Crea report…</i>
scrive accanto al PDF un file <b>.idml</b>; dal compositore di stampa lo fa
<i>Layout → Esporta per InDesign (IDML)…</i>, con qualunque layout. In
InDesign si apre con <i>File → Apri</i> e diventa un documento normale:</p>
<ul>
<li><b>testi</b> modificabili, nello stesso carattere, corpo, colore e
posizione, con gli a capo di QGIS; uno <i>stile di paragrafo</i> per ogni
tipo di testo (titoli, numeri, note…): cambiandone uno si ritoccano tutti
insieme;</li>
<li><b>forme</b> (schede, barre, badge, pallini) come cornici con
riempimento, contorno e angoli arrotondati, nei gruppi del layout;</li>
<li><b>mappe</b>, barre di scala, nord e logo come <b>immagini</b> PNG a
300 dpi nella cartella <i>Links</i> accanto al file: si spostano,
ritagliano o sostituiscono come ogni immagine collegata (tenere la
cartella <i>Links</i> insieme al file .idml);</li>
<li>numero di pagina automatico nel piè di pagina; colori RGB come nel
PDF.</li>
</ul>
<p>Serve che in InDesign ci sia lo stesso carattere del report (TWK
Everett se installato, altrimenti quello usato da QGIS, di solito Segoe
UI): se manca, InDesign lo segnala e propone di sostituirlo. Lo stesso
file si apre anche con Affinity.</p>
<p><b>Grafica</b>: il report riprende i colori di MIC Hub (testo nero,
viola e lavanda, menta e verde petrolio) e usa TWK Everett, il carattere
del sito, se è installato sul computer.</p>
"""),
    "coverage": ("Residenti serviti · aiuto", """
<h3>Residenti serviti dal trasporto pubblico</h3>
<p>Risponde a due domande: <b>quanti residenti hanno una fermata a portata
di piedi</b> e <b>con quante corse all'ora</b>. Usa il feed della scheda
GTFS (o un altro, in <i>Sorgente GTFS alternativa</i>).</p>
<ul>
<li><b>Popolazione dai dati ISTAT 2021</b>: con la spunta i residenti sono
quelli delle sezioni di censimento ISTAT (si scaricano una volta sola, solo
in Italia) e si sceglie l'<b>area</b>: un comune, l'inquadratura della
mappa o i poligoni di un layer. Senza la spunta si indica un proprio layer
di poligoni (sezioni, isolati) o di punti (edifici) con un campo di
abitanti: si analizzano tutte le sue feature.</li>
<li><b>Distanze</b>: di norma a piedi <i>lungo la rete</i>: un layer di
strade o, se vuoto, la rete scaricata da OSM per l'area più un margine.
Una rete propria deve coprire anche i dintorni dell'area (almeno le soglie
qui sotto), altrimenti le fermate appena fuori non contano; autostrade e
superstrade non si usano a piedi. <i>In linea d'aria</i> è più rapido e
non richiede una rete, ma conta come vicine anche fermate oltre un fiume o
una ferrovia: di solito dà valori più alti.</li>
<li><b>Fascia oraria</b>: le corse si contano in questa fascia, nel giorno
di servizio scelto nella scheda GTFS (o nel più carico del feed).</li>
<li><b>Soglie</b>: una fermata serve un residente se è entro la distanza
del suo mezzo: 400 m per bus e tram, 800 m per metro e treno (valori
usuali, modificabili).</li>
</ul>
<p><b>Come si conta</b>: ogni sezione (o edificio) è rappresentata da un
punto al suo interno. Una linea è raggiungibile se lo è almeno una sua
fermata e conta una volta sola, con la frequenza più alta fra le sue
fermate raggiungibili; i due versi della stessa linea non si sommano. Il
capolinea di arrivo non conta: lì si scende soltanto. Le <b>corse all'ora
raggiungibili</b> sono la somma delle linee, e danno la classe di
servizio: 12 o più, da 6 a 12, da 2 a 6, meno di 2, nessuna fermata.</p>
<p><b>Risultati</b>:</p>
<ul>
<li><i>Residenti serviti</i>: le sezioni con residenti colorate per classe
di servizio, con la distanza dalla fermata più vicina, le corse e le linee
raggiungibili;</li>
<li><i>Fermate e residenti</i>: le fermate a portata dei residenti, con
cerchi proporzionali ai residenti entro la soglia (si vedono ingrandendo
oltre 1:40.000) e, in un altro campo, i residenti per cui quella è la
fermata più vicina;</li>
<li><i>Linee e residenti</i>: una tabella con, per ogni linea, corse
all'ora, fermate a portata e residenti serviti (un residente vicino a più
linee conta per ognuna);</li>
<li>il <b>riepilogo</b> nel pannello, che si copia negli appunti.</li>
</ul>
<p><b>Avvertenze</b>: una sezione grande (campagna, zone industriali) è
rappresentata da un solo punto: lì il risultato è grossolano. I residenti
delle sezioni a cavallo del confine dell'area contano per la parte dentro.
Nel <b>Report</b> la stessa misura compare nella pagina del trasporto
pubblico, calcolata sulle celle.</p>
"""),
    "istat": ("ISTAT · aiuto", """
<h3>Sezioni di censimento ISTAT 2021</h3>
<p>Scarica dal sito dell'ISTAT le <b>sezioni di censimento</b> del
Censimento permanente 2021 e le carica come layer, già colorate e con un
riepilogo dell'area. La sezione è l'unità più piccola per cui l'ISTAT
pubblica i dati: in città vale circa un isolato.</p>
<ul>
<li><b>Area</b>: <i>un comune</i> (scrivi il nome e scegli dall'elenco: i
comuni con lo stesso nome si distinguono per la provincia), l'<i>
inquadratura della mappa</i> o i <i>poligoni di un layer</i> (quelli
selezionati, o tutti). Fuori dall'Italia non ci sono dati.</li>
<li><b>Con gli indicatori demografici</b>: oltre a residenti, famiglie,
abitazioni ed edifici aggiunge 119 colonne: residenti per sesso e classe
di età, titolo di studio, occupati, italiani e stranieri (UE ed extra UE),
famiglie per numero di componenti, abitazioni occupate e non. Senza, il
primo download della regione è più rapido.</li>
<li><b>Colora per</b>: densità (abitanti per ettaro), abitanti, componenti
per famiglia e, con gli indicatori, quota di 0-14 anni, quota di 65 anni e
più, indice di vecchiaia, stranieri, titolo terziario, tasso di
occupazione 15-64, abitazioni non occupate da residenti. Cinque classi con
lo stesso numero di sezioni; in grigio le sezioni senza residenti. Il tema
si può cambiare dopo il caricamento: il layer si ricolora senza
riscaricare.</li>
</ul>
<p><b>Il layer</b>: una riga per sezione con il codice ISTAT
(<i>SEZ21_ID</i>), il comune, i dati di base (<i>POP21</i>, <i>FAM21</i>,
<i>ABI21</i>, <i>EDI21</i>), la superficie, gli indicatori calcolati
(<i>DENS_HA</i>, <i>PCT_65P</i>, <i>PCT_STRAN</i>…) e le colonne
dell'ISTAT con il loro codice (<i>P1</i>, <i>ST1</i>, <i>PF1</i>…). Nella
tabella degli attributi ogni colonna ha la descrizione accanto al codice.
Il campo <i>POP21</i> si può usare come popolazione nelle altre schede
(15 minuti, accessibilità, equità, Report).</p>
<p><b>Il riepilogo</b>: totali e indicatori dell'area (si copia negli
appunti). Per un comune i totali sono quelli ufficiali. Per
un'inquadratura o un layer le sezioni a cavallo del confine restano intere
nel layer ma nel riepilogo contano per la parte che cade dentro l'area
(campo <i>QUOTA</i>): è una stima, tanto più precisa quanto più l'area è
grande rispetto alle sezioni.</p>
<p><b>Download</b>: i dati arrivano per regione (da 4 MB della Valle
d'Aosta a oltre 60 MB della Lombardia, più gli indicatori) e restano nel
profilo di QGIS: la volta dopo il caricamento è immediato e non serve
internet. In <i>Dati scaricati</i> si vede quanto occupano e si possono
cancellare. Se l'area tocca più regioni si scaricano tutte.</p>
<p><b>Avvertenze</b>: i conteggi piccoli sono incerti (l'ISTAT li
perturba per riservatezza): le percentuali di una sezione con pochi
residenti vanno lette con prudenza; meglio guardare gruppi di sezioni. I
confini comunali sono quelli del 2021.</p>
<h3>Addetti (posti di lavoro, 2011)</h3>
<p>Nella sezione <b>Addetti</b>, con l'area scelta in cima alla scheda,
<b>Scarica e carica gli addetti</b> carica le sezioni di censimento 2011
con gli addetti alle unità locali di imprese, istituzioni pubbliche e
istituzioni non profit, anche per settore (industria, commercio, servizi
alle imprese, pubblica amministrazione, istruzione e sanità…).</p>
<ul>
<li><b>Perché 2011</b>: è l'ultimo dato ISTAT degli addetti per sezione di
censimento (9° Censimento dell'industria e dei servizi); dopo il 2011 gli
addetti si pubblicano solo per comune. Le sezioni 2011 hanno confini
diversi da quelle 2021: il layer è uno strato a sé.</li>
<li><b>Colora per</b>: addetti per ettaro, addetti per sezione, addetti
delle imprese, dipendenti pubblici, settore con più addetti; il tema si
cambia senza riscaricare.</li>
<li><b>Riepilogo</b>: addetti per tipo e per settore, unità locali
(indicative) e, come confronto, il dato comunale recente del comune
scelto (o di quello con più addetti nell'area): addetti delle imprese
2024 (registro ASIA) e dipendenti pubblici 2020, con la variazione dal
2011. La prima volta il dato comunale recente richiede fino a un minuto.</li>
<li><b>Cosa contano</b>: per le imprese gli addetti (dipendenti e
indipendenti) delle unità locali; per le istituzioni pubbliche e le non
profit i dipendenti. I posti di lavoro sono contati dove si trova l'unità
locale, non nella sede: grandi uffici o stabilimenti danno picchi
isolati. Per un'area le sezioni a cavallo del confine contano per la
parte dentro (campo <i>QUOTA</i>).</li>
</ul>
<p>Nel <b>Report</b>, con i dati ISTAT, gli addetti dell'area compaiono
nella sintesi e nella pagina «Popolazione» (con il rapporto addetti ogni
100 residenti) e in un foglio dell'Excel.</p>
<h3>I dati ISTAT nelle altre schede</h3>
<p>Dove un'analisi chiede la popolazione c'è il pulsante <b>🌐 ISTAT</b>:
nelle <i>Isocrone</i> (residenti o addetti raggiunti, dal menu), nel
<i>PTAL</i> (gap analysis), nell'<i>Accessibilità</i> (origini con i
residenti, poi peso nella sintesi di equità; destinazioni con gli addetti,
cioè i posti di lavoro raggiungibili) e nei <i>15 minuti</i> (zone). Scarica i residenti 2021 delle
sezioni di censimento dell'inquadratura, crea il layer e lo imposta nel
campo giusto con <i>POP21</i>: un punto per sezione dove servono punti, le
sezioni dove servono zone; solo le sezioni con residenti. Finché si resta
nella stessa zona i pulsanti delle altre schede riusano gli stessi dati,
senza riscaricare e senza creare doppioni. Per un comune intero o per gli
indicatori demografici si usa questa scheda.</p>
<h3>Pendolarismo fra comuni (2021)</h3>
<p>Nella sezione <b>Pendolarismo fra comuni</b> si sceglie un comune e il
plugin scarica (2 MB, una volta sola) le matrici ISTAT 2021 degli
spostamenti quotidiani per <b>lavoro</b> e per <b>studio</b>, poi disegna
le linee di desiderio fra quel comune e gli altri.</p>
<ul>
<li><b>Flussi</b>: <i>in uscita</i> (dove vanno a lavorare o studiare i
residenti), <i>in entrata</i> (da dove arriva chi lavora o studia nel
comune) o entrambi. <b>Motivo</b>: lavoro, studio o la loro somma.</li>
<li><b>Almeno … persone</b>: la matrice contiene moltissimi flussi di una
o due persone, anche da centinaia di chilometri; con la soglia di 50
persone resta di solito oltre il 90 % delle persone con un quinto delle
linee. <b>Primi</b>: solo i flussi più grandi, per ciascun verso.</li>
</ul>
<p><b>Risultati</b>: il layer dei <i>flussi</i> (arancio in uscita, blu
in entrata, spessore secondo le persone; per ogni linea i due comuni, le
persone per lavoro e per studio e la distanza in linea d'aria) e quello
dei <i>comuni</i> collegati (cerchi secondo le persone scambiate, con il
nome dei principali e il saldo). Nel pannello: quanti restano nel comune,
quanti escono e quanti entrano, le prime destinazioni e le prime
origini.</p>
<p><b>Cosa dice e cosa no</b>: persone che vanno al luogo abituale di
lavoro o di studio almeno tre giorni a settimana, al 31/12/2021. È una
<b>stima</b> da modello (registri e indagine), non un conteggio: i flussi
piccoli sono incerti. Non c'è il mezzo di trasporto né l'orario, e non
compare chi va all'estero (Svizzera, San Marino…). Lo studio riguarda i
non occupati: sommare lavoro e studio non conta due volte nessuno. Le
linee partono dal baricentro dei residenti di ogni comune.</p>
<p>Fonte: ISTAT, Basi territoriali e variabili censuarie e Matrici del
pendolarismo, Censimento permanente della popolazione 2021. Licenza
CC BY 4.0: citare l'ISTAT quando si pubblicano mappe o numeri.</p>
"""),
    "fifteen": ("Città 15 minuti · aiuto", """
<h3>Città dei 15 minuti</h3>
<p>Per ogni zona o cella misura, lungo la rete, il tempo fino al servizio più
vicino di ogni categoria (alimentari, scuole, salute, parchi…) e calcola
l'<b>indice</b>: la quota di categorie raggiunte entro la soglia (100 = tutte
entro 15 minuti a piedi).</p>
<ul>
<li><b>Servizi</b>: un layer di punti o poligoni con un <i>campo
categoria</i>, oppure <b>🌐 Da OSM</b> (accanto ai servizi), che scarica
dall'inquadratura 9 categorie: alimentari, scuole e nidi, salute, parchi e
gioco, sport, trasporto pubblico, cultura e socialità, bar e ristoranti,
uffici e servizi (campo <i>categoria</i>). Puoi togliere dal layer le
categorie che non ti interessano.</li>
<li><b>Zone o punti</b> (opz.): sezioni di censimento, quartieri, edifici…
(il risultato è una copia con i campi aggiunti). Vuoto = <b>griglia
esagonale</b> sulla rete, o solo dentro l'<i>Area della griglia</i>;
<i>Cella</i> = raggio dell'esagono. <b>🌐 ISTAT</b> scarica le sezioni di
censimento con residenti dell'inquadratura (solo in Italia) e le imposta
come zone, con i residenti 2021 (<i>POP21</i>) come popolazione: l'esito
dice anche quale quota dei residenti ha tutti i servizi.</li>
<li><b>Mezzo</b>: piedi (anche con la pendenza da un DEM) o bici;
<b>Soglia</b>: 15 minuti di default.</li>
<li><b>Popolazione delle zone</b> (opz.): il messaggio riporta la quota di
popolazione con tutti i servizi.</li>
</ul>
<p>Campi: <i>t_&lt;categoria&gt;</i> (minuti al più vicino; vuoto se oltre il
doppio della soglia), <i>n_servizi</i>, <i>indice</i> (0–100, legenda dal
rosso al verde), <i>t_tutti</i> (minuti per averle tutte) e <i>mancanti</i>.
Il messaggio indica la categoria che manca più spesso. Zone a più di 500 m
dalla rete: indice 0.</p>
<p>Il calcolo fa un percorso a ritroso per categoria da tutti i servizi, non
uno per zona: anche migliaia di celle restano rapide. Anche in Processing:
<i>mic:fifteenminutes</i>.</p>
""" + _SNAP + _OSM),
}
