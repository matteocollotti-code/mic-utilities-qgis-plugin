# -*- coding: utf-8 -*-
"""Esportazione di un layout di stampa di QGIS in IDML (InDesign Markup
Language): il formato che Adobe InDesign apre come documento modificabile.

Ogni pagina del layout diventa una pagina di InDesign con gli stessi
oggetti nelle stesse posizioni:

- le etichette diventano cornici di testo con il loro testo, carattere,
  corpo, colore e allineamento; le righe vanno a capo dove vanno a capo in
  QGIS (a capo forzato), e uno stile di paragrafo per ogni combinazione di
  corpo, peso e colore permette di ritoccarle tutte insieme;
- rettangoli ed ellissi diventano cornici con riempimento, contorno, angoli
  arrotondati e trasparenza;
- mappe, barre di scala, immagini e ogni altro oggetto diventano immagini
  PNG ad alta risoluzione (cartella «Links» accanto al file IDML), rese da
  QGIS una per una: in InDesign si spostano, si ridimensionano e si
  sostituiscono come qualunque immagine collegata;
- i gruppi del layout restano gruppi.

Va chiamato sul thread principale (rende gli oggetti del layout).
"""
import os
import re
import zipfile
from xml.sax.saxutils import escape, quoteattr

from qgis.PyQt.QtCore import QRectF, QSize, Qt, QUrl
from qgis.PyQt.QtGui import (QColor, QFont, QFontDatabase, QFontMetricsF,
                             QImage)
from qgis.core import (QgsApplication, QgsLayoutExporter, QgsLayoutItem,
                       QgsLayoutItemGroup, QgsLayoutItemLabel,
                       QgsLayoutItemPage, QgsLayoutItemShape,
                       QgsRenderContext, QgsTextFormat, QgsTextRenderer,
                       QgsUnitTypes)

PT = 72.0 / 25.4          # punti per millimetro
DOM = "13.1"
NS = "http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging"
KAPPA = 0.5522847498      # approssimazione di un quarto di ellisse
LSEP = " "           # a capo forzato di InDesign

_STYLE_WORDS = {"normale": "Regular", "normal": "Regular", "regular": "Regular",
                "standard": "Regular", "grassetto": "Bold", "bold": "Bold",
                "gras": "Bold", "fett": "Bold", "negrita": "Bold",
                "corsivo": "Italic", "italic": "Italic", "kursiv": "Italic",
                "italique": "Italic", "cursiva": "Italic"}


def _n(v):
    """Numero per gli attributi IDML."""
    s = "%.4f" % v
    s = s.rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def _dpi():
    try:
        return float(QgsApplication.primaryScreen().logicalDotsPerInch()) \
            or 96.0
    except Exception:
        return 96.0


def font_style_name(family, weight, italic=False):
    """Nome dello stile del carattere come lo usa InDesign (Regular, Bold,
    Semibold, Medium…): lo stile della famiglia con il peso più vicino; i
    nomi tradotti da Qt (Normale, Grassetto, Corsivo) tornano in inglese."""
    db = QFontDatabase()
    best = None
    for st in db.styles(family):
        if db.italic(family, st) != bool(italic):
            continue
        name = " ".join(_STYLE_WORDS.get(w.lower(), w) for w in st.split())
        d = abs(db.weight(family, st) - weight)
        rank = (d, 0 if name in ("Regular", "Bold", "Italic", "Bold Italic")
                else 1)
        if best is None or rank < best[0]:
            best = (rank, name)
    if best is not None:
        return best[1]
    base = ("Bold" if weight >= 70 else "Semibold" if weight >= 60 else
            "Medium" if weight >= 55 else "Light" if weight <= 30 else
            "Regular")
    return (base + " Italic").replace("Regular Italic", "Italic") \
        if italic else base


# ---------------------------------------------------------------- registri
class _Ids(object):
    def __init__(self):
        self.k = 0x100

    def __call__(self):
        self.k += 1
        return "u%x" % self.k


class _Colors(object):
    """Colori RGB del documento, uno per valore (campioni «R=… G=… B=…»)."""

    def __init__(self):
        self.items = {}

    def ref(self, c):
        key = (c.red(), c.green(), c.blue())
        if key not in self.items:
            self.items[key] = "Color/R=%d G=%d B=%d" % key
        return self.items[key]

    def xml(self):
        out = []
        for (r, g, b), self_ in sorted(self.items.items()):
            out.append(
                '<Color Self=%s Model="Process" Space="RGB" ColorValue="%d %d '
                '%d" ColorOverride="Normal" AlternateSpace="NoAlternateColor" '
                'AlternateColorValue="" Name=%s ColorEditable="true" '
                'ColorRemovable="true" Visible="true" SwatchCreatorID="7937"/>'
                % (quoteattr(self_), r, g, b, quoteattr(self_[6:])))
        return "\n\t".join(out)


class _ParaStyles(object):
    """Uno stile di paragrafo per combinazione di carattere, corpo, peso,
    spaziatura e colore: in InDesign si ritoccano tutti i titoli (o tutte le
    note) cambiando uno stile."""

    def __init__(self, colors):
        self.colors = colors
        self.items = {}

    def ref(self, family, style, size, leading, tracking, color):
        key = (family, style, round(size, 2), round(leading, 2),
               int(round(tracking)), color.name())
        if key not in self.items:
            name = "MIC %s %s %s%s" % (
                ("%g" % round(size, 2)).replace(".", ","), style,
                color.name()[1:],
                (" t%d" % key[4]) if key[4] else "")
            base, n = name, 2
            while name in [v[0] for v in self.items.values()]:
                name = "%s (%d)" % (base, n)
                n += 1
            self.items[key] = (name, self.colors.ref(color))
        return "ParagraphStyle/" + self.items[key][0]

    def xml(self):
        out = []
        for (family, style, size, leading, tracking, _c), (name, cref) in \
                sorted(self.items.items(), key=lambda kv: kv[1][0]):
            self_ = "ParagraphStyle/" + name
            out.append(
                '<ParagraphStyle Self=%s Name=%s Imported="false" '
                'NextStyle=%s KeyboardShortcut="0 0" PointSize="%s" '
                'FontStyle=%s Tracking="%d" FillColor=%s Hyphenation="false" '
                'SpaceBefore="0" SpaceAfter="0" FirstLineIndent="0" '
                'LeftIndent="0" RightIndent="0">'
                '<Properties><BasedOn type="string">$ID/[No paragraph style]'
                '</BasedOn><PreviewColor type="enumeration">Nothing'
                '</PreviewColor><AppliedFont type="string">%s</AppliedFont>'
                '<Leading type="unit">%s</Leading></Properties>'
                '</ParagraphStyle>' % (
                    quoteattr(self_), quoteattr(name), quoteattr(self_),
                    _n(size), quoteattr(style), tracking, quoteattr(cref),
                    escape(family), _n(leading)))
        return "\n\t\t".join(out)


# ---------------------------------------------------------- geometria IDML
def _path(x0, y0, x1, y1):
    pts = [(x0, y0), (x0, y1), (x1, y1), (x1, y0)]
    return ('<Properties><PathGeometry><GeometryPathType PathOpen="false">'
            '<PathPointArray>%s</PathPointArray></GeometryPathType>'
            '</PathGeometry></Properties>' % "".join(
                '<PathPointType Anchor="%s %s" LeftDirection="%s %s" '
                'RightDirection="%s %s"/>' % ((_n(x), _n(y)) * 3)
                for x, y in pts))


def _oval_path(x0, y0, x1, y1):
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    rx, ry = (x1 - x0) / 2.0, (y1 - y0) / 2.0
    kx, ky = rx * KAPPA, ry * KAPPA
    # da sinistra verso il basso, destra, alto: per ogni punto la maniglia
    # «Left» va verso il punto precedente, «Right» verso il successivo
    pts = [((x0, cy), (x0, cy - ky), (x0, cy + ky)),
           ((cx, y1), (cx - kx, y1), (cx + kx, y1)),
           ((x1, cy), (x1, cy + ky), (x1, cy - ky)),
           ((cx, y0), (cx + kx, y0), (cx - kx, y0))]
    return ('<Properties><PathGeometry><GeometryPathType PathOpen="false">'
            '<PathPointArray>%s</PathPointArray></GeometryPathType>'
            '</PathGeometry></Properties>' % "".join(
                '<PathPointType Anchor="%s %s" LeftDirection="%s %s" '
                'RightDirection="%s %s"/>' % (
                    _n(a[0]), _n(a[1]), _n(l[0]), _n(l[1]), _n(r[0]),
                    _n(r[1])) for a, l, r in pts))


def _transparency(fill_alpha=255, stroke_alpha=255, opacity=1.0,
                  blend="Normal"):
    out = ""
    if opacity < 0.999 or blend != "Normal":
        out += ('<TransparencySetting><BlendingSetting BlendMode="%s" '
                'Opacity="%s"/></TransparencySetting>'
                % (blend, _n(100.0 * opacity)))
    if fill_alpha < 255:
        out += ('<FillTransparencySetting><BlendingSetting Opacity="%s"/>'
                '</FillTransparencySetting>' % _n(100.0 * fill_alpha / 255))
    if stroke_alpha < 255:
        out += ('<StrokeTransparencySetting><BlendingSetting Opacity="%s"/>'
                '</StrokeTransparencySetting>'
                % _n(100.0 * stroke_alpha / 255))
    return out


_BLEND = {0: "Normal"}
try:
    from qgis.PyQt.QtGui import QPainter as _QP
    _BLEND = {int(_QP.CompositionMode_SourceOver): "Normal",
              int(_QP.CompositionMode_Multiply): "Multiply",
              int(_QP.CompositionMode_Screen): "Screen",
              int(_QP.CompositionMode_Overlay): "Overlay",
              int(_QP.CompositionMode_Darken): "Darken",
              int(_QP.CompositionMode_Lighten): "Lighten"}
except Exception:
    pass


def _zmin(it, visible):
    """Ordine di disegno di un oggetto o di un gruppo (il suo elemento
    più in basso); None per un gruppo senza oggetti visibili."""
    if isinstance(it, QgsLayoutItemGroup):
        zs = [_zmin(k, visible) for k in it.items()]
        zs = [z for z in zs if z is not None]
        return min(zs) if zs else None
    return it.zValue() if it in visible else None


def _file_uri(path):
    """Percorso come lo scrive InDesign: file:C:/… su Windows, file:/…
    altrove, con gli spazi codificati."""
    u = QUrl.fromLocalFile(os.path.abspath(path)).toString(QUrl.FullyEncoded)
    rest = u[len("file://"):] if u.startswith("file://") else u[5:]
    if re.match(r"^/[A-Za-z]:", rest):
        rest = rest[1:]
    return "file:" + rest


# ------------------------------------------------------------ esportatore
class IdmlExporter(object):
    """Converte un QgsPrintLayout in un pacchetto IDML.

    :param dpi: risoluzione delle immagini (mappe, barre di scala…).
    """

    def __init__(self, layout, dpi=300, progress=None):
        self.layout = layout
        self.dpi = float(dpi)
        self.progress = progress
        self.ids = _Ids()
        self.colors = _Colors()
        self.colors.ref(QColor("#000000"))
        self.styles = _ParaStyles(self.colors)
        self.stories = []        # (id, xml)
        self.layer = self.ids()
        self.links = []          # percorsi dei PNG scritti
        self.stats = {"pages": 0, "texts": 0, "shapes": 0, "images": 0,
                      "groups": 0}
        self.warnings = []
        self._mm = self.layout.convertFromLayoutUnits(
            1.0, QgsUnitTypes.LayoutMillimeters).length()
        self._probes = {}
        self._plab = None
        self._play = None
        # misure del testo alla risoluzione di esportazione del layout
        self._ctx = QgsRenderContext()
        self._ctx.setScaleFactor(max(150.0, float(
            self.layout.renderContext().dpi() or 300.0)) / 25.4)

    # -------------------------------------------------------- oggetti
    def _top_items(self, page_index, visible):
        out = []
        for it in self.layout.items():
            if not isinstance(it, QgsLayoutItem) or isinstance(
                    it, QgsLayoutItemPage):
                continue
            if it.parentGroup() is not None:
                continue
            if isinstance(it, QgsLayoutItemGroup):
                z = _zmin(it, visible)
                if z is None or it.page() != page_index:
                    continue
                out.append((z, it))
            elif it in visible and it.page() == page_index:
                out.append((it.zValue(), it))
        out.sort(key=lambda t: t[0])
        return [it for _z, it in out]

    def _rect_pt(self, it, page, frame=False):
        """(x0, y0, x1, y1) dell'oggetto in punti, coordinate della pagina."""
        if frame:
            r = it.sceneBoundingRect()
            x, y, w, h = r.x(), r.y(), r.width(), r.height()
        else:
            p = it.scenePos()
            x, y = p.x(), p.y()
            w, h = it.rect().width(), it.rect().height()
        x -= page.pos().x()
        y -= page.pos().y()
        k = self._mm * PT
        return x * k, y * k, (x + w) * k, (y + h) * k

    def _entry(self, it, page, H, visible, prefix):
        """XML di un oggetto (o di un gruppo) in coordinate dello spread."""
        if isinstance(it, QgsLayoutItemGroup):
            kids = sorted([k for k in it.items() if k in visible or
                           isinstance(k, QgsLayoutItemGroup)],
                          key=lambda k: _zmin(k, visible))
            parts = [self._entry(k, page, H, visible, prefix) for k in kids]
            parts = [p for p in parts if p]
            if len(parts) == 1:
                return parts[0]
            if not parts:
                return ""
            self.stats["groups"] += 1
            return ('<Group Self="%s" ItemLayer="%s" Locked="false" '
                    'Visible="true" Name="$ID/" AppliedObjectStyle='
                    '"ObjectStyle/$ID/[None]" ItemTransform="1 0 0 1 0 0">'
                    '%s</Group>' % (self.ids(), self.layer, "".join(parts)))
        rot = getattr(it, "itemRotation", lambda: 0.0)()
        if isinstance(it, QgsLayoutItemLabel) and not rot and \
                it.mode() != QgsLayoutItemLabel.ModeHtml:
            x = self._text(it, page, H, it.page())
            if x is not None:
                return x
        if isinstance(it, QgsLayoutItemShape) and not rot:
            x = self._shape(it, page, H)
            if x is not None:
                return x
        return self._image(it, page, H, visible, prefix)

    # ------------------------------------------------------- etichette
    def _label_font(self, lab):
        try:
            tf = lab.textFormat()
            font = QFont(tf.font())
            size = tf.size()
            if tf.sizeUnit() == QgsUnitTypes.RenderMillimeters:
                size *= PT
            color = QColor(tf.color())
            opacity = tf.opacity()
        except AttributeError:   # QGIS < 3.24
            font = QFont(lab.font())
            size = font.pointSizeF()
            color = QColor(lab.fontColor())
            opacity = 1.0
        if size <= 0:
            size = 10.0
        font.setPointSizeF(size)
        return font, size, color, opacity

    def _measure(self, lab, text, font, size, width_pt):
        """Righe, interlinea e prima linea di base come le calcola QGIS
        (motore di testo dei layout alla risoluzione di esportazione):
        (paragrafi [[righe]], interlinea pt, prima base pt, altezza di una
        riga pt)."""
        paras = None
        try:
            tf = lab.textFormat()
            ctx = self._ctx
            sf = ctx.scaleFactor()
            wpu = width_pt / PT * sf
            paras = [QgsTextRenderer.wrappedText(ctx, par, wpu, tf) or [""]
                     for par in text.split("\n")]
            mode = getattr(QgsTextRenderer, "Rect", None)
            if mode is None:
                from qgis.core import Qgis
                mode = Qgis.TextLayoutMode.Rectangle
            h1 = QgsTextRenderer.textHeight(ctx, tf, ["x"], mode) / sf * PT
            h2 = QgsTextRenderer.textHeight(ctx, tf, ["x", "x"], mode) \
                / sf * PT
            lead = h2 - h1
            if not (h1 > 0 and lead > 0):
                raise ValueError("misure non valide")
        except Exception:
            # QGIS < 3.24: a capo per parola con le metriche di Qt
            paras = None
        big = QFont(font)
        big.setPointSizeF(100.0)
        bm = QFontMetricsF(big)
        if paras is None:
            fm = QFontMetricsF(font)
            dpi = _dpi()

            def w(t):
                try:
                    px = fm.horizontalAdvance(t)
                except AttributeError:
                    px = fm.width(t)
                return px * 72.0 / dpi

            paras = []
            for par in text.split("\n"):
                lines, cur = [], ""
                for word in par.split(" "):
                    t = word if not cur else cur + " " + word
                    if cur and w(t) > width_pt:
                        lines.append(cur)
                        cur = word
                    else:
                        cur = t
                lines.append(cur)
                paras.append(lines)
            h1 = lead = fm.lineSpacing() / dpi * 72.0
        # prima linea di base e interlinea misurate su QGIS (stima se la
        # misura non riesce)
        desc = bm.descent() / max(1e-9, bm.ascent() + bm.descent())
        first = h1 * (1.0 - desc)
        got = self._probe(lab)
        if got is not None:
            first, lead = got[0], got[1]
        return paras, lead, first, h1

    def _probe(self, lab):
        """(prima linea di base, interlinea) in punti come le disegna
        un'etichetta di QGIS con questo formato: due «H» su due righe rese
        ad alta risoluzione; il fondo di ogni «H» è la linea di base.
        Una misura per formato, poi dalla memoria."""
        try:
            tf = QgsTextFormat(lab.textFormat())
        except AttributeError:
            return None
        key = (tf.font().toString(), round(tf.size(), 3), int(tf.sizeUnit()),
               round(tf.lineHeight(), 3))
        if key in self._probes:
            return self._probes[key]
        out = None
        try:
            import numpy as np
            from qgis.core import QgsLayoutPoint, QgsLayoutSize, QgsPrintLayout
            if self._plab is None:
                self._play = QgsPrintLayout(self.layout.project())
                self._plab = QgsLayoutItemLabel(self._play)
                self._play.addLayoutItem(self._plab)
                self._plab.setMarginX(0)
                self._plab.setMarginY(0)
                self._plab.setText("H\nH")
            tf.setColor(QColor(0, 0, 0))
            tf.setOpacity(1.0)
            for get, put in ((tf.buffer, tf.setBuffer),
                             (tf.background, tf.setBackground),
                             (tf.shadow, tf.setShadow)):
                part = get()
                part.setEnabled(False)
                put(part)
            self._plab.setTextFormat(tf)
            size_pt = tf.size() * (PT if tf.sizeUnit() ==
                                   QgsUnitTypes.RenderMillimeters else 1.0)
            w_mm = max(5.0, 1.6 * size_pt / PT)
            h_mm = max(5.0, 4.0 * size_pt * max(1.0, tf.lineHeight()) / PT)
            self._plab.attemptMove(QgsLayoutPoint(0, 0, QgsUnitTypes.LayoutMillimeters))
            self._plab.attemptResize(QgsLayoutSize(
                w_mm, h_mm, QgsUnitTypes.LayoutMillimeters))
            dpi = 1200.0 if size_pt < 20 else 600.0
            k = dpi / 25.4
            img = QgsLayoutExporter(self._play).renderRegionToImage(
                self._plab.sceneBoundingRect(),
                QSize(int(w_mm * k), int(h_mm * k)), dpi)
            img = img.convertToFormat(QImage.Format_ARGB32)
            w, h = img.width(), img.height()
            arr = np.frombuffer(img.constBits().asstring(img.sizeInBytes()),
                                np.uint8).reshape(h, img.bytesPerLine())
            alpha = arr[:, :w * 4].reshape(h, w, 4)[:, :, 3]
            rows = np.nonzero((alpha > 127).any(axis=1))[0]
            ends = [int(r) for i, r in enumerate(rows)
                    if i + 1 == len(rows) or rows[i + 1] != r + 1]
            if len(ends) == 2:
                b1 = (ends[0] + 1) / dpi * 72.0
                b2 = (ends[1] + 1) / dpi * 72.0
                if b2 > b1 > 0:
                    out = (b1, b2 - b1)
        except Exception:
            out = None
        self._probes[key] = out
        return out

    @staticmethod
    def _ascent_d(font, size):
        """Altezza della «d» in punti: è la distanza fra il bordo della
        cornice e la prima linea di base con l'opzione «Ascendente», quella
        predefinita di InDesign (e usata anche da Affinity)."""
        big = QFont(font)
        big.setPointSizeF(100.0)
        fm = QFontMetricsF(big)
        r = fm.tightBoundingRect("d")
        if r.height() <= 0:
            return 0.75 * size
        return -r.top() / _dpi() * 72.0 * size / 100.0

    def _text(self, lab, page, H, page_index):
        text = lab.currentText()
        if text is None:
            return None
        text = str(text).replace("\r\n", "\n").replace("\r", "\n")
        font, size, color, opacity = self._label_font(lab)
        bx0, by0, bx1, by1 = self._rect_pt(lab, page)
        mx, my = lab.marginX() * self._mm * PT, lab.marginY() * self._mm * PT
        x0, x1, y0, y1 = bx0 + mx, bx1 - mx, by0 + my, by1 - my
        if x1 - x0 <= 0.5:
            return None
        paras, lead, first, h1 = self._measure(lab, text, font, size,
                                               x1 - x0)
        nlines = sum(len(p) for p in paras)
        block = h1 + lead * (nlines - 1)
        family = font.family()
        style = font_style_name(family, font.weight(), font.italic())
        spacing = font.letterSpacing() if font.letterSpacingType() == \
            QFont.AbsoluteSpacing else 0.0
        tracking = 1000.0 * spacing / size if size else 0.0
        ha, va = lab.hAlign(), lab.vAlign()
        # posizione verticale del blocco di testo come in QGIS: la cornice
        # di InDesign è allineata in alto e parte dalla cima del blocco (non
        # dipende da come InDesign centra il testo)
        if va & Qt.AlignBottom:
            top = y1 - block
        elif va & Qt.AlignVCenter:
            top = y0 + (y1 - y0 - block) / 2.0
        else:
            top = y0
        bottom = max(top + block + 0.35 * lead + 2.0, y1 if top == y0
                     else top)
        # prima linea di base con l'ascendente (opzione predefinita di
        # InDesign, la sola che Affinity legge): la cornice sale quanto
        # basta perché la base cada dove la mette QGIS
        ftop = top + first - self._ascent_d(font, size)
        # cornice un po' più larga dalla parte opposta all'allineamento: il
        # testo resta dov'è ma in InDesign, con metriche leggermente
        # diverse, una riga non va a capo da sola
        dw = max(3.0, 0.04 * (x1 - x0))
        if ha & Qt.AlignRight:
            fx0, fx1 = x0 - dw, x1
        elif ha & Qt.AlignHCenter:
            fx0, fx1 = x0 - dw / 2, x1 + dw / 2
        else:
            fx0, fx1 = x0, x1 + dw
        just = ("RightAlign" if ha & Qt.AlignRight else "CenterAlign"
                if ha & Qt.AlignHCenter else "LeftJustified"
                if ha & Qt.AlignJustify else "LeftAlign")
        pstyle = self.styles.ref(family, style, size, lead, tracking, color)
        sid, fid = self.ids(), self.ids()
        contents = [escape(LSEP.join(lines)) for lines in paras]
        # numero di pagina del piè di pagina: numero automatico di InDesign
        raw = str(lab.text() or "")
        m = re.match(r"^\s*\[%\s*@layout_page\s*%\]", raw)
        num = str(page_index + 1)
        if m and contents and contents[0].startswith(num):
            contents[0] = "<?ACE 18?>" + contents[0][len(num):]
        body = "<Br/>".join("<Content>%s</Content>" % c for c in contents)
        self.stories.append((sid, (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<idPkg:Story xmlns:idPkg="%s" DOMVersion="%s">'
            '<Story Self="%s" AppliedTOCStyle="n" TrackChanges="false" '
            'StoryTitle="$ID/" AppliedNamedGrid="n">'
            '<StoryPreference OpticalMarginAlignment="false" '
            'OpticalMarginSize="12" FrameType="TextFrameType" '
            'StoryOrientation="Horizontal" '
            'StoryDirection="LeftToRightDirection"/>'
            '<ParagraphStyleRange AppliedParagraphStyle=%s Justification="%s">'
            '<CharacterStyleRange AppliedCharacterStyle="CharacterStyle/$ID/'
            '[No character style]">%s</CharacterStyleRange>'
            '</ParagraphStyleRange></Story></idPkg:Story>'
            % (NS, DOM, sid, quoteattr(pstyle), just, body))))
        yo = -H / 2.0
        out = ""
        # sfondo e cornice dell'etichetta: un rettangolo a sé, al posto
        # esatto dell'etichetta
        try:
            bg = QColor(lab.backgroundColor()) if lab.hasBackground() \
                else None
            fc = QColor(lab.frameStrokeColor()) if lab.frameEnabled() \
                else None
        except Exception:
            bg = fc = None
        if (bg is not None and bg.alpha() > 0) or fc is not None:
            attrs = ('FillColor=%s' % quoteattr(self.colors.ref(bg))
                     if bg is not None and bg.alpha() > 0
                     else 'FillColor="Swatch/None"')
            if fc is not None:
                attrs += ' StrokeColor=%s StrokeWeight="%s"' % (
                    quoteattr(self.colors.ref(fc)),
                    _n(lab.frameStrokeWidth().length() * self._mm * PT))
            else:
                attrs += ' StrokeColor="Swatch/None" StrokeWeight="0"'
            self.stats["shapes"] += 1
            out += ('<Rectangle Self="%s" ContentType="Unassigned" '
                    'ItemLayer="%s" Locked="false" Visible="true" '
                    'Name="$ID/" AppliedObjectStyle="ObjectStyle/$ID/[None]" '
                    '%s ItemTransform="1 0 0 1 0 0">%s%s</Rectangle>' % (
                        self.ids(), self.layer, attrs,
                        _path(bx0, by0 + yo, bx1, by1 + yo),
                        _transparency(bg.alpha() if bg is not None and
                                      bg.alpha() else 255, 255,
                                      lab.itemOpacity())))
        self.stats["texts"] += 1
        out += ('<TextFrame Self="%s" ParentStory="%s" PreviousTextFrame="n" '
                'NextTextFrame="n" ContentType="TextType" ItemLayer="%s" '
                'Locked="false" Visible="true" Name="$ID/" '
                'AppliedObjectStyle="ObjectStyle/$ID/[None]" '
                'FillColor="Swatch/None" StrokeColor="Swatch/None" '
                'StrokeWeight="0" ItemTransform="1 0 0 1 0 0">%s'
                '<TextFramePreference TextColumnCount="1" '
                'VerticalJustification="TopAlign" InsetSpacing="0 0 0 0" '
                'FirstBaselineOffset="AscentOffset" AutoSizingType="Off" '
                'UseNoLineBreaksForAutoSizing="false"/>%s</TextFrame>' % (
                    fid, sid, self.layer,
                    _path(fx0, ftop + yo, fx1, bottom + yo),
                    _transparency(opacity=opacity * lab.itemOpacity())))
        if len(out) and out.startswith("<Rectangle"):
            self.stats["groups"] += 1
            return ('<Group Self="%s" ItemLayer="%s" Locked="false" '
                    'Visible="true" Name="$ID/" AppliedObjectStyle='
                    '"ObjectStyle/$ID/[None]" ItemTransform="1 0 0 1 0 0">'
                    '%s</Group>' % (self.ids(), self.layer, out))
        return out

    # ------------------------------------------------------------ forme
    def _shape(self, sh, page, H):
        sym = sh.symbol()
        if sym is None or sym.symbolLayerCount() != 1:
            return None
        sl = sym.symbolLayer(0)
        if sl.layerType() != "SimpleFill":
            return None
        kind = sh.shapeType()
        if kind not in (QgsLayoutItemShape.Rectangle,
                        QgsLayoutItemShape.Ellipse):
            return None
        fc = QColor(sl.color())
        has_stroke = sl.strokeStyle() != Qt.NoPen and sl.strokeWidth() > 0 \
            and QColor(sl.strokeColor()).alpha() > 0
        try:
            if sl.brushStyle() == Qt.NoBrush:
                fc.setAlpha(0)
        except Exception:
            pass
        if fc.alpha() == 0 and not has_stroke:
            return ""      # forma invisibile (per esempio un ritaglio)
        x0, y0, x1, y1 = self._rect_pt(sh, page)
        yo = -H / 2.0
        attrs = []
        trans = ""
        if fc.alpha() > 0:
            attrs.append('FillColor=%s' % quoteattr(self.colors.ref(fc)))
        else:
            attrs.append('FillColor="Swatch/None"')
        sa = 255
        if has_stroke:
            scol = QColor(sl.strokeColor())
            sa = scol.alpha()
            sw = sl.strokeWidth()
            if sl.strokeWidthUnit() == QgsUnitTypes.RenderMillimeters:
                sw *= PT
            elif sl.strokeWidthUnit() != QgsUnitTypes.RenderPoints:
                sw *= PT * 0.26
            attrs.append('StrokeColor=%s StrokeWeight="%s" '
                         'StrokeAlignment="CenterAlignment"'
                         % (quoteattr(self.colors.ref(scol)), _n(sw)))
        else:
            attrs.append('StrokeColor="Swatch/None" StrokeWeight="0"')
        op = sh.itemOpacity() * sym.opacity()
        blend = _BLEND.get(int(sh.blendMode()), "Normal")
        trans = _transparency(fc.alpha() if fc.alpha() else 255, sa, op,
                              blend)
        self.stats["shapes"] += 1
        common = ('Self="%s" ContentType="Unassigned" ItemLayer="%s" '
                  'Locked="false" Visible="true" Name="$ID/" '
                  'AppliedObjectStyle="ObjectStyle/$ID/[None]" %s '
                  'ItemTransform="1 0 0 1 0 0"' % (
                      self.ids(), self.layer, " ".join(attrs)))
        if kind == QgsLayoutItemShape.Ellipse:
            return '<Oval %s>%s%s</Oval>' % (
                common, _oval_path(x0, y0 + yo, x1, y1 + yo), trans)
        corner = ""
        try:
            rad = sh.cornerRadius()
            r_mm = self.layout.convertToLayoutUnits(rad) * self._mm
            if r_mm > 0:
                r = _n(min(r_mm * PT, (x1 - x0) / 2, (y1 - y0) / 2))
                corner = (' TopLeftCornerOption="RoundedCorner" '
                          'TopRightCornerOption="RoundedCorner" '
                          'BottomLeftCornerOption="RoundedCorner" '
                          'BottomRightCornerOption="RoundedCorner" '
                          'TopLeftCornerRadius="%s" TopRightCornerRadius="%s"'
                          ' BottomLeftCornerRadius="%s" '
                          'BottomRightCornerRadius="%s"' % (r, r, r, r))
        except Exception:
            pass
        return '<Rectangle %s%s>%s%s</Rectangle>' % (
            common, corner, _path(x0, y0 + yo, x1, y1 + yo), trans)

    # --------------------------------------------------------- immagini
    def _render(self, it, visible):
        """PNG dell'oggetto da solo, sfondo trasparente, alla risoluzione
        scelta. Gli altri oggetti e la carta si nascondono per il tempo
        della resa."""
        hidden = []
        for o in visible:
            if o is not it and o.isVisible():
                o.setVisible(False)
                hidden.append(o)
        pc = self.layout.pageCollection()
        pages = [pc.page(i) for i in range(pc.pageCount())]
        for pg in pages:
            if pg.isVisible():
                pg.setVisible(False)
                hidden.append(pg)
        try:
            r = it.sceneBoundingRect()
            k = self._mm / 25.4 * self.dpi
            size = QSize(max(1, int(round(r.width() * k))),
                         max(1, int(round(r.height() * k))))
            img = QgsLayoutExporter(self.layout).renderRegionToImage(
                QRectF(r), size, self.dpi)
            dpm = int(round(self.dpi / 0.0254))
            img.setDotsPerMeterX(dpm)
            img.setDotsPerMeterY(dpm)
        finally:
            for o in hidden:
                o.setVisible(True)
        return img

    def _image(self, it, page, H, visible, prefix):
        img = self._render(it, visible)
        if img is None or img.isNull():
            self.warnings.append("oggetto non reso: %s" % it.displayName())
            return ""
        name = "%s-p%02d-%03d.png" % (prefix, self.stats["pages"] + 1,
                                      len(self.links) + 1)
        path = os.path.join(self.links_dir, name)
        img.save(path, "PNG")
        self.links.append(path)
        x0, y0, x1, y1 = self._rect_pt(it, page, frame=True)
        yo = -H / 2.0
        wpt = img.width() * 72.0 / self.dpi
        hpt = img.height() * 72.0 / self.dpi
        sx = (x1 - x0) / wpt if wpt else 1.0
        sy = (y1 - y0) / hpt if hpt else 1.0
        uri = _file_uri(path)
        self.stats["images"] += 1
        return (
            '<Rectangle Self="%s" ContentType="GraphicType" ItemLayer="%s" '
            'Locked="false" Visible="true" Name=%s '
            'AppliedObjectStyle="ObjectStyle/$ID/[None]" '
            'FillColor="Swatch/None" StrokeColor="Swatch/None" '
            'StrokeWeight="0" ItemTransform="1 0 0 1 0 0">%s'
            '<Image Self="%s" Space="$ID/RGB" ActualPpi="%s %s" '
            'EffectivePpi="%s %s" ImageRenderingIntent="UseColorSettings" '
            'ImageTypeName="$ID/Portable Network Graphics (PNG)" '
            'AppliedObjectStyle="ObjectStyle/$ID/[None]" Visible="true" '
            'Name="$ID/" ItemTransform="%s 0 0 %s %s %s">'
            '<Properties><Profile type="string">$ID/None</Profile>'
            '<GraphicBounds Left="0" Top="0" Right="%s" Bottom="%s"/>'
            '</Properties>'
            '<Link Self="%s" AssetURL="$ID/" AssetID="$ID/" '
            'LinkResourceURI=%s '
            'LinkResourceFormat="$ID/Portable Network Graphics (PNG)" '
            'StoredState="Normal" LinkClassID="35906" LinkClientID="257" '
            'LinkResourceModified="false" LinkObjectModified="false" '
            'ShowInUI="true" CanEmbed="true" CanUnembed="true" '
            'CanPackage="true" ImportPolicy="NoAutoImport" '
            'ExportPolicy="NoAutoExport"/>'
            '</Image></Rectangle>' % (
                self.ids(), self.layer,
                quoteattr(it.displayName() or "$ID/"),
                _path(x0, y0 + yo, x1, y1 + yo), self.ids(),
                int(self.dpi), int(self.dpi), int(self.dpi), int(self.dpi),
                _n(sx), _n(sy), _n(x0), _n(y0 + yo), _n(wpt), _n(hpt),
                self.ids(), quoteattr(uri)))

    # -------------------------------------------------------- pacchetto
    def export(self, path):
        """Scrive il file IDML e le immagini nella cartella «Links» accanto.

        :return: dict con pages, texts, shapes, images, groups, links (PNG
            scritti), links_dir, warnings.
        """
        folder = os.path.dirname(os.path.abspath(path))
        stem = re.sub(r"[^\w\-]+", "_", os.path.splitext(
            os.path.basename(path))[0]).strip("_") or "report"
        self.links_dir = os.path.join(folder, "Links")
        os.makedirs(self.links_dir, exist_ok=True)
        for fn in os.listdir(self.links_dir):   # immagini di un export prima
            if re.match(r"^%s-p\d\d-\d{3}\.png$" % re.escape(stem), fn):
                try:
                    os.remove(os.path.join(self.links_dir, fn))
                except OSError:
                    pass
        pc = self.layout.pageCollection()
        n = pc.pageCount()
        if not n:
            raise ValueError("il layout non ha pagine")
        visible = set(it for it in self.layout.items()
                      if isinstance(it, QgsLayoutItem)
                      and not isinstance(it, (QgsLayoutItemPage,
                                              QgsLayoutItemGroup))
                      and it.isVisible() and not it.excludeFromExports())
        spreads, page_ids, sizes = [], [], []
        for p in range(n):
            page = pc.page(p)
            W = page.rect().width() * self._mm * PT
            H = page.rect().height() * self._mm * PT
            sizes.append((W, H))
            items = self._top_items(p, visible)
            parts = []
            for k, it in enumerate(items):
                x = self._entry(it, page, H, visible, stem)
                if x:
                    parts.append(x)
                if self.progress:
                    self.progress(100.0 * (p + (k + 1.0) / max(1, len(items)))
                                  / n)
            sid, pid = self.ids(), self.ids()
            page_ids.append(pid)
            spreads.append((sid, (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                '<idPkg:Spread xmlns:idPkg="%s" DOMVersion="%s">'
                '<Spread Self="%s" FlattenerOverride="Default" '
                'AllowPageShuffle="true" ItemTransform="1 0 0 1 0 0" '
                'ShowMasterItems="true" PageCount="1" BindingLocation="0" '
                'PageTransitionType="None" '
                'PageTransitionDirection="NotApplicable" '
                'PageTransitionDuration="Medium">'
                '<Page Self="%s" Name="%d" AppliedMaster="%s" '
                'GeometricBounds="0 0 %s %s" ItemTransform="1 0 0 1 0 %s" '
                'MasterPageTransform="1 0 0 1 0 0" OverrideList="" '
                'TabOrder="" GridStartingPoint="TopOutside" '
                'UseMasterGrid="true"><MarginPreference ColumnCount="1" '
                'ColumnGutter="12" Top="0" Bottom="0" Left="0" Right="0" '
                'ColumnDirection="Horizontal" ColumnsPositions="0 %s"/>'
                '</Page>%s</Spread></idPkg:Spread>' % (
                    NS, DOM, sid, pid, p + 1, "%(master)s", _n(H), _n(W),
                    _n(-H / 2.0), _n(W), "".join(parts)))))
            self.stats["pages"] += 1
        W0, H0 = sizes[0]
        master, mpage = self.ids(), self.ids()
        spreads = [(s, x.replace("%(master)s", master)) for s, x in spreads]
        files = {}
        files["MasterSpreads/MasterSpread_%s.xml" % master] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<idPkg:MasterSpread xmlns:idPkg="%s" DOMVersion="%s">'
            '<MasterSpread Self="%s" ItemTransform="1 0 0 1 0 0" '
            'OverriddenPageItemProps="" Name="A-Master" NamePrefix="A" '
            'BaseName="Master" ShowMasterItems="true" PageCount="1" '
            'PrimaryTextFrame="n"><Page Self="%s" Name="A" AppliedMaster="n" '
            'GeometricBounds="0 0 %s %s" ItemTransform="1 0 0 1 0 %s" '
            'MasterPageTransform="1 0 0 1 0 0" OverrideList="" TabOrder="" '
            'GridStartingPoint="TopOutside" UseMasterGrid="true">'
            '<MarginPreference ColumnCount="1" ColumnGutter="12" Top="0" '
            'Bottom="0" Left="0" Right="0" ColumnDirection="Horizontal" '
            'ColumnsPositions="0 %s"/></Page></MasterSpread>'
            '</idPkg:MasterSpread>' % (NS, DOM, master, mpage, _n(H0),
                                        _n(W0), _n(-H0 / 2.0), _n(W0)))
        for sid, xml in spreads:
            files["Spreads/Spread_%s.xml" % sid] = xml
        for sid, xml in self.stories:
            files["Stories/Story_%s.xml" % sid] = xml
        files["Resources/Graphic.xml"] = self._graphic()
        files["Resources/Fonts.xml"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<idPkg:Fonts xmlns:idPkg="%s" DOMVersion="%s"></idPkg:Fonts>'
            % (NS, DOM))
        files["Resources/Styles.xml"] = self._styles()
        files["Resources/Preferences.xml"] = self._preferences(W0, H0, n)
        files["META-INF/container.xml"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<container version="1.0" xmlns="urn:oasis:names:tc:opendocument'
            ':xmlns:container"><rootfiles><rootfile full-path="designmap.xml"'
            ' media-type="text/xml"></rootfile></rootfiles></container>')
        section = self.ids()
        design = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<?aid style="50" type="document" readerVersion="6.0" '
            'featureSet="257" product="%s(0)" ?>\n'
            '<Document xmlns:idPkg="%s" DOMVersion="%s" Self="d" '
            'StoryList="%s" ZeroPoint="0 0" ActiveLayer="%s" '
            'CMYKProfile="$ID/" RGBProfile="$ID/" '
            'SolidColorIntent="UseColorSettings" '
            'AfterBlendingIntent="UseColorSettings" '
            'DefaultImageIntent="UseColorSettings" RGBPolicy="ColorPolicyOff"'
            ' CMYKPolicy="ColorPolicyOff" AccurateLABSpots="false">'
            '<idPkg:Graphic src="Resources/Graphic.xml"/>'
            '<idPkg:Fonts src="Resources/Fonts.xml"/>'
            '<idPkg:Styles src="Resources/Styles.xml"/>'
            '<idPkg:Preferences src="Resources/Preferences.xml"/>'
            '<Layer Self="%s" Name="Report" Visible="true" Locked="false" '
            'IgnoreWrap="false" ShowGuides="true" LockGuides="false" '
            'UI="true" Expendable="true" Printable="true"><Properties>'
            '<LayerColor type="enumeration">LightBlue</LayerColor>'
            '</Properties></Layer>'
            '<idPkg:MasterSpread src="MasterSpreads/MasterSpread_%s.xml"/>'
            '%s'
            '<Section Self="%s" Length="%d" Name="" ContinueNumbering="true" '
            'IncludeSectionPrefix="false" Marker="" PageStart="%s" '
            'SectionPrefix=""><Properties><PageNumberStyle '
            'type="enumeration">Arabic</PageNumberStyle></Properties>'
            '</Section>%s</Document>' % (
                DOM, NS, DOM, " ".join(s for s, _x in self.stories),
                self.layer, self.layer, master,
                "".join('<idPkg:Spread src="Spreads/Spread_%s.xml"/>' % s
                        for s, _x in spreads),
                section, n, page_ids[0],
                "".join('<idPkg:Story src="Stories/Story_%s.xml"/>' % s
                        for s, _x in self.stories)))
        tmp = path + ".part"
        with zipfile.ZipFile(tmp, "w") as z:
            info = zipfile.ZipInfo("mimetype")
            info.compress_type = zipfile.ZIP_STORED
            z.writestr(info, "application/vnd.adobe.indesign-idml-package")
            z.writestr(zipfile.ZipInfo("designmap.xml"), design.encode(
                "utf-8"), zipfile.ZIP_DEFLATED)
            for name in ("META-INF/container.xml", "Resources/Graphic.xml",
                         "Resources/Fonts.xml", "Resources/Styles.xml",
                         "Resources/Preferences.xml"):
                z.writestr(name, files.pop(name).encode("utf-8"),
                           zipfile.ZIP_DEFLATED)
            for name in sorted(files):
                z.writestr(name, files[name].encode("utf-8"),
                           zipfile.ZIP_DEFLATED)
        try:
            os.replace(tmp, path)
        except OSError:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise OSError("non posso scrivere %s: il file è aperto in un "
                          "altro programma (InDesign?)" % path)
        out = dict(self.stats)
        out.update({"links": list(self.links), "links_dir": self.links_dir,
                    "warnings": list(self.warnings), "path": path})
        return out

    def _graphic(self):
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<idPkg:Graphic xmlns:idPkg="%s" DOMVersion="%s">\n\t'
            '<Color Self="Color/Black" Model="Process" Space="CMYK" '
            'ColorValue="0 0 0 100" ColorOverride="Specialblack" '
            'AlternateSpace="NoAlternateColor" AlternateColorValue="" '
            'Name="Black" ColorEditable="false" ColorRemovable="false" '
            'Visible="true" SwatchCreatorID="7937"/>\n\t'
            '<Color Self="Color/Paper" Model="Process" Space="CMYK" '
            'ColorValue="0 0 0 0" ColorOverride="Specialpaper" '
            'AlternateSpace="NoAlternateColor" AlternateColorValue="" '
            'Name="Paper" ColorEditable="true" ColorRemovable="false" '
            'Visible="true" SwatchCreatorID="7937"/>\n\t'
            '<Color Self="Color/Registration" Model="Registration" '
            'Space="CMYK" ColorValue="100 100 100 100" '
            'ColorOverride="Specialregistration" '
            'AlternateSpace="NoAlternateColor" AlternateColorValue="" '
            'Name="Registration" ColorEditable="false" '
            'ColorRemovable="false" Visible="true" SwatchCreatorID="7937"/>'
            '\n\t%s\n\t'
            '<Ink Self="Ink/$ID/Process Cyan" Name="$ID/Process Cyan" '
            'Angle="75" ConvertToProcess="false" Frequency="70" '
            'NeutralDensity="0.61" PrintInk="true" TrapOrder="1" '
            'InkType="Normal"/>\n\t'
            '<Ink Self="Ink/$ID/Process Magenta" Name="$ID/Process Magenta" '
            'Angle="15" ConvertToProcess="false" Frequency="70" '
            'NeutralDensity="0.76" PrintInk="true" TrapOrder="2" '
            'InkType="Normal"/>\n\t'
            '<Ink Self="Ink/$ID/Process Yellow" Name="$ID/Process Yellow" '
            'Angle="0" ConvertToProcess="false" Frequency="70" '
            'NeutralDensity="0.16" PrintInk="true" TrapOrder="3" '
            'InkType="Normal"/>\n\t'
            '<Ink Self="Ink/$ID/Process Black" Name="$ID/Process Black" '
            'Angle="45" ConvertToProcess="false" Frequency="70" '
            'NeutralDensity="1.7" PrintInk="true" TrapOrder="4" '
            'InkType="Normal"/>\n\t'
            '<Swatch Self="Swatch/None" Name="None" ColorEditable="false" '
            'ColorRemovable="false" Visible="true" SwatchCreatorID="7937"/>'
            '\n\t<StrokeStyle Self="StrokeStyle/$ID/Solid" Name="$ID/Solid"/>'
            '\n</idPkg:Graphic>' % (NS, DOM, self.colors.xml()))

    def _styles(self):
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<idPkg:Styles xmlns:idPkg="%s" DOMVersion="%s">\n\t'
            '<RootCharacterStyleGroup Self="%s"><CharacterStyle '
            'Self="CharacterStyle/$ID/[No character style]" Imported="false"'
            ' Name="$ID/[No character style]"/></RootCharacterStyleGroup>\n\t'
            '<RootParagraphStyleGroup Self="%s">\n\t\t<ParagraphStyle '
            'Self="ParagraphStyle/$ID/[No paragraph style]" Name="$ID/[No '
            'paragraph style]" Imported="false" FillColor="Color/Black" '
            'PointSize="12" FontStyle="Regular" Justification="LeftAlign" '
            'Hyphenation="false"><Properties><Leading type="enumeration">Auto'
            '</Leading><AppliedFont type="string">Arial</AppliedFont>'
            '</Properties></ParagraphStyle>\n\t\t<ParagraphStyle '
            'Self="ParagraphStyle/$ID/NormalParagraphStyle" '
            'Name="$ID/NormalParagraphStyle" Imported="false" '
            'NextStyle="ParagraphStyle/$ID/NormalParagraphStyle" '
            'KeyboardShortcut="0 0"><Properties><BasedOn type="string">'
            '$ID/[No paragraph style]</BasedOn><PreviewColor '
            'type="enumeration">Nothing</PreviewColor></Properties>'
            '</ParagraphStyle>\n\t\t%s\n\t</RootParagraphStyleGroup>\n\t'
            '<RootCellStyleGroup Self="%s"><CellStyle Self="CellStyle/$ID/'
            '[None]" Name="$ID/[None]"/></RootCellStyleGroup>\n\t'
            '<RootTableStyleGroup Self="%s"><TableStyle Self="TableStyle/$ID/'
            '[No table style]" Name="$ID/[No table style]"/><TableStyle '
            'Self="TableStyle/$ID/[Basic Table]" Name="$ID/[Basic Table]"/>'
            '</RootTableStyleGroup>\n\t'
            '<RootObjectStyleGroup Self="%s"><ObjectStyle '
            'Self="ObjectStyle/$ID/[None]" Name="$ID/[None]" '
            'FillColor="Swatch/None" StrokeColor="Swatch/None" '
            'StrokeWeight="0"/><ObjectStyle Self="ObjectStyle/$ID/[Normal '
            'Graphics Frame]" Name="$ID/[Normal Graphics Frame]"/>'
            '<ObjectStyle Self="ObjectStyle/$ID/[Normal Text Frame]" '
            'Name="$ID/[Normal Text Frame]"/></RootObjectStyleGroup>\n'
            '</idPkg:Styles>' % (NS, DOM, self.ids(), self.ids(),
                                 self.styles.xml(), self.ids(), self.ids(),
                                 self.ids()))

    def _preferences(self, W, H, n):
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<idPkg:Preferences xmlns:idPkg="%s" DOMVersion="%s">\n\t'
            '<DocumentPreference PageHeight="%s" PageWidth="%s" '
            'PagesPerDocument="%d" FacingPages="false" '
            'DocumentBleedTopOffset="0" DocumentBleedBottomOffset="0" '
            'DocumentBleedInsideOrLeftOffset="0" '
            'DocumentBleedOutsideOrRightOffset="0" '
            'DocumentBleedUniformSize="true" CreatePrimaryTextFrame="false" '
            'AllowPageShuffle="true" Intent="PrintIntent" '
            'PageBinding="LeftToRight" ColumnDirection="Horizontal" '
            'MasterTextFrame="false"/>\n\t'
            '<MarginPreference ColumnCount="1" ColumnGutter="12" Top="0" '
            'Bottom="0" Left="0" Right="0" ColumnDirection="Horizontal" '
            'ColumnsPositions="0 %s"/>\n\t'
            '<ViewPreference HorizontalMeasurementUnits="Millimeters" '
            'VerticalMeasurementUnits="Millimeters" '
            'RulerOrigin="PageOrigin"/>\n\t'
            # colori RGB del report come in QGIS anche dove c'è trasparenza
            # (le immagini PNG): spazio di fusione RGB, non CMYK
            '<TransparencyPreference BlendingSpace="RGB" '
            'GlobalLightAngle="120" GlobalLightAltitude="30"/>\n'
            '</idPkg:Preferences>' % (NS, DOM, _n(H), _n(W), n, _n(W)))


def export_idml(layout, path, dpi=300, progress=None):
    """Esporta il layout in IDML (vedi IdmlExporter.export)."""
    return IdmlExporter(layout, dpi, progress).export(path)


# ------------------------------------------------------- interfaccia QGIS
ACTION_NAME = "micExportIdml"
SETTINGS_KEY = "MIC-Utilities/idml_dir"


def export_with_progress(layout, path, parent=None, dpi=300):
    """export_idml con una barra di avanzamento (sul thread principale:
    rende gli oggetti del layout)."""
    from qgis.PyQt.QtWidgets import QApplication, QProgressDialog
    dlg = QProgressDialog("Esportazione per InDesign…", "", 0, 100, parent)
    dlg.setWindowTitle("MIC - Utilities")
    dlg.setCancelButton(None)
    dlg.setMinimumDuration(0)
    dlg.setWindowModality(Qt.WindowModal if parent is not None
                          else Qt.ApplicationModal)

    def prog(v):
        dlg.setValue(int(v))
        QApplication.processEvents()

    try:
        return export_idml(layout, path, dpi, prog)
    finally:
        dlg.close()
        dlg.deleteLater()


def ask_path(layout, parent=None):
    """Percorso del file IDML scelto dall'utente (None se annullato)."""
    from qgis.PyQt.QtWidgets import QFileDialog
    from qgis.core import QgsSettings
    st = QgsSettings()
    last = st.value(SETTINGS_KEY, "") or os.path.expanduser("~")
    safe = re.sub(r"[^\w\-]+", "_", layout.name() or "").strip("_") \
        or "layout"
    path, _f = QFileDialog.getSaveFileName(
        parent, "Esporta per InDesign (IDML)",
        os.path.join(last, safe + ".idml"), "InDesign IDML (*.idml)")
    if not path:
        return None
    if not path.lower().endswith(".idml"):
        path += ".idml"
    st.setValue(SETTINGS_KEY, os.path.dirname(path))
    return path


def summary(res):
    """Riepilogo di un'esportazione per i messaggi."""
    return ("%d pagine, %d testi, %d forme, %d immagini (cartella «Links» "
            "accanto al file)" % (res["pages"], res["texts"], res["shapes"],
                                  res["images"]))


def _designer_layout(designer):
    from qgis.core import QgsLayout, QgsPrintLayout
    lay = designer.masterLayout()
    if isinstance(lay, QgsPrintLayout):
        return lay
    lay = designer.layout()
    return lay if isinstance(lay, QgsLayout) else None


def designer_export(designer):
    """Comando del compositore: esporta il layout aperto in IDML."""
    bar = designer.messageBar()
    lay = _designer_layout(designer)
    if lay is None:
        bar.pushWarning("MIC - Utilities", "Nessun layout da esportare.")
        return None
    path = ask_path(lay, designer.window())
    if not path:
        return None
    try:
        res = export_with_progress(lay, path, designer.window())
    except Exception as exc:
        bar.pushCritical("MIC - Utilities",
                         "File per InDesign non creato: %s" % exc)
        return None
    bar.pushSuccess("MIC - Utilities", "Esportato per InDesign: %s → %s"
                    % (summary(res), path))
    return res


def add_designer_action(designer, icon_path=None):
    """Aggiunge «Esporta per InDesign (IDML)…» al menu Layout e alla barra
    del compositore, dopo «Esporta come PDF»."""
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import QAction
    win = designer.window()
    if win is None or win.findChild(QAction, ACTION_NAME) is not None:
        return None
    act = QAction(QIcon(icon_path) if icon_path else QIcon(),
                  "Esporta per InDesign (IDML)…", win)
    act.setObjectName(ACTION_NAME)
    act.setToolTip("Esporta il layout in IDML: InDesign lo apre come "
                   "documento modificabile (MIC - Utilities)")
    act.triggered.connect(lambda _c=False, d=designer: designer_export(d))
    for host in (designer.layoutMenu(), designer.layoutToolbar()):
        if host is None:
            continue
        acts = host.actions()
        before = None
        for i, a in enumerate(acts):
            if a.objectName() == "mActionExportAsPDF" and i + 1 < len(acts):
                before = acts[i + 1]
        if before is not None:
            host.insertAction(before, act)
        else:
            host.addAction(act)
    return act


def remove_designer_action(designer):
    from qgis.PyQt.QtWidgets import QAction
    win = designer.window()
    act = win.findChild(QAction, ACTION_NAME) if win is not None else None
    if act is None:
        return
    for host in (designer.layoutMenu(), designer.layoutToolbar()):
        if host is not None:
            host.removeAction(act)
    act.setParent(None)   # via subito dalla finestra, poi eliminata
