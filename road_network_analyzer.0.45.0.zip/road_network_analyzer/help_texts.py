# -*- coding: utf-8 -*-
"""Testi di aiuto per ogni scheda.

Obiettivo: spiegare con chiarezza il SIGNIFICATO delle operazioni spaziali che
ogni funzione esegue (aggancio alla rete, distanze di rete, buffer, ecc.), non
solo l'elenco dei campi.
"""

# Nota condivisa sull'aggancio alla rete (riusata in più schede).
_SNAP = ("""
<p><b>Come vengono misurate le distanze sulla rete</b>: ogni punto (origine,
fermata, destinazione) viene <i>proiettato sull'arco stradale più vicino</i>
entro 500 m (non sul vertice più vicino, ma sul punto esatto del segmento). Da
lì il percorso più breve si calcola con l'algoritmo di Dijkstra sul grafo della
rete. Se due punti cadono sullo stesso arco la distanza è quella diretta lungo
l'arco. Un punto a più di 500 m da qualsiasi strada non viene agganciato e non
produce risultati: avvicinalo o usa una rete più fitta.</p>
""")

_OSM = ("""
<p><b>🌐 Rete da OSM (vista)</b>: scarica al volo da OpenStreetMap la rete
stradale contenuta nell'inquadratura corrente della mappa e la imposta in questo
campo. La rete è <i>filtrata per modo</i>: a piedi esclude autostrade/superstrade
e include marciapiedi/sentieri; in auto esclude i percorsi pedonali/ciclabili;
in bici una via di mezzo. Comodo quando non hai già un layer di strade.</p>
""")

HELP_TEXTS = {
    "road": ("Rete stradale · aiuto", """
<h3>Analisi della rete stradale</h3>
<p>Misura le lunghezze per tipologia e conta gli <b>incroci reali</b>: i
vertici <b>condivisi</b> in cui si incontrano almeno tre bracci di strada. I
vertici che disegnano solo la forma della strada non contano, e due strade che
si attraversano senza vertice comune (ponte, sottopasso) non sono un
incrocio.</p>
<ul>
<li><b>Rete stradale</b>: layer di linee da analizzare.</li>
<li><b>Campo tipologia</b>: classifica le strade (es. <i>highway</i>). Lunghezze
e matrice incroci sono raggruppate per questo campo.</li>
<li><b>Area di progetto</b>: poligono (opzionale). Lunghezze, incroci e vicoli
ciechi vengono <b>ritagliati sull'area</b>, così le densità (km/km², n/km²) si
riferiscono alla stessa area; lunghezze ellissoidali (QgsDistanceArea).</li>
</ul>
<p><b>Matrice incroci</b>: la cella (A, B) conta gli incroci in cui si
incontrano strade di tipo A e B; la diagonale (A, A) quelli con almeno tre
bracci di tipo A (due strade di quel tipo). Un incrocio con più tipologie conta
in più celle, il totale degli incroci è nei Rapporti.</p>
<p><b>Rapporti</b>: incroci reali, vicoli ciechi, rapporto nodi connessi
(incroci / incroci + vicoli ciechi), densità. I punti dove due strade allo
<b>stesso livello</b> si attraversano senza vertice comune sono contati a parte
e mostrati in un layer: se sono incroci veri usa <i>Prepara rete</i>; se sono
ponti, tunnel o percorsi interni su piani diversi, il layer deve avere i campi
<i>bridge/tunnel/layer/level</i> (OSM) o <i>ponte/galleria/livello/piano</i>.</p>
""" + _OSM + """
<p>Output: tab Lunghezze, Matrice incroci, Rapporti (esportabili in CSV).
Il calcolo gira in background con barra e «Annulla».</p>
<h4>Walkability index</h4>
<p>Indice 0-100 per <b>zona</b> (poligoni) o <b>griglia</b> automatica, da fino a
tre dimensioni (mediate):</p>
<ul>
<li><b>Design</b> (sempre): densità di incroci, densità stradale, link/nodi,
connettività media, calcolati sul grafo degli incroci reali (nodi = incroci e
vicoli ciechi, link = tratti tra due nodi): non dipendono da quanti vertici o
feature disegnano le strade.</li>
<li><b>Destinazioni</b> (se dai un layer <b>POI</b>): amenità raggiungibili a
piedi con decadimento della distanza, <i>in linea d'aria</i> o <b>su rete</b>
(Dijkstra, opzione «Destinazioni su rete»); con un <i>campo categoria</i> premia
la diversità di servizi (il più vicino per categoria), senza categoria somma
tutti i POI raggiungibili, in entrambe le modalità.</li>
<li><b>Pendenza</b> (se dai un <b>DEM</b>): grado medio delle strade; più ripido
= meno camminabile.</li>
<li><b>Attraversamenti</b> (se dai un layer di punti o usi «🌐 Attraversamenti
da OSM»): densità di attraversamenti pedonali per zona.</li>
</ul>
<p>Output: campi <i>walkability, design, destinazioni, pendenza, attraversam</i>
+ indicatori grezzi. Indice relativo (serve più di una zona). Raffinabile.</p>
<p><i>Pulizia rete:</i> tutte le analisi su rete stradale (isocrone,
accessibilità, PTAL su rete, space syntax, walkability) eseguono uno snap dei
vertici vicini e rimuovono segmenti nulli/duplicati per preparare il grafo.</p>
<h4>Preparazione & diagnostica rete</h4>
<ul>
<li><b>🔧 Prepara rete (noding)</b>: spezza le linee dove si incrociano senza un
vertice condiviso. <b>Indispensabile</b> se la rete non è già "noded": altrimenti
due strade che si incrociano restano scollegate nel grafo e isocrone/
accessibilità/PTAL risultano sottostimati. <b>Ponti e tunnel</b>: se il layer ha
i campi <i>bridge/tunnel/layer/level</i> (le reti scaricate con «Rete da OSM»
li hanno) o <i>ponte/galleria/livello/piano</i>, si collegano solo le strade
allo stesso livello: un cavalcavia non viene unito alla strada sotto, né un
corridoio interno a quello del piano di sopra. Ogni strada è divisa
<b>solo agli incroci</b> e conserva <b>tutti i suoi attributi</b> (più
<i>oneway</i> nel verso del tratto, <i>src_fid</i> e <i>mic_prepared</i>). La
<i>lunghezza minima</i> evita schegge: un taglio più vicino di così a un
vertice esistente si aggancia a quel vertice. Apre una <b>procedura guidata</b>
in 3 passi: (1) <i>diagnosi iniziale</i> (segmenti, componenti, incroci non
noded); (2) <i>opzioni</i> (tolleranza snap, lunghezza minima, noding); (3)
<i>anteprima</i> con il numero di split e il miglioramento delle componenti
connesse, prima di applicare. Al termine imposta la rete preparata come rete
stradale corrente.</li>
<li><b>🩺 Diagnostica rete</b>: segnala componenti scollegate, % nella componente
principale, sorgenti non agganciate o isolate, e <b>incroci non noded</b> (a X e
a T, solo tra strade allo stesso livello). Crea
layer diagnostici (componenti colorate, incroci, sorgenti isolate). Utile quando
un'analisi dà risultati nulli o strani.</li>
</ul>
"""),
    "gtfs": ("GTFS · aiuto", """
<h3>Caricamento GTFS e map-matching</h3>
<p>Il feed caricato qui è la <b>sorgente GTFS condivisa</b>: le schede PTAL,
Isochrones, Accessibilità e OD lo riusano senza doverlo reinserire.</p>
<ul>
<li><b>Percorso feed</b>: file .zip o cartella GTFS (anche con i file in una
sottocartella dello zip e con testi in codifica Latin-1/Windows).</li>
<li><b>Linea</b> + <i>Leggi linee</i>: per feed grandi scegli una sola linea
(caricamento leggero). «Tutte le linee» carica l'intero giorno di servizio
(Roma: circa 30 s e 0,7 GB di memoria).</li>
<li><b>Data servizio</b> (YYYYMMDD, opz.): seleziona i servizi attivi quel giorno
da <i>calendar.txt</i>/<i>calendar_dates.txt</i>; vuoto = il giorno più carico
del calendario (tutti i servizi attivi quel giorno). Vale per il caricamento
GTFS, PTAL, isocrone TP, accessibilità TP e matrice OD; il messaggio finale dice
quale giorno è stato usato.</li>
<li><b>Valida feed</b>: file richiesti, periodo di validità (anche con il solo
calendar_dates.txt), giorno più carico, riferimenti fra tabelle (corse senza
linea o senza calendario, orari con fermate inesistenti), fermate senza
coordinate, orari mancanti, fuso orario e codifica dei testi.</li>
<li><b>Carica GTFS</b>: ricostruisce le geometrie delle linee dalle <i>shapes</i>
(senza shapes.txt, dalla sequenza delle fermate) e aggiorna i layer <i>GTFS -
Linee</i> e <i>GTFS - Metriche linee</i>. Le linee caricate dallo <b>stesso feed
e per lo stesso giorno</b> si sommano: segmenti, logging RT, Excel e
map-matching le usano tutte. Cambiando feed o giorno si riparte da zero (e il
logging in corso si ferma).</li>
<li><b>Crea layer segmenti</b>: geometrie stop-to-stop con velocità programmate.
I segmenti seguono la <i>shape</i> anche quando stop_times non ha
<i>shape_dist_traveled</i> (le fermate vengono proiettate sulla shape). Gli
orari mancanti (fermate non timepoint) e le coppie a tempo zero degli orari al
minuto vengono ricostruiti per distanza fra gli orari noti della corsa.</li>
</ul>
<h4>Map-matching su rete (operazione spaziale)</h4>
<p>Campiona punti lungo le strade (lontano dagli estremi) e <i>aggancia</i> ad
ogni tratto stradale i segmenti GTFS vicini, entro la <b>tolleranza</b> e con
direzione simile (entro l'<b>angolo</b>); il <b>passo</b> è la spaziatura di
campionamento. Una strada è abbinata solo se almeno la <b>copertura minima</b>
dei campioni sta lungo la linea, così le vie che la toccano solo in un incrocio
non prendono la velocità del bus. Sulle strade a <i>senso unico</i> (campo
oneway) conta il verso: le due carreggiate di un viale restano separate. Con un
campo <i>highway</i> (OSM) si escludono marciapiedi, ciclabili, scale e
banchine. Il calcolo è in metri reali (UTM se la rete è geografica o in Web
Mercator). Output: le strade con velocità programmata/effettiva, linee e
<i>copertura</i>.</p>
"""),
    "gtfs_live": ("GTFS live · aiuto", """
<h3>Confronto con il GTFS realtime</h3>
<p>Operazione: confronta la velocità <i>programmata</i> di ogni segmento
stop-to-stop con quella <i>osservata</i> ricavata dai TripUpdates in tempo reale.</p>
<ul>
<li><b>URL feed TripUpdates</b>: endpoint protobuf GTFS-RT.</li>
<li><b>Intervallo</b>: ogni quanti secondi interrogare il feed.</li>
<li><b>Avvia / Ferma logging</b>: raccolta continua delle osservazioni.</li>
<li><b>Scansione programmata</b>: imposta ora di inizio e durata; la raccolta
parte da sola e si ferma dopo la durata (utile per una fascia oraria).</li>
<li><b>Top N</b> + <i>Evidenzia divari</i>: colora i segmenti per scarto
osservato vs teorico e seleziona i N con il divario maggiore.</li>
<li><b>Esporta Excel</b>: report con curve della velocità di esercizio per linea
per ora di partenza della corsa.</li>
</ul>
<p><b>Come si conta un'osservazione.</b> Per ogni corsa si prendono le coppie
di fermate <i>consecutive nell'orario statico</i> (anche se stop_sequence salta
10, 20, 30… e anche senza stop_id). Valgono gli orari dichiarati o, se c'è solo
il ritardo, orario programmato + ritardo. Le fermate SKIPPED/NO_DATA e le corse
cancellate non contano. I TripUpdates sono <b>previsioni</b>: una coppia diventa
osservazione solo quando, secondo l'ultimo feed, la fermata d'arrivo è già
passata (il messaggio mostra le previsioni in attesa). Lo scarto è rispetto al
<b>programmato delle stesse corse</b> (campo <i>v_sched_obs</i>), confrontando
come con come (partenza→arrivo o arrivo→arrivo). Dopo 30 minuti le osservazioni
vengono riassunte: la memoria non cresce con la durata del logging.</p>
"""),
    "lines2gtfs": ("Da linee a GTFS · aiuto", """
<h3>Genera un GTFS da linee e fermate</h3>
<p>Operazione spaziale: <i>aggancia</i> le fermate alle linee (entro la
tolleranza), le <b>ordina lungo la linea</b> (posizione progressiva calcolata in
metri), e deriva i tempi di percorrenza da distanza/velocità.</p>
<ul>
<li><b>Linee (rotte)</b>: layer lineare; ogni feature è una rotta.</li>
<li><b>Fermate</b>: layer puntuale agganciato alle linee e ordinato.</li>
<li><b>Tipo / Velocità / Frequenza / Orario / Sosta</b>: parametri del servizio.</li>
<li><b>Tolleranza fermate</b>: distanza massima fermata-linea per l'aggancio.</li>
<li><b>Direzioni</b>: andata (verso di disegno) e ritorno (verso opposto), o
solo andata.</li>
<li><b>Fermate</b>: lato delle fermate rispetto al verso di marcia. Le fermate
ai due lati della strada vanno ciascuna alla sua direzione; quelle sulla linea
(entro 2 m) servono entrambe; se sono disegnate su un solo lato servono
entrambe le direzioni.</li>
<li><b>Fuso orario / Validità / Giorni</b>: scritti in agency.txt e
calendar.txt.</li>
</ul>
<p>Output: un feed GTFS .zip, impostato anche come sorgente nella scheda GTFS.
La generazione gira in background con barra e «Annulla».</p>
"""),
    "isochrones": ("Isochrones · aiuto", """
<h3>Isocrone su rete stradale</h3>
<p>Operazione spaziale: dalla sorgente si percorre la rete con Dijkstra fino al
budget di tempo di ogni fascia (distanza = velocità × tempo); l'insieme dei
tratti raggiunti definisce l'area servita.</p>
<ul>
<li><b>Sorgenti</b>: layer di punti, oppure <i>Scegli punti sulla mappa</i>,
oppure <i>Usa fermate GTFS caricate</i>.</li>
<li><b>Rete stradale</b>: layer di linee su cui si calcolano i percorsi.</li>
<li><b>Mezzo / Velocità</b> e <b>Tempi (min)</b> (es. 5,10,15): definiscono le
fasce. La legenda mostra «5 min / 10 min / 15 min».</li>
<li><b>Modalità output</b>:
  <i>Concavo</i> = buffer dei tratti raggiunti (segue le strade, include gli
  edifici vicini, esclude le aree senza accesso);
  <i>Poligono</i> = area che segue la rete: i tratti raggiunti allargati di
  80 m e poi ristretti, così gli isolati fra strade raggiunte sono pieni e le
  zone senza strade raggiunte (ferrovie, parchi chiusi, fiumi) restano fuori;
  buchi interni sotto 4 ha riempiti. Con più sorgenti le aree restano
  separate se non si toccano;
  <i>Lineare</i> = i soli tratti stradali raggiunti.</li>
<li><b>Dissolvi</b>: unisce le sorgenti in un'unica isocrona per fascia.</li>
<li><b>Avanzate · Allargamento</b>: larghezza del buffer attorno alla rete
(modalità concavo/poligono).</li>
<li><b>Rispetta i sensi unici</b>: se la rete ha un campo <i>oneway</i>
(1 = avanti, -1 = indietro, 0 = doppio senso) il routing diventa orientato
(utile in auto). La rete da OSM porta già questo campo; rotatorie e autostrade
OSM sono a senso unico anche senza. Scegliendo «Auto» si attiva da solo.</li>
<li><b>Auto · velocità di ogni strada</b> (solo in auto, attiva di default):
ogni strada si percorre alla sua velocità, come nel percorso più veloce:
<i>campo velocità</i> se indicato, altrimenti limite OSM <i>maxspeed</i>,
altrimenti un valore tipico del tipo di strada (residenziale 30, principale
50, autostrada 130…); la <i>Velocità</i> sopra vale per le strade di tipo
sconosciuto. <i>Velocità effettiva</i>: quota del limite a cui si viaggia
davvero (in città spesso 60–70 %). Marciapiedi, sentieri e scale sono esclusi.
Le fasce sono in tempo vero: le strade veloci allungano l'isocrona.</li>
<li><b>A piedi · pendenza dal DEM</b> (opz.): un raster di quote in metri, in
qualsiasi sistema di riferimento. La velocità segue la pendenza (funzione di
Tobler): la <i>Velocità</i> è quella in piano; in salita al 10 % si va al 70 %,
al 20 % a metà; in leggera discesa un po' più veloci. Ogni tratto ha un
tempo per verso, quindi l'isocrona si allunga verso valle. Ponti e gallerie
seguono la pendenza fra i loro estremi, non il terreno. Le mappe di sfondo
(XYZ/WMS) non compaiono fra i DEM. Se parte della rete è fuori dal DEM il
messaggio lo segnala (lì pendenza zero).</li>
<li><b>POI/popolazione (opz.)</b>: un layer di punti (con campo peso opzionale, es.
popolazione): a fine calcolo conta quante opportunità cadono in ogni isocrona e
aggiunge i campi <i>n_poi</i> e <i>peso_poi</i> (solo per output poligonali).</li>
<li><b>Modalità interattiva</b>: con una rete selezionata (modo rete), ogni click
sulla mappa ricalcola l'isocrona aggiornando un unico layer «MIC - Isocrona
interattiva»; avvisa se il punto non aggancia la rete o è su una componente
isolata. Il calcolo è in background: un nuovo click annulla quello in corso.</li>
<li><b>Barra di avanzamento</b>: durante il calcolo mostra la fase (lettura
della rete, percorsi, costruzione poligoni…) e la percentuale; <i>Annulla</i>
interrompe il calcolo. QGIS resta utilizzabile nel frattempo. Su reti grandi
in auto (tutta la rete raggiunta) la costruzione dei poligoni può richiedere
decine di secondi.</li>
<li><b>Sistemi di riferimento</b>: sorgenti e rete possono avere CRS diversi
(vengono riproiettati automaticamente), purché il CRS assegnato a ogni layer
sia corretto.</li>
</ul>
<p><b>Trasporto pubblico (GTFS)</b> come mezzo: la raggiungibilità si calcola con
il Connection Scan Algorithm (orari reali del feed, anche da
<i>frequencies.txt</i>). Sono configurabili il modo di <b>accesso</b>
(sorgente→fermata) e di <b>egress</b> (fermata→destinazione), a piedi o in bici,
più una <b>penalità di trasferimento</b> (minuti per ogni cambio di mezzo, anche
alla stessa fermata).</p>
<ul>
<li><b>Partenza / Finestra di partenza</b>: con una finestra (es. 30 min) il
calcolo si ripete ogni 5 minuti e per ogni fermata usa il tempo di viaggio
<i>mediano</i>: il risultato non dipende dal minuto esatto di partenza. 0 = una
sola partenza.</li>
<li><b>Rete stradale</b> (opzionale): accesso alle fermate ed egress seguono le
strade invece della linea d'aria.</li>
<li>Dalle fermate si prosegue al massimo per il raggio di egress (800 m a piedi,
3 km in bici); attorno all'origine c'è anche lo spostamento diretto.</li>
<li><b>Dividi per linea</b>: un'isocrona per ogni linea che serve il punto (con
una partenza nella finestra da una fermata raggiungibile a piedi), calcolata
usando solo quella linea, senza cambi. Il layer ha il campo <i>linea</i> e una
legenda per linea.</li>
</ul>
""" + _SNAP + _OSM),
    "ptal": ("PTAL · aiuto", """
<h3>PTAL · Public Transport Accessibility Level (TfL)</h3>
<p>Operazione spaziale: per ogni punto si cercano le fermate raggiungibili a
piedi entro la soglia di cammino del modo; con una rete pedonale le distanze
sono <i>di rete</i> (Dijkstra), altrimenti in linea d'aria.</p>
<p><b>Servizio senza GTFS</b>: con «Dati forniti» il PTAL usa un layer di
fermate al posto del feed. Ogni punto è una linea che serve una fermata nella
fascia di analisi, con il campo <i>corse/ora</i>; facoltativi il campo
<i>linea</i> (una linea alla stessa fermata conta una volta; senza, ogni
fermata conta come una linea diversa e il PTAL può risultare più alto), il
campo
<i>modo</i> (bus, tram, metro, treno, traghetto o il route_type GTFS: decide
soglia di cammino e affidabilità) e il <i>codice fermata</i>. Più linee alla
stessa fermata = più punti nella stessa posizione (entro 5 m) o con lo stesso
codice. Utile per scenari di progetto o reti senza GTFS.</p>
<ul>
<li><b>GTFS</b>: di default il feed caricato nella scheda GTFS (frequenze per
fermata e rotta).</li>
<li><b>Modalità</b>: <i>PTAL (TfL standard)</i> = distanza <b>in linea d'aria</b>
(metodo ufficiale TfL, default); <i>PTAL su rete pedonale</i> = distanza a piedi
<b>di rete</b> (Dijkstra), più realistica ma <b>non-standard</b> — richiede una
rete pedonale (anche via «Rete da OSM»).</li>
<li><b>Punti di analisi</b> o <b>griglia</b> (esagoni/quadrati) da valutare.</li>
<li><b>Fascia oraria</b>: orari su cui calcolare le frequenze; il metodo TfL
usa l'ora di punta 08:15–09:15 (predefinita).</li>
<li><b>Profili orari AM/interpeak/PM</b>: calcola PTAL per le tre fasce standard
(08:15-09:15 / 10-16 / 16-19) e aggiunge i campi <i>ai_am, ptal_am, ai_ip, ...</i>;
lo stile usa la fascia AM come primaria.</li>
</ul>
<h4>Calcolo (per ogni punto)</h4>
<p>Tempo di accesso a una linea = cammino fino alla fermata + attesa (30/frequenza)
+ <b>affidabilità</b>; EDF = 30/accesso. Ogni linea conta una volta sola, alla
fermata dove ha l'EDF più alto; per ogni modo (bus, tram, metro, treno) la linea
migliore pesa 1 e le altre 0,5; la somma sui modi è l'Accessibility Index, mappato
sulle fasce PTAL 0..6b (tutte in legenda).</p>
<h4>Avanzate · aree di influenza</h4>
<p>Per ogni modo (bus/tram/metro/treno) puoi cambiare <b>soglia di cammino</b>
(TfL: 640 m bus/tram, 960 m rail) e <b>affidabilità</b> (minuti di margine).</p>
<h4>Gap analysis</h4>
<p>Incrocia il PTAL a celle con la popolazione: gap = popolazione × (8 − livello
PTAL)/8 → evidenzia dove c'è molta gente con poca accessibilità. Ogni
centroide di popolazione va in una sola cella, anche se cade sul bordo.</p>
""" + _SNAP),
    "spacesyntax": ("Space syntax · aiuto", """
<h3>Space syntax sul grafo stradale</h3>
<p>Operazione: la rete viene divisa in <b>segmenti</b>, i tratti di strada tra
due incroci reali (vertici condivisi da almeno tre bracci) o tra un incrocio e
un vicolo cieco. Ogni segmento è un nodo, collegato ai segmenti che
condividono un incrocio. Il risultato <b>non dipende da come è disegnata la
rete</b>: una via in una sola feature o spezzata in dieci dà gli stessi
segmenti, e una strada che attraversa un incrocio viene comunque divisa lì.
Strade che si attraversano senza vertice comune (ponti, o rete non noded) non
sono collegate: in caso di dubbio usa prima <i>Prepara rete</i>.</p>
<ul>
<li><b>Connettività</b>: numero di segmenti connessi a ciascun segmento.</li>
<li><b>Profondità media/totale</b>: distanza topologica (numero di passi) dagli
altri tratti.</li>
<li><b>Integrazione (HH)</b>: centralità/accessibilità del tratto (inverso di
RRA, normalizzazione Hillier-Hanson).</li>
<li><b>Choice (betweenness)</b>: quanti percorsi più brevi attraversano il tratto
(potenziale di attraversamento, algoritmo di Brandes).</li>
<li><b>NAIN / NACH</b>: integrazione e choice normalizzate (Hillier, Yang,
Turner 2012) per confrontare reti di dimensioni diverse.</li>
<li><b>Raggio</b>: R0 = globale (Rn), un valore = analisi locale entro quel
numero di passi topologici (molto più veloce su reti grandi).</li>
</ul>
<p>Output: un tratto per segmento con gli attributi della strada d'origine
(quella che copre la maggior parte del segmento), i campi calcolati,
<i>lunghezza_m</i>, <i>n_feature</i> (feature d'origine unite) e
<i>src_fid</i>; stile per integrazione. Il calcolo gira in background e si può
annullare.</p>
"""),
    "routing": ("Percorsi · aiuto", """
<h3>Percorso più breve e più veloce</h3>
<p>Calcola il percorso su rete fra due o più punti: <b>in sequenza</b>
(1 → 2 → 3 …, utile per un giro con tappe) o fra <b>tutte le coppie</b> (in
entrambi i versi: con i sensi unici andata e ritorno possono differire).
Ogni punto si aggancia al punto più vicino della strada (entro 500 m) e il
percorso parte e arriva lì. Se i due punti stanno su pezzi di rete
scollegati, chi è fuori dalla rete principale si aggancia ad essa.</p>
<ul>
<li><b>Più breve</b>: distanza minima sulla rete così com'è (anche pedonale);
il tempo sui tratti solo pedonali è a passo d'uomo (4,5 km/h).</li>
<li><b>Più veloce</b>: tempo minimo in auto. La velocità di ogni strada è, in
ordine: il <i>campo velocità</i> indicato, il limite OSM <i>maxspeed</i> (anche
«IT:urban» = 50, «IT:rural» = 90, «mph», «knots»), un valore tipico per tipo
di strada
(<i>highway</i>: residenziale 30, principale 50, autostrada 130…), la velocità
di default. La <i>velocità effettiva</i> la riduce (es. 70 % per il traffico).
Marciapiedi, sentieri, ciclabili e scale sono esclusi.</li>
<li><b>Punti</b>: un layer (ordinato con il <i>campo ordine</i>, altrimenti
nell'ordine delle feature) oppure i clic sulla mappa, che hanno la
precedenza.</li>
<li><b>Sensi unici</b>: dal campo <i>oneway</i> (yes/no/-1 o 1/0/-1); rotatorie
e autostrade OSM sono a senso unico anche senza il campo.</li>
</ul>
""" + _OSM + """
<p>Output: un percorso per coppia con <i>lunghezza_m</i>, <i>tempo_min</i>,
<i>vel_kmh</i> (con il più breve il tempo è stimato con le stesse velocità,
a piedi sui tratti pedonali);
le coppie senza percorso hanno l'esito con il motivo. Anche in Processing:
<i>mic:shortestpath</i>.</p>
"""),
    "access": ("Accessibilità · aiuto", """
<h3>Accessibilità cumulativa alle opportunità</h3>
<p>Operazione spaziale: per ogni origine conta quante destinazioni (o quanto
peso) sono raggiungibili entro ciascuna soglia di tempo.</p>
<ul>
<li><b>Origini</b>: punti (o griglia) da valutare.</li>
<li><b>Destinazioni</b>: punti/poligoni (POI, popolazione, posti di lavoro). Con
<b>Campo peso</b> si sommano i pesi, altrimenti si contano.</li>
<li><b>Modo</b>: a piedi/bici/auto sulla <b>rete</b> (Dijkstra), oppure
<b>Trasporto pubblico</b> via GTFS (Connection Scan). In TP si scelgono accesso/
egress a piedi o in bici e una penalità di trasferimento (opzioni multimodali).</li>
<li><b>Tempi (min)</b>: una colonna <i>acc_Xmin</i> per ogni soglia.</li>
<li><b>Rispetta i sensi unici</b>: per i modi su strada, usa il campo
<i>oneway</i> della rete per un routing orientato (con i sensi unici impliciti
OSM di rotatorie e autostrade).</li>
</ul>
<h4>Metriche di sintesi & equità</h4>
<p>Su un layer di accessibilità/PTAL (campo valore) eventualmente pesato per la
popolazione: <b>media/mediana pesate</b>, <b>% «servita»</b> (quota di peso con
valore ≥ soglia), <b>indice di Gini</b> e <b>curva di Lorenz</b>
dell'accessibilità (grafico a video o export Excel). Gini 0 = perfetta
uguaglianza, valori alti = forte disuguaglianza.</p>
<h4>Confronto scenari (B − A)</h4>
<p>Differenza tra due layer di risultati con la stessa geometria (es. PTAL prima/
dopo una modifica al servizio): produce un layer <i>delta = B − A</i> con stile
divergente (rosso = peggioramento, blu = miglioramento).</p>
<h4>Scenario A/B — confronto fra due reti</h4>
<p>Confronta due reti stradali (A = attuale, B = progetto: nuova strada,
passerella, strada chiusa) usando Origini/Destinazioni/Modo/Tempi della sezione
Accessibilità. Due tipi di confronto:</p>
<ul>
<li><b>Accessibilità (origini → destinazioni)</b>: calcola l'accessibilità
cumulativa sulle stesse origini con le due reti e produce il delta per origine
(classe gain/loss/unchanged) con sintesi delle origini migliorate/peggiorate.</li>
<li><b>Isocrone (differenza geometrica)</b>: calcola l'<i>area raggiungibile</i>
(isocrona su rete, modo concavo) dalle origini alla soglia massima dei Tempi su
entrambe le reti e ne fa la <b>differenza geometrica</b>: poligoni
<i>guadagno</i> (B−A, area raggiungibile solo nel progetto), <i>perdita</i>
(A−B) e <i>comune</i> (A∩B), con aree in ettari. Il calcolo gira in background
(la barra di stato mostra l'avanzamento); con molte origini l'unione delle aree
può richiedere un po': per scenari puntuali usa <b>poche sorgenti</b>.</li>
</ul>
""" + _SNAP + _OSM),
    "od": ("OD · aiuto", """
<h3>Origine-Destinazione</h3>
<p>Operazione spaziale: traccia <b>desire lines</b> tra i centroidi delle zone,
con spessore proporzionale al flusso; in alternativa calcola la matrice dei
<b>tempi di viaggio</b> zona-zona via trasporto pubblico.</p>
<ul>
<li><b>Zone</b>: punti o poligoni con un identificativo (per i poligoni si usa il
centroide).</li>
<li><b>Campo ID zona</b>: deve corrispondere agli id nella matrice OD.</li>
<li><b>Matrice OD (CSV)</b>: colonne origine, destinazione, valore.</li>
<li><b>Filtri</b>: flusso minimo, top N, singola origine/destinazione.</li>
<li><b>Linee arcuate</b>: traccia le desire lines come archi (Bézier) anziché
rette; la curva piega sempre dallo stesso lato, così andata e ritorno fra due
zone non si sovrappongono e i flussi sovrapposti restano leggibili.</li>
</ul>
<h4>Matrice tempi e distanze su strada (Excel)</h4>
<p>Tempo e distanza sulla rete fra ogni <b>origine</b> e ogni
<b>destinazione</b> (vuoto = le origini stesse), lungo il percorso più
veloce; la distanza è la lunghezza di quel percorso.</p>
<ul>
<li><b>Origini / Destinazioni</b>: punti o poligoni (centroide), con un
<i>campo ID</i> (vuoto = numero della feature).</li>
<li><b>Mezzo</b>: piedi o bici a velocità unica (a piedi anche con la
<i>pendenza dal DEM</i>: andata e ritorno possono differire), oppure auto con
il <i>limite di ogni strada</i> (campo, maxspeed OSM o tipo di strada) e la
velocità effettiva; in auto i sensi unici sono attivi.</li>
<li><b>Tempo massimo</b> (opz.): oltre, la coppia è «non raggiungibile» e il
calcolo è più rapido.</li>
<li>Il pulsante chiede dove salvare l'<b>Excel</b>: fogli <i>Tempi (min)</i>
e <i>Distanze (km)</i> (matrici colorate), <i>Coppie</i> (anche velocità
media) e <i>Parametri</i> (mezzo, rete, punti fuori rete o agganciati alla rete
principale). Facoltative le <b>linee</b> origine → destinazione sulla mappa,
colorate per tempo (fino a 20 000 coppie).</li>
<li>I punti si agganciano alla strada più vicina entro 500 m; chi è vicino
solo a un pezzo di rete isolato si aggancia alla rete principale.</li>
</ul>
<p>Molte coppie senza percorso in auto di solito sono sensi unici che escono
dalla rete scaricata: allarga la rete. Anche in Processing:
<i>mic:roadodmatrix</i>.</p>
""" + _OSM + """
<h4>Matrice tempi via trasporto pubblico</h4>
<p>Per ogni coppia di zone calcola il tempo minimo di viaggio in trasporto
pubblico (Connection Scan) entro il budget; di default usa il GTFS caricato.</p>
"""),
    "fifteen": ("Città 15 minuti · aiuto", """
<h3>Città dei 15 minuti</h3>
<p>Per ogni zona o cella misura, lungo la rete, il tempo fino al servizio più
vicino di ogni categoria (alimentari, scuole, salute, parchi…) e calcola
l'<b>indice</b>: la quota di categorie raggiunte entro la soglia (100 = tutte
entro 15 minuti a piedi).</p>
<ul>
<li><b>Servizi</b>: un layer di punti o poligoni con un <i>campo
categoria</i>, oppure <b>🌐 Servizi da OSM (vista)</b>, che scarica
dall'inquadratura 9 categorie: alimentari, scuole e nidi, salute, parchi e
gioco, sport, trasporto pubblico, cultura e socialità, bar e ristoranti,
uffici e servizi (campo <i>categoria</i>). Puoi togliere dal layer le
categorie che non ti interessano.</li>
<li><b>Zone o punti</b> (opz.): sezioni di censimento, quartieri, edifici…
(il risultato è una copia con i campi aggiunti). Vuoto = <b>griglia
esagonale</b> sulla rete, o solo dentro l'<i>Area della griglia</i>;
<i>Cella</i> = raggio dell'esagono.</li>
<li><b>Mezzo</b>: piedi (anche con la pendenza da un DEM) o bici;
<b>Soglia</b>: 15 minuti di default.</li>
<li><b>Popolazione delle zone</b> (opz.): il messaggio riporta la quota di
popolazione con tutti i servizi.</li>
</ul>
<p>Campi: <i>t_&lt;categoria&gt;</i> (minuti al più vicino; vuoto se oltre il
doppio della soglia), <i>n_servizi</i>, <i>indice</i> (0–100, legenda dal
rosso al verde), <i>t_tutti</i> (minuti per averle tutte) e <i>mancanti</i>.
Il messaggio indica la categoria che manca più spesso. Zone a più di 500 m
dalla rete: indice 0.</p>
<p>Il calcolo fa un percorso a ritroso per categoria da tutti i servizi, non
uno per zona: anche migliaia di celle restano rapide. Anche in Processing:
<i>mic:fifteenminutes</i>.</p>
""" + _SNAP + _OSM),
}
