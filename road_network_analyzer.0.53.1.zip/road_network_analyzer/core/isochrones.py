# -*- coding: utf-8 -*-
"""Isocrone: geometrie e layer.

Dai tratti di rete raggiunti (net_iso) costruisce le aree per fascia di tempo
in modalita' concava (buffer dei tratti), poligono (inviluppo convesso) o
lineare; inoltre bacini del trasporto pubblico (cerchi attorno alle fermate
raggiunte) e scenario A/B.
"""
from ..i18n import tr
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsSymbol,
    QgsVectorLayer,
    QgsWkbTypes,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


def _utm_crs_for(lon, lat):
    zone = int((lon + 180) / 6) + 1
    epsg = (32600 if lat >= 0 else 32700) + zone
    return QgsCoordinateReferenceSystem.fromEpsgId(epsg)


class MetricFrame(object):
    """Da WGS84 a metri e ritorno per i buffer delle isocrone.

    Di solito la zona UTM. Prima la si prova su un punto: se la
    trasformazione non avviene davvero (CRS o PROJ non utilizzabili:
    QgsGeometry.transform allora lascia le coordinate in gradi senza dare
    errore, e un buffer di 30 «metri» diventa di 30 gradi, l'«uovo» grande
    come l'Europa) si usa una proiezione locale affine calcolata qui
    (equirettangolare attorno al centro: errore sotto lo 0,1 % entro qualche
    decina di km)."""

    def __init__(self, lon0, lat0, transform_context=None):
        self.lon0, self.lat0 = float(lon0), float(lat0)
        self.affine = None
        self.to_utm = self.to_wgs = None
        try:
            utm = _utm_crs_for(self.lon0, self.lat0)
            if utm.isValid():
                self.to_utm = QgsCoordinateTransform(WGS84, utm,
                                                     transform_context)
                self.to_wgs = QgsCoordinateTransform(utm, WGS84,
                                                     transform_context)
        except Exception:
            self.to_utm = None
        if not self._utm_works():
            self._use_affine()

    def _utm_works(self):
        if self.to_utm is None or not self.to_utm.isValid():
            return False
        try:
            g = QgsGeometry.fromPointXY(QgsPointXY(self.lon0, self.lat0))
            if g.transform(self.to_utm) != 0:
                return False
            p = g.asPoint()
            if abs(p.x()) <= 180.0 and abs(p.y()) <= 90.0:
                return False        # rimasto in gradi: non trasformato
            if g.transform(self.to_wgs) != 0:
                return False
            q = g.asPoint()
            return abs(q.x() - self.lon0) < 1e-6 and \
                abs(q.y() - self.lat0) < 1e-6
        except Exception:
            return False

    def _use_affine(self):
        import math
        from qgis.PyQt.QtGui import QTransform
        phi = math.radians(self.lat0)
        ky = 111132.954 - 559.822 * math.cos(2 * phi) + \
            1.175 * math.cos(4 * phi)
        kx = max(1.0, 111412.84 * math.cos(phi) - 93.5 * math.cos(3 * phi))
        fwd = QTransform(kx, 0.0, 0.0, ky, -self.lon0 * kx,
                         -self.lat0 * ky)
        inv, _ok = fwd.inverted()
        self.affine = (fwd, inv)

    def forward(self, geom):
        """Geometria WGS84 → metri, sul posto. True se riuscito."""
        if self.affine:
            return geom.transform(self.affine[0]) == 0
        return geom.transform(self.to_utm) == 0

    def point(self, lon, lat):
        """Punto WGS84 → QgsPointXY in metri."""
        g = QgsGeometry.fromPointXY(QgsPointXY(lon, lat))
        self.forward(g)
        return g.asPoint()

    def back(self, geom):
        """Geometria in metri → WGS84, sul posto. True se riuscito."""
        if self.affine:
            return geom.transform(self.affine[1]) == 0
        return geom.transform(self.to_wgs) == 0


def _too_big(geom, ref_box, margin_m):
    """La geometria (WGS84) esce dal riquadro dei dati allargato del
    buffer? Allora il buffer non era in metri: va scartata."""
    if geom is None or geom.isEmpty() or ref_box is None:
        return False
    import math
    b = geom.boundingBox()
    lat = (ref_box[1] + ref_box[3]) / 2.0
    dy = margin_m / 110000.0 * 1.5 + 0.002
    dx = dy / max(0.05, math.cos(math.radians(lat)))
    return (b.xMinimum() < ref_box[0] - dx or b.xMaximum() > ref_box[2] + dx
            or b.yMinimum() < ref_box[1] - dy or b.yMaximum() > ref_box[3] + dy)


def _style_by_time(layer):
    """Legenda CATEGORIZZATA per tempo: una voce per fascia (es. 5, 10, 15 min).

    Verde scuro = vicino, chiaro = lontano. Le voci mostrano i minuti esatti.
    Vale per poligoni (riempimento semitrasparente) e linee (tratto pieno e
    più spesso, altrimenti le fasce non si distinguono sulla mappa).
    """
    from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory
    values = sorted({f["time_min"] for f in layer.getFeatures()
                     if f["time_min"] is not None})
    if not values:
        return
    n = len(values)
    is_line = layer.geometryType() == QgsWkbTypes.LineGeometry
    # verde scuro -> chiaro; per le linee il chiaro è meno tenue (leggibile
    # come tratto su una mappa di base chiara)
    far = (120, 198, 121) if is_line else (199, 233, 192)
    cats = []
    for i, t in enumerate(values):
        frac = i / (n - 1) if n > 1 else 0.0
        col = QColor(
            int(0 + frac * (far[0] - 0)),
            int(104 + frac * (far[1] - 104)),
            int(55 + frac * (far[2] - 55)),
        )
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(col)
        if is_line:
            sym.setWidth(0.9)  # mm
        else:
            sym.setOpacity(0.55)
        label = (tr("%g min") % t)
        cats.append(QgsRendererCategory(t, sym, label))
    layer.setRenderer(QgsCategorizedSymbolRenderer("time_min", cats))


def _empty_iso_layer(name, geom="Polygon"):
    layer = QgsVectorLayer("%s?crs=EPSG:4326" % geom, name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("source_id", QVariant.Int),
        QgsField("time_min", QVariant.Double),
        QgsField("mezzo", QVariant.String),
        QgsField("speed_kmh", QVariant.Double),
    ])
    layer.updateFields()
    return layer


_CHUNK = 2500      # tratti per blocco nell'unione dei buffer
_FILL_M = 80.0     # poligono: raggio di chiusura (riempie gli isolati)
_HOLE_M2 = 40000.0  # poligono: buchi interni più piccoli (4 ha) riempiti
_TILE_M = 800.0    # tessera per ordinare i tratti (blocchi compatti)


def _union_buffers(parts, access_m, progress=None, is_canceled=None):
    """Buffer di ogni tratto (metri) e unione, a blocchi spazialmente compatti.

    Stesso risultato e stessi tempi di un'unica unione, ma con avanzamento
    continuo e annullabile fra un blocco e l'altro: su una rete grande
    l'unione dura decine di secondi e una sola chiamata GEOS sembrerebbe un
    blocco. In ogni blocco le linee vengono prima unite (mergeLines), così i
    buffer da unire sono molti meno.
    """
    def key(g):
        c = g.boundingBox().center()
        return (int(c.y() // _TILE_M), int(c.x() // _TILE_M))

    parts = sorted(parts, key=key)
    n = len(parts)
    partial = []
    for k in range(0, n, _CHUNK):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        merged = QgsGeometry.unaryUnion(parts[k:k + _CHUNK]).mergeLines()
        lines = (merged.asGeometryCollection() if merged.isMultipart()
                 else [merged])
        partial.append(QgsGeometry.unaryUnion(
            [ln.buffer(access_m, 8) for ln in lines]))
        if progress:
            progress(min(95, int(95 * (k + _CHUNK) / n)))
    return partial[0] if len(partial) == 1 else QgsGeometry.unaryUnion(partial)


def _segments_to_geom(segs, output_mode, access_m, transform_context,
                      progress=None, is_canceled=None):
    """Unisce i segmenti (lon/lat) in una geometria WGS84.

    `linear` = linee unite; `polygon` = area che segue la rete: buffer largo
    dei tratti raggiunti, poi ristretto (chiusura morfologica: riempie gli
    isolati fra strade raggiunte) e senza i buchi interni sotto 4 ha;
    altrimenti (concavo) = buffer dei segmenti. Tutto in METRI (proiezione
    UTM → buffer → WGS84, così `access_m` è in metri e non in gradi).

    Prima `polygon` era l'inviluppo convesso: copriva zone non raggiungibili
    (ferrovie, parchi chiusi, l'altra sponda di un fiume) e, con più
    sorgenti dissolte, anche tutto lo spazio fra loro.
    """
    parts = [QgsGeometry.fromPolylineXY([QgsPointXY(lo, la) for lo, la in s])
             for s in (segs or []) if len(s) >= 2]
    if not parts:
        return None
    if output_mode == "linear":
        union = QgsGeometry.unaryUnion(parts)
        return union if (union is not None and not union.isEmpty()) else None
    lon0 = sum(s[0][0] for s in segs) / len(segs)
    lat0 = sum(s[0][1] for s in segs) / len(segs)
    xs = [lo for s in segs for lo, _la in s]
    ys = [la for s in segs for _lo, la in s]
    ref_box = (min(xs), min(ys), max(xs), max(ys))
    frame = MetricFrame(lon0, lat0, transform_context)
    for p in parts:
        if not frame.forward(p):
            return None
    if output_mode == "polygon":
        r = max(_FILL_M, 2.0 * float(access_m))
        geom = _union_buffers(parts, r, progress, is_canceled)
        if geom is not None and not geom.isEmpty():
            geom = geom.buffer(-(r - float(access_m)), 8)
            if geom is not None and not geom.isEmpty():
                geom = geom.removeInteriorRings(_HOLE_M2)
    else:
        # buffer per tratto/linea + unione: decine di volte piu' veloce del
        # buffer di un'unica multilinea con migliaia di tratti
        geom = _union_buffers(parts, access_m, progress, is_canceled)
    if geom is None or geom.isEmpty() or not frame.back(geom):
        return None
    if _too_big(geom, ref_box, max(_FILL_M, 2.0 * float(access_m))):
        return None     # buffer non in metri: meglio niente che l'«uovo»
    return geom


def band_geometries(per_source, output_mode, access_m, dissolve,
                    transform_context, progress=None, is_canceled=None):
    """Parte pesante (thread-safe) del layer isocrone: una geometria WGS84 per
    fascia (e per sorgente se non dissolto). Non crea layer, quindi può
    girare in un QgsTask.

    :return: lista di (source_id, time_min, QgsGeometry); source_id = 0 se
        dissolto. Fasce dalla più ampia alla più stretta.
    """
    times = sorted({t for bands in per_source for t in bands}, reverse=True)
    jobs = []
    for t in times:
        if dissolve:
            merged = []
            for bands in per_source:
                merged.extend(bands.get(t, []))
            jobs.append((0, t, _dedup_segments(merged)))
        else:
            for sidx, bands in enumerate(per_source):
                jobs.append((sidx, t, bands.get(t, [])))
    # peso di ogni fascia/sorgente = numero di tratti (avanzamento realistico)
    total = float(sum(len(s) for _i, _t, s in jobs)) or 1.0
    out = []
    done = 0.0
    for sidx, t, segs in jobs:
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        base, share = done, len(segs)
        sub = ((lambda p, b=base, s=share:
                progress(int(100 * (b + s * p / 100.0) / total)))
               if progress else None)
        g = _segments_to_geom(segs, output_mode, access_m, transform_context,
                              sub, is_canceled)
        if g is not None:
            out.append((sidx, t, g))
        done += share
        if progress:
            progress(int(100 * done / total))
    return out


def layer_from_band_geoms(items, speed_kmh, mode_label, output_mode,
                          name=tr("Isocrone (rete)")):
    """Layer isocrone (main thread) dalle geometrie di `band_geometries`.

    Gli elementi possono avere un quarto valore, l'etichetta della linea
    di TP ("Dividi per linea"): allora il layer ha il campo «linea» e la
    legenda è per linea.
    """
    geom_type = "MultiLineString" if output_mode == "linear" else "MultiPolygon"
    layer = _empty_iso_layer(name, geom_type)
    by_line = any(len(it) > 3 for it in items)
    if by_line:
        layer.dataProvider().addAttributes([QgsField("linea", QVariant.String)])
        layer.updateFields()
    feats = []
    for it in items:
        sidx, t, g = it[0], it[1], it[2]
        g = QgsGeometry(g)
        g.convertToMultiType()
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        attrs = [sidx, t, mode_label, speed_kmh]
        if by_line:
            attrs.append(it[3] if len(it) > 3 else "")
        f.setAttributes(attrs)
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    if by_line:
        _style_by_line(layer)
    else:
        # fasce dalla più ampia: le più vicine (più scure) disegnate sopra
        _style_by_time(layer)
    return layer


# colori qualitativi per le linee di TP (ColorBrewer Set1 + Dark2)
_LINE_COLORS = ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00",
                "#a65628", "#f781bf", "#1b9e77", "#d95f02", "#7570b3",
                "#e7298a", "#66a61e", "#e6ab02", "#666666"]


def _style_by_line(layer):
    """Legenda categorizzata per linea di TP: un colore per linea."""
    from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory
    lines = sorted({f["linea"] for f in layer.getFeatures()
                    if f["linea"] is not None})
    is_line = layer.geometryType() == QgsWkbTypes.LineGeometry
    cats = []
    for i, ln in enumerate(lines):
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(QColor(_LINE_COLORS[i % len(_LINE_COLORS)]))
        if is_line:
            sym.setWidth(0.9)
        else:
            sym.setOpacity(0.35)
        cats.append(QgsRendererCategory(ln, sym, tr("linea %s") % ln))
    layer.setRenderer(QgsCategorizedSymbolRenderer("linea", cats))


def build_layer_from_segments(per_source, speed_kmh, mode_label, output_mode,
                              access_m, dissolve, transform_context=None,
                              name=tr("Isocrone (rete)")):
    """Costruisce il layer isocrone dai segmenti calcolati (lon/lat).

    Il buffer (concavo/poligono) è in METRI: la geometria viene proiettata in
    UTM, bufferata e riproiettata in WGS84 (altrimenti `access_m` sarebbe in
    gradi). Nella GUI le geometrie si calcolano nel task (band_geometries) e
    qui resta solo layer_from_band_geoms.
    """
    if transform_context is None:
        from qgis.core import QgsProject
        transform_context = QgsProject.instance().transformContext()
    items = band_geometries(per_source, output_mode, access_m, dissolve,
                            transform_context)
    return layer_from_band_geoms(items, speed_kmh, mode_label, output_mode,
                                 name)


def _dedup_segments(segs):
    """Rimuove i segmenti duplicati (molte sorgenti raggiungono gli stessi
    archi): unisce per chiave coordinate arrotondate, indipendente dal verso.

    Senza dedup, l'unione di N sorgenti produrrebbe N copie di ogni arco
    condiviso → unaryUnion patologico. Riduce drasticamente l'input.
    """
    seen = set()
    out = []
    for s in segs:
        if len(s) < 2:
            continue
        a = (round(s[0][0], 6), round(s[0][1], 6))
        b = (round(s[-1][0], 6), round(s[-1][1], 6))
        key = (a, b) if a <= b else (b, a)
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


def dissolved_reach_geom(per_source, time_min, access_m, transform_context):
    """Poligono unico (WGS84, modo concavo) dell'area raggiunta a `time_min`.

    Unisce i segmenti di tutte le sorgenti per la fascia indicata, deduplicati
    per non far esplodere l'unione quando le sorgenti sono molte.
    """
    merged = []
    for bands in per_source:
        merged.extend(bands.get(time_min, []))
    merged = _dedup_segments(merged)
    return _segments_to_geom(merged, "concave", access_m, transform_context)


def _geom_area_m2(geom, transform_context):
    """Area in metri quadri (proiezione UTM locale). 0 se geometria vuota."""
    if geom is None or geom.isEmpty():
        return 0.0
    c = geom.centroid().asPoint()
    g = QgsGeometry(geom)
    if not MetricFrame(c.x(), c.y(), transform_context).forward(g):
        return 0.0
    return g.area()


def _polygonal(geom):
    """Mantiene solo le parti poligonali di una geometria.

    Le operazioni di differenza/intersezione fra poligoni bufferati possono
    restituire una GeometryCollection (poligoni + tratti di bordo); un layer
    Polygon scarterebbe quelle feature. Qui si filtrano le sole parti poligono.
    """
    if geom is None or geom.isEmpty():
        return QgsGeometry()
    parts = [g for g in geom.asGeometryCollection()
             if not g.isEmpty() and g.type() == QgsWkbTypes.PolygonGeometry]
    if not parts:
        return QgsGeometry()
    if len(parts) == 1:
        return parts[0]
    u = QgsGeometry.unaryUnion(parts)
    return u if (u is not None and not u.isEmpty()) else parts[0]


def build_isochrone_diff_layer(geom_a, geom_b, time_min, transform_context,
                               name=tr("MIC - Scenario isocrone A/B")):
    """Differenza geometrica fra due isocrone su rete (A attuale, B progetto).

    Tre classi: «comune» (A∩B), «guadagno» (B−A, area raggiungibile solo nel
    progetto), «perdita» (A−B, area persa rispetto allo stato attuale).
    Ritorna (layer, summary) con aree in m² ed ettari per classe.
    """
    from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory
    layer = QgsVectorLayer("MultiPolygon?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("classe", QVariant.String),
        QgsField("time_min", QVariant.Double),
        QgsField("area_m2", QVariant.Double),
        QgsField("area_ha", QVariant.Double),
    ])
    layer.updateFields()

    ga = QgsGeometry(geom_a) if geom_a is not None else QgsGeometry()
    gb = QgsGeometry(geom_b) if geom_b is not None else QgsGeometry()
    a_ok = not ga.isEmpty()
    b_ok = not gb.isEmpty()
    common = ga.intersection(gb) if (a_ok and b_ok) else QgsGeometry()
    # guadagno = area solo in B (se A vuota, è tutta B); perdita = solo in A
    gain = (gb.difference(ga) if a_ok else QgsGeometry(gb)) if b_ok \
        else QgsGeometry()
    loss = (ga.difference(gb) if b_ok else QgsGeometry(ga)) if a_ok \
        else QgsGeometry()
    common, gain, loss = _polygonal(common), _polygonal(gain), _polygonal(loss)
    parts = [("comune", common, QColor(120, 120, 120)),
             ("guadagno", gain, QColor(27, 158, 55)),
             ("perdita", loss, QColor(202, 0, 32))]
    feats = []
    summary = {"time_min": time_min}
    cats = []
    for cls, geom, col in parts:
        area = _geom_area_m2(geom, transform_context)
        summary[cls] = area
        if geom is not None and not geom.isEmpty():
            f = QgsFeature(layer.fields())
            f.setGeometry(geom)
            f.setAttributes([cls, time_min, round(area, 1),
                             round(area / 1e4, 3)])
            feats.append(f)
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(col)
        sym.setOpacity(0.5)
        cats.append(QgsRendererCategory(cls, sym, cls))
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    layer.setRenderer(QgsCategorizedSymbolRenderer("classe", cats))
    return layer, summary


def isochrone_scenario_geoms(roads_a, roads_b, sources_latlon, speed_kmh,
                             time_min, access_m=30.0, dir_a=None, dir_b=None,
                             transform_context=None, progress=None,
                             is_canceled=None):
    """Parte pesante (thread-safe) dello scenario isocrone A/B.

    Calcola le due isocrone su rete (Dijkstra sub-arco) per le stesse sorgenti
    e ritorna (ga, gb, n_snap_a, n_snap_b) come geometrie WGS84 dissolte. Non
    crea layer, quindi è eseguibile in un QgsTask in background.
    """
    from . import net_iso
    if transform_context is None:
        from qgis.core import QgsProject
        transform_context = QgsProject.instance().transformContext()
    ps_a, na = net_iso.compute_reachable_segments(
        roads_a, sources_latlon, speed_kmh, [time_min], directions=dir_a,
        progress=(lambda p: progress(int(p * 0.40))) if progress else None,
        is_canceled=is_canceled, dissolve=True)
    ga = dissolved_reach_geom(ps_a, time_min, access_m, transform_context)
    if progress:
        progress(55)
    ps_b, nb = net_iso.compute_reachable_segments(
        roads_b, sources_latlon, speed_kmh, [time_min], directions=dir_b,
        progress=(lambda p: progress(55 + int(p * 0.40))) if progress else None,
        is_canceled=is_canceled, dissolve=True)
    gb = dissolved_reach_geom(ps_b, time_min, access_m, transform_context)
    if progress:
        progress(100)
    return ga, gb, na, nb


def isochrone_scenario(roads_a, roads_b, sources_latlon, speed_kmh, time_min,
                       access_m=30.0, dir_a=None, dir_b=None,
                       transform_context=None, name=tr("MIC - Scenario isocrone A/B"),
                       progress=None):
    """Scenario isocrone A/B completo (calcolo + layer). Per uso headless o
    Processing; nella GUI il calcolo gira in un task e il layer si costruisce
    sul main thread via build_isochrone_diff_layer.

    Ritorna (layer, summary) con summary[comune|guadagno|perdita] in m² e
    summary[snap_a|snap_b] = sorgenti agganciate per rete.
    """
    if transform_context is None:
        from qgis.core import QgsProject
        transform_context = QgsProject.instance().transformContext()
    ga, gb, na, nb = isochrone_scenario_geoms(
        roads_a, roads_b, sources_latlon, speed_kmh, time_min, access_m,
        dir_a, dir_b, transform_context, progress=progress)
    layer, summary = build_isochrone_diff_layer(ga, gb, time_min,
                                                transform_context, name)
    summary["snap_a"] = na
    summary["snap_b"] = nb
    return layer, summary


def catchment_geoms(per_band_circles, transform_context, progress=None,
                    is_canceled=None):
    """Parte pesante (thread-safe) dei bacini del trasporto pubblico: unione
    dei cerchi per fascia. Ritorna [(0, t_min, geometria WGS84)] come
    band_geometries, dalla fascia più ampia.

    :param per_band_circles: lista di (t_min, [(lat, lon, radius_m), ...]).
    """
    all_pts = [c for _, circles in per_band_circles for c in circles]
    if not all_pts:
        raise ValueError(tr("Nessuna fermata raggiunta in TP."))
    lat0 = sum(c[0] for c in all_pts) / len(all_pts)
    lon0 = sum(c[1] for c in all_pts) / len(all_pts)
    frame = MetricFrame(lon0, lat0, transform_context)
    ref_box = (min(c[1] for c in all_pts), min(c[0] for c in all_pts),
               max(c[1] for c in all_pts), max(c[0] for c in all_pts))
    rmax = max([c[2] for c in all_pts] + [0.0])
    bands = sorted(per_band_circles, key=lambda x: -x[0])
    out = []
    for k, (t, circles) in enumerate(bands):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        buffs = []
        for la, lo, rad in circles:
            if rad <= 0:
                continue
            p = frame.point(lo, la)
            buffs.append(QgsGeometry.fromPointXY(p).buffer(rad, 18))
        if buffs:
            union = QgsGeometry.unaryUnion(buffs)
            if union is not None and not union.isEmpty() and \
                    frame.back(union) and not _too_big(union, ref_box, rmax):
                out.append((0, t, union))
        if progress:
            progress(int(100 * (k + 1) / len(bands)))
    return out
