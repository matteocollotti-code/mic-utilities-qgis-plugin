# -*- coding: utf-8 -*-
"""Provider e algoritmi Processing di MIC - Utilities.

Espone alcuni core come algoritmi Processing (batch, Model Builder, headless),
riusando le stesse funzioni del pannello. I core sono già senza GUI, quindi qui
si fa solo il "wrapping": materializza l'input, chiama il core, scrive nel sink.
"""
from .i18n import tr
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterString,
    QgsProcessingProvider,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QVariant


def _parse_times(text):
    out = []
    for x in str(text).replace(";", ",").split(","):
        x = x.strip()
        if x:
            try:
                v = float(x)
                if v > 0:
                    out.append(v)
            except ValueError:
                pass
    return out


class _FeedbackTask(object):
    """Adatta il feedback di Processing all'interfaccia «task» dei core
    (setProgress / isCanceled)."""

    def __init__(self, feedback):
        self.fb = feedback

    def setProgress(self, p):
        self.fb.setProgress(int(p))

    def isCanceled(self):
        return self.fb.isCanceled()


MODE_SPEED = {0: 4.5, 1: 15.0, 2: 50.0}


def _cost_from_params(alg, parameters, context, rsrc, mode, ctx):
    """Configurazione dei tempi per tratto dai parametri comuni (MODE 0 =
    piedi, 1 = bici, 2 = auto con il limite di ogni strada; SPEED, FACTOR,
    SPEED_FIELD, DEM). :return: (cost, velocità massima km/h, testo)."""
    from .core import travel_cost
    speed = alg.parameterAsDouble(parameters, "SPEED", context) or \
        MODE_SPEED.get(mode, 4.5)
    if mode == 2:
        fac = alg.parameterAsDouble(parameters, "FACTOR", context) / 100.0
        sf = alg.parameterAsString(parameters, "SPEED_FIELD", context) or None
        cost, vmax = travel_cost.car_cost(rsrc.fields().names(), speed, fac, sf)
        return cost, vmax, tr("auto, limite di ogni strada al %d %%") % (fac * 100)
    cost = {"default_mps": speed / 3.6}
    desc = tr("%s a %.1f km/h") % ("piedi" if mode == 0 else "bici", speed)
    dem = alg.parameterAsRasterLayer(parameters, "DEM", context) \
        if mode == 0 else None
    if dem is not None:
        cost["dem"] = travel_cost.dem_spec(dem, ctx)
        return (cost, speed * travel_cost.TOBLER_MAX,
                desc + tr(" in piano, pendenza dal DEM"))
    return cost, speed, desc


def _road_source_spec(rsrc, ctx, oneway, clip_wgs=None):
    """Spec della rete (come _road_spec del pannello) da una sorgente di
    Processing, eventualmente ritagliata al riquadro WGS84 clip_wgs."""
    from qgis.core import QgsRectangle
    from .core import topology, isochrones
    names = rsrc.fields().names()
    spec = {"source": rsrc, "crs": rsrc.sourceCrs(), "ctx": ctx,
            "count": max(0, rsrc.featureCount()),
            "oneway": bool(oneway and {"oneway", "junction", "highway"}
                           & {n.lower() for n in names}),
            "level_of": topology.level_reader(names)}
    if clip_wgs is not None:
        try:
            spec["rect"] = QgsCoordinateTransform(
                isochrones.WGS84, rsrc.sourceCrs(), ctx).transformBoundingBox(
                QgsRectangle(*clip_wgs))
        except Exception:
            pass
    return spec


def _add_cost_params(alg, roads_key, modes, default_mode=0, with_dem=True,
                     with_car=True):
    alg.addParameter(QgsProcessingParameterEnum(
        "MODE", tr("Mezzo"), modes, defaultValue=default_mode))
    alg.addParameter(QgsProcessingParameterNumber(
        "SPEED", tr("Velocità km/h (0 = tipica: piedi 4.5, bici 15, auto 50 se "
        "manca il limite)"), QgsProcessingParameterNumber.Double, 0.0,
        minValue=0.0))
    if with_car:
        alg.addParameter(QgsProcessingParameterNumber(
            "FACTOR", tr("Auto: velocità effettiva (% del limite)"),
            QgsProcessingParameterNumber.Double, 100.0, minValue=5.0,
            maxValue=200.0))
        alg.addParameter(QgsProcessingParameterField(
            "SPEED_FIELD", tr("Auto: campo velocità km/h (opz.)"),
            parentLayerParameterName=roads_key, optional=True))
    if with_dem:
        alg.addParameter(QgsProcessingParameterRasterLayer(
            "DEM", tr("A piedi: DEM per la pendenza (opz., Tobler)"),
            optional=True))
    alg.addParameter(QgsProcessingParameterBoolean(
        "ONEWAY", tr("Rispetta i sensi unici (campo oneway)"), False))


def _copy_to_sink(self, result_layer, parameters, context, out_key):
    sink, dest_id = self.parameterAsSink(
        parameters, out_key, context, result_layer.fields(),
        result_layer.wkbType(), result_layer.crs())
    for f in result_layer.getFeatures():
        sink.addFeature(f, QgsFeatureSink.FastInsert)
    return dest_id


class SpaceSyntaxAlgorithm(QgsProcessingAlgorithm):
    INPUT, RADIUS, OUTPUT = "INPUT", "RADIUS", "OUTPUT"

    def name(self):
        return "spacesyntax"

    def displayName(self):
        return tr("Space syntax (rete stradale)")

    def group(self):
        return tr("Rete stradale")

    def groupId(self):
        return "rete"

    def createInstance(self):
        return SpaceSyntaxAlgorithm()

    def shortHelpString(self):
        return (tr("Connettività, profondità, integrazione (HH), choice "
                "(betweenness), NAIN e NACH sulla segment map: i tratti di "
                "strada tra incroci reali (vertici condivisi da almeno tre "
                "bracci), indipendenti da come la rete è digitalizzata. "
                "Output: un tratto per segmento con gli attributi della "
                "strada d'origine. Raggio 0 = globale, n = analisi locale "
                "entro n passi topologici."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(
            self.RADIUS, tr("Raggio (0 = globale)"),
            QgsProcessingParameterNumber.Integer, 0, minValue=0))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("Space syntax")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import space_syntax, gtfs_layers, net_iso, isochrones
        from .core.gtfs_static import GtfsCancelled
        source = self.parameterAsSource(parameters, self.INPUT, context)
        mat = source.materialize(QgsFeatureRequest())
        radius = self.parameterAsInt(parameters, self.RADIUS, context)
        ct = QgsCoordinateTransform(mat.crs(), isochrones.WGS84,
                                    context.transformContext())
        ids = []
        try:
            roads, _d = net_iso.read_roads(mat.getFeatures(), ct, ids=ids,
                                           is_canceled=feedback.isCanceled)
            ok, vmsg, _info = net_iso.validate_network(roads)
            if not ok:
                raise QgsProcessingException(vmsg)
            topo, adjacency = space_syntax.segment_map(
                roads, sources=ids, is_canceled=feedback.isCanceled)
            if not topo.chains:
                raise QgsProcessingException(tr("Nessun tratto valido nella rete."))
            feedback.pushInfo(tr("Segment map: %d segmenti tra %d incroci reali "
                              "(da %d strade).") % (len(topo.chains),
                                                    len(topo.junctions()),
                                                    len(set(ids))))
            metrics = space_syntax.compute_metrics(
                adjacency, radius=radius,
                progress=lambda p: feedback.setProgress(int(p)),
                is_canceled=feedback.isCanceled)
        except GtfsCancelled:
            raise QgsProcessingException(tr("Calcolo annullato."))
        space_syntax.attach_segments(metrics, topo, len(set(ids)))
        attrs = gtfs_layers.space_syntax_source_attrs(mat, metrics["src"])
        result = gtfs_layers.build_space_syntax_layer(
            mat, metrics, attrs, transform_context=context.transformContext())
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class RoadLengthsAlgorithm(QgsProcessingAlgorithm):
    INPUT, FIELD, OUTPUT = "INPUT", "FIELD", "OUTPUT"

    def name(self):
        return "roadlengths"

    def displayName(self):
        return tr("Lunghezze per tipologia (rete stradale)")

    def group(self):
        return tr("Rete stradale")

    def groupId(self):
        return "rete"

    def createInstance(self):
        return RoadLengthsAlgorithm()

    def shortHelpString(self):
        return (tr("Somma la lunghezza ellissoidale dei tratti raggruppata per il "
                "campo tipologia. Output: tabella tipologia / lunghezza."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterField(
            self.FIELD, tr("Campo tipologia (vuoto = tutte insieme)"),
            parentLayerParameterName=self.INPUT, optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("Lunghezze per tipologia"),
            QgsProcessing.TypeVector))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import analysis
        source = self.parameterAsSource(parameters, self.INPUT, context)
        mat = source.materialize(QgsFeatureRequest())
        field = self.parameterAsString(parameters, self.FIELD, context) or None
        da = analysis.distance_area(mat)
        lengths = analysis.compute_lengths_by_type(mat, field, da)
        fields = QgsFields()
        fields.append(QgsField("tipologia", QVariant.String))
        fields.append(QgsField("lunghezza_m", QVariant.Double))
        fields.append(QgsField("lunghezza_km", QVariant.Double))
        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields,
            QgsWkbTypes.NoGeometry, mat.crs())
        for typ, m in sorted(lengths.items(), key=lambda kv: -kv[1]):
            f = QgsFeature(fields)
            f.setAttributes([str(typ), round(m, 2), round(m / 1000.0, 3)])
            sink.addFeature(f, QgsFeatureSink.FastInsert)
        return {self.OUTPUT: dest_id}


class NetworkIsochronesAlgorithm(QgsProcessingAlgorithm):
    POINTS, ROADS, SPEED, TIMES, OUTPUT = (
        "POINTS", "ROADS", "SPEED", "TIMES", "OUTPUT")

    def name(self):
        return "netisochrones"

    def displayName(self):
        return tr("Isocrone su rete stradale")

    def group(self):
        return tr("Accessibilità")

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return NetworkIsochronesAlgorithm()

    def shortHelpString(self):
        return (tr("Isocrone concave (buffer sui tratti raggiunti) da punti "
                "sorgente lungo la rete stradale, per fasce di tempo. Con "
                "velocità unica la velocità definisce la distanza "
                "percorribile. In auto con il limite di ogni strada ogni "
                "tratto si percorre alla sua velocità (campo, maxspeed OSM, "
                "tipo di strada) e i percorsi pedonali sono esclusi. Con un "
                "DEM (a velocità unica) il tempo segue la pendenza "
                "(funzione di Tobler): la velocità indicata è quella in "
                "piano."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, tr("Sorgenti (punti)"), [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPEED, tr("Velocità (km/h; in auto: se manca il limite)"),
            QgsProcessingParameterNumber.Double, 4.5, minValue=0.1))
        self.addParameter(QgsProcessingParameterString(
            self.TIMES, tr("Tempi (min, es. 5,10,15)"), "5,10,15"))
        self.addParameter(QgsProcessingParameterEnum(
            "SPEEDS", tr("Velocità"), [tr("Unica (quella indicata)"),
                                   tr("Auto: limite di ogni strada")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            "FACTOR", tr("Auto: velocità effettiva (% del limite)"),
            QgsProcessingParameterNumber.Double, 100.0, minValue=5.0,
            maxValue=200.0))
        self.addParameter(QgsProcessingParameterField(
            "SPEED_FIELD", tr("Auto: campo velocità km/h (opz.)"),
            parentLayerParameterName=self.ROADS, optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            "DEM", tr("DEM per la pendenza a piedi (opz., Tobler)"),
            optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            "ONEWAY", tr("Rispetta i sensi unici (campo oneway)"), False))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("Isocrone")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import net_iso, isochrones, net_clean
        ctx = context.transformContext()
        psrc = self.parameterAsSource(parameters, self.POINTS, context)
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        speed = self.parameterAsDouble(parameters, self.SPEED, context)
        times = _parse_times(self.parameterAsString(
            parameters, self.TIMES, context))
        if not times:
            raise QgsProcessingException(tr("Tempi non validi."))

        ctp = QgsCoordinateTransform(psrc.sourceCrs(), isochrones.WGS84, ctx)
        coords = []
        for f in psrc.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ctp)
            p = g.centroid().asPoint()
            coords.append((p.y(), p.x()))
        if not coords:
            raise QgsProcessingException(tr("Nessuna sorgente valida."))

        from .core import travel_cost
        from .core.gtfs_tasks import read_costed_network
        from .core.gtfs_static import GtfsCancelled
        car = self.parameterAsEnum(parameters, "SPEEDS", context) == 1
        dem = self.parameterAsRasterLayer(parameters, "DEM", context)
        oneway = self.parameterAsBool(parameters, "ONEWAY", context)
        cost = None
        vmax = speed
        label = "rete"
        if car:
            fac = self.parameterAsDouble(parameters, "FACTOR", context) / 100.0
            sf = self.parameterAsString(parameters, "SPEED_FIELD",
                                        context) or None
            cost, vmax = travel_cost.car_cost(rsrc.fields().names(), speed,
                                              fac, sf)
            label = tr("auto (limiti per strada)")
        elif dem is not None:
            try:
                cost = {"default_mps": speed / 3.6,
                        "dem": travel_cost.dem_spec(dem, ctx)}
            except ValueError as exc:
                raise QgsProcessingException(str(exc))
            vmax = speed * travel_cost.TOBLER_MAX
            label = tr("piedi (pendenza DEM)")
        radius = net_iso.reach_radius_m(vmax, times)
        spec = _road_source_spec(rsrc, ctx, oneway,
                                 net_iso.reach_bbox(coords, radius))
        task = _FeedbackTask(feedback)
        ec = None
        try:
            if cost is not None:
                roads, dirs, ec, st, cstats = read_costed_network(
                    spec, cost, task, 0, 30)
                vmax = 3.6 * st.get("vmax_mps", vmax / 3.6)
            else:
                from .core.gtfs_tasks import read_spec_roads
                raw, dirs = read_spec_roads(spec, task, 0, 20)
                ok, vmsg, _ = net_iso.validate_network(raw)
                if not ok:
                    raise QgsProcessingException(vmsg)
                # stessa pulizia del pannello (snap vertici, nulli, duplicati)
                roads, dirs, cstats = net_clean.clean_network(raw, 1.0, dirs)
            feedback.pushInfo(net_clean.clean_summary(cstats))
            per_source, n_snap = net_iso.compute_reachable_segments(
                roads, coords, vmax if ec is not None else speed, times,
                directions=dirs, edge_costs=ec,
                progress=lambda p: feedback.setProgress(30 + int(0.6 * p)),
                is_canceled=feedback.isCanceled, dissolve=True)
        except GtfsCancelled:
            raise QgsProcessingException(tr("Calcolo annullato."))
        except ValueError as exc:
            raise QgsProcessingException(str(exc))
        result = isochrones.build_layer_from_segments(
            per_source, speed, label, "concave", 30.0, True,
            transform_context=ctx)
        feedback.pushInfo(tr("Sorgenti agganciate: %d/%d") % (n_snap, len(coords)))
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


def _source_points_latlon(source, ctx):
    from .core import isochrones
    ct = QgsCoordinateTransform(source.sourceCrs(), isochrones.WGS84, ctx)
    coords = []
    for f in source.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        p = g.centroid().asPoint()
        coords.append((p.y(), p.x()))
    return coords


def _source_points_weighted(source, ctx, weight_field=None):
    from .core import isochrones
    ct = QgsCoordinateTransform(source.sourceCrs(), isochrones.WGS84, ctx)
    names = [fld.name() for fld in source.fields()]
    out = []
    for f in source.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        p = g.centroid().asPoint()
        w = 1.0
        if weight_field and weight_field in names:
            try:
                w = float(f[weight_field])
            except (TypeError, ValueError):
                w = 0.0  # peso mancante (NULL): non conta
        out.append((p.y(), p.x(), w))
    return out


def _source_roads(source, ctx):
    from .core import isochrones
    ct = QgsCoordinateTransform(source.sourceCrs(), isochrones.WGS84, ctx)
    roads = []
    for f in source.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        if g.isMultipart():
            for part in g.asMultiPolyline():
                roads.append([(p.x(), p.y()) for p in part])
        else:
            roads.append([(p.x(), p.y()) for p in g.asPolyline()])
    return roads


class PtalAlgorithm(QgsProcessingAlgorithm):
    GTFS, POINTS, START, END, ROADS, DATE, OUTPUT = (
        "GTFS", "POINTS", "START", "END", "ROADS", "DATE", "OUTPUT")
    STOPS, FREQ, ROUTE, MODE = "STOPS", "FREQ", "ROUTE", "MODE"

    def name(self):
        return "ptal"

    def displayName(self):
        return tr("PTAL (Public Transport Accessibility Level)")

    def group(self):
        return tr("Accessibilità")

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return PtalAlgorithm()

    def shortHelpString(self):
        return (tr("PTAL TfL per ogni punto. Senza rete pedonale usa la distanza in "
                "linea d'aria (standard TfL); con una rete pedonale usa le "
                "distanze di rete. Data servizio (YYYYMMDD) opzionale. "
                "Senza GTFS: un layer di fermate con un punto per ogni linea "
                "che serve la fermata, le corse all'ora (nella fascia) e, "
                "facoltativi, linea e modo (bus, tram, metro, treno o "
                "route_type)."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            self.GTFS, tr("Feed GTFS (.zip) (opz. se si danno le fermate)"),
            extension="zip", optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.STOPS, tr("Fermate con frequenze (al posto del GTFS)"),
            [QgsProcessing.TypeVectorPoint], optional=True))
        self.addParameter(QgsProcessingParameterField(
            self.FREQ, tr("Campo corse/ora"), parentLayerParameterName=self.STOPS,
            optional=True))
        self.addParameter(QgsProcessingParameterField(
            self.ROUTE, tr("Campo linea (opz.)"),
            parentLayerParameterName=self.STOPS, optional=True))
        self.addParameter(QgsProcessingParameterField(
            self.MODE, tr("Campo modo (opz., default bus)"),
            parentLayerParameterName=self.STOPS, optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, tr("Punti di analisi"), [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterNumber(
            self.START, tr("Ora inizio fascia"),
            QgsProcessingParameterNumber.Integer, 7, minValue=0, maxValue=23))
        self.addParameter(QgsProcessingParameterNumber(
            self.END, tr("Ora fine fascia"),
            QgsProcessingParameterNumber.Integer, 10, minValue=1, maxValue=30))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, tr("Rete pedonale (opz. → PTAL su rete)"),
            [QgsProcessing.TypeVectorLine], optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.DATE, tr("Data servizio YYYYMMDD (opz.)"), "", optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("PTAL")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import ptal, gtfs_layers
        ctx = context.transformContext()
        gtfs = self.parameterAsFile(parameters, self.GTFS, context)
        psrc = self.parameterAsSource(parameters, self.POINTS, context)
        start = self.parameterAsInt(parameters, self.START, context)
        end = self.parameterAsInt(parameters, self.END, context)
        date = self.parameterAsString(parameters, self.DATE, context).strip()
        date = date if (len(date) == 8 and date.isdigit()) else None
        coords = _source_points_latlon(psrc, ctx)
        if not coords:
            raise QgsProcessingException(tr("Nessun punto valido."))
        feedback.setProgress(10)
        ssrc = self.parameterAsSource(parameters, self.STOPS, context)
        if ssrc is not None:
            ff = self.parameterAsString(parameters, self.FREQ, context)
            if not ff:
                raise QgsProcessingException(tr("Indica il campo corse/ora."))
            rf = self.parameterAsString(parameters, self.ROUTE, context) or None
            mf = self.parameterAsString(parameters, self.MODE, context) or None
            cts = QgsCoordinateTransform(ssrc.sourceCrs(),
                                         QgsCoordinateReferenceSystem("EPSG:4326"),
                                         ctx)
            recs = []
            for f in ssrc.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(cts)
                p = g.centroid().asPoint()
                recs.append((p.y(), p.x(), None, f[rf] if rf else None,
                             ptal.mode_code(f[mf]) if mf else "3", f[ff]))
            stop_routes, stops_xy = ptal.stops_from_records(recs)
            if not stop_routes:
                raise QgsProcessingException(
                    tr("Nessuna fermata con corse/ora valide."))
        elif gtfs:
            stop_routes, stops_xy = ptal.compute_stop_frequencies(
                gtfs, start, end, service_date=date)
        else:
            raise QgsProcessingException(
                tr("Indica un feed GTFS oppure il layer delle fermate."))
        feedback.setProgress(40)
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        params = {"start_h": start, "end_h": end}
        if rsrc is not None:
            roads = _source_roads(rsrc, ctx)
            results = ptal.compute_ptal_network(
                coords, stop_routes, stops_xy, roads, params,
                progress=lambda p: feedback.setProgress(40 + int(p * 0.5)))
        else:
            results = ptal.compute_ptal(
                coords, stop_routes, stops_xy, params,
                progress=lambda p: feedback.setProgress(40 + int(p * 0.5)))
        mat = psrc.materialize(QgsFeatureRequest())
        result = gtfs_layers.build_ptal_layer(mat, results)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class AccessibilityAlgorithm(QgsProcessingAlgorithm):
    ORIGINS, DESTS, WEIGHT, ROADS, SPEED, TIMES, OUTPUT = (
        "ORIGINS", "DESTS", "WEIGHT", "ROADS", "SPEED", "TIMES", "OUTPUT")

    def name(self):
        return "accessibility"

    def displayName(self):
        return tr("Accessibilità cumulativa su rete")

    def group(self):
        return tr("Accessibilità")

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return AccessibilityAlgorithm()

    def shortHelpString(self):
        return (tr("Per ogni origine, quante destinazioni (o peso) sono "
                "raggiungibili entro ciascuna soglia di tempo, sulla rete."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ORIGINS, tr("Origini (punti)"), [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.DESTS, tr("Destinazioni"),
            [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT, tr("Campo peso (opz.)"), parentLayerParameterName=self.DESTS,
            optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPEED, tr("Velocità (km/h)"),
            QgsProcessingParameterNumber.Double, 4.5, minValue=0.1))
        self.addParameter(QgsProcessingParameterString(
            self.TIMES, tr("Tempi (min, es. 15,30)"), "15,30"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("Accessibilità")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import accessibility, gtfs_layers
        ctx = context.transformContext()
        osrc = self.parameterAsSource(parameters, self.ORIGINS, context)
        dsrc = self.parameterAsSource(parameters, self.DESTS, context)
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        wfield = self.parameterAsString(parameters, self.WEIGHT, context) or None
        speed = self.parameterAsDouble(parameters, self.SPEED, context)
        times = _parse_times(self.parameterAsString(
            parameters, self.TIMES, context))
        if not times:
            raise QgsProcessingException(tr("Tempi non validi."))
        origins = [(la, lo) for la, lo, _ in _source_points_weighted(osrc, ctx)]
        dests = _source_points_weighted(dsrc, ctx, wfield)
        roads = _source_roads(rsrc, ctx)
        if not origins or not dests:
            raise QgsProcessingException(tr("Origini/destinazioni vuote."))
        results, out_times = accessibility.accessibility_network(
            origins, dests, roads, speed, times,
            progress=lambda p: feedback.setProgress(int(p)))
        mat = osrc.materialize(QgsFeatureRequest())
        result = gtfs_layers.build_access_layer(mat, results, out_times)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


def _source_roads_dir(source, ctx, oneway_field=None, ids=None, levels=None,
                      attrs=None):
    """Roads lon/lat + directions da un campo oneway (testuale o numerico).

    Con `ids` / `levels` (liste) raccoglie id della feature e livello
    (ponte/tunnel/layer) per polilinea; con `attrs` (dict) gli attributi.
    """
    from .core import isochrones, osm_download, topology
    ct = QgsCoordinateTransform(source.sourceCrs(), isochrones.WGS84, ctx)
    names = [f.name() for f in source.fields()]
    has_ow = bool(oneway_field) and oneway_field in names
    direction_of = osm_download.oneway_reader(names, oneway_field) \
        if has_ow else None
    level_of = topology.level_reader(names) if levels is not None else None
    roads, dirs = [], ([] if has_ow else None)
    for f in source.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        d = direction_of(f) if has_ow else 0
        lev = level_of(f) if level_of else 0
        if attrs is not None:
            attrs[f.id()] = f.attributes()
        parts = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
        for part in parts:
            roads.append([(p.x(), p.y()) for p in part])
            if has_ow:
                dirs.append(d)
            if ids is not None:
                ids.append(f.id())
            if levels is not None:
                levels.append(lev)
    return roads, dirs


class PrepareNetworkAlgorithm(QgsProcessingAlgorithm):
    INPUT, SNAP, MINSEG, ONEWAY, OUTPUT = (
        "INPUT", "SNAP", "MINSEG", "ONEWAY", "OUTPUT")

    def name(self):
        return "preparenetwork"

    def displayName(self):
        return tr("Prepara rete (noding + snap)")

    def group(self):
        return tr("Rete stradale")

    def groupId(self):
        return "rete"

    def createInstance(self):
        return PrepareNetworkAlgorithm()

    def shortHelpString(self):
        return (tr("Spezza le linee alle intersezioni (noding), unisce gli estremi "
                "vicini (snap) e rimuove segmenti nulli/duplicati: produce una "
                "rete 'analysis-ready' per isocrone, accessibilità, PTAL, space "
                "syntax. Ogni strada è divisa solo agli incroci e conserva i "
                "suoi attributi. Se il layer ha campi bridge/tunnel/layer "
                "(OSM) o ponte/galleria/livello, le strade a livelli diversi "
                "non vengono collegate dove si sovrappongono."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(
            self.SNAP, tr("Tolleranza snap (m)"),
            QgsProcessingParameterNumber.Double, 1.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MINSEG, tr("Lunghezza minima segmento (m)"),
            QgsProcessingParameterNumber.Double, 0.2, minValue=0.0))
        self.addParameter(QgsProcessingParameterField(
            self.ONEWAY, tr("Campo senso unico (opz.)"),
            parentLayerParameterName=self.INPUT, optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("Rete preparata")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import network_prepare, net_layers
        from .core.gtfs_static import GtfsCancelled
        ctx = context.transformContext()
        source = self.parameterAsSource(parameters, self.INPUT, context)
        owf = self.parameterAsString(parameters, self.ONEWAY, context) or None
        if owf is None and "oneway" in [f.name() for f in source.fields()]:
            owf = "oneway"  # campo OSM: senza, i sensi unici si perdevano
        ids, levels, attrs = [], [], {}
        roads, dirs = _source_roads_dir(source, ctx, owf, ids=ids,
                                        levels=levels, attrs=attrs)
        if not roads:
            raise QgsProcessingException(tr("Nessuna geometria valida."))
        seg_src = []
        try:
            seg, sdir, stats = network_prepare.node_network(
                roads, self.parameterAsDouble(parameters, self.SNAP, context),
                self.parameterAsDouble(parameters, self.MINSEG, context),
                directions=dirs, levels=levels if any(levels) else None,
                sources=ids, src_out=seg_src,
                progress=lambda p: feedback.setProgress(int(p)),
                is_canceled=feedback.isCanceled)
        except GtfsCancelled:
            raise QgsProcessingException(tr("Calcolo annullato."))
        except ValueError as exc:
            raise QgsProcessingException(str(exc))
        result = net_layers.build_prepared_layer(
            seg, sdir, seg_src=seg_src, src_fields=source.fields(),
            src_attrs=attrs, stats=stats)
        feedback.pushInfo(network_prepare.prepare_summary(stats))
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class ShortestPathAlgorithm(QgsProcessingAlgorithm):
    ROADS, POINTS, ORDER, MODE, PAIRS, ONEWAY, SPEED_FIELD, DEF_SPEED, \
        FACTOR, OUTPUT = ("ROADS", "POINTS", "ORDER", "MODE", "PAIRS",
                          "ONEWAY", "SPEED_FIELD", "DEF_SPEED", "FACTOR",
                          "OUTPUT")

    def name(self):
        return "shortestpath"

    def displayName(self):
        return tr("Percorso più breve / più veloce")

    def group(self):
        return tr("Rete stradale")

    def groupId(self):
        return "rete"

    def createInstance(self):
        return ShortestPathAlgorithm()

    def shortHelpString(self):
        return (tr("Percorsi fra due o più punti, in sequenza o fra tutte le "
                "coppie. Più breve = distanza minima; più veloce = tempo "
                "minimo con la velocità di ogni strada: campo indicato, "
                "altrimenti il limite OSM (maxspeed), altrimenti un valore "
                "tipico per tipo di strada (highway), altrimenti la velocità "
                "di default, per il fattore. Il più veloce esclude le strade "
                "dove le auto non passano. Output: un percorso per coppia con "
                "lunghezza e tempo."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, tr("Punti"), [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterField(
            self.ORDER, tr("Campo ordine (opz.)"),
            parentLayerParameterName=self.POINTS, optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.MODE, tr("Percorso"), [tr("Più breve (distanza)"),
                                    tr("Più veloce (tempo)")], defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.PAIRS, tr("Collegamento"), [tr("In sequenza"), tr("Tutte le coppie")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterBoolean(
            self.ONEWAY, tr("Rispetta i sensi unici (campo oneway)"), True))
        self.addParameter(QgsProcessingParameterField(
            self.SPEED_FIELD, tr("Campo velocità km/h (opz.)"),
            parentLayerParameterName=self.ROADS, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEF_SPEED, tr("Velocità se manca il limite (km/h)"),
            QgsProcessingParameterNumber.Double, 50.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.FACTOR, tr("Velocità effettiva (% del limite)"),
            QgsProcessingParameterNumber.Double, 100.0, minValue=10.0))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("Percorsi")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import routing, net_layers, isochrones
        from .core.gtfs_static import GtfsCancelled
        ctx = context.transformContext()
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        psrc = self.parameterAsSource(parameters, self.POINTS, context)
        order = self.parameterAsString(parameters, self.ORDER, context) or None
        mode = ["shortest", "fastest"][
            self.parameterAsEnum(parameters, self.MODE, context)]
        pairs = ["sequence", "all"][
            self.parameterAsEnum(parameters, self.PAIRS, context)]
        ctp = QgsCoordinateTransform(psrc.sourceCrs(), isochrones.WGS84, ctx)
        rows = []
        for k, f in enumerate(psrc.getFeatures()):
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ctp)
            p = g.centroid().asPoint()
            key = k
            if order:
                try:
                    key = float(f[order])
                except (TypeError, ValueError):
                    key = float("inf")
            rows.append((key, k, (p.y(), p.x())))
        rows.sort(key=lambda r: (r[0], r[1]))
        pts = [r[2] for r in rows]
        if len(pts) < 2:
            raise QgsProcessingException(tr("Servono almeno due punti."))
        speed_of = routing.speed_reader(
            [fl.name() for fl in rsrc.fields()],
            self.parameterAsString(parameters, self.SPEED_FIELD, context)
            or None,
            self.parameterAsDouble(parameters, self.DEF_SPEED, context),
            self.parameterAsDouble(parameters, self.FACTOR, context) / 100.0,
            walk_only_ways=(mode == "shortest"))
        ctr = QgsCoordinateTransform(rsrc.sourceCrs(), isochrones.WGS84, ctx)
        try:
            roads, dirs, speeds = routing.read_roads_for_routing(
                rsrc.getFeatures(), ctr,
                self.parameterAsBool(parameters, self.ONEWAY, context),
                speed_of, cars_only=(mode == "fastest"),
                is_canceled=feedback.isCanceled)
            legs = routing.compute_routes(
                roads, pts, mode, pairs, directions=dirs, speeds=speeds,
                progress=lambda p: feedback.setProgress(int(p)),
                is_canceled=feedback.isCanceled)
        except GtfsCancelled:
            raise QgsProcessingException(tr("Calcolo annullato."))
        except ValueError as exc:
            raise QgsProcessingException(str(exc))
        for leg in legs:
            if not leg["ok"]:
                feedback.pushInfo(tr("%d → %d: %s") % (leg["da"], leg["a"],
                                                    leg["msg"]))
        result = net_layers.build_routes_layer(legs, mode)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class NetworkDiagnosticsAlgorithm(QgsProcessingAlgorithm):
    ROADS, SOURCES, DESTS, SPEED, TIMES, SNAP_MAX = (
        "ROADS", "SOURCES", "DESTS", "SPEED", "TIMES", "SNAP_MAX")
    OUT_COMP, OUT_CROSS = "OUTPUT_COMPONENTS", "OUTPUT_CROSSINGS"

    def name(self):
        return "networkdiagnostics"

    def displayName(self):
        return tr("Diagnostica rete")

    def group(self):
        return tr("Rete stradale")

    def groupId(self):
        return "rete"

    def createInstance(self):
        return NetworkDiagnosticsAlgorithm()

    def shortHelpString(self):
        return (tr("Valida la rete: componenti scollegate, sorgenti/destinazioni "
                "non agganciate o isolate, incroci non noded. Output: componenti "
                "(linee) e incroci non noded (punti); i problemi nel Log."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.SOURCES, tr("Sorgenti (opz.)"), [QgsProcessing.TypeVectorPoint],
            optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.DESTS, tr("Destinazioni (opz.)"), [QgsProcessing.TypeVectorPoint],
            optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPEED, tr("Velocità (km/h)"),
            QgsProcessingParameterNumber.Double, 4.8, minValue=0.1))
        self.addParameter(QgsProcessingParameterString(
            self.TIMES, tr("Tempi (min)"), "5,10,15"))
        self.addParameter(QgsProcessingParameterNumber(
            self.SNAP_MAX, tr("Distanza max snap (m)"),
            QgsProcessingParameterNumber.Double, 500.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUT_COMP, tr("Componenti")))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUT_CROSS, tr("Incroci non noded")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import network_diagnostics as nd, net_layers
        ctx = context.transformContext()
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        levels = []
        roads, dirs = _source_roads_dir(rsrc, ctx, None, levels=levels)
        ssrc = self.parameterAsSource(parameters, self.SOURCES, context)
        dsrc = self.parameterAsSource(parameters, self.DESTS, context)
        sources = _source_points_latlon(ssrc, ctx) if ssrc else None
        dests = _source_points_latlon(dsrc, ctx) if dsrc else None
        times = _parse_times(self.parameterAsString(parameters, self.TIMES, context))
        rep = nd.diagnose_network(
            roads, sources_latlon=sources, dests_latlon=dests, times_min=times,
            speed_kmh=self.parameterAsDouble(parameters, self.SPEED, context),
            snap_max_m=self.parameterAsDouble(parameters, self.SNAP_MAX, context),
            progress=lambda p: feedback.setProgress(int(p)),
            levels=levels if any(levels) else None)
        for it in rep["issues"]:
            feedback.pushInfo("[%s] %s" % (it["severity"], it["message"]))
        comp = net_layers.build_components_layer(
            rep["segments"], rep["comp_of_seg"], rep["main_comp"])
        cross = net_layers.build_points_diag_layer(
            [(la, lo, {}) for la, lo in rep["crossings"]], "incroci")
        dc = _copy_to_sink(self, comp, parameters, context, self.OUT_COMP)
        dx = _copy_to_sink(self, cross, parameters, context, self.OUT_CROSS)
        return {self.OUT_COMP: dc, self.OUT_CROSS: dx}


class ScenarioCompareAlgorithm(QgsProcessingAlgorithm):
    ROADS_A, ROADS_B, ORIGINS, DESTS, WEIGHT, SPEED, TIMES, OUTPUT = (
        "ROADS_A", "ROADS_B", "ORIGINS", "DESTS", "WEIGHT", "SPEED",
        "TIMES", "OUTPUT")

    def name(self):
        return "scenariocompare"

    def displayName(self):
        return tr("Scenario A/B — accessibilità (rete)")

    def group(self):
        return tr("Accessibilità")

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return ScenarioCompareAlgorithm()

    def shortHelpString(self):
        return (tr("Confronta l'accessibilità cumulativa sulle stesse origini con "
                "due reti (A = stato attuale, B = progetto). Output: origini con "
                "a_value/b_value/delta/delta_pct/classe (gain/loss/unchanged)."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS_A, tr("Rete A"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS_B, tr("Rete B"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ORIGINS, tr("Origini"), [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.DESTS, tr("Destinazioni"),
            [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT, tr("Campo peso (opz.)"),
            parentLayerParameterName=self.DESTS, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPEED, tr("Velocità (km/h)"),
            QgsProcessingParameterNumber.Double, 4.5, minValue=0.1))
        self.addParameter(QgsProcessingParameterString(
            self.TIMES, tr("Tempi (min)"), "15,30"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("Scenario A/B")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import scenarios, net_layers
        ctx = context.transformContext()
        osrc = self.parameterAsSource(parameters, self.ORIGINS, context)
        dsrc = self.parameterAsSource(parameters, self.DESTS, context)
        ra = _source_roads(self.parameterAsSource(parameters, self.ROADS_A, context), ctx)
        rb = _source_roads(self.parameterAsSource(parameters, self.ROADS_B, context), ctx)
        wf = self.parameterAsString(parameters, self.WEIGHT, context) or None
        speed = self.parameterAsDouble(parameters, self.SPEED, context)
        times = _parse_times(self.parameterAsString(parameters, self.TIMES, context))
        if not times:
            raise QgsProcessingException(tr("Tempi non validi."))
        origins = [(la, lo) for la, lo, _ in _source_points_weighted(osrc, ctx)]
        dests = _source_points_weighted(dsrc, ctx, wf)
        if not origins or not dests:
            raise QgsProcessingException(tr("Origini/destinazioni vuote."))
        rows, t = scenarios.accessibility_ab(
            origins, dests, ra, rb, speed, times,
            progress=lambda p: feedback.setProgress(int(p)))
        s = scenarios.scenario_summary(rows)
        feedback.pushInfo(tr("Migliorate: %d, peggiorate: %d, invariate: %d; "
                          "delta medio %.2f (@%g min).")
                          % (s["migliorate"], s["peggiorate"], s["invariate"],
                             s["delta_medio"], t))
        mat = osrc.materialize(QgsFeatureRequest())
        result = net_layers.build_scenario_layer(mat, rows)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class ScenarioPtalAlgorithm(QgsProcessingAlgorithm):
    GTFS_A, GTFS_B, POINTS, START, END, DATE, OUTPUT = (
        "GTFS_A", "GTFS_B", "POINTS", "START", "END", "DATE", "OUTPUT")

    def name(self):
        return "scenarioptal"

    def displayName(self):
        return tr("Scenario A/B — PTAL (due GTFS)")

    def group(self):
        return tr("Accessibilità")

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return ScenarioPtalAlgorithm()

    def shortHelpString(self):
        return (tr("Confronta il PTAL sugli stessi punti con due feed GTFS "
                "(A = attuale, B = progetto). Output: punti con a_value/b_value "
                "(livello PTAL 0..8), delta e classe gain/loss/unchanged."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            self.GTFS_A, tr("Feed GTFS A (.zip)"), extension="zip"))
        self.addParameter(QgsProcessingParameterFile(
            self.GTFS_B, tr("Feed GTFS B (.zip)"), extension="zip"))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, tr("Punti di analisi"), [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterNumber(
            self.START, tr("Ora inizio"),
            QgsProcessingParameterNumber.Integer, 7, minValue=0, maxValue=23))
        self.addParameter(QgsProcessingParameterNumber(
            self.END, tr("Ora fine"),
            QgsProcessingParameterNumber.Integer, 10, minValue=1, maxValue=30))
        self.addParameter(QgsProcessingParameterString(
            self.DATE, tr("Data servizio YYYYMMDD (opz.)"), "", optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, tr("Scenario PTAL A/B")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import scenarios, net_layers
        ctx = context.transformContext()
        ga = self.parameterAsFile(parameters, self.GTFS_A, context)
        gb = self.parameterAsFile(parameters, self.GTFS_B, context)
        psrc = self.parameterAsSource(parameters, self.POINTS, context)
        start = self.parameterAsInt(parameters, self.START, context)
        end = self.parameterAsInt(parameters, self.END, context)
        date = self.parameterAsString(parameters, self.DATE, context).strip()
        date = date if (len(date) == 8 and date.isdigit()) else None
        coords = _source_points_latlon(psrc, ctx)
        if not coords:
            raise QgsProcessingException(tr("Nessun punto valido."))
        rows = scenarios.ptal_ab(
            coords, ga, gb, start, end, service_date=date,
            progress=lambda p: feedback.setProgress(int(p)))
        s = scenarios.scenario_summary(rows)
        feedback.pushInfo(tr("PTAL migliorato in %d punti, peggiorato in %d, "
                          "invariato in %d.") % (s["migliorate"], s["peggiorate"],
                                                s["invariate"]))
        mat = psrc.materialize(QgsFeatureRequest())
        result = net_layers.build_scenario_layer(mat, rows, tr("Scenario PTAL A/B"))
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class RoadOdMatrixAlgorithm(QgsProcessingAlgorithm):
    """Matrice tempi e distanze su strada (molti a molti)."""

    def name(self):
        return "roadodmatrix"

    def displayName(self):
        return tr("Matrice tempi e distanze su strada")

    def group(self):
        return tr("Accessibilità")

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return RoadOdMatrixAlgorithm()

    def shortHelpString(self):
        return (tr("Tempo e distanza sulla rete fra ogni origine e ogni "
                "destinazione (vuoto = le origini stesse), lungo il percorso "
                "più veloce. Piedi e bici a velocità unica (a piedi anche con "
                "la pendenza da un DEM), auto con il limite di ogni strada. "
                "Output: una linea per coppia raggiungibile (tempo_min, "
                "distanza_km, vel_kmh) e, se indicato, un file Excel con "
                "matrici, elenco delle coppie e parametri."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            "ORIGINS", tr("Origini"), [QgsProcessing.TypeVectorPoint,
                                   QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterField(
            "ORIGIN_ID", tr("Campo ID origini (opz.)"),
            parentLayerParameterName="ORIGINS", optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            "DESTS", tr("Destinazioni (opz., vuoto = origini)"),
            [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon],
            optional=True))
        self.addParameter(QgsProcessingParameterField(
            "DEST_ID", tr("Campo ID destinazioni (opz.)"),
            parentLayerParameterName="DESTS", optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            "ROADS", tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        _add_cost_params(self, "ROADS", [tr("Piedi"), tr("Bici"),
                                         tr("Auto (limite di ogni strada)")])
        self.addParameter(QgsProcessingParameterNumber(
            "MAX_MIN", tr("Tempo massimo (min, 0 = nessuno)"),
            QgsProcessingParameterNumber.Double, 0.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterFeatureSink(
            "OUTPUT", tr("Matrice OD (linee)"), QgsProcessing.TypeVectorLine))
        self.addParameter(QgsProcessingParameterFileDestination(
            "XLSX", tr("Excel (opz.)"), "Excel (*.xlsx)", optional=True,
            createByDefault=False))

    @staticmethod
    def _points(alg, parameters, context, key, id_key, ctx):
        from .core import isochrones, od_viz
        src = alg.parameterAsSource(parameters, key, context)
        if src is None:
            return None, None
        idf = alg.parameterAsString(parameters, id_key, context) or None
        ct = QgsCoordinateTransform(src.sourceCrs(), isochrones.WGS84, ctx)
        out = []
        for f in src.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            p = g.centroid().asPoint()
            out.append((od_viz.norm_id(f[idf] if idf else f.id()),
                        p.y(), p.x()))
        return src, out

    def processAlgorithm(self, parameters, context, feedback):
        from .core import od_road, net_iso, fifteen
        from .core.gtfs_tasks import read_costed_network
        from .core.gtfs_static import GtfsCancelled
        ctx = context.transformContext()
        osrc, O = self._points(self, parameters, context, "ORIGINS",
                               "ORIGIN_ID", ctx)
        _d, D = self._points(self, parameters, context, "DESTS", "DEST_ID",
                             ctx)
        if D is None:
            D = list(O)
        if not O or not D:
            raise QgsProcessingException(tr("Nessun punto valido."))
        if len(O) * len(D) > 1000000:
            raise QgsProcessingException(tr("Troppe coppie (al massimo un "
                                         "milione)."))
        rsrc = self.parameterAsSource(parameters, "ROADS", context)
        mode = self.parameterAsEnum(parameters, "MODE", context)
        try:
            cost, _vmax, desc = _cost_from_params(self, parameters, context,
                                                  rsrc, mode, ctx)
        except ValueError as exc:
            raise QgsProcessingException(str(exc))
        pts = [(la, lo) for _i, la, lo in O + D]
        diag = fifteen.haversine_m(min(p[0] for p in pts), min(p[1] for p in pts),
                                   max(p[0] for p in pts), max(p[1] for p in pts))
        clip = net_iso.reach_bbox(pts, max(2000.0, 0.3 * diag))
        oneway = self.parameterAsBool(parameters, "ONEWAY", context)
        spec = _road_source_spec(rsrc, ctx, oneway, clip)
        max_min = self.parameterAsDouble(parameters, "MAX_MIN", context) or None
        task = _FeedbackTask(feedback)
        try:
            roads, dirs, ec, _st, _cs = read_costed_network(spec, cost, task,
                                                            0, 35)
            res = od_road.road_od_matrix(
                roads, O, D, dirs, ec, max_min=max_min,
                progress=lambda p: feedback.setProgress(35 + int(0.6 * p)),
                is_canceled=feedback.isCanceled)
        except GtfsCancelled:
            raise QgsProcessingException(tr("Calcolo annullato."))
        except ValueError as exc:
            raise QgsProcessingException(str(exc))
        n_ok = sum(1 for row in res["time_s"] for t in row if t is not None)
        feedback.pushInfo(tr("Matrice %d × %d (%s): %d coppie raggiungibili, "
                          "motore %s.") % (len(O), len(D), desc, n_ok,
                                          res["engine"]))
        xlsx = self.parameterAsFileOutput(parameters, "XLSX", context)
        out = {}
        if xlsx:
            if not xlsx.lower().endswith(".xlsx"):
                xlsx += ".xlsx"
            od_road.write_excel(xlsx, [o[0] for o in O], [d[0] for d in D],
                                res, [(tr("Mezzo"), desc), (tr("Sensi unici"),
                                      "rispettati" if oneway else "ignorati"),
                                      (tr("Tempo massimo"), tr("%g min") % max_min
                                       if max_min else "nessuno")])
            out["XLSX"] = xlsx
        layer = od_road.build_lines_layer(O, D, res)
        out["OUTPUT"] = _copy_to_sink(self, layer, parameters, context,
                                      "OUTPUT")
        return out


class FifteenMinuteAlgorithm(QgsProcessingAlgorithm):
    """Città dei 15 minuti: servizi raggiungibili per zona o cella."""

    def name(self):
        return "fifteenminutes"

    def displayName(self):
        return tr("Città dei 15 minuti")

    def group(self):
        return tr("Accessibilità")

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return FifteenMinuteAlgorithm()

    def shortHelpString(self):
        return (tr("Per ogni zona (poligoni o punti) o cella di una griglia "
                "esagonale: il tempo sulla rete fino al servizio più vicino "
                "di ogni categoria (campo categoria dei servizi) e l'indice "
                "0–100 = quota di categorie raggiunte entro la soglia. Campi "
                "t_<categoria> (min), n_servizi, indice, t_tutti (tempo per "
                "averle tutte), mancanti. A piedi anche con la pendenza da "
                "un DEM (Tobler)."))

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            "ROADS", tr("Rete stradale"), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            "POIS", tr("Servizi"), [QgsProcessing.TypeVectorPoint,
                                QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterField(
            "CATEGORY", tr("Campo categoria dei servizi"),
            parentLayerParameterName="POIS"))
        self.addParameter(QgsProcessingParameterFeatureSource(
            "ZONES", tr("Zone o punti (opz., vuoto = griglia sulla rete)"),
            [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon],
            optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            "CELL", tr("Griglia: raggio della cella (m)"),
            QgsProcessingParameterNumber.Double, 150.0, minValue=25.0))
        self.addParameter(QgsProcessingParameterNumber(
            "MINUTES", tr("Soglia (min)"), QgsProcessingParameterNumber.Double,
            15.0, minValue=1.0))
        _add_cost_params(self, "ROADS", [tr("Piedi"), tr("Bici")], with_car=False)
        self.addParameter(QgsProcessingParameterFeatureSink(
            "OUTPUT", tr("Città dei 15 minuti")))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import fifteen, grid_gen, net_iso, isochrones
        from .core.gtfs_tasks import read_costed_network
        from .core.gtfs_static import GtfsCancelled
        ctx = context.transformContext()
        rsrc = self.parameterAsSource(parameters, "ROADS", context)
        psrc = self.parameterAsSource(parameters, "POIS", context)
        catf = self.parameterAsString(parameters, "CATEGORY", context)
        ctp = QgsCoordinateTransform(psrc.sourceCrs(), isochrones.WGS84, ctx)
        pois = []
        for f in psrc.getFeatures():
            g = f.geometry()
            c = f[catf]
            if g is None or g.isEmpty() or c is None or str(c).strip() in (
                    "", "NULL"):
                continue
            g = QgsGeometry(g)
            g.transform(ctp)
            p = g.pointOnSurface().asPoint()
            pois.append((p.y(), p.x(), str(c).strip()))
        cats = fifteen.order_categories({c for _a, _b, c in pois})
        if not cats:
            raise QgsProcessingException(tr("Nessun servizio con categoria."))
        if len(cats) > 25:
            raise QgsProcessingException(
                tr("Il campo categoria ha %d valori: scegli un campo con poche "
                "categorie.") % len(cats))
        zsrc = self.parameterAsSource(parameters, "ZONES", context)
        cells = None
        zmat = None
        if zsrc is not None:
            zmat = zsrc.materialize(QgsFeatureRequest())
            ctz = QgsCoordinateTransform(zmat.crs(), isochrones.WGS84, ctx)
            origins = []
            for f in zmat.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ctz)
                p = g.pointOnSurface().asPoint()
                origins.append((p.y(), p.x()))
        else:
            ext = QgsCoordinateTransform(rsrc.sourceCrs(), isochrones.WGS84,
                                         ctx).transformBoundingBox(
                rsrc.sourceExtent())
            origins, cells = grid_gen.build_grid(
                ext.yMinimum(), ext.yMaximum(), ext.xMinimum(),
                ext.xMaximum(),
                self.parameterAsDouble(parameters, "CELL", context), "hex")
        if not origins:
            raise QgsProcessingException(tr("Nessuna zona da analizzare."))
        if len(origins) > 60000:
            raise QgsProcessingException(tr("Troppe celle (%d): aumenta la "
                                         "cella.") % len(origins))
        mode = self.parameterAsEnum(parameters, "MODE", context)
        try:
            cost, vmax, desc = _cost_from_params(self, parameters, context,
                                                 rsrc, mode, ctx)
        except ValueError as exc:
            raise QgsProcessingException(str(exc))
        thr = self.parameterAsDouble(parameters, "MINUTES", context)
        max_s = max(2 * thr, thr + 15) * 60.0
        radius = vmax / 3.6 * max_s + 500.0
        spec = _road_source_spec(
            rsrc, ctx, self.parameterAsBool(parameters, "ONEWAY", context),
            net_iso.reach_bbox(origins, radius))
        task = _FeedbackTask(feedback)
        try:
            roads, dirs, ec, _st, _cs = read_costed_network(spec, cost, task,
                                                            0, 40)
            times, n_out, _np = fifteen.nearest_times(
                roads, dirs, ec, origins, pois, cats, max_s,
                progress=lambda p: feedback.setProgress(40 + int(0.6 * p)),
                is_canceled=feedback.isCanceled)
        except GtfsCancelled:
            raise QgsProcessingException(tr("Calcolo annullato."))
        except ValueError as exc:
            raise QgsProcessingException(str(exc))
        summ = fifteen.summarize(times, cats, thr * 60.0)
        K = len(cats)
        full = sum(1 for x in summ if x["n"] == K)
        feedback.pushInfo(tr("%d %s, %s, %d categorie: indice medio %.0f, con "
                          "tutti i servizi %d.") % (
                              len(summ), "celle" if cells else "zone", desc,
                              K, sum(x["indice"] for x in summ) / len(summ),
                              full))
        layer = fifteen.build_layer(cats, summ, thr, cells=cells,
                                    source_layer=zmat)
        return {"OUTPUT": _copy_to_sink(self, layer, parameters, context,
                                        "OUTPUT")}


class MicProvider(QgsProcessingProvider):
    def id(self):
        return "mic"

    def name(self):
        return "MIC - Utilities"

    def icon(self):
        return QIcon(self.svgIconPath())

    def svgIconPath(self):  # noqa: N802 (API QGIS)
        import os
        return os.path.join(os.path.dirname(__file__), "icon.svg")

    def loadAlgorithms(self):
        self.addAlgorithm(SpaceSyntaxAlgorithm())
        self.addAlgorithm(RoadLengthsAlgorithm())
        self.addAlgorithm(NetworkIsochronesAlgorithm())
        self.addAlgorithm(PtalAlgorithm())
        self.addAlgorithm(AccessibilityAlgorithm())
        self.addAlgorithm(PrepareNetworkAlgorithm())
        self.addAlgorithm(NetworkDiagnosticsAlgorithm())
        self.addAlgorithm(ShortestPathAlgorithm())
        self.addAlgorithm(ScenarioCompareAlgorithm())
        self.addAlgorithm(ScenarioPtalAlgorithm())
        self.addAlgorithm(RoadOdMatrixAlgorithm())
        self.addAlgorithm(FifteenMinuteAlgorithm())
