# -*- coding: utf-8 -*-
"""Report d'area: tutti i numeri in un file Excel (un foglio per sezione).

Usa XlsxWriter incluso nel plugin (vendor). Nessun oggetto QGIS.
"""
from ..i18n import tr
from .area_report import SECTION_LABEL, THRESHOLD_TEXT
from .excel_report import xlsxwriter


def write(path, res, meta):
    """Scrive l'Excel del report.

    :param res: risultato di area_report.compute.
    :param meta: [(etichetta, valore)] per il foglio Parametri (fonti,
        versione, data).
    """
    wb = xlsxwriter.Workbook(path, {"nan_inf_to_errors": True})
    head = wb.add_format({"bold": True, "bg_color": "#E8EEF4", "border": 1,
                          "text_wrap": True, "valign": "top"})
    num0 = wb.add_format({"num_format": "#,##0"})
    num1 = wb.add_format({"num_format": "#,##0.0"})
    num2 = wb.add_format({"num_format": "#,##0.00"})
    fills = {"verde": wb.add_format({"bg_color": "#DCFCE7"}),
             "giallo": wb.add_format({"bg_color": "#FEF9C3"}),
             "rosso": wb.add_format({"bg_color": "#FEE2E2"})}

    def sheet(name, headers, rows, widths=None, fmts=None):
        ws = wb.add_worksheet(name[:31])
        for c, h in enumerate(headers):
            ws.write(0, c, h, head)
        for r, row in enumerate(rows, start=1):
            for c, v in enumerate(row):
                if v is None:
                    continue
                f = fmts[c] if fmts and c < len(fmts) else None
                if isinstance(v, (int, float)) and f is not None:
                    ws.write_number(r, c, v, f)
                else:
                    ws.write(r, c, v)
        for c, w in enumerate(widths or [18] * len(headers)):
            ws.set_column(c, c, w)
        ws.freeze_panes(1, 0)
        return ws

    # sintesi
    ws = wb.add_worksheet(tr("Sintesi"))
    for c, h in enumerate((tr("Indicatore"), tr("Valore"), tr("Nota"), tr("Semaforo"))):
        ws.write(0, c, h, head)
    for r, cd in enumerate(res.get("summary", []), start=1):
        f = fills.get(cd.get("light"))
        ws.write(r, 0, cd["title"])
        ws.write(r, 1, cd["value"], f)
        ws.write(r, 2, cd["note"])
        ws.write(r, 3, cd.get("light") or "")
    ws.set_column(0, 0, 30)
    ws.set_column(1, 1, 16)
    ws.set_column(2, 2, 46)
    ws.set_column(3, 3, 10)
    ws.freeze_panes(1, 0)

    dm = res.get("demo")
    if dm:
        pa, pc = dm["profile"], dm["comune"]["profile"]
        com = dm["comune"]["nome"]
        ws = wb.add_worksheet(tr("Popolazione"))
        for c, h in enumerate((tr("Indicatore"), "Area", tr("Comune di %s") % com)):
            ws.write(0, c, h, head)
        rows = [(tr("Residenti"), pa["pop"], pc["pop"], num0),
                (tr("Famiglie"), pa["fam"], pc["fam"], num0),
                (tr("Abitazioni"), pa["abi"], pc["abi"], num0),
                (tr("Edifici residenziali"), pa["edi"], pc["edi"], num0),
                (tr("Superficie (km²)"), res["area_km2"], pc["area_km2"], num2)]
        rows += [("%s%s" % (lab, " (%s)" % unit if unit else ""), a, c,
                  (num0, num1, num2)[min(2, dec)])
                 for lab, a, c, unit, dec in dm["compare"]]
        for lab, key in ((tr("Occupati maschi 15-64 anni (%)"), "occ_m"),
                         (tr("Occupate femmine 15-64 anni (%)"), "occ_f")):
            rows.append((lab, pa.get(key), pc.get(key), num1))
        k = 1
        for lab, a, c, f in rows:
            ws.write(k, 0, lab)
            if a is not None:
                ws.write_number(k, 1, a, f)
            if c is not None:
                ws.write_number(k, 2, c, f)
            k += 1

        def block(k, title, cols, data, fmts):
            k += 1
            ws.write(k, 0, title, head)
            for c, h in enumerate(cols, start=1):
                ws.write(k, c, h, head)
            for row in data:
                k += 1
                ws.write(k, 0, row[0])
                for c, v in enumerate(row[1:], start=1):
                    if v is not None:
                        ws.write_number(k, c, v, fmts[c - 1])
            return k + 1

        tot_a = float(sum(m + f for _l, m, f in pa["age"]) or 1)
        tot_c = float(sum(m + f for _l, m, f in pc["age"]) or 1)
        k = block(k, tr("Classe di età"), [tr("Maschi"), tr("Femmine"), tr("% dell'area"),
                                       tr("% del comune")],
                  [(lab, m, f, 100.0 * (m + f) / tot_a,
                    100.0 * (cm + cf) / tot_c)
                   for (lab, m, f), (_l, cm, cf) in zip(pa["age"],
                                                        pc["age"])],
                  [num0, num0, num1, num1])
        for title, key in ((tr("Famiglie per componenti"), "families"),
                           (tr("Titolo di studio (9 anni e più)"), "education"),
                           (tr("Cittadinanza"), "citizenship"),
                           (tr("Abitazioni"), "dwellings")):
            k = block(k, title, [tr("Nell'area"), tr("% dell'area"), tr("% del comune")],
                      [(lab, n, sh, csh) for (lab, n, sh), (_l, _n, csh)
                       in zip(pa[key], pc[key])], [num0, num1, num1])
        ws.set_column(0, 0, 38)
        ws.set_column(1, 4, 16)
        ws.freeze_panes(1, 0)
        sheet(tr("Popolazione sezioni"),
              [tr("Sezione di censimento"), tr("Quota nell'area"),
               tr("Residenti nell'area"), tr("Residenti della sezione"), tr("Famiglie"),
               tr("Abitazioni"), tr("Edifici residenziali"), tr("Abitanti per ettaro"),
               "% 0-14 anni", tr("% 65 anni e più"), "% stranieri",
               tr("% titolo terziario"), "% occupati 15-64"],
              [(str(x["id"]), x["quota"], x["pop"] * x["quota"], x["pop"],
                x["fam"], x["abi"], x["edi"], x["dens_ha"], x["pct_0_14"],
                x["pct_65"], x["pct_stran"], x["pct_laurea"], x["occ"])
               for x in dm["sections"]],
              [20, 12, 12, 12, 10, 10, 10, 12, 10, 10, 10, 12, 12],
              [None, num2, num1, num0, num0, num0, num0, num1, num1, num1,
               num1, num1, num1])

    jobs = res.get("jobs")
    if jobs:
        tot = jobs["total"] or 1.0
        rows = [(tr("Addetti totali"), jobs["total"], 100.0),
                (tr("Imprese (addetti delle unità locali)"), jobs["im"],
                 100.0 * jobs["im"] / tot),
                (tr("Istituzioni pubbliche (dipendenti)"), jobs["ip"],
                 100.0 * jobs["ip"] / tot),
                (tr("Istituzioni non profit (dipendenti)"), jobs["np"],
                 100.0 * jobs["np"] / tot),
                (tr("Unità locali (indicativo)"), jobs["ul"], None),
                (tr("Sezioni 2011 con addetti"), jobs["sections"], None)]
        rows += [(tr("Settore: ") + lab, v, 100.0 * v / tot)
                 for lab, v in jobs["sectors"]]
        if res.get("pop"):
            rows.append((tr("Addetti ogni 100 residenti"),
                         100.0 * jobs["total"] / res["pop"], None))
        rows.append((tr("Fonte: ") + jobs.get("source", ""), None, None))
        sheet("Addetti 2011", [tr("Voce"), tr("Addetti"), "%"], rows, [52, 14, 10],
              [None, num0, num1])

    rete = res.get("rete")
    if rete:
        tot = sum(rete["lengths"].values()) or 1.0
        rows = [(t, m / 1000.0, 100.0 * m / tot)
                for t, m in rete["lengths"].items()]
        ws = sheet(tr("Rete"), [tr("Tipo di strada (%s)") % (rete.get("type_field")
                                                     or "tutte"),
                            "km", "%"], rows, [32, 12, 10],
                   [None, num2, num1])
        r0 = len(rows) + 3
        ws.write(r0, 0, tr("Indicatore"), head)
        ws.write(r0, 1, tr("Valore"), head)
        labels = [("total_length_km", tr("Lunghezza totale (km)"), num2),
                  ("area_km2", tr("Superficie (km²)"), num2),
                  ("density_km_per_km2", tr("Densità della rete (km/km²)"), num1),
                  ("junctions", tr("Incroci reali"), num0),
                  ("intersection_density_per_km2", tr("Incroci per km²"), num1),
                  ("dead_ends", tr("Vicoli ciechi"), num0),
                  ("connected_node_ratio", tr("Quota di nodi che sono incroci"),
                   num2),
                  ("unnoded_crossings", tr("Attraversamenti senza vertice "
                   "(da verificare)"), num0)]
        k = r0 + 1
        for key, lab, f in labels:
            v = rete["ratios"].get(key)
            if v is None:
                continue
            ws.write(k, 0, lab)
            ws.write_number(k, 1, v, f)
            k += 1

    pop = res.get("cell_pop")
    w = res.get("walk")
    if w:
        rows = []
        for i, r in enumerate(w["cells"]):
            la, lo = res["centroids"][i]
            rows.append((i + 1, la, lo, r["walkability"], r["n_incroci"],
                         r["int_density"], r["street_density"],
                         r["link_node"], r.get("grade_pct"),
                         pop[i] if pop else None))
        sheet(tr("Camminabilità"), [tr("Cella"), "Lat", "Lon", tr("Indice (0-100, "
                                "relativo fra le celle)"), tr("Incroci"),
                                "Incroci/km²", tr("km strade/km²"), "Link/nodi",
                                "Pendenza %", tr("Abitanti")], rows,
              [8, 11, 11, 18, 10, 12, 13, 10, 11, 11],
              [None, None, None, num1, num0, num1, num1, num2, num1, num0])

    tp = res.get("tp")
    if tp:
        rows = [(b, sc, sp) for b, sc, sp in tp["by_band"]]
        ws = sheet("PTAL", [tr("Fascia PTAL"), "% celle", "% popolazione"], rows,
                   [14, 12, 14], [None, num1, num1])
        r0 = len(rows) + 3
        for k, (lab, v) in enumerate((
                (tr("Fascia oraria"), tp.get("band_label", "")),
                (tr("Giorno di servizio"), tp.get("selection", "")),
                (tr("Fermate nell'area"), tp["n_stops"]),
                (tr("Linee che le servono"), tp["n_lines"]),
                (tr("Corse/ora (somma sulle fermate)"), round(tp["deps_h"], 1)),
                (tr("AI medio"), round(tp["mean_ai"], 2)),
                (tr("Fermata a portata: % delle celle (400 m bus e tram, "
                 "800 m metro e treno)"), tp.get("served_cells")),
                (tr("Fermata a portata: % dei residenti"), tp.get("served_pop")),
                (tr("Con 6 o più corse l'ora: % delle celle"),
                 tp.get("served6_cells")),
                (tr("Con 6 o più corse l'ora: % dei residenti"),
                 tp.get("served6_pop")))):
            if v is None:
                continue
            ws.write(r0 + k, 0, lab, head)
            ws.write(r0 + k, 1, v)
        cov = tp.get("coverage") or [(None, None, None, None)] * len(
            tp["cells"])
        rows = [(i + 1, res["centroids"][i][0], res["centroids"][i][1],
                 r["ai"], r["band"], pop[i] if pop else None, cov[i][0],
                 cov[i][1], cov[i][2])
                for i, r in enumerate(tp["cells"])]
        sheet(tr("PTAL celle"), [tr("Cella"), "Lat", "Lon", "AI", "PTAL", tr("Abitanti"),
                             tr("Fermata più vicina (m)"),
                             tr("Corse/ora raggiungibili"),
                             tr("Linee raggiungibili")],
              rows, [8, 11, 11, 10, 8, 11, 14, 14, 12],
              [None, None, None, num2, None, num0, num0, num1, num0])
        if tp.get("stops"):
            sheet(tr("Fermate"), [tr("Fermata"), "Lat", "Lon", tr("Linee"), "Corse/ora"],
                  tp["stops"], [16, 11, 11, 8, 10],
                  [None, None, None, num0, num1])

    iso = res.get("iso")
    if iso:
        cats = sorted({c for b in iso["bands"] for c in b["services"]})
        rows = [[b["t"], b["area_ha"], b["pop"]]
                + [b["services"].get(c, 0) for c in cats]
                for b in iso["bands"]]
        sheet(tr("Isocrone"), [tr("Minuti a piedi"), tr("Ettari"), tr("Abitanti")] + cats,
              rows, [14, 10, 11] + [14] * len(cats),
              [num0, num1, num0] + [num0] * len(cats))

    f = res.get("f15")
    if f:
        rows = [(r["categoria"], r["mediana_min"], r["celle_pct"],
                 r["pop_pct"]) for r in f["per_cat"]]
        sheet(tr("15 minuti"), [tr("Categoria"), tr("Minuti (mediana delle celle)"),
                            tr("% celle entro la soglia"),
                            tr("% popolazione entro la soglia")], rows,
              [26, 16, 16, 18], [None, num1, num1, num1])
        rows = []
        for i, s in enumerate(f["summary"]):
            la, lo = res["centroids"][i]
            rows.append([i + 1, la, lo, s["indice"], s["n"], s["t_tutti"],
                         s["mancanti"]] + list(s["tempi_min"]))
        sheet(tr("15 minuti celle"), [tr("Cella"), "Lat", "Lon", tr("Indice"), tr("Servizi"),
                                  tr("Minuti per averli tutti"), tr("Mancanti")]
              + [tr("min %s") % c for c in f["categories"]], rows,
              [8, 11, 11, 9, 9, 12, 30] + [12] * len(f["categories"]),
              [None, None, None, num1, num0, num1, None]
              + [num1] * len(f["categories"]))

    s = res.get("servizi")
    if s:
        sheet(tr("Servizi"), [tr("Categoria"), tr("Nell'area"), tr("Ogni 1 000 abitanti")],
              s["rows"], [26, 12, 18], [None, num0, num2])

    rows = list(meta)
    rows += [(tr("Soglia: ") + k, v) for k, v in THRESHOLD_TEXT.items()]
    rows += [(tr("Sezione saltata: ") + SECTION_LABEL.get(k, k), v)
             for k, v in res.get("skipped", {}).items()]
    rows += [(tr("Nota"), n) for n in res.get("notes", [])]
    sheet(tr("Parametri"), [tr("Voce"), tr("Valore")], rows, [40, 90])
    wb.close()
    return path
