# -*- coding: utf-8 -*-
"""Addetti ISTAT per sezione di censimento (Censimento dell'industria e dei
servizi 2011).

Gli addetti (posti di lavoro) per sezione esistono solo per il 2011: un
file nazionale (`dati-sce_2011.zip`, 22 MB) con una riga per tipo di
soggetto (imprese, istituzioni pubbliche, non profit) × sezione 2011 ×
gruppo ATECO, e le geometrie delle sezioni 2011 per regione. Le sezioni
2011 non coincidono con quelle 2021 e non c'è un raccordo ufficiale: qui
si usano le loro geometrie, come strato a sé.

Per confronto si legge anche il dato comunale recente dalle API SDMX
dell'ISTAT: addetti delle unità locali delle imprese (ASIA, 2024) e
dipendenti delle unità locali delle istituzioni pubbliche (2020).

Download, costruzione e lettura (`ensure_region`, `fetch`, `recent`) usano
solo GDAL e la libreria standard: sicuri in un task di background.
`build_layer`, `build_points_layer` e `apply_theme` vanno chiamati sul
thread principale.
"""
import csv
import io
import json
import os
import re
import shutil
import time
import zipfile

from . import istat

YEAR = 2011
SCE_URL = ("https://www.istat.it/storage/cartografia/variabili-censuarie/"
           "dati-sce_2011.zip")
BT_URL = ("https://www.istat.it/storage/cartografia/basi_territoriali/"
          "WGS_84_UTM/2011/R%02d_11_WGS84.zip")
SCE_MEMBER = "Dati_SCE_2011/Sez_AttivitaEconomica/%02d_AttEcon_SCE_2011.txt"
SOURCE = ("ISTAT – 9° Censimento dell'industria e dei servizi 2011, dati "
          "per sezione di censimento; Basi territoriali 2011 (CC BY 4.0)")
SCHEMA = 1

# dato comunale recente (API SDMX dell'ISTAT)
SDMX = "https://esploradati.istat.it/SDMXWS/rest/data/"
ASIA_YEAR = 2024
ASIA_KEY = ("IT1,183_285_DF_DICA_ASIAULP_3,1.0/A..LU+LUEMPDAA.0010.TOTAL"
            "?startPeriod=%d&endPeriod=%d" % (ASIA_YEAR, ASIA_YEAR))
IP_YEAR = 2020
IP_KEY = ("IT1,741_1099_DF_DICA_IPSTRULCOM_9,1.0/"
          "A..LUAPIEMP.0010.TOT.ALL.TOT.9.N1_GE.9"
          "?startPeriod=%d&endPeriod=%d" % (IP_YEAR, IP_YEAR))
RECENT_SOURCE = ("ISTAT – Registro delle unità locali ASIA %d e censimento "
                 "permanente delle istituzioni pubbliche %d"
                 % (ASIA_YEAR, IP_YEAR))

# file dei dati per regione (il Trentino-Alto Adige è diviso in Bolzano e
# Trento; le sue geometrie invece sono in un file solo)
SCE_FILES = {4: (21, 22)}

# settori: divisioni ATECO (prime due cifre del gruppo a tre cifre)
SECTORS = [
    ("S_AGR", "Agricoltura e pesca", "#65a30d", range(1, 4)),
    ("S_IND", "Industria", "#475569", range(5, 40)),
    ("S_COS", "Costruzioni", "#a16207", range(41, 44)),
    ("S_COM", "Commercio", "#ea580c", range(45, 48)),
    ("S_TRA", "Trasporti e logistica", "#0891b2", range(49, 54)),
    ("S_ALL", "Alloggio e ristorazione", "#db2777", range(55, 57)),
    ("S_SER", "Servizi alle imprese, finanza, ICT", "#4f46e5",
     range(58, 83)),
    ("S_PUB", "Pubblica amministrazione, istruzione, sanità", "#16a34a",
     range(84, 89)),
    ("S_ALT", "Altri servizi", "#9333ea", range(90, 100)),
]
SECTOR_LABEL = {k: lab for k, lab, _c, _r in SECTORS}
_DIVISION = {}
for _k, _lab, _col, _rng in SECTORS:
    for _d in _rng:
        _DIVISION[_d] = _k

TYPES = [("IM", "Imprese"), ("IP", "Istituzioni pubbliche"),
         ("NP", "Istituzioni non profit")]
FIELDS = (["SEZ2011", "PRO_COM", "ADD_TOT", "ADD_IM", "ADD_IP", "ADD_NP",
           "UL_TOT", "ALTRI_RETR", "VOLONTARI"]
          + [k for k, _l, _c, _r in SECTORS] + ["AREA_M2"])
LABELS = {
    "SEZ2011": "Codice della sezione di censimento 2011",
    "PRO_COM": "Codice ISTAT del comune al 2011",
    "COMUNE": "Comune (nome attuale, se il codice non è cambiato)",
    "ADD_TOT": "Addetti 2011 (imprese + istituzioni pubbliche + non profit)",
    "ADD_IM": "Addetti delle unità locali delle imprese",
    "ADD_IP": "Dipendenti delle unità locali delle istituzioni pubbliche",
    "ADD_NP": "Dipendenti delle unità locali delle istituzioni non profit",
    "UL_TOT": "Unità locali (indicativo)",
    "ALTRI_RETR": "Altri lavoratori retribuiti (istituzioni)",
    "VOLONTARI": "Volontari (non profit)",
    "ADD_HA": "Addetti per ettaro",
    "SETTORE": "Settore con più addetti",
    "AREA_HA": "Superficie (ettari)",
    "QUOTA": "Quota della sezione dentro l'area (0-1)",
}
LABELS.update({k: "Addetti: " + lab.lower() for k, lab, _c, _r in SECTORS})

# temi della mappa: (chiave, voce, campo, decimali, chiaro, scuro)
THEMES = [
    ("dens", "Addetti per ettaro", "ADD_HA", 0, "#fff7ed", "#9a3412"),
    ("tot", "Addetti per sezione", "ADD_TOT", 0, "#fff7ed", "#9a3412"),
    ("im", "Addetti delle imprese", "ADD_IM", 0, "#eef2ff", "#3730a3"),
    ("ip", "Dipendenti pubblici", "ADD_IP", 0, "#f0fdf4", "#166534"),
    ("set", "Settore con più addetti", "SETTORE", 0, None, None),
]


# ---------------------------------------------------------------- cache
def gpkg_path(code):
    return os.path.join(istat.cache_dir(), "addetti%d_R%02d_v%d.gpkg" % (
        YEAR, code, SCHEMA))


def _meta_path(code):
    return gpkg_path(code)[:-5] + ".json"


def sce_path():
    return os.path.join(istat.cache_dir(), "sce2011.zip")


def region_state(code):
    p, m = gpkg_path(code), _meta_path(code)
    if not (os.path.exists(p) and os.path.exists(m)):
        return None
    try:
        with open(m, encoding="utf-8") as fh:
            meta = json.load(fh)
    except Exception:
        return None
    meta["size"] = os.path.getsize(p)
    return meta


def cached_size():
    """Byte occupati dai dati degli addetti (regioni, file nazionale,
    dati comunali recenti)."""
    d = istat.cache_dir()
    tot = 0
    for fn in os.listdir(d):
        if re.match(r"^(addetti\d{4}_R\d\d_v\d+\.(gpkg|json)|sce2011\.zip"
                    r"|asia_ul_\d{4}\.csv|ip_ul_\d{4}\.csv)$", fn):
            tot += os.path.getsize(os.path.join(d, fn))
    return tot


CACHE_PATTERN = (r"addetti\d{4}_R\d\d_v\d+(_build)?\.(gpkg|json)|sce2011\.zip"
                 r"|R\d\d_11_WGS84\.zip|asia_ul_\d{4}\.csv|ip_ul_\d{4}\.csv")


# ------------------------------------------------------------- download
def _zip_ok(path, member=None):
    try:
        with zipfile.ZipFile(path) as z:
            return member is None or member in z.namelist()
    except Exception:
        return False


def ensure_sce(progress=None, is_canceled=None):
    """Il file nazionale degli addetti 2011 (22 MB), scaricato una volta."""
    path = sce_path()
    if os.path.exists(path) and _zip_ok(path):
        return path
    istat._download(SCE_URL, path, istat._span(progress, 0, 1),
                    is_canceled)
    if not _zip_ok(path):
        istat._remove(path)
        raise RuntimeError("il file ISTAT degli addetti non si legge: "
                           "riprova")
    return path


def division_sector(ateco3):
    """Settore (chiave di SECTORS) dal gruppo ATECO a tre cifre."""
    try:
        return _DIVISION.get(int(str(ateco3).strip()[:2]))
    except ValueError:
        return None


def read_sce(zip_path, code, is_canceled=None):
    """Addetti 2011 della regione per sezione: {SEZ2011: valori} con i
    valori nell'ordine ADD_IM, ADD_IP, ADD_NP, UL_TOT, ALTRI_RETR,
    VOLONTARI, settori."""
    nsec = len(SECTORS)
    sec_ix = {k: i for i, (k, _l, _c, _r) in enumerate(SECTORS)}
    out = {}
    with zipfile.ZipFile(zip_path) as z:
        names = set(z.namelist())
        for fcode in SCE_FILES.get(code, (code,)):
            member = SCE_MEMBER % fcode
            if member not in names:
                raise RuntimeError("addetti della regione %s assenti nel "
                                   "file ISTAT" % istat.REGIONS.get(code))
            with z.open(member) as raw:
                f = io.TextIOWrapper(raw, encoding="ascii",
                                     errors="replace", newline="")
                head = f.readline().strip().split(";")
                ix = {h.strip().upper(): i for i, h in enumerate(head)}
                need = ("TIPO_SOGGETTO", "PROCOM", "NSEZ", "ATECO3",
                        "NUM_UNITA", "ADDETTI")
                if any(k not in ix for k in need):
                    raise RuntimeError("file ISTAT degli addetti con "
                                       "colonne inattese")
                i_t, i_pc, i_ns, i_at, i_ul, i_ad = (ix[k] for k in need)
                i_ar = ix.get("ALTRI_RETRIB")
                i_vo = ix.get("VOLONTARI")
                for k, line in enumerate(f):
                    if k % 20000 == 0:
                        istat._check(is_canceled)
                    p = line.rstrip("\r\n").split(";")
                    if len(p) <= max(i_t, i_pc, i_ns, i_at, i_ul, i_ad):
                        continue
                    try:
                        sez = int(p[i_pc]) * 10000000 + int(p[i_ns])
                    except ValueError:
                        continue
                    v = out.get(sez)
                    if v is None:
                        v = out[sez] = [0] * (6 + nsec)
                    add = istat._int(p[i_ad])
                    t = p[i_t].strip().upper()
                    if t == "IM":
                        v[0] += add
                    elif t == "IP":
                        v[1] += add
                    elif t == "NP":
                        v[2] += add
                    else:
                        continue
                    v[3] += istat._int(p[i_ul])
                    if i_ar is not None and len(p) > i_ar:
                        v[4] += istat._int(p[i_ar])
                    if i_vo is not None and len(p) > i_vo:
                        v[5] += istat._int(p[i_vo])
                    s = division_sector(p[i_at])
                    if s is not None:
                        v[6 + sec_ix[s]] += add
    return out


def _extract_bt(zpath, tmp):
    shp = None
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            name = os.path.basename(info.filename)
            if not re.match(r"^r\d\d_11_wgs84\.(shp|shx|dbf|prj|cpg)$",
                            name.lower()):
                continue
            out = os.path.join(tmp, name)
            with z.open(info) as src, open(out, "wb") as dst:
                shutil.copyfileobj(src, dst)
            if name.lower().endswith(".shp"):
                shp = out
    if not shp:
        raise RuntimeError("archivio ISTAT delle sezioni 2011 con una "
                           "struttura inattesa")
    return shp


def _build_gpkg(shp, table, out, step, is_canceled):
    """Sezioni 2011 con gli addetti in un GeoPackage (layer «sezioni2011»).
    Le sezioni senza righe nel file degli addetti valgono 0."""
    from osgeo import gdal, ogr
    src = ogr.Open(shp)
    if src is None:
        raise RuntimeError("le sezioni 2011 scaricate non si aprono")
    sl = src.GetLayer(0)
    sd = sl.GetLayerDefn()
    names = {sd.GetFieldDefn(i).GetName().upper(): i
             for i in range(sd.GetFieldCount())}
    if "SEZ2011" not in names:
        raise RuntimeError("sezioni ISTAT 2011 senza il campo SEZ2011")
    istat._remove(out)
    dst = ogr.GetDriverByName("GPKG").CreateDataSource(out)
    if dst is None:
        raise RuntimeError("impossibile scrivere nella cache: %s" % out)
    dl = dst.CreateLayer("sezioni2011", sl.GetSpatialRef(),
                         ogr.wkbMultiPolygon)
    for name in FIELDS:
        kind = (ogr.OFTInteger64 if name == "SEZ2011" else
                ogr.OFTReal if name == "AREA_M2" else ogr.OFTInteger)
        dl.CreateField(ogr.FieldDefn(name, kind))
    dd = dl.GetLayerDefn()
    i_sez = names["SEZ2011"]
    i_pc = names.get("PRO_COM")
    zero = [0] * (6 + len(SECTORS))
    total = max(1, sl.GetFeatureCount())
    n = fixed = matched = 0
    tot = [0, 0, 0]
    seen = set()
    dl.StartTransaction()
    gdal.PushErrorHandler("CPLQuietErrorHandler")
    try:
        for k, f in enumerate(sl):
            if k % 500 == 0:
                istat._check(is_canceled)
                step(k / float(total))
            g = f.GetGeometryRef()
            if g is None or g.IsEmpty():
                continue
            if not g.IsValid():
                g = g.MakeValid()
                fixed += 1
                if g is None:
                    continue
            g = istat._multipolygon(g)
            if g is None:
                continue
            try:
                sez = int(float(f.GetField(i_sez)))
            except (TypeError, ValueError):
                continue
            pc = sez // 10000000
            if i_pc is not None and f.GetField(i_pc) is not None:
                pc = int(float(f.GetField(i_pc)))
            v = table.get(sez)
            if v is not None:
                matched += 1
                seen.add(sez)
            else:
                v = zero
            o = ogr.Feature(dd)
            o.SetGeometry(g)
            o.SetField("SEZ2011", sez)
            o.SetField("PRO_COM", pc)
            o.SetField("ADD_TOT", v[0] + v[1] + v[2])
            for name, x in zip(FIELDS[3:-1], v):
                o.SetField(name, x)
            o.SetField("AREA_M2", g.GetArea())
            dl.CreateFeature(o)
            n += 1
            tot[0] += v[0]
            tot[1] += v[1]
            tot[2] += v[2]
        dl.CommitTransaction()
    except BaseException:
        dl.RollbackTransaction()
        dl = None
        dst = None
        src = None
        raise
    finally:
        gdal.PopErrorHandler()
    dst.ExecuteSQL("CREATE INDEX idx_sez11_pro_com ON sezioni2011 "
                   "(PRO_COM)")
    dl = None
    dst = None
    src = None
    lost = sum(sum(table[s][:3]) for s in table if s not in seen)
    return {"sections": n, "with_jobs": matched, "fixed": fixed,
            "add_im": tot[0], "add_ip": tot[1], "add_np": tot[2],
            "unmatched": len(table) - len(seen), "unmatched_jobs": lost}


def ensure_region(code, progress=None, is_canceled=None):
    """Mette in cache gli addetti 2011 della regione (se mancano) e
    ritorna il percorso del GeoPackage.

    :raises istat.Cancelled: annullato.
    """
    if code not in istat.REGIONS:
        raise ValueError("codice di regione non valido: %s" % code)
    path = gpkg_path(code)
    if region_state(code) is not None:
        return path
    d = istat.cache_dir()
    sce = ensure_sce(istat._span(progress, 0, 30), is_canceled)
    zpath = os.path.join(d, "R%02d_11_WGS84.zip" % code)
    tmp = os.path.join(d, "tmp_R%02d_11" % code)
    build = path[:-5] + "_build.gpkg"
    try:
        istat._download(BT_URL % code, zpath, istat._span(progress, 30, 65),
                        is_canceled)
        shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)
        shp = _extract_bt(zpath, tmp)
        table = read_sce(sce, code, is_canceled)
        meta = _build_gpkg(shp, table, build,
                           istat._span(progress, 70, 99), is_canceled)
        istat._remove(path)
        os.replace(build, path)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        for p in (zpath, build, build + "-journal"):
            istat._remove(p)
    meta.update({"code": code, "year": YEAR, "ts": time.time()})
    with open(_meta_path(code), "w", encoding="utf-8") as fh:
        json.dump(meta, fh)
    if progress:
        progress(100)
    return path


# --------------------------------------------------------------- lettura
def read_sections(code, rect=None, wkt=None, pro_com=None, point_in=None,
                  wgs84=False, is_canceled=None):
    """Sezioni 2011 della regione in cache: del comune `pro_com` (codice
    2011), o che toccano il poligono `wkt` / il riquadro `rect` (WGS84,
    con la quota dentro l'area), o il cui punto interno cade nel poligono
    `point_in` (WKB in EPSG:32632, quota 1).

    :return: (campi, righe) con righe = [(geometria, quota, valori)] come
        in istat.read_sections (campi = FIELDS).
    """
    from osgeo import ogr
    ds = ogr.Open(gpkg_path(code))
    lay = ds.GetLayerByName("sezioni2011") if ds is not None else None
    if lay is None:
        raise RuntimeError("addetti ISTAT di %s non leggibili: cancella i "
                           "dati scaricati e riprova"
                           % istat.REGIONS.get(code, code))
    to_l, to_w = istat._transforms(lay.GetSpatialRef())
    area = None
    inside = None
    if pro_com is not None:
        codes = pro_com if isinstance(pro_com, (list, tuple, set)) \
            else [pro_com]
        lay.SetAttributeFilter("PRO_COM IN (%s)" % ",".join(
            str(int(c)) for c in codes))
    elif point_in is not None:
        inside = ogr.CreateGeometryFromWkb(point_in)
        lay.SetSpatialFilter(inside)
    elif wkt or rect:
        if wkt:
            area = ogr.CreateGeometryFromWkt(wkt)
        else:
            w, s, e, n = rect
            area = ogr.CreateGeometryFromWkt(
                "POLYGON((%r %r,%r %r,%r %r,%r %r,%r %r))" % (
                    w, s, e, s, e, n, w, n, w, s))
        area.Segmentize(0.02)
        area.Transform(to_l)
        if not area.IsValid():
            area = area.MakeValid()
        lay.SetSpatialFilter(area)
    dd = lay.GetLayerDefn()
    idx = [dd.GetFieldIndex(k) for k in FIELDS]
    rows = []
    for k, f in enumerate(lay):
        if k % 500 == 0:
            istat._check(is_canceled)
        g = f.GetGeometryRef()
        if g is None:
            continue
        share = 1.0
        if inside is not None:
            pt = g.PointOnSurface()
            if pt is None or not pt.Within(inside):
                continue
        elif area is not None:
            if not g.Intersects(area):
                continue
            a = g.GetArea()
            inter = g.Intersection(area)
            share = min(1.0, inter.GetArea() / a) if a > 0 and \
                inter is not None else 0.0
            if share <= 0:
                continue
        vals = [f.GetField(i) if i >= 0 else None for i in idx]
        if wgs84:
            g = g.Clone()
            g.Transform(to_w)
            geom = g.ExportToWkt()
        else:
            geom = bytes(g.ExportToWkb())
        rows.append((geom, share, vals))
    lay = None
    ds = None
    return list(FIELDS), rows


def _comune_shape(pro_com, progress=None, is_canceled=None):
    """Il comune (confini 2021) come unione delle sue sezioni 2021, WKB in
    EPSG:32632: serve per i comuni nati o ricodificati dopo il 2011."""
    from osgeo import ogr
    c = istat._comuni_index().get(int(pro_com))
    if c is None:
        return None
    istat.ensure_region(c["reg"], False, progress, is_canceled)
    _f, rows = istat.read_sections(c["reg"], pro_com=pro_com,
                                   indicators=False,
                                   is_canceled=is_canceled)
    u = None
    for wkb, _q, _v in rows:
        g = ogr.CreateGeometryFromWkb(wkb)
        u = g if u is None else u.Union(g)
    return bytes(u.ExportToWkb()) if u is not None else None


def _same_extent(rows, bbox, wgs84, tol=0.006):
    """True se le sezioni 2011 con il codice del comune coprono lo stesso
    riquadro del comune 2021 (W, S, E, N in WGS84), a meno di `tol` gradi
    (circa 500 m): altrimenti il comune è cambiato (per esempio ha
    incorporato un comune vicino mantenendo il codice)."""
    from osgeo import ogr, osr
    env = None
    for g, _q, _v in rows:
        geom = (ogr.CreateGeometryFromWkt(g) if wgs84
                else ogr.CreateGeometryFromWkb(g))
        e = geom.GetEnvelope()
        env = e if env is None else (min(env[0], e[0]), max(env[1], e[1]),
                                     min(env[2], e[2]), max(env[3], e[3]))
    if env is None:
        return False
    if not wgs84:
        loc = osr.SpatialReference()
        loc.ImportFromEPSG(istat.EPSG)
        _to_l, to_w = istat._transforms(loc)
        ring = ogr.CreateGeometryFromWkt(
            "POLYGON((%r %r,%r %r,%r %r,%r %r,%r %r))" % (
                env[0], env[2], env[1], env[2], env[1], env[3], env[0],
                env[3], env[0], env[2]))
        ring.Segmentize(500.0)
        ring.Transform(to_w)
        env = ring.GetEnvelope()
    w, e, s, n = env
    bw, bs, be, bn = bbox
    return (abs(w - bw) <= tol and abs(e - be) <= tol
            and abs(s - bs) <= tol and abs(n - bn) <= tol)


def fetch(rect=None, wkt=None, pro_com=None, wgs84=False, progress=None,
          is_canceled=None):
    """Scarica le regioni che servono e legge le sezioni 2011 di un comune
    (codice 2021) o di un'area.

    Per un comune: le sezioni 2011 con lo stesso codice; se il comune è
    nato o ha cambiato codice dopo il 2011, quelle il cui punto interno
    cade nei suoi confini 2021.

    :return: dict con fields, rows, regions, notes, by_point (True se il
        comune è stato ricostruito dai confini); None se annullato.
    """
    out = {"fields": list(FIELDS), "rows": [], "regions": [], "notes": [],
           "by_point": False}
    try:
        if pro_com is not None:
            c = istat._comuni_index().get(int(pro_com))
            if c is None:
                raise ValueError("comune %s sconosciuto" % pro_com)
            out["regions"] = [c["reg"]]
            ensure_region(c["reg"], istat._span(progress, 0, 85),
                          is_canceled)
            _f, rows = read_sections(c["reg"], pro_com=pro_com,
                                     wgs84=wgs84, is_canceled=is_canceled)
            if not rows or not _same_extent(rows, c["bbox"], wgs84):
                # comune nato, ricodificato o allargato dopo il 2011: le
                # sezioni 2011 il cui punto interno cade nei confini 2021
                shape = _comune_shape(pro_com, None, is_canceled)
                if shape is not None:
                    out["by_point"] = True
                    _f, rows = read_sections(c["reg"], point_in=shape,
                                             wgs84=wgs84,
                                             is_canceled=is_canceled)
            out["rows"] = rows
        else:
            box = istat._bbox_of_wkt(wkt) if wkt else rect
            if box is None:
                raise ValueError("indica un comune o un'area")
            regions = istat.regions_for_bbox(*box)
            out["regions"] = regions
            for k, code in enumerate(regions):
                ensure_region(code, istat._span(
                    progress, 85.0 * k / len(regions),
                    85.0 * (k + 1) / len(regions)), is_canceled)
                _f, rows = read_sections(code, rect, wkt, None, None,
                                         wgs84, is_canceled)
                out["rows"] += rows
    except istat.Cancelled:
        return None
    if progress:
        progress(100)
    return out


# -------------------------------------------------------- dato recente
def _sdmx_get(url, path, is_canceled=None):
    """Risposta CSV di una richiesta SDMX salvata in path. Il server può
    impiegare oltre un minuto prima di rispondere."""
    import urllib.error
    import urllib.request
    h = dict(istat.HEADERS)
    h["Accept"] = "application/vnd.sdmx.data+csv;version=1.0.0"
    part = path + ".part"
    try:
        resp = urllib.request.urlopen(urllib.request.Request(url, headers=h),
                                      timeout=300)
    except urllib.error.HTTPError as exc:
        raise RuntimeError("l'ISTAT ha risposto con l'errore %s" % exc.code)
    except (urllib.error.URLError, OSError) as exc:
        raise RuntimeError("l'ISTAT non risponde (%s)"
                           % getattr(exc, "reason", exc))
    try:
        with open(part, "wb") as fh:
            for chunk in istat._chunks(resp, is_canceled):
                fh.write(chunk)
        os.replace(part, path)
    finally:
        resp.close()
        istat._remove(part)


def _read_sdmx(path, data_type, year):
    """{codice comune (int): valore} da un CSV SDMX."""
    out = {}
    with open(path, encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            area = (r.get("REF_AREA") or "").strip()
            if len(area) != 6 or not area.isdigit():
                continue
            if (r.get("DATA_TYPE") or "").strip() != data_type:
                continue
            if (r.get("TIME_PERIOD") or "").strip()[:4] != str(year):
                continue
            try:
                out[int(area)] = float(r.get("OBS_VALUE") or 0)
            except ValueError:
                continue
    return out


def recent_path(kind):
    if kind == "asia":
        return os.path.join(istat.cache_dir(), "asia_ul_%d.csv" % ASIA_YEAR)
    return os.path.join(istat.cache_dir(), "ip_ul_%d.csv" % IP_YEAR)


def recent(pro_coms, progress=None, is_canceled=None):
    """Dato comunale recente per i comuni indicati: {codice: {"asia":
    addetti delle imprese ASIA_YEAR, "asia_ul": unità locali, "ip":
    dipendenti pubblici IP_YEAR}}. Scarica una volta i dati di tutti i
    comuni (2 + 1 MB; la richiesta delle istituzioni pubbliche può durare
    oltre un minuto). Un comune senza righe vale 0 (nessuna unità
    locale)."""
    paths = {}
    for k, (kind, key) in enumerate((("asia", ASIA_KEY), ("ip", IP_KEY))):
        p = recent_path(kind)
        if not os.path.exists(p) or os.path.getsize(p) < 1000:
            _sdmx_get(SDMX + key, p, is_canceled)
        paths[kind] = p
        if progress:
            progress(50.0 * (k + 1))
    asia = _read_sdmx(paths["asia"], "LUEMPDAA", ASIA_YEAR)
    asia_ul = _read_sdmx(paths["asia"], "LU", ASIA_YEAR)
    ip = _read_sdmx(paths["ip"], "LUAPIEMP", IP_YEAR)
    if not asia or not ip:
        for p in paths.values():
            istat._remove(p)
        raise RuntimeError("risposta ISTAT senza dati comunali: riprova")
    out = {}
    for pc in pro_coms:
        pc = int(pc)
        if pc not in asia and pc not in ip:
            # codice che non c'è più (fusione o ricodifica dopo il 2011)
            out[pc] = {"asia": None, "asia_ul": None, "ip": None}
        else:
            out[pc] = {"asia": asia.get(pc, 0.0),
                       "asia_ul": asia_ul.get(pc, 0.0),
                       "ip": ip.get(pc, 0.0)}
    return out


# -------------------------------------------------------------- riepilogo
def totals(data):
    """Somme pesate con la quota di ogni sezione: dict campo → totale, più
    «_sections», «_with_jobs» e «by_comune» (addetti per comune 2011)."""
    f = data["fields"]
    ix = {k: i for i, k in enumerate(f)}
    keys = [k for k in f if k not in ("SEZ2011", "PRO_COM")]
    out = {k: 0.0 for k in keys}
    by = {}
    with_jobs = 0
    for _g, q, v in data["rows"]:
        for k in keys:
            x = v[ix[k]]
            if x:
                out[k] += q * x
        if v[ix["ADD_TOT"]]:
            with_jobs += 1
            pc = v[ix["PRO_COM"]]
            by[pc] = by.get(pc, 0.0) + q * v[ix["ADD_TOT"]]
    out["_sections"] = len(data["rows"])
    out["_with_jobs"] = with_jobs
    out["by_comune"] = by
    return out


def summary(data, fmt, recent_data=None):
    """Riepilogo leggibile: [(voce, valore)]. `recent_data` = (nome del
    comune, totali 2011 del comune, dato recente) per il confronto."""
    t = totals(data)
    tot = t["ADD_TOT"]

    def pct(v):
        return "%s (%s %%)" % (fmt(v, 0), fmt(100.0 * v / tot, 1)) \
            if tot else fmt(v, 0)

    rows = [("Sezioni 2011", "%s (%s con addetti)" % (
        fmt(t["_sections"], 0), fmt(t["_with_jobs"], 0))),
        ("Addetti 2011", fmt(tot, 0)),
        ("Imprese", pct(t["ADD_IM"])),
        ("Istituzioni pubbliche", pct(t["ADD_IP"])),
        ("Istituzioni non profit", pct(t["ADD_NP"])),
        ("Unità locali (indicativo)", fmt(t["UL_TOT"], 0)),
        ("Addetti per km²", fmt(1e6 * tot / t["AREA_M2"], 0)
         if t["AREA_M2"] else "–")]
    for k, lab, _c, _r in sorted(SECTORS, key=lambda s: -t[s[0]]):
        if t[k] > 0:
            rows.append((lab, pct(t[k])))
    if recent_data:
        name, t11, rc = recent_data
        if rc and rc.get("asia") is not None:
            im11 = t11.get("ADD_IM") or 0
            var = (" (%+.1f %% dal 2011)" % (100.0 * (rc["asia"] - im11)
                                             / im11)).replace(".", ",") \
                if im11 else ""
            rows.append(("%s: addetti delle imprese %d" % (name, ASIA_YEAR),
                         fmt(rc["asia"], 0) + var))
        if rc and rc.get("ip") is not None:
            ip11 = t11.get("ADD_IP") or 0
            var = (" (%+.1f %% dal 2011)" % (100.0 * (rc["ip"] - ip11)
                                             / ip11)).replace(".", ",") \
                if ip11 else ""
            rows.append(("%s: dipendenti pubblici %d" % (name, IP_YEAR),
                         fmt(rc["ip"], 0) + var))
    return rows


def report_totals(data):
    """Addetti dell'area per il report: totali per tipo e per settore
    (pesati con la quota delle sezioni)."""
    t = totals(data)
    return {"total": t["ADD_TOT"], "im": t["ADD_IM"], "ip": t["ADD_IP"],
            "np": t["ADD_NP"], "ul": t["UL_TOT"],
            "sections": t["_with_jobs"],
            "sectors": [(lab, t[k]) for k, lab, _c, _r in SECTORS],
            "source": SOURCE}


def main_comune(data):
    """Codice (2011) del comune con più addetti fra le sezioni lette."""
    by = totals(data)["by_comune"]
    return max(by, key=by.get) if by else None


def _sectors_of(row):
    return max(SECTORS, key=lambda s: row.get(s[0]) or 0)[0] \
        if any(row.get(s[0]) for s in SECTORS) else None


# ------------------------------------------------------------ layer QGIS
def build_layer(data, name, theme="dens"):
    """Layer in memoria delle sezioni 2011 lette (EPSG:32632) con addetti,
    settori, addetti per ettaro e settore prevalente. Thread principale."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import QgsFeature, QgsField, QgsGeometry, QgsVectorLayer
    lay = QgsVectorLayer("MultiPolygon?crs=EPSG:%d" % istat.EPSG, name,
                         "memory")
    fields = data["fields"]
    partial = any(q < 0.999 for _g, q, _v in data["rows"])
    head = (["SEZ2011", "COMUNE", "PRO_COM", "ADD_TOT", "ADD_IM", "ADD_IP",
             "ADD_NP", "UL_TOT", "ALTRI_RETR", "VOLONTARI", "ADD_HA",
             "SETTORE"] + [k for k, _l, _c, _r in SECTORS] + ["AREA_HA"]
            + (["QUOTA"] if partial else []))
    defs = []
    for k in head:
        kind = (QVariant.String if k in ("COMUNE", "SETTORE") else
                QVariant.Double if k in ("ADD_HA", "AREA_HA", "QUOTA") else
                QVariant.LongLong if k == "SEZ2011" else QVariant.Int)
        defs.append(QgsField(k, kind))
    pr = lay.dataProvider()
    pr.addAttributes(defs)
    lay.updateFields()
    names = istat._comuni_index()
    from qgis.core import (QgsCoordinateReferenceSystem,
                           QgsCoordinateTransform, QgsProject)
    to_local = QgsCoordinateTransform(
        QgsCoordinateReferenceSystem("EPSG:4326"),
        QgsCoordinateReferenceSystem("EPSG:%d" % istat.EPSG),
        QgsProject.instance().transformContext())
    feats = []
    for wkb, q, v in data["rows"]:
        row = dict(zip(fields, v))
        if isinstance(wkb, str):   # letto con wgs84=True
            g = QgsGeometry.fromWkt(wkb)
            g.transform(to_local)
        else:
            g = QgsGeometry()
            g.fromWkb(wkb)
        f = QgsFeature(lay.fields())
        f.setGeometry(g)
        c = names.get(row.get("PRO_COM"))
        area = row.get("AREA_M2") or 0
        sec = _sectors_of(row)
        attrs = []
        for k in head:
            if k == "COMUNE":
                attrs.append(c["nome"] if c else None)
            elif k == "ADD_HA":
                attrs.append(round(1e4 * (row.get("ADD_TOT") or 0) / area,
                                   2) if area else None)
            elif k == "SETTORE":
                attrs.append(SECTOR_LABEL.get(sec) if sec else None)
            elif k == "AREA_HA":
                attrs.append(round(area / 1e4, 3))
            elif k == "QUOTA":
                attrs.append(round(q, 4))
            else:
                attrs.append(row.get(k))
        f.setAttributes(attrs)
        feats.append(f)
    pr.addFeatures(feats)
    lay.updateExtents()
    for i, fld in enumerate(lay.fields()):
        label = LABELS.get(fld.name())
        if label:
            lay.setFieldAlias(i, "%s · %s" % (fld.name(), label))
    apply_theme(lay, theme)
    return lay


def build_points_layer(data, name):
    """Un punto per sezione 2011 con addetti (dentro la sezione), con gli
    addetti per tipo e settore: per le analisi che vogliono punti pesati
    (destinazioni dell'accessibilità, opportunità nelle isocrone)."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsFeature, QgsField, QgsGeometry, QgsMarkerSymbol,
                           QgsPointXY, QgsProperty, QgsSingleSymbolRenderer,
                           QgsSymbolLayer, QgsVectorLayer)
    from osgeo import ogr, osr
    lay = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    keep = ["SEZ2011", "PRO_COM", "ADD_TOT", "ADD_IM", "ADD_IP", "ADD_NP"] \
        + [k for k, _l, _c, _r in SECTORS]
    pr = lay.dataProvider()
    pr.addAttributes([QgsField(k, QVariant.LongLong if k == "SEZ2011"
                               else QVariant.Int) for k in keep])
    lay.updateFields()
    loc = osr.SpatialReference()
    loc.ImportFromEPSG(istat.EPSG)
    _to_l, to_w = istat._transforms(loc)
    ix = {k: i for i, k in enumerate(data["fields"])}
    feats = []
    top = 1
    for wkb, _q, v in data["rows"]:
        if not v[ix["ADD_TOT"]]:
            continue
        g = (ogr.CreateGeometryFromWkt(wkb) if isinstance(wkb, str)
             else ogr.CreateGeometryFromWkb(wkb))
        pt = g.PointOnSurface() if g is not None else None
        if pt is None or pt.IsEmpty():
            pt = g.Centroid()
        if isinstance(wkb, str):
            x, y = pt.GetX(), pt.GetY()
        else:
            x, y, _z = to_w.TransformPoint(pt.GetX(), pt.GetY())
        f = QgsFeature(lay.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
        f.setAttributes([v[ix[k]] for k in keep])
        feats.append(f)
        top = max(top, v[ix["ADD_TOT"]])
    pr.addFeatures(feats)
    lay.updateExtents()
    sym = QgsMarkerSymbol.createSimple({
        "name": "circle", "color": "234,88,12,170",
        "outline_color": "#ffffff", "outline_width": "0.15", "size": "1.4"})
    sym.symbolLayer(0).setDataDefinedProperty(
        QgsSymbolLayer.PropertySize, QgsProperty.fromExpression(
            'scale_linear(sqrt("ADD_TOT"), 0, %r, 0.7, 4)' % (top ** 0.5)))
    lay.setRenderer(QgsSingleSymbolRenderer(sym))
    for i, fld in enumerate(lay.fields()):
        label = LABELS.get(fld.name())
        if label:
            lay.setFieldAlias(i, "%s · %s" % (fld.name(), label))
    return lay


def theme_available(layer, key):
    t = next((x for x in THEMES if x[0] == key), None)
    return t is not None and layer.fields().indexOf(t[2]) >= 0


def apply_theme(layer, key, classes=5):
    """Colora le sezioni: cinque classi a quantili sulle sezioni con
    addetti (le altre in grigio), oppure per settore prevalente."""
    from qgis.PyQt.QtGui import QColor
    from qgis.core import (QgsCategorizedSymbolRenderer, QgsFillSymbol,
                           QgsGradientColorRamp, QgsGraduatedSymbolRenderer,
                           QgsRendererCategory, QgsRendererRangeLabelFormat,
                           QgsRuleBasedRenderer, QgsSingleSymbolRenderer)
    t = next((x for x in THEMES if x[0] == key), None)
    empty = QgsFillSymbol.createSimple({
        "color": "244,244,245,120", "outline_color": "#d4d4d8",
        "outline_width": "0.1"})
    layer.setOpacity(0.85)
    if t is None or layer.fields().indexOf(t[2]) < 0:
        layer.setRenderer(QgsSingleSymbolRenderer(empty))
        return False
    _k, _label, field, dec, lo, hi = t
    if key == "set":
        cats = [QgsRendererCategory(lab, QgsFillSymbol.createSimple({
            "color": col, "outline_color": "#ffffff",
            "outline_width": "0.1"}), lab)
            for _s, lab, col, _r in SECTORS]
        cats.append(QgsRendererCategory(None, empty, "senza addetti"))
        layer.setRenderer(QgsCategorizedSymbolRenderer("SETTORE", cats))
        layer.setCustomProperty("mic/addetti_theme", key)
        return True
    expr = ('CASE WHEN "ADD_TOT" > 0 AND "%s" > 0 THEN "%s" END'
            % (field, field))
    r = QgsGraduatedSymbolRenderer(expr)
    r.setSourceSymbol(QgsFillSymbol.createSimple({
        "color": lo, "outline_color": "#ffffff", "outline_width": "0.1"}))
    r.setSourceColorRamp(QgsGradientColorRamp(QColor(lo), QColor(hi)))
    try:
        from qgis.core import QgsClassificationQuantile
        method = QgsClassificationQuantile()
        method.setLabelFormat("%1 – %2")
        method.setLabelPrecision(dec)
        method.setLabelTrimTrailingZeroes(False)
        r.setClassificationMethod(method)
        r.updateClasses(layer, classes)
    except Exception:
        r.setLabelFormat(QgsRendererRangeLabelFormat("%1 – %2", dec))
        r.updateClasses(layer, QgsGraduatedSymbolRenderer.Quantile, classes)
    if not r.ranges():
        layer.setRenderer(QgsSingleSymbolRenderer(empty))
        return False
    rb = QgsRuleBasedRenderer.convertFromRenderer(r)
    rb.rootRule().appendChild(QgsRuleBasedRenderer.Rule(
        empty, 0, 0, "ELSE", "senza addetti"))
    layer.setRenderer(rb)
    layer.setCustomProperty("mic/addetti_theme", key)
    return True
