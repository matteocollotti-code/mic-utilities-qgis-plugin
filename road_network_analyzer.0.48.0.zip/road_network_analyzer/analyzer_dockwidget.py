# -*- coding: utf-8 -*-
"""Dock widget del plugin: input, esecuzione analisi e visualizzazione."""
import csv
import os
import re

from qgis.PyQt.QtCore import Qt, QDate, QEventLoop, QTime, QTimer, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QLayout,
    QGridLayout,
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QDockWidget,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QProgressDialog,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QTimeEdit,
    QVBoxLayout,
    QWidget,
    QWizard,
    QWizardPage,
)
from qgis.core import (
    QgsApplication,
    QgsCoordinateTransform,
    QgsFieldProxyModel,
    QgsGeometry,
    QgsMapLayerProxyModel,
    QgsProject,
    QgsRectangle,
    QgsVectorLayerFeatureSource,
)
from qgis.gui import (
    QgsFieldComboBox, QgsMapLayerComboBox, QgsMapToolEmitPoint,
)

from .core import analysis
from .core import (
    gtfs_static, gtfs_layers, excel_report, isochrones, gtfs_builder,
    space_syntax, od_viz, ptal, grid_gen, net_iso, gap as gap_mod, equity,
    compare, net_clean, opportunities, walkability, network_prepare,
    map_matching,
    network_diagnostics, net_layers, scenarios, osm_cache, topology, routing,
    travel_cost, od_road, fifteen, area_report, osm_basemap, istat,
    tp_coverage, pendolarismo, addetti,
)
from .core.gtfs_logger import GtfsRealtimeLogger
from .core.gtfs_tasks import (
    GtfsLoadTask, GtfsMatchTask, SpaceSyntaxTask, PtalTask, GtfsIsoTask,
    AccessTask, OdMatrixTask, OsmRoadsTask, OsmCrossingsTask, ScenarioIsoTask,
    FunctionTask, read_spec_roads, read_costed_network, OsmServicesTask,
)
from .core import osm_download

from . import travel_ui, map_tools
from .help_texts import HELP_TEXTS, SECTIONS_NOTE
from .style import panel_style

RATIO_LABELS = [
    ("total_length_m", "Lunghezza totale (m)"),
    ("total_length_km", "Lunghezza totale (km)"),
    ("junctions", "Incroci reali (nodi con ≥3 bracci)"),
    ("dead_ends", "Vicoli ciechi (nodi con 1 braccio)"),
    ("connected_node_ratio", "Rapporto nodi connessi (incroci / nodi)"),
    ("unnoded_crossings",
     "Attraversamenti senza vertice comune (da verificare)"),
    ("area_m2", "Area di progetto (m2)"),
    ("area_km2", "Area di progetto (km2)"),
    ("density_km_per_km2", "Densità stradale (km/km²)"),
    ("intersection_density_per_km2", "Densità incroci (n/km²)"),
]
RATIO_INTEGER = ("junctions", "dead_ends", "unnoded_crossings")


class _PrepPage(QWizardPage):
    """Pagina del wizard di preparazione rete con callback di inizializzazione.

    `on_init(page)` viene eseguito quando la pagina è mostrata; `is_complete()`
    abilita il pulsante Avanti/Fine (es. solo se l'anteprima è pronta).
    """

    def __init__(self, title, subtitle="", on_init=None, is_complete=None,
                 parent=None):
        super().__init__(parent)
        self.setTitle(title)
        if subtitle:
            self.setSubTitle(subtitle)
        self._on_init = on_init
        self._is_complete = is_complete

    def initializePage(self):  # noqa: N802 (API Qt)
        if self._on_init:
            self._on_init(self)

    def isComplete(self):  # noqa: N802 (API Qt)
        if self._is_complete is not None:
            return self._is_complete()
        return True


class AnalyzerDockWidget(QDockWidget):
    """Pannello agganciabile per l'analisi della rete stradale."""

    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("MIC - Utilities")
        self._results = None
        self._scan_timer = None
        self._gtfs = None
        self._logger = None
        self._load_task = None
        self._match_task = None
        self._gtfs_seg_layer = None
        # accumulatore: linee/metriche restano in un unico layer aggiornato
        self._acc = {"shapes": {}, "shape_routes": {}, "routes": {},
                     "line_metrics": {}}
        self._lines_layer_id = None
        self._metrics_layer_id = None
        self._isoa_picked = []
        self._isoa_tool = None
        self._rt_picked = []
        self._rt_tool = None
        self._isoa_task = None
        self._ptal_cells = None
        self._ptal_points = None
        self._ptal_grid_layer_id = None
        self._osm_task = None
        self._osm_target = None
        self._osm_mode = "all"
        self._osm_cross_task = None
        self._rep_tool = None
        self._rep_geom = None     # area disegnata (WGS84)
        self._ist_layer_id = None  # ultimo layer di sezioni ISTAT caricato
        self._istat_view = None    # residenti ISTAT presi con «🌐 ISTAT»
        self._jobs_view = None     # addetti ISTAT presi con «🌐 ISTAT»
        self._jobs_layer_id = None  # ultimo layer degli addetti caricato
        self._build_ui()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        # pannello «MIC - Utilities» con le schede raggruppate in 3 categorie
        # (tab annidati); ogni scheda è avvolta in uno scroll.
        self.mainTabs = QTabWidget()

        # nomi brevi: le schede stanno in un pannello stretto (~320 px); il
        # nome completo è nel suggerimento
        tp = QTabWidget()
        for build, name, tip in (
                (self._build_gtfs_tab, "GTFS", "Linee e velocità dal GTFS"),
                (self._build_gtfs_live_tab, "GTFS live",
                 "Velocità osservate dal GTFS-Realtime"),
                (self._build_lines2gtfs_tab, "Crea GTFS",
                 "Da linee e fermate disegnate a un feed GTFS"),
                (self._build_ptal_tab, "PTAL",
                 "Public Transport Accessibility Level"),
                (self._build_coverage_tab, "Serviti",
                 "Residenti serviti dal trasporto pubblico: quanti hanno "
                 "una fermata a portata di piedi, e con quante corse")):
            tp.setTabToolTip(tp.addTab(self._scroll(build()), name), tip)

        rn = QTabWidget()
        for build, name, tip in (
                (self._build_road_tab, "Analisi",
                 "Lunghezze, incroci, walkability, preparazione della rete"),
                (self._build_spacesyntax_tab, "Space syntax",
                 "Integrazione e choice sulla segment map"),
                (self._build_routing_tab, "Percorsi",
                 "Percorso più breve o più veloce")):
            rn.setTabToolTip(rn.addTab(self._scroll(build()), name), tip)

        ac = QTabWidget()
        for build, name, tip in (
                (self._build_isochrones_tab, "Isocrone",
                 "Aree raggiungibili a piedi, in bici, in auto, in TP"),
                (self._build_access_tab, "Accessibilità",
                 "Opportunità raggiungibili, equità, scenari A/B"),
                (self._build_od_tab, "OD",
                 "Desire lines e matrici origine-destinazione"),
                (self._build_fifteen_tab, "15 min",
                 "Città dei 15 minuti")):
            ac.setTabToolTip(ac.addTab(self._scroll(build()), name), tip)

        for w, name, tip in ((tp, "Trasporti", "Trasporto pubblico"),
                             (rn, "Rete", "Rete stradale"),
                             (ac, "Accessibilità", "Accessibilità"),
                             (self._scroll(self._build_report_tab()),
                              "Report", "Report automatico di un'area: PDF "
                              "ed Excel"),
                             (self._scroll(self._build_istat_tab()),
                              "ISTAT", "Sezioni di censimento ISTAT 2021: "
                              "scarica e consulta popolazione e "
                              "indicatori")):
            self.mainTabs.setTabToolTip(self.mainTabs.addTab(w, name), tip)
        # nomi brevi per i dock stretti: [schede, [(intero, breve)], brevi
        # ora?, larghezza che serve ai nomi interi]
        self._tab_fits = [
            [self.mainTabs, [("Trasporti", "TP"), ("Rete", "Rete"),
                             ("Accessibilità", "Access."),
                             ("Report", "Report"), ("ISTAT", "ISTAT")],
             False, None],
            [tp, [("GTFS", "GTFS"), ("GTFS live", "Live"),
                  ("Crea GTFS", "Crea"), ("PTAL", "PTAL"),
                  ("Serviti", "Serviti")], False, None]]
        # le sottoschede prendono la loro larghezza solo quando si vedono
        self.mainTabs.currentChanged.connect(
            lambda _i: QTimer.singleShot(0, self._refit_main_tabs))
        container = QWidget()
        cl = QVBoxLayout(container)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.addWidget(self._build_output_row())
        cl.addWidget(self.mainTabs, 1)
        self.setWidget(container)
        self._fit_narrow()
        style = panel_style(os.path.join(os.path.dirname(__file__), "icons"))
        self.mainTabs.setStyleSheet(style)
        self.setStyleSheet(style)

    def _fit_main_tabs(self):
        """Schede con nomi interi se ci stanno, altrimenti brevi (TP,
        Access., Live, Crea), così in un dock stretto la barra non scorre.
        Il nome completo resta nel suggerimento."""
        for fit in self._tab_fits:
            tw, names, short, need = fit
            tb = tw.tabBar()
            avail = tw.width()
            if avail <= 0 or not tw.isVisible():
                continue
            if not short:
                n = tb.sizeHint().width()
                if n > avail:
                    fit[2], fit[3] = True, n
                    for i, (_full, brief) in enumerate(names):
                        tb.setTabText(i, brief)
            elif need is not None and need <= avail:
                fit[2] = False
                for i, (full, _brief) in enumerate(names):
                    tb.setTabText(i, full)

    def _refit_main_tabs(self):
        try:
            self._fit_main_tabs()
        except Exception:   # pannello già chiuso o non ancora costruito
            pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._refit_main_tabs()

    def showEvent(self, event):
        # aperto già stretto: le misure ci sono solo dopo la prima
        # disposizione dei controlli
        super().showEvent(event)
        QTimer.singleShot(0, self._refit_main_tabs)

    def _fit_narrow(self):
        """Il pannello deve stare anche in un dock stretto (~320 px) senza
        scorrimento orizzontale: nei moduli il campo va sotto l'etichetta
        quando non c'è spazio, le combo non si allargano sul testo più
        lungo, le etichette lunghe vanno a capo."""
        for form in self.findChildren(QFormLayout):
            form.setRowWrapPolicy(QFormLayout.WrapLongRows)
            form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        for cb in self.findChildren(QComboBox):
            cb.setSizeAdjustPolicy(
                QComboBox.AdjustToMinimumContentsLengthWithIcon)
            cb.setMinimumContentsLength(5)
        for lab in self.findChildren(QLabel):
            if not lab.wordWrap() and lab.sizeHint().width() > 240:
                lab.setWordWrap(True)
        # margini interni più stretti: annidati (scheda, sezione, riga)
        # costavano più di 40 px di larghezza
        for lay in self.findChildren(QLayout):
            m = lay.contentsMargins()
            if max(m.left(), m.right()) > 6:
                lay.setContentsMargins(6, min(m.top(), 6), 6,
                                       min(m.bottom(), 6))

    @staticmethod
    def _paint_status(label, text, error=False):
        """Esito in un riquadro tenue (verde = fatto, rosso = errore); ogni
        avviso ⚠️ va su una riga sua, in ambra, così non si perde nel testo."""
        import html
        text = text or ""
        if not text.strip():
            label.setStyleSheet("")
            label.setText("")
            return
        parts = text.split("⚠️")
        body = html.escape(parts[0].strip(), quote=False)
        warns = [html.escape(p.strip(), quote=False) for p in parts[1:]
                 if p.strip()]
        out = body.replace("\n", "<br>") + "".join(
            '<br><span style="color:#92400e">⚠️ %s</span>' % w for w in warns)
        fg, bg, bd = (("#991b1b", "rgba(254,226,226,0.9)", "#fca5a5")
                      if error else
                      ("#14532d", "rgba(220,252,231,0.9)", "#86efac"))
        label.setTextFormat(Qt.RichText)
        label.setWordWrap(True)
        label.setStyleSheet(
            "QLabel { color: %s; background: %s; border: 1px solid %s; "
            "border-radius: 8px; padding: 6px 8px; }" % (fg, bg, bd))
        label.setText(out)

    # ------------------------------------------------- salvataggio risultati
    _OUT_KEY = "MIC-Utilities/"

    def _build_output_row(self):
        """Riga «Risultati»: temporanei, file chiesto ogni volta o un
        GeoPackage unico (scelta ricordata fra le sessioni)."""
        from qgis.core import QgsSettings
        st = QgsSettings()
        w = QWidget()
        row = QHBoxLayout(w)
        row.setContentsMargins(4, 2, 4, 2)
        row.addWidget(QLabel("Risultati:"))
        self.outModeCombo = QComboBox()
        self.outModeCombo.addItem("Temporanei (in memoria)", "memory")
        self.outModeCombo.addItem("Chiedi il file ogni volta", "ask")
        self.outModeCombo.addItem("In un GeoPackage", "gpkg")
        self.outModeCombo.setToolTip(
            "Dove salvare i layer creati dalle analisi. «Chiedi» apre una "
            "finestra per ogni risultato (GeoPackage, Shapefile, GeoJSON, "
            "CSV); «In un GeoPackage» li aggiunge tutti al file indicato.")
        row.addWidget(self.outModeCombo)
        self.outGpkgEdit = QLineEdit(st.value(self._OUT_KEY + "out_gpkg", ""))
        self.outGpkgEdit.setPlaceholderText("file .gpkg dei risultati")
        row.addWidget(self.outGpkgEdit, 1)
        self.outGpkgBtn = QPushButton("…")
        self.outGpkgBtn.setFixedWidth(28)
        self.outGpkgBtn.clicked.connect(self._out_browse)
        row.addWidget(self.outGpkgBtn)
        i = self.outModeCombo.findData(st.value(self._OUT_KEY + "out_mode",
                                                "memory"))
        self.outModeCombo.setCurrentIndex(max(0, i))
        self.outModeCombo.currentIndexChanged.connect(self._out_mode_changed)
        self.outGpkgEdit.editingFinished.connect(
            lambda: QgsSettings().setValue(self._OUT_KEY + "out_gpkg",
                                           self.outGpkgEdit.text().strip()))
        self._out_mode_changed()
        return w

    def _out_mode_changed(self, *_a):
        from qgis.core import QgsSettings
        gpkg = self.outModeCombo.currentData() == "gpkg"
        self.outGpkgEdit.setVisible(gpkg)
        self.outGpkgBtn.setVisible(gpkg)
        QgsSettings().setValue(self._OUT_KEY + "out_mode",
                               self.outModeCombo.currentData())

    def _out_browse(self):
        from qgis.core import QgsSettings
        path, _ = QFileDialog.getSaveFileName(
            self, "GeoPackage dei risultati",
            self.outGpkgEdit.text() or "risultati_mic.gpkg",
            "GeoPackage (*.gpkg)", options=QFileDialog.DontConfirmOverwrite)
        if path:
            if not path.lower().endswith(".gpkg"):
                path += ".gpkg"
            self.outGpkgEdit.setText(path)
            QgsSettings().setValue(self._OUT_KEY + "out_gpkg", path)

    @staticmethod
    def _safe_name(name):
        n = re.sub(r"[^0-9A-Za-zÀ-ÿ_]+", "_", name or "risultato").strip("_")
        return (n or "risultato")[:60]

    def _save_output(self, layer):
        """Scrive il layer su file secondo l'impostazione «Risultati» e
        ritorna il layer su file (stesso stile); se annullato o in caso di
        errore ritorna quello in memoria."""
        from qgis.core import (QgsMapLayerStyle, QgsSettings, QgsVectorFileWriter,
                               QgsVectorLayer, QgsWkbTypes)
        mode = self.outModeCombo.currentData() if hasattr(
            self, "outModeCombo") else "memory"
        if mode == "memory" or layer is None or not layer.isValid():
            return layer
        name = self._safe_name(layer.name())
        no_geom = layer.geometryType() == QgsWkbTypes.NullGeometry
        exts = {"GeoPackage": ".gpkg", "Shapefile": ".shp",
                "GeoJSON": ".geojson", "CSV": ".csv"}
        add_layer = False   # GeoPackage esistente: aggiungi, non sostituire
        if mode == "ask":
            last = QgsSettings().value(self._OUT_KEY + "out_dir", "")
            filters = ("GeoPackage (*.gpkg);;CSV (*.csv)" if no_geom else
                       "GeoPackage (*.gpkg);;Shapefile (*.shp);;"
                       "GeoJSON (*.geojson);;CSV con geometria WKT (*.csv)")
            # la conferma di sovrascrittura la chiediamo noi: per un
            # GeoPackage si può anche aggiungere il layer
            path, filt = QFileDialog.getSaveFileName(
                self, "Salva «%s»" % layer.name(),
                os.path.join(last, name + ".gpkg"), filters,
                options=QFileDialog.DontConfirmOverwrite)
            if not path:
                return layer  # resta temporaneo
            if os.path.splitext(path)[1].lower() not in exts.values():
                # estensione dal filtro scelto; alcune finestre non lo
                # restituiscono: allora GeoPackage
                path += exts.get((filt or "").split(" ")[0], ".gpkg")
            QgsSettings().setValue(self._OUT_KEY + "out_dir",
                                   os.path.dirname(path))
            if os.path.exists(path):
                choice = self._ask_existing(path)
                if choice is None:
                    return layer
                add_layer = choice == "add"
                busy = self._layers_on_file(path)
                if not add_layer and busy:
                    # su Windows un file aperto non si può sostituire
                    self.iface.messageBar().pushWarning(
                        "MIC - Utilities",
                        "«%s» è aperto nel progetto (%s): rimuovi il layer "
                        "o scegli un altro nome. Il risultato resta "
                        "temporaneo." % (os.path.basename(path),
                                         ", ".join(busy[:3])))
                    return layer
        else:
            path = self.outGpkgEdit.text().strip()
            if not path:
                self.iface.messageBar().pushWarning(
                    "MIC - Utilities", "Indica il GeoPackage dei risultati: "
                    "il layer resta temporaneo.")
                return layer
            if not path.lower().endswith(".gpkg"):
                path += ".gpkg"
            add_layer = os.path.exists(path)
        drv = {".gpkg": "GPKG", ".shp": "ESRI Shapefile",
               ".geojson": "GeoJSON", ".csv": "CSV"}[
            os.path.splitext(path)[1].lower()]
        if drv == "GPKG" and add_layer:
            base, k = name, 2
            while QgsVectorLayer("%s|layername=%s" % (path, name), "t",
                                 "ogr").isValid():
                name = "%s_%d" % (base, k)
                k += 1
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = drv
        opts.fileEncoding = "UTF-8"
        if drv == "GPKG":
            opts.layerName = name
            if add_layer:
                opts.actionOnExistingFile = \
                    QgsVectorFileWriter.CreateOrOverwriteLayer
        elif drv == "CSV":
            # tipi dei campi nel .csvt (altrimenti tutto torna testo) e
            # geometria come WKT
            opts.layerOptions = ["CREATE_CSVT=YES"] + (
                [] if no_geom else ["GEOMETRY=AS_WKT"])
        res = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer, path, QgsProject.instance().transformContext(), opts)
        if res[0] != QgsVectorFileWriter.NoError:
            self.iface.messageBar().pushWarning(
                "MIC - Utilities", "Salvataggio non riuscito (%s): il layer "
                "resta temporaneo." % (res[1] if len(res) > 1 else res[0]))
            return layer
        uri = "%s|layername=%s" % (path, name) if drv == "GPKG" else path
        saved = QgsVectorLayer(uri, layer.name(), "ogr")
        if not saved.isValid():
            return layer
        style = QgsMapLayerStyle()
        style.readFromLayer(layer)
        style.writeToLayer(saved)
        self._remap_style_fields(layer, saved)
        return saved

    def _ask_existing(self, path):
        """File già esistente: "add" (GeoPackage: nuovo layer nel file),
        "replace" o None (annulla)."""
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Question)
        box.setWindowTitle("MIC - Utilities")
        box.setText("«%s» esiste già." % os.path.basename(path))
        add = None
        if path.lower().endswith(".gpkg"):
            box.setInformativeText("Il risultato può essere aggiunto al "
                                   "GeoPackage come nuovo layer, oppure "
                                   "sostituire tutto il file.")
            add = box.addButton("Aggiungi layer", QMessageBox.AcceptRole)
        rep = box.addButton("Sostituisci", QMessageBox.DestructiveRole)
        box.addButton("Annulla", QMessageBox.RejectRole)
        box.setDefaultButton(add or rep)
        box.exec_()
        clicked = box.clickedButton()
        if add is not None and clicked is add:
            return "add"
        if clicked is rep:
            return "replace"
        return None

    @staticmethod
    def _layers_on_file(path):
        """Nomi dei layer del progetto letti dal file indicato."""
        norm = os.path.normcase(os.path.abspath(path))
        out = []
        for lyr in QgsProject.instance().mapLayers().values():
            src = lyr.source().split("|")[0]
            try:
                if os.path.normcase(os.path.abspath(src)) == norm:
                    out.append(lyr.name())
            except (TypeError, ValueError):
                pass
        return out

    @staticmethod
    def _remap_style_fields(src, saved):
        """Lo Shapefile tronca i nomi dei campi a 10 caratteri: il campo
        usato da simbologia ed etichette va ricollegato a quello nuovo
        (altrimenti il layer salvato non disegna nulla)."""
        old = src.fields().names()
        new = saved.fields().names()
        if old == new or len(old) != len(new):
            return
        ren = dict(zip(old, new))
        r = saved.renderer()
        if r is not None and hasattr(r, "classAttribute"):
            a = r.classAttribute()
            if a in ren and ren[a] != a:
                r.setClassAttribute(ren[a])
        lab = saved.labeling()
        if lab is not None and hasattr(lab, "settings"):
            try:
                s = lab.settings()
                if not s.isExpression and s.fieldName in ren:
                    s.fieldName = ren[s.fieldName]
                    lab.setSettings(s)
            except Exception:
                pass

    @staticmethod
    def _scroll(widget):
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QScrollArea.NoFrame)
        sa.setWidget(widget)
        return sa

    def _help_button(self, key):
        btn = QPushButton("❓ Spiegazione campi")
        btn.setFlat(True)
        btn.clicked.connect(lambda: self._show_help(key))
        return btn

    def _show_help(self, key):
        title, html = HELP_TEXTS.get(key, ("Aiuto", ""))
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.resize(500, 440)
        lay = QVBoxLayout(dlg)
        tb = QTextBrowser()
        tb.setHtml(html + SECTIONS_NOTE)
        tb.setOpenExternalLinks(True)
        lay.addWidget(tb)
        close = QPushButton("Chiudi")
        close.clicked.connect(dlg.accept)
        lay.addWidget(close)
        dlg.exec_()

    def _build_road_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("road"))

        form = QFormLayout()
        self.roadLayerCombo = QgsMapLayerComboBox()
        self.roadLayerCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Rete stradale:", self._combo_with_osm(self.roadLayerCombo))

        self.typeFieldCombo = QgsFieldComboBox()
        self.typeFieldCombo.setAllowEmptyFieldName(True)
        form.addRow("Campo tipologia:", self.typeFieldCombo)

        self.areaLayerCombo = QgsMapLayerComboBox()
        self.areaLayerCombo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.areaLayerCombo.setAllowEmptyLayer(True)
        form.addRow("Area di progetto:", self.areaLayerCombo)
        layout.addLayout(form)

        btn_row = QHBoxLayout()
        self.runButton = QPushButton("Calcola")
        self.exportButton = QPushButton("Esporta CSV")
        self.exportButton.setEnabled(False)
        btn_row.addWidget(self.runButton)
        btn_row.addWidget(self.exportButton)
        layout.addLayout(btn_row)

        self.tabs = QTabWidget()
        self.lengthTable = self._make_table()
        self.matrixTable = self._make_table()
        self.ratiosTable = self._make_table()
        self.tabs.addTab(self.lengthTable, "Lunghezze")
        self.tabs.addTab(self.matrixTable, "Matrice incroci")
        self.tabs.addTab(self.ratiosTable, "Rapporti")
        layout.addWidget(self.tabs)

        walk_box = QGroupBox("Walkability")
        wf = QFormLayout(walk_box)
        self.walkZones = QgsMapLayerComboBox()
        self.walkZones.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.walkZones.setAllowEmptyLayer(True)
        wf.addRow("Zone (vuoto = griglia):", self.walkZones)
        self.walkGridSize = QSpinBox()
        self.walkGridSize.setRange(50, 5000)
        self.walkGridSize.setValue(300)
        self.walkGridSize.setSuffix(" m")
        wf.addRow("Cella della griglia:", self.walkGridSize)
        self.walkPoi = QgsMapLayerComboBox()
        self.walkPoi.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.walkPoi.setAllowEmptyLayer(True)
        wf.addRow("POI/destinazioni (opz.):", self.walkPoi)
        self.walkPoiCat = QgsFieldComboBox()
        self.walkPoiCat.setAllowEmptyFieldName(True)
        self.walkPoi.layerChanged.connect(self.walkPoiCat.setLayer)
        self.walkPoiCat.setLayer(self.walkPoi.currentLayer())
        wf.addRow("Campo categoria (opz.):", self.walkPoiCat)
        self.walkDestM = QSpinBox()
        self.walkDestM.setRange(100, 5000)
        self.walkDestM.setValue(800)
        self.walkDestM.setSuffix(" m")
        wf.addRow("Distanza max destinazioni:", self.walkDestM)
        self.walkDestNet = QCheckBox("Destinazioni lungo la rete")
        self.walkDestNet.setToolTip("Distanza delle destinazioni lungo la "
                                    "rete (Dijkstra) invece che in linea "
                                    "d'aria.")
        wf.addRow("", self.walkDestNet)
        cross_row = QHBoxLayout()
        self.walkCross = QgsMapLayerComboBox()
        self.walkCross.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.walkCross.setAllowEmptyLayer(True)
        cross_row.addWidget(self.walkCross, 1)
        self.walkCrossOsm = QPushButton("🌐 Da OSM")
        self.walkCrossOsm.setToolTip("Scarica gli attraversamenti pedonali "
                                     "dell'inquadratura da OpenStreetMap.")
        self.walkCrossOsm.clicked.connect(self._download_osm_crossings)
        cross_row.addWidget(self.walkCrossOsm)
        wf.addRow("Attraversamenti (opz.):", self._wrap(cross_row))
        self.walkDem = self._dem_combo()
        wf.addRow("DEM per pendenza (opz.):", self.walkDem)
        self.walkButton = QPushButton("Calcola walkability")
        self.walkButton.clicked.connect(self._walk_run)
        wf.addRow(self.walkButton)
        self.walkStatus = QLabel("")
        self.walkStatus.setWordWrap(True)
        wf.addRow(self.walkStatus)
        self._make_collapsible(walk_box, collapsed=True)
        layout.addWidget(walk_box)

        prep_box = QGroupBox("Prepara e controlla la rete")
        pf = QVBoxLayout(prep_box)
        pf.addWidget(QLabel(
            "Usa la <b>Rete stradale</b> in alto. <i>Prepara</i> spezza le linee "
            "agli incroci (noding) per analisi corrette; <i>Diagnostica</i> "
            "segnala componenti scollegate, sorgenti isolate e incroci non noded."))
        prow = QHBoxLayout()
        self.prepButton = QPushButton("🔧 Prepara")
        self.prepButton.setToolTip("Spezza le linee agli incroci (noding).")
        self.prepButton.clicked.connect(self._prepare_run)
        self.diagButton = QPushButton("🩺 Diagnostica")
        self.diagButton.clicked.connect(self._diag_run)
        prow.addWidget(self.prepButton)
        prow.addWidget(self.diagButton)
        pf.addLayout(prow)
        dform = QFormLayout()
        self.diagSources = QgsMapLayerComboBox()
        self.diagSources.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.diagSources.setAllowEmptyLayer(True)
        dform.addRow("Sorgenti da controllare (opz.):", self.diagSources)
        pf.addLayout(dform)
        self.presetButton = QPushButton("📍 Preset area OSM…")
        self.presetButton.setToolTip("Salva/richiama un'area (bbox) per i "
                                     "download OSM riproducibili.")
        self.presetButton.clicked.connect(self._osm_presets_dialog)
        pf.addWidget(self.presetButton)
        self.prepStatus = QLabel("")
        self.prepStatus.setWordWrap(True)
        pf.addWidget(self.prepStatus)
        self._make_collapsible(prep_box, collapsed=True)
        layout.addWidget(prep_box)

        self.statusLabel = QLabel("")
        self.statusLabel.setWordWrap(True)
        layout.addWidget(self.statusLabel)

        self.roadLayerCombo.layerChanged.connect(self.typeFieldCombo.setLayer)
        self.typeFieldCombo.setLayer(self.roadLayerCombo.currentLayer())
        self.runButton.clicked.connect(self.run_analysis)
        self.exportButton.clicked.connect(self.export_csv)
        return container

    # -------------------------------------------------------------- GTFS UI
    def _build_gtfs_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("gtfs"))

        # --- dati statici ---
        static_box = QGroupBox("Dati statici (zip o cartella)")
        sb = QVBoxLayout(static_box)
        src_row = QHBoxLayout()
        self.gtfsSourceEdit = QLineEdit()
        self.gtfsSourceEdit.setPlaceholderText("Percorso del feed GTFS (.zip o cartella)")
        btn_zip = QPushButton("Zip…")
        btn_zip.setToolTip("Scegli il feed GTFS (.zip).")
        btn_dir = QPushButton("Cartella…")
        btn_dir.setToolTip("Scegli la cartella con i file GTFS (.txt).")
        btn_zip.clicked.connect(self._gtfs_browse_zip)
        btn_dir.clicked.connect(self._gtfs_browse_folder)
        sb.addWidget(self.gtfsSourceEdit)
        src_row.addWidget(btn_zip)
        src_row.addWidget(btn_dir)
        src_row.addStretch()
        sb.addLayout(src_row)
        sform = QFormLayout()
        route_row = QHBoxLayout()
        route_row.setContentsMargins(0, 0, 0, 0)
        self.gtfsRouteCombo = QComboBox()
        self.gtfsRouteCombo.addItem("Tutte le linee", None)
        route_row.addWidget(self.gtfsRouteCombo, 1)
        self.gtfsReadRoutesButton = QPushButton("Leggi")
        self.gtfsReadRoutesButton.setToolTip("Legge dal feed l'elenco delle "
                                             "linee.")
        self.gtfsReadRoutesButton.clicked.connect(self._gtfs_read_routes)
        route_row.addWidget(self.gtfsReadRoutesButton)
        sform.addRow("Linea:", self._wrap(route_row))

        date_row = QHBoxLayout()
        date_row.setContentsMargins(0, 0, 0, 0)
        self.gtfsServiceDate = QLineEdit()
        self.gtfsServiceDate.setPlaceholderText("AAAAMMGG")
        self.gtfsServiceDate.setToolTip("Giorno di servizio (AAAAMMGG). Vuoto "
                                        "= il giorno più carico del feed.")
        date_row.addWidget(self.gtfsServiceDate, 1)
        self.gtfsValidateButton = QPushButton("Valida")
        self.gtfsValidateButton.setToolTip("Controlla il feed: riferimenti fra "
                                           "tabelle, date, orari, codifica.")
        self.gtfsValidateButton.clicked.connect(self._gtfs_validate)
        date_row.addWidget(self.gtfsValidateButton)
        sform.addRow("Data:", self._wrap(date_row))
        sb.addLayout(sform)

        act_row = QHBoxLayout()
        self.gtfsLoadButton = QPushButton("Carica GTFS")
        self.gtfsLoadButton.setToolTip("Legge il feed e crea il layer delle "
                                       "linee.")
        self.gtfsSegButton = QPushButton("Crea segmenti")
        self.gtfsSegButton.setToolTip("Crea il layer dei segmenti fra "
                                      "fermate.")
        self.gtfsSegButton.setEnabled(False)
        self.gtfsLoadButton.clicked.connect(self._gtfs_load)
        self.gtfsSegButton.clicked.connect(self._gtfs_create_segments)
        act_row.addWidget(self.gtfsLoadButton)
        act_row.addWidget(self.gtfsSegButton)
        sb.addLayout(act_row)
        layout.addWidget(static_box)

        # --- map-matching sulla rete stradale ---
        mm_box = QGroupBox("Map-matching sulla rete")
        mm = QVBoxLayout(mm_box)
        mm_form = QFormLayout()
        self.mmRoadCombo = QgsMapLayerComboBox()
        self.mmRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        mm_form.addRow("Rete stradale:", self._combo_with_osm(
            self.mmRoadCombo, "vehicular"))
        mm.addLayout(mm_form)
        mm_adv = QGroupBox("Avanzate · aggancio")
        mm_af = QFormLayout(mm_adv)
        self.mmTolSpin = QSpinBox()
        self.mmTolSpin.setRange(1, 200)
        self.mmTolSpin.setValue(20)
        self.mmTolSpin.setSuffix(" m")
        mm_af.addRow("Tolleranza (distanza max strada-linea):", self.mmTolSpin)
        self.mmAngleSpin = QSpinBox()
        self.mmAngleSpin.setRange(5, 90)
        self.mmAngleSpin.setValue(30)
        self.mmAngleSpin.setSuffix("°")
        mm_af.addRow("Angolo (differenza max di direzione):", self.mmAngleSpin)
        self.mmSpacingSpin = QSpinBox()
        self.mmSpacingSpin.setRange(5, 200)
        self.mmSpacingSpin.setValue(25)
        self.mmSpacingSpin.setSuffix(" m")
        mm_af.addRow("Passo (spaziatura di campionamento):", self.mmSpacingSpin)
        self.mmCoverSpin = QSpinBox()
        self.mmCoverSpin.setRange(10, 100)
        self.mmCoverSpin.setValue(50)
        self.mmCoverSpin.setSuffix(" %")
        self.mmCoverSpin.setToolTip(
            "Quota minima della strada (campioni lontani dagli estremi) che "
            "deve stare lungo la linea: evita di abbinare le vie che la "
            "toccano solo in un incrocio.")
        mm_af.addRow("Copertura minima della strada:", self.mmCoverSpin)
        self._make_collapsible(mm_adv, collapsed=True)
        mm.addWidget(mm_adv)
        self.mmRunButton = QPushButton("Esegui map-matching")
        self.mmRunButton.setEnabled(False)
        self.mmRunButton.clicked.connect(self._gtfs_map_match)
        mm.addWidget(self.mmRunButton)
        layout.addWidget(mm_box)

        cov = QLabel("ℹ️ Per le isocrone delle fermate usa la scheda "
                     "<b>Isocrone</b> (opzione «usa fermate GTFS "
                     "caricate»): calcolo su rete in background, "
                     "concavo/poligono/lineare e modo trasporto pubblico.")
        cov.setWordWrap(True)
        layout.addWidget(cov)

        self.gtfsStatus = QLabel("")
        self.gtfsStatus.setWordWrap(True)
        layout.addWidget(self.gtfsStatus)
        layout.addStretch()
        return container

    # ---------------------------------------------------------- GTFS live UI
    def _build_gtfs_live_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("gtfs_live"))

        # --- realtime ---
        rt_box = QGroupBox("GTFS-Realtime (TripUpdates)")
        rb = QVBoxLayout(rt_box)
        self.gtfsRtUrlEdit = QLineEdit()
        self.gtfsRtUrlEdit.setPlaceholderText("URL del feed TripUpdates (protobuf)")
        rb.addWidget(self.gtfsRtUrlEdit)
        rt_form = QFormLayout()
        self.gtfsIntervalSpin = QSpinBox()
        self.gtfsIntervalSpin.setRange(10, 3600)
        self.gtfsIntervalSpin.setValue(30)
        self.gtfsIntervalSpin.setSuffix(" s")
        rt_form.addRow("Intervallo:", self.gtfsIntervalSpin)
        rb.addLayout(rt_form)
        rt_row = QHBoxLayout()
        self.gtfsStartButton = QPushButton("Avvia logging")
        self.gtfsStopButton = QPushButton("Ferma")
        self.gtfsStartButton.setEnabled(False)
        self.gtfsStopButton.setEnabled(False)
        self.gtfsStartButton.clicked.connect(self._gtfs_start_logging)
        self.gtfsStopButton.clicked.connect(self._gtfs_stop_logging)
        rt_row.addWidget(self.gtfsStartButton)
        rt_row.addWidget(self.gtfsStopButton)
        rt_row.addStretch()
        rb.addLayout(rt_row)

        sched_form = QFormLayout()
        self.gtfsScanTime = QTimeEdit()
        self.gtfsScanTime.setDisplayFormat("HH:mm")
        self.gtfsScanTime.setTime(QTime(8, 0))
        sched_form.addRow("Scansione programmata alle:", self.gtfsScanTime)
        self.gtfsScanDur = QSpinBox()
        self.gtfsScanDur.setRange(1, 1440)
        self.gtfsScanDur.setValue(30)
        self.gtfsScanDur.setSuffix(" min")
        sched_form.addRow("Durata:", self.gtfsScanDur)
        rb.addLayout(sched_form)
        sched_row = QHBoxLayout()
        self.gtfsScanButton = QPushButton("Programma")
        self.gtfsScanButton.setToolTip("Avvia il logging all'ora indicata "
                                       "per la durata indicata.")
        self.gtfsScanButton.setEnabled(False)
        self.gtfsScanButton.clicked.connect(self._gtfs_schedule_scan)
        self.gtfsScanCancel = QPushButton("Annulla")
        self.gtfsScanCancel.setEnabled(False)
        self.gtfsScanCancel.clicked.connect(self._gtfs_cancel_scan)
        sched_row.addWidget(self.gtfsScanButton)
        sched_row.addWidget(self.gtfsScanCancel)
        sched_row.addStretch()
        rb.addLayout(sched_row)

        self.gtfsRtStatus = QLabel("Logging non attivo.")
        self.gtfsRtStatus.setWordWrap(True)
        rb.addWidget(self.gtfsRtStatus)
        layout.addWidget(rt_box)

        # --- analisi & export ---
        an_box = QGroupBox("Analisi divari ed export")
        abv = QVBoxLayout(an_box)
        an_form = QFormLayout()
        self.gtfsTopNSpin = QSpinBox()
        self.gtfsTopNSpin.setRange(1, 500)
        self.gtfsTopNSpin.setValue(20)
        an_form.addRow("Segmenti peggiori (top N):", self.gtfsTopNSpin)
        abv.addLayout(an_form)
        ab = QHBoxLayout()
        abv.addLayout(ab)
        self.gtfsHighlightButton = QPushButton("Evidenzia")
        self.gtfsHighlightButton.setToolTip("Seleziona i segmenti con il "
                                            "divario maggiore fra velocità "
                                            "programmata e osservata.")
        self.gtfsExcelButton = QPushButton("Excel velocità")
        self.gtfsExcelButton.setToolTip("Esporta in Excel le velocità "
                                        "programmate e osservate per linea.")
        self.gtfsHighlightButton.setEnabled(False)
        self.gtfsExcelButton.setEnabled(False)
        self.gtfsHighlightButton.clicked.connect(self._gtfs_highlight)
        self.gtfsExcelButton.clicked.connect(self._gtfs_export_excel)
        ab.addWidget(self.gtfsHighlightButton)
        ab.addWidget(self.gtfsExcelButton)
        ab.addStretch()
        layout.addWidget(an_box)

        self.gtfsLineTable = self._make_table()
        layout.addWidget(QLabel("Metriche per linea (programmato e "
                                "osservato):"))
        layout.addWidget(self.gtfsLineTable)

        self.gtfsLiveStatus = QLabel("")
        self.gtfsLiveStatus.setWordWrap(True)
        layout.addWidget(self.gtfsLiveStatus)
        return container

    # ----------------------------------------------------- Da linee a GTFS
    def _build_lines2gtfs_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("lines2gtfs"))

        in_box = QGroupBox("Input")
        form = QFormLayout(in_box)
        self.l2gLineCombo = QgsMapLayerComboBox()
        self.l2gLineCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Linee (rotte):", self.l2gLineCombo)
        self.l2gRouteField = QgsFieldComboBox()
        self.l2gRouteField.setAllowEmptyFieldName(True)
        self.l2gLineCombo.layerChanged.connect(self.l2gRouteField.setLayer)
        self.l2gRouteField.setLayer(self.l2gLineCombo.currentLayer())
        form.addRow("Campo nome linea:", self.l2gRouteField)
        self.l2gStopsCombo = QgsMapLayerComboBox()
        self.l2gStopsCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        form.addRow("Fermate:", self.l2gStopsCombo)
        self.l2gStopField = QgsFieldComboBox()
        self.l2gStopField.setAllowEmptyFieldName(True)
        self.l2gStopsCombo.layerChanged.connect(self.l2gStopField.setLayer)
        self.l2gStopField.setLayer(self.l2gStopsCombo.currentLayer())
        form.addRow("Campo nome fermata:", self.l2gStopField)
        layout.addWidget(in_box)

        par_box = QGroupBox("Parametri di servizio")
        pf = QFormLayout(par_box)
        self.l2gTypeCombo = QComboBox()
        self.l2gTypeCombo.addItem("Bus", "3")
        self.l2gTypeCombo.addItem("Tram", "0")
        self.l2gTypeCombo.addItem("Metro", "1")
        self.l2gTypeCombo.addItem("Treno", "2")
        pf.addRow("Tipo:", self.l2gTypeCombo)
        self.l2gSpeed = QSpinBox()
        self.l2gSpeed.setRange(1, 200)
        self.l2gSpeed.setValue(20)
        self.l2gSpeed.setSuffix(" km/h")
        pf.addRow("Velocità:", self.l2gSpeed)
        self.l2gHeadway = QSpinBox()
        self.l2gHeadway.setRange(1, 240)
        self.l2gHeadway.setValue(10)
        self.l2gHeadway.setSuffix(" min")
        pf.addRow("Frequenza:", self.l2gHeadway)
        hours = QHBoxLayout()
        self.l2gStart = QSpinBox()
        self.l2gStart.setRange(0, 23)
        self.l2gStart.setValue(6)
        self.l2gEnd = QSpinBox()
        self.l2gEnd.setRange(1, 30)
        self.l2gEnd.setValue(22)
        hours.addWidget(QLabel("dalle"))
        hours.addWidget(self.l2gStart)
        hours.addWidget(QLabel("alle"))
        hours.addWidget(self.l2gEnd)
        hours.addWidget(QLabel("(h)"))
        hours.addStretch()
        pf.addRow("Orario:", self._wrap(hours))
        self.l2gDwell = QSpinBox()
        self.l2gDwell.setRange(0, 600)
        self.l2gDwell.setValue(20)
        self.l2gDwell.setSuffix(" s")
        pf.addRow("Sosta/fermata:", self.l2gDwell)
        self.l2gSnap = QSpinBox()
        self.l2gSnap.setRange(1, 500)
        self.l2gSnap.setValue(50)
        self.l2gSnap.setSuffix(" m")
        pf.addRow("Tolleranza fermate:", self.l2gSnap)
        self.l2gAgency = QLineEdit("Agenzia")
        pf.addRow("Agenzia:", self.l2gAgency)
        self.l2gDirections = QComboBox()
        self.l2gDirections.addItem("Andata e ritorno", "both")
        self.l2gDirections.addItem("Solo nel verso di disegno", "one")
        pf.addRow("Direzioni:", self.l2gDirections)
        self.l2gSide = QComboBox()
        self.l2gSide.addItem("A destra del verso di marcia", "right")
        self.l2gSide.addItem("A sinistra (circolazione a sinistra)", "left")
        self.l2gSide.setToolTip(
            "Le fermate disegnate ai due lati della strada vanno ciascuna "
            "alla sua direzione; quelle sulla linea servono entrambe.")
        pf.addRow("Fermate:", self.l2gSide)
        self.l2gTz = QComboBox()
        self.l2gTz.setEditable(True)
        for tz in ("Europe/Rome", "Europe/London", "Europe/Paris",
                   "Europe/Madrid", "Europe/Berlin", "Asia/Baghdad",
                   "America/New_York", "UTC"):
            self.l2gTz.addItem(tz)
        pf.addRow("Fuso orario:", self.l2gTz)
        self.l2gFrom = QDateEdit(QDate.currentDate())
        self.l2gFrom.setCalendarPopup(True)
        self.l2gTo = QDateEdit(QDate.currentDate().addYears(1))
        self.l2gTo.setCalendarPopup(True)
        pf.addRow("Valido dal:", self.l2gFrom)
        pf.addRow("al:", self.l2gTo)
        self.l2gDays = QComboBox()
        self.l2gDays.addItem("Tutti i giorni", "all")
        self.l2gDays.addItem("Lunedì–venerdì", "weekdays")
        self.l2gDays.addItem("Lunedì–sabato", "monsat")
        pf.addRow("Giorni:", self.l2gDays)
        layout.addWidget(par_box)

        out_row = QHBoxLayout()
        self.l2gOutEdit = QLineEdit()
        self.l2gOutEdit.setPlaceholderText("File GTFS di output (.zip)")
        out_btn = QPushButton("...")
        out_btn.clicked.connect(self._l2g_browse_out)
        out_row.addWidget(self.l2gOutEdit, 1)
        out_row.addWidget(out_btn)
        layout.addLayout(out_row)
        self.l2gRunButton = QPushButton("Genera GTFS")
        self.l2gRunButton.clicked.connect(self._l2g_generate)
        layout.addWidget(self.l2gRunButton)
        self.l2gStatus = QLabel("")
        self.l2gStatus.setWordWrap(True)
        layout.addWidget(self.l2gStatus)
        layout.addStretch()
        return container

    # ------------------------------------------------------ schede nuove
    def _build_isochrones_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("isochrones"))
        form = QFormLayout()
        self.isoaSourceCombo = QgsMapLayerComboBox()
        self.isoaSourceCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.isoaSourceCombo.setAllowEmptyLayer(True)
        form.addRow("Sorgenti (punti):", self.isoaSourceCombo)
        self.isoaUseGtfs = QPushButton("Usa fermate GTFS caricate")
        self.isoaUseGtfs.setCheckable(True)
        form.addRow("", self.isoaUseGtfs)
        pick_row = QHBoxLayout()
        self.isoaPickButton = QPushButton("📍 Scegli")
        self.isoaPickButton.setToolTip("Clic sulla mappa per aggiungere "
                                       "sorgenti.")
        self.isoaPickButton.setCheckable(True)
        self.isoaPickButton.toggled.connect(self._isoa_toggle_pick)
        self.isoaPickClear = QPushButton("Cancella")
        self.isoaPickClear.clicked.connect(self._isoa_clear_pick)
        self.isoaPickLabel = QLabel("0 punti")
        pick_row.addWidget(self.isoaPickButton)
        pick_row.addWidget(self.isoaPickClear)
        pick_row.addWidget(self.isoaPickLabel)
        form.addRow("Sulla mappa:", self._wrap(pick_row))
        self.isoaRoadCombo = QgsMapLayerComboBox()
        self.isoaRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.isoaRoadCombo.setAllowEmptyLayer(True)
        form.addRow("Rete stradale:",
                    self._combo_with_osm(self.isoaRoadCombo, self._iso_osm_mode))
        self.isoaModeCombo = QComboBox()
        self.isoaModeCombo.addItem("Piedi", 4.5)
        self.isoaModeCombo.addItem("Bici", 15.0)
        self.isoaModeCombo.addItem("Auto", 30.0)
        self.isoaModeCombo.addItem("Trasporto pubblico (GTFS)", "pt")
        self.isoaModeCombo.currentIndexChanged.connect(self._isoa_mode_changed)
        form.addRow("Mezzo:", self.isoaModeCombo)
        self.isoaSpeed = QDoubleSpinBox()
        self.isoaSpeed.setDecimals(1)
        self.isoaSpeed.setRange(0.5, 200.0)
        self.isoaSpeed.setSingleStep(0.5)
        self.isoaSpeed.setValue(4.5)
        self.isoaSpeed.setSuffix(" km/h")
        form.addRow("Velocità:", self.isoaSpeed)
        self.isoaTimes = QLineEdit("5,10,15")
        form.addRow("Tempi (min):", self.isoaTimes)
        self.isoaOutput = QComboBox()
        self.isoaOutput.addItem("Concavo (buffer su rete)", "concave")
        self.isoaOutput.addItem("Poligono (area riempita)", "polygon")
        self.isoaOutput.addItem("Lineare (segmenti)", "linear")
        form.addRow("Modalità output:", self.isoaOutput)
        self.isoaDissolve = QCheckBox("Unisci le sorgenti (dissolvi)")
        self.isoaDissolve.setChecked(True)
        form.addRow("", self.isoaDissolve)
        self.isoaOneway = QCheckBox("Rispetta i sensi unici")
        self.isoaOneway.setToolTip("Usa il campo «oneway» della rete (e i "
                                   "sensi unici impliciti OSM).")
        form.addRow("", self.isoaOneway)

        # auto: velocità di ogni strada (limiti OSM, tipo di strada, campo)
        self.isoaCarBox = QGroupBox("Auto · velocità per strada")
        cf = QFormLayout(self.isoaCarBox)
        self.isoaCarSpeeds = QCheckBox("Limite di ogni strada")
        self.isoaCarSpeeds.setChecked(True)
        self.isoaCarSpeeds.setToolTip(
            "Ogni strada si percorre alla sua velocità: campo indicato, "
            "altrimenti limite OSM (maxspeed, anche «IT:urban»), altrimenti "
            "un valore tipico del tipo di strada. Marciapiedi, scale e "
            "percorsi pedonali sono esclusi. Senza spunta tutta la rete va "
            "alla «Velocità» qui sopra.")
        cf.addRow(self.isoaCarSpeeds)
        self.isoaSpeedField = QgsFieldComboBox()
        self.isoaSpeedField.setAllowEmptyFieldName(True)
        self.isoaRoadCombo.layerChanged.connect(self.isoaSpeedField.setLayer)
        self.isoaSpeedField.setLayer(self.isoaRoadCombo.currentLayer())
        cf.addRow("Campo velocità km/h (opz.):", self.isoaSpeedField)
        self.isoaFactor = QSpinBox()
        self.isoaFactor.setRange(10, 150)
        self.isoaFactor.setValue(100)
        self.isoaFactor.setSuffix(" %")
        self.isoaFactor.setToolTip(
            "Quota del limite a cui si viaggia davvero (es. 60–70 % in città "
            "per semafori e traffico).")
        cf.addRow("Velocità effettiva:", self.isoaFactor)
        car_note = QLabel("La «Velocità» qui sopra vale solo per le strade "
                          "senza limite e di tipo sconosciuto.")
        car_note.setWordWrap(True)
        cf.addRow(car_note)
        self.isoaCarBox.setVisible(False)
        form.addRow(self.isoaCarBox)

        # piedi: pendenza dal DEM (Tobler)
        self.isoaDemBox = QGroupBox("A piedi · pendenza (DEM)")
        dfm = QFormLayout(self.isoaDemBox)
        self.isoaDem = self._dem_combo()
        dfm.addRow("DEM (quote in m):", self.isoaDem)
        dem_note = QLabel("Con un DEM la velocità segue la pendenza (funzione "
                          "di Tobler): la «Velocità» è quella in piano, in "
                          "salita si va più piano, in leggera discesa un po' "
                          "più veloce. Ponti e gallerie seguono la pendenza "
                          "fra i loro estremi.")
        dem_note.setWordWrap(True)
        dfm.addRow(dem_note)
        form.addRow(self.isoaDemBox)

        self.isoaPoiCombo = QgsMapLayerComboBox()
        self.isoaPoiCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.isoaPoiCombo.setAllowEmptyLayer(True)
        form.addRow("POI/popolazione (opz.):", self._combo_with_istat(
            self.isoaPoiCombo, lambda: self.isoaPoiWeight, "points",
            jobs=True))
        self.isoaPoiWeight = QgsFieldComboBox()
        self.isoaPoiWeight.setAllowEmptyFieldName(True)
        self.isoaPoiCombo.layerChanged.connect(self.isoaPoiWeight.setLayer)
        self.isoaPoiWeight.setLayer(self.isoaPoiCombo.currentLayer())
        form.addRow("Campo peso (opz.):", self.isoaPoiWeight)
        self.isoaInteractive = QCheckBox("Interattiva: calcola al clic")
        self.isoaInteractive.setToolTip(
            "Ogni clic sulla mappa ricalcola l'isocrona in un unico layer "
            "(solo mezzi su rete, non trasporto pubblico).")
        self.isoaInteractive.toggled.connect(self._isoa_interactive_toggled)
        form.addRow("", self.isoaInteractive)
        layout.addLayout(form)

        iso_adv = QGroupBox("Avanzate")
        ia_f = QFormLayout(iso_adv)
        self.isoaAccess = QSpinBox()
        self.isoaAccess.setRange(1, 500)
        self.isoaAccess.setValue(30)
        self.isoaAccess.setSuffix(" m")
        self.isoaAccess.setToolTip("Larghezza del buffer attorno ai tratti "
                                   "raggiunti (concavo e poligono).")
        ia_f.addRow("Allargamento attorno alla rete:", self.isoaAccess)
        self._make_collapsible(iso_adv, collapsed=True)
        layout.addWidget(iso_adv)

        # --- opzioni Trasporto pubblico: visibili solo in modo TP ---
        self.isoaPtBox = QGroupBox("Trasporto pubblico (GTFS)")
        ptf = QFormLayout(self.isoaPtBox)
        pt_row = QHBoxLayout()
        self.isoaGtfsEdit = QLineEdit()
        self.isoaGtfsEdit.setPlaceholderText(
            "(vuoto = usa il GTFS caricato nella scheda GTFS)")
        isoa_gtfs_btn = QPushButton("Sfoglia...")
        isoa_gtfs_btn.clicked.connect(self._isoa_browse_gtfs)
        pt_row.addWidget(self.isoaGtfsEdit, 1)
        pt_row.addWidget(isoa_gtfs_btn)
        ptf.addRow("GTFS (TP):", self._wrap(pt_row))
        self.isoaStartH = QTimeEdit(QTime(8, 0))
        self.isoaStartH.setDisplayFormat("HH:mm")
        ptf.addRow("Partenza (TP):", self.isoaStartH)
        self.isoaWindow = QSpinBox()
        self.isoaWindow.setRange(0, 120)
        self.isoaWindow.setSingleStep(5)
        self.isoaWindow.setValue(30)
        self.isoaWindow.setSuffix(" min")
        self.isoaWindow.setToolTip(
            "Le partenze sono campionate ogni 5 minuti nella finestra e per ogni "
            "fermata si usa il tempo di viaggio mediano: il risultato non "
            "dipende dal minuto esatto di partenza. 0 = una sola partenza.")
        ptf.addRow("Finestra di partenza:", self.isoaWindow)
        self.isoaAccessMode = self._pt_leg_combo()
        ptf.addRow("Accesso alle fermate:", self.isoaAccessMode)
        self.isoaEgressMode = self._pt_leg_combo()
        ptf.addRow("Egress dalle fermate:", self.isoaEgressMode)
        self.isoaTransferPen = QSpinBox()
        self.isoaTransferPen.setRange(0, 30)
        self.isoaTransferPen.setValue(0)
        self.isoaTransferPen.setSuffix(" min")
        ptf.addRow("Penalità trasferimento:", self.isoaTransferPen)
        self.isoaDivideLines = QCheckBox("Un'isocrona per ogni linea")
        self.isoaDivideLines.setToolTip(
            "Per ogni linea che parte da una fermata raggiungibile a piedi "
            "nella finestra di partenza calcola l'area raggiungibile usando "
            "solo quella linea (accesso, viaggio, egress, senza cambi).")
        ptf.addRow("", self.isoaDivideLines)
        self.isoaPtBox.setVisible(False)
        layout.addWidget(self.isoaPtBox)

        self.isoaRunButton = QPushButton("Crea isocrone")
        self.isoaRunButton.clicked.connect(self._isoa_run)
        layout.addWidget(self.isoaRunButton)
        # barra di avanzamento (visibile solo durante il calcolo) + Annulla
        prog_row = QHBoxLayout()
        self.isoaProgress = QProgressBar()
        self.isoaProgress.setRange(0, 100)
        self.isoaProgress.setTextVisible(True)
        self.isoaCancel = QPushButton("Annulla")
        self.isoaCancel.clicked.connect(self._isoa_cancel)
        prog_row.addWidget(self.isoaProgress, 1)
        prog_row.addWidget(self.isoaCancel)
        self.isoaProgressRow = self._wrap(prog_row)
        self.isoaProgressRow.setVisible(False)
        layout.addWidget(self.isoaProgressRow)
        self.isoaStatus = QLabel("")
        self.isoaStatus.setWordWrap(True)
        layout.addWidget(self.isoaStatus)
        layout.addStretch()
        return container

    def _isoa_mode_changed(self):
        data = self.isoaModeCombo.currentData()
        is_pt = (data == "pt")
        kind = self._isoa_kind()
        self.isoaPtBox.setVisible(is_pt)
        self.isoaCarBox.setVisible(kind == "car")
        self.isoaDemBox.setVisible(kind == "walk")
        if kind != "pt":
            # le auto rispettano i sensi unici, pedoni e bici no (la spunta
            # resta modificabile)
            self.isoaOneway.setChecked(kind == "car")
        if isinstance(data, (int, float)):
            self.isoaSpeed.setValue(float(data))
        elif is_pt:
            # in modo TP la velocità è quella a piedi dei trasbordi fra fermate
            self.isoaSpeed.setValue(4.5)

    def _isoa_kind(self):
        """Mezzo delle isocrone: "walk", "bike", "car" o "pt"."""
        d = self.isoaModeCombo.currentData()
        if d == "pt":
            return "pt"
        return {4.5: "walk", 15.0: "bike", 30.0: "car"}.get(d, "walk")

    @staticmethod
    def _dem_combo():
        return travel_ui.dem_combo()

    @staticmethod
    def _dem_spec(dem, ctx):
        return travel_ui.dem_spec(dem, ctx)

    def _isoa_cost(self, road, ctx):
        """Tempi per tratto delle isocrone su rete.

        :return: (cost per GtfsIsoTask o None, velocità massima km/h che
            delimita l'area di rete da leggere, nota per il messaggio,
            chiave per la cache dell'isocrona interattiva).
        """
        kind = self._isoa_kind()
        speed = self.isoaSpeed.value()
        if kind == "car" and self.isoaCarSpeeds.isChecked():
            fac = self.isoaFactor.value() / 100.0
            sf = self.isoaSpeedField.currentField() or None
            cost, vmax = travel_ui.car_cost(road, speed, fac, sf)
            note = ("velocità di ogni strada (%s, %d %% del limite). "
                    % ("campo «%s»" % sf if sf else "limiti OSM e tipo di "
                       "strada", self.isoaFactor.value()))
            return cost, vmax, note, ("car", sf, fac, speed)
        dem = self.isoaDem.currentLayer() if kind == "walk" else None
        if dem is not None:
            spec = self._dem_spec(dem, ctx)
            cost = {"default_mps": speed / 3.6, "dem": spec}
            return (cost, speed * travel_cost.TOBLER_MAX,
                    "pendenza dal DEM «%s» (Tobler). " % dem.name(),
                    ("dem", dem.id(), speed))
        return None, speed, "", None

    @staticmethod
    def _cost_note(stats):
        """Avviso sulle quote mancanti (strade fuori dal DEM)."""
        n = stats.get("campioni") or 0
        miss = stats.get("senza_quota") or 0
        if n and miss / float(n) > 0.05:
            return (" ⚠️ %.0f %% dei punti delle strade è fuori dal DEM o "
                    "senza quota: lì la pendenza vale zero."
                    % (100.0 * miss / n))
        return ""

    def _isoa_browse_gtfs(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.isoaGtfsEdit.setText(path)

    def _build_ptal_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("ptal"))
        form = QFormLayout()
        self.ptalSourceEdit = QLineEdit()
        self.ptalServiceCombo = QComboBox()
        self.ptalServiceCombo.addItem("GTFS caricato (scheda GTFS)", "gtfs")
        self.ptalServiceCombo.addItem("Dati forniti (layer fermate con "
                                      "frequenze)", "manual")
        self.ptalServiceCombo.currentIndexChanged.connect(
            self._ptal_service_changed)
        form.addRow("Servizio:", self.ptalServiceCombo)
        self.ptalDistCombo = QComboBox()
        self.ptalDistCombo.addItem(
            "PTAL (TfL standard) · linea d'aria", "standard")
        self.ptalDistCombo.addItem("PTAL su rete pedonale", "network")
        self.ptalDistCombo.currentIndexChanged.connect(self._ptal_mode_changed)
        form.addRow("Modalità:", self.ptalDistCombo)
        self.ptalPointsCombo = QgsMapLayerComboBox()
        self.ptalPointsCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.ptalPointsCombo.setAllowEmptyLayer(True)
        form.addRow("Punti di analisi:", self.ptalPointsCombo)
        self.ptalGridCheck = QCheckBox("Griglia automatica (celle)")
        self.ptalGridCheck.setChecked(True)
        form.addRow("", self.ptalGridCheck)
        self.ptalGridShape = QComboBox()
        self.ptalGridShape.addItem("Esagoni", "hex")
        self.ptalGridShape.addItem("Quadrati", "square")
        form.addRow("Griglia:", self.ptalGridShape)
        self.ptalGridSize = QSpinBox()
        self.ptalGridSize.setRange(20, 5000)
        self.ptalGridSize.setValue(200)
        self.ptalGridSize.setSuffix(" m")
        form.addRow("Cella:", self.ptalGridSize)
        self.ptalExtentCombo = QgsMapLayerComboBox()
        self.ptalExtentCombo.setAllowEmptyLayer(True)
        form.addRow("Estensione (vuoto=vista):", self.ptalExtentCombo)
        hours = QHBoxLayout()
        # ora di punta del mattino del metodo TfL
        self.ptalStart = QTimeEdit(QTime(8, 15))
        self.ptalStart.setDisplayFormat("HH:mm")
        self.ptalEnd = QTimeEdit(QTime(9, 15))
        self.ptalEnd.setDisplayFormat("HH:mm")
        hours.addWidget(QLabel("dalle"))
        hours.addWidget(self.ptalStart)
        hours.addWidget(QLabel("alle"))
        hours.addWidget(self.ptalEnd)
        hours.addStretch()
        self.ptalHoursWidget = self._wrap(hours)
        form.addRow("Fascia oraria:", self.ptalHoursWidget)
        self.ptalProfilesCheck = QCheckBox("Profili AM / interpeak / PM")
        self.ptalProfilesCheck.setToolTip("Calcola le tre fasce orarie TfL "
                                          "(ignora la fascia indicata sopra).")
        self.ptalProfilesCheck.toggled.connect(
            lambda on: self.ptalHoursWidget.setEnabled(not on))
        form.addRow("", self.ptalProfilesCheck)
        layout.addLayout(form)
        self.ptalManBox = QGroupBox("Servizio fornito (senza GTFS)")
        mf = QFormLayout(self.ptalManBox)
        note = QLabel("Un punto per ogni linea che serve una fermata nella "
                      "fascia di analisi, con le corse all'ora. Più linee "
                      "alla stessa fermata = più punti nella stessa posizione "
                      "(o con lo stesso codice fermata).")
        note.setWordWrap(True)
        mf.addRow(note)
        self.ptalManLayer = QgsMapLayerComboBox()
        self.ptalManLayer.setFilters(QgsMapLayerProxyModel.PointLayer)
        mf.addRow("Fermate:", self.ptalManLayer)
        self.ptalManFreq = QgsFieldComboBox()
        self.ptalManFreq.setFilters(QgsFieldProxyModel.Numeric)
        mf.addRow("Campo corse/ora:", self.ptalManFreq)
        self.ptalManRoute = QgsFieldComboBox()
        self.ptalManRoute.setAllowEmptyFieldName(True)
        mf.addRow("Campo linea (opz.):", self.ptalManRoute)
        self.ptalManMode = QgsFieldComboBox()
        self.ptalManMode.setAllowEmptyFieldName(True)
        mf.addRow("Campo modo (opz.):", self.ptalManMode)
        self.ptalManStop = QgsFieldComboBox()
        self.ptalManStop.setAllowEmptyFieldName(True)
        mf.addRow("Campo codice fermata (opz.):", self.ptalManStop)
        self.ptalManDefMode = QComboBox()
        for lbl, code in (("Bus", "3"), ("Tram", "0"), ("Metro", "1"),
                          ("Treno", "2"), ("Traghetto", "4")):
            self.ptalManDefMode.addItem(lbl, code)
        mf.addRow("Modo se manca il campo:", self.ptalManDefMode)
        for fc in (self.ptalManFreq, self.ptalManRoute, self.ptalManMode,
                   self.ptalManStop):
            self.ptalManLayer.layerChanged.connect(fc.setLayer)
            fc.setLayer(self.ptalManLayer.currentLayer())
        self.ptalManBox.setVisible(False)
        layout.addWidget(self.ptalManBox)
        self.ptalGtfsBox = self._gtfs_override_box(
            self.ptalSourceEdit, self._ptal_browse)
        layout.addWidget(self.ptalGtfsBox)

        adv = QGroupBox("Avanzate · soglie per mezzo")
        af = QFormLayout(adv)
        self.ptalWalk = QSpinBox()
        self.ptalWalk.setRange(1, 100)
        self.ptalWalk.setValue(48)
        af.addRow("Velocità cammino (km/h ×10):", self.ptalWalk)
        per_mode = QLabel("<b>Per mezzo: soglia di cammino e "
                          "affidabilità</b>")
        per_mode.setWordWrap(True)
        af.addRow(per_mode)
        self.ptalModeWidgets = {}
        mode_grid = QGridLayout()
        for c, h in enumerate(("", "Soglia", "Affidabilità")):
            mode_grid.addWidget(QLabel(h), 0, c)
        for r, (label, rtype, thr, rel) in enumerate([
                ("Bus", "3", 640, 2.0), ("Tram", "0", 640, 1.5),
                ("Metro", "1", 960, 0.75), ("Treno", "2", 960, 0.75)], 1):
            sthr = QSpinBox()
            sthr.setRange(50, 5000)
            sthr.setValue(thr)
            sthr.setSuffix(" m")
            srel = QDoubleSpinBox()
            srel.setDecimals(2)
            srel.setRange(0.0, 60.0)
            srel.setSingleStep(0.25)
            srel.setValue(rel)
            srel.setSuffix(" min")
            mode_grid.addWidget(QLabel(label), r, 0)
            mode_grid.addWidget(sthr, r, 1)
            mode_grid.addWidget(srel, r, 2)
            self.ptalModeWidgets[rtype] = (sthr, srel)
        af.addRow(self._wrap(mode_grid))
        self._make_collapsible(adv, collapsed=True)
        layout.addWidget(adv)

        self.ptalPedBox = QGroupBox("Rete pedonale (PTAL su rete)")
        pedf = QVBoxLayout(self.ptalPedBox)
        ped = QHBoxLayout()
        self.ptalRoadCombo = QgsMapLayerComboBox()
        self.ptalRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.ptalRoadCombo.setAllowEmptyLayer(True)
        ped.addWidget(self.ptalRoadCombo, 1)
        ped.addWidget(self._osm_button(self.ptalRoadCombo, "pedestrian"))
        pedf.addLayout(ped)
        note = QLabel("Distanze a piedi reali sulla rete. <i>Nota:</i> non "
                      "conforme allo standard TfL (linea d'aria).")
        note.setWordWrap(True)
        pedf.addWidget(note)
        self.ptalPedBox.setVisible(False)
        layout.addWidget(self.ptalPedBox)
        self.ptalRunButton = QPushButton("Calcola PTAL")
        self.ptalRunButton.clicked.connect(self._ptal_run)
        layout.addWidget(self.ptalRunButton)

        gap_box = QGroupBox("Gap analysis")
        gf = QFormLayout(gap_box)
        gap_note = QLabel("Celle con PTAL basso e molta popolazione.")
        gap_note.setWordWrap(True)
        gf.addRow(gap_note)
        self.gapPopCombo = QgsMapLayerComboBox()
        self.gapPopCombo.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        gf.addRow("Popolazione:", self._combo_with_istat(
            self.gapPopCombo, lambda: self.gapPopField, "points"))
        self.gapPopField = QgsFieldComboBox()
        self.gapPopField.setAllowEmptyFieldName(True)
        self.gapPopCombo.layerChanged.connect(self.gapPopField.setLayer)
        self.gapPopField.setLayer(self.gapPopCombo.currentLayer())
        gf.addRow("Campo popolazione:", self.gapPopField)
        self.gapButton = QPushButton("Calcola gap analysis")
        self.gapButton.setToolTip("Usa l'ultimo PTAL calcolato a celle.")
        self.gapButton.clicked.connect(self._gap_run)
        gf.addRow(self.gapButton)
        self._make_collapsible(gap_box, collapsed=True)
        layout.addWidget(gap_box)

        self.ptalStatus = QLabel("")
        self.ptalStatus.setWordWrap(True)
        layout.addWidget(self.ptalStatus)
        layout.addStretch()
        return container

    def _build_spacesyntax_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("spacesyntax"))
        form = QFormLayout()
        self.ssRoadCombo = QgsMapLayerComboBox()
        self.ssRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Rete stradale:", self._combo_with_osm(self.ssRoadCombo))
        self.ssRadius = QSpinBox()
        self.ssRadius.setRange(0, 50)
        self.ssRadius.setValue(0)
        self.ssRadius.setSpecialValueText("Globale (Rn)")
        self.ssRadius.setPrefix("R")
        form.addRow("Raggio:", self.ssRadius)
        layout.addLayout(form)
        msg = QLabel("Calcola: connettivita, profondita media/totale, "
                     "integrazione (HH), choice, NAIN, NACH.")
        msg.setWordWrap(True)
        layout.addWidget(msg)
        self.ssRunButton = QPushButton("Calcola space syntax")
        self.ssRunButton.clicked.connect(self._ss_run)
        layout.addWidget(self.ssRunButton)
        self.ssStatus = QLabel("")
        self.ssStatus.setWordWrap(True)
        layout.addWidget(self.ssStatus)
        layout.addStretch()
        return container

    def _build_routing_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("routing"))
        form = QFormLayout()
        self.rtRoadCombo = QgsMapLayerComboBox()
        self.rtRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Rete stradale:", self._combo_with_osm(
            self.rtRoadCombo,
            lambda: "vehicular" if self.rtModeCombo.currentData() == "fastest"
            else "all"))
        self.rtModeCombo = QComboBox()
        self.rtModeCombo.addItem("Più breve (distanza)", "shortest")
        self.rtModeCombo.addItem("Più veloce (tempo, limiti OSM)", "fastest")
        form.addRow("Percorso:", self.rtModeCombo)
        self.rtPairs = QComboBox()
        self.rtPairs.addItem("In sequenza (1 → 2 → 3 …)", "sequence")
        self.rtPairs.addItem("Tutte le coppie", "all")
        form.addRow("Collegamento:", self.rtPairs)
        self.rtPointsCombo = QgsMapLayerComboBox()
        self.rtPointsCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.rtPointsCombo.setAllowEmptyLayer(True)
        form.addRow("Punti (layer):", self.rtPointsCombo)
        self.rtOrderField = QgsFieldComboBox()
        self.rtOrderField.setAllowEmptyFieldName(True)
        self.rtPointsCombo.layerChanged.connect(self.rtOrderField.setLayer)
        self.rtOrderField.setLayer(self.rtPointsCombo.currentLayer())
        form.addRow("Campo ordine (opz.):", self.rtOrderField)
        pick = QHBoxLayout()
        self.rtPickButton = QPushButton("📍 Scegli")
        self.rtPickButton.setToolTip("Clic sulla mappa sui punti, "
                                     "nell'ordine.")
        self.rtPickButton.setCheckable(True)
        self.rtPickButton.toggled.connect(self._rt_toggle_pick)
        pick.addWidget(self.rtPickButton)
        clr = QPushButton("Pulisci")
        clr.clicked.connect(self._rt_clear_pick)
        pick.addWidget(clr)
        self.rtPickLabel = QLabel("0 punti")
        pick.addWidget(self.rtPickLabel)
        pick.addStretch()
        form.addRow("Oppure:", self._wrap(pick))
        self.rtOneway = QCheckBox("Rispetta i sensi unici")
        self.rtOneway.setToolTip("Usa il campo «oneway» della rete (e i sensi "
                                 "unici impliciti OSM).")
        self.rtOneway.setChecked(True)
        form.addRow("", self.rtOneway)
        layout.addLayout(form)
        adv = QGroupBox("Velocità (per il più veloce)")
        af = QFormLayout(adv)
        self.rtSpeedField = QgsFieldComboBox()
        self.rtSpeedField.setAllowEmptyFieldName(True)
        self.rtRoadCombo.layerChanged.connect(self.rtSpeedField.setLayer)
        self.rtSpeedField.setLayer(self.rtRoadCombo.currentLayer())
        af.addRow("Campo velocità km/h (opz.):", self.rtSpeedField)
        self.rtDefSpeed = QSpinBox()
        self.rtDefSpeed.setRange(1, 150)
        self.rtDefSpeed.setValue(50)
        self.rtDefSpeed.setSuffix(" km/h")
        af.addRow("Velocità se manca il limite:", self.rtDefSpeed)
        self.rtFactor = QSpinBox()
        self.rtFactor.setRange(10, 150)
        self.rtFactor.setValue(100)
        self.rtFactor.setSuffix(" %")
        self.rtFactor.setToolTip("Quota del limite a cui si viaggia davvero "
                                 "(es. 70 % per il traffico urbano).")
        af.addRow("Velocità effettiva:", self.rtFactor)
        self._make_collapsible(adv, collapsed=True)
        layout.addWidget(adv)
        self.rtRunButton = QPushButton("Calcola percorsi")
        self.rtRunButton.clicked.connect(self._rt_run)
        layout.addWidget(self.rtRunButton)
        self.rtStatus = QLabel("")
        self.rtStatus.setWordWrap(True)
        layout.addWidget(self.rtStatus)
        layout.addStretch()
        return container

    def _build_od_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("od"))
        form = QFormLayout()
        self.odZonesCombo = QgsMapLayerComboBox()
        self.odZonesCombo.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        self.odZonesCombo.setToolTip("Zone per le desire lines e per la "
                                     "matrice in trasporto pubblico.")
        form.addRow("Zone:", self.odZonesCombo)
        self.odIdField = QgsFieldComboBox()
        self.odZonesCombo.layerChanged.connect(self.odIdField.setLayer)
        self.odIdField.setLayer(self.odZonesCombo.currentLayer())
        form.addRow("Campo ID zona:", self.odIdField)
        layout.addLayout(form)
        dl_box = QGroupBox("Desire lines (CSV)")
        dl = QVBoxLayout(dl_box)
        csv_row = QHBoxLayout()
        self.odCsvEdit = QLineEdit()
        self.odCsvEdit.setPlaceholderText("Matrice OD (CSV)")
        csv_btn = QPushButton("...")
        csv_btn.clicked.connect(self._od_browse_csv)
        csv_row.addWidget(self.odCsvEdit, 1)
        csv_row.addWidget(csv_btn)
        dl.addLayout(csv_row)
        cols = QFormLayout()
        self.odColO = QLineEdit("origin")
        self.odColD = QLineEdit("destination")
        self.odColV = QLineEdit("count")
        cols.addRow("Colonna origine:", self.odColO)
        cols.addRow("Colonna destinazione:", self.odColD)
        cols.addRow("Colonna valore:", self.odColV)
        dl.addLayout(cols)
        filt = QGroupBox("Filtri")
        ff = QFormLayout(filt)
        self.odMinFlow = QSpinBox()
        self.odMinFlow.setRange(0, 1000000)
        self.odMinFlow.setValue(0)
        ff.addRow("Flusso minimo:", self.odMinFlow)
        self.odTopN = QSpinBox()
        self.odTopN.setRange(0, 100000)
        self.odTopN.setValue(0)
        self.odTopN.setSpecialValueText("tutte")
        ff.addRow("Top N (per flusso):", self.odTopN)
        self.odFilterO = QLineEdit()
        self.odFilterO.setPlaceholderText("(opz.) solo da questa origine")
        ff.addRow("Solo origine:", self.odFilterO)
        self.odFilterD = QLineEdit()
        self.odFilterD.setPlaceholderText("(opz.) solo verso questa destinazione")
        ff.addRow("Solo destinazione:", self.odFilterD)
        dl.addWidget(filt)
        self.odArc = QCheckBox("Linee arcuate")
        self.odArc.setToolTip("Curve che separano andata e ritorno.")
        self.odArc.setChecked(True)
        dl.addWidget(self.odArc)
        self.odRunButton = QPushButton("Crea desire lines")
        self.odRunButton.clicked.connect(self._od_run)
        dl.addWidget(self.odRunButton)
        self._make_collapsible(dl_box, collapsed=False)
        layout.addWidget(dl_box)

        rm = QGroupBox("Matrice su strada (Excel)")
        rf = QFormLayout(rm)
        self.odrOrig = QgsMapLayerComboBox()
        self.odrOrig.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        rf.addRow("Origini:", self.odrOrig)
        self.odrOrigId = QgsFieldComboBox()
        self.odrOrigId.setAllowEmptyFieldName(True)
        self.odrOrig.layerChanged.connect(self.odrOrigId.setLayer)
        self.odrOrigId.setLayer(self.odrOrig.currentLayer())
        rf.addRow("Campo ID (vuoto = n. feature):", self.odrOrigId)
        self.odrDest = QgsMapLayerComboBox()
        self.odrDest.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        self.odrDest.setAllowEmptyLayer(True)
        self.odrDest.setLayer(None)
        self.odrDest.setToolTip("Vuoto = le stesse origini (matrice quadrata).")
        rf.addRow("Destinazioni (vuoto = origini):", self.odrDest)
        self.odrDestId = QgsFieldComboBox()
        self.odrDestId.setAllowEmptyFieldName(True)
        self.odrDest.layerChanged.connect(self.odrDestId.setLayer)
        rf.addRow("Campo ID destinazioni:", self.odrDestId)
        self.odrRoad = QgsMapLayerComboBox()
        self.odrRoad.setFilters(QgsMapLayerProxyModel.LineLayer)
        rf.addRow("Rete stradale:", self._combo_with_osm(
            self.odrRoad, lambda: self.odrTravel.osm_mode()))
        self.odrTravel = travel_ui.TravelControls(rf, self.odrRoad)
        self.odrMax = QSpinBox()
        self.odrMax.setRange(0, 1440)
        self.odrMax.setSingleStep(15)
        self.odrMax.setSuffix(" min")
        self.odrMax.setSpecialValueText("nessuno")
        self.odrMax.setToolTip("Oltre questo tempo la coppia risulta non "
                               "raggiungibile (calcolo più rapido).")
        rf.addRow("Tempo massimo:", self.odrMax)
        self.odrLines = QCheckBox("Linee O → D sulla mappa")
        self.odrLines.setToolTip("In linea d'aria, colorate per tempo; fino "
                                 "a 20 000 coppie.")
        self.odrLines.setChecked(True)
        rf.addRow("", self.odrLines)
        self.odrButton = QPushButton("Calcola matrice (Excel)…")
        self.odrButton.clicked.connect(self._odr_run)
        rf.addRow(self.odrButton)
        self._make_collapsible(rm, collapsed=True)
        layout.addWidget(rm)

        tm = QGroupBox("Matrice tempi in TP (GTFS)")
        tf = QFormLayout(tm)
        tr = QHBoxLayout()
        self.odTmGtfs = QLineEdit()
        self.odTmGtfs.setPlaceholderText(
            "(vuoto = usa il GTFS caricato nella scheda GTFS)")
        tb = QPushButton("Sfoglia...")
        tb.clicked.connect(self._od_tm_browse)
        tr.addWidget(self.odTmGtfs, 1)
        tr.addWidget(tb)
        tf.addRow("GTFS:", self._wrap(tr))
        self.odTmStart = QSpinBox()
        self.odTmStart.setRange(0, 23)
        self.odTmStart.setValue(8)
        tf.addRow("Ora partenza:", self.odTmStart)
        self.odTmBudget = QSpinBox()
        self.odTmBudget.setRange(5, 240)
        self.odTmBudget.setValue(60)
        self.odTmBudget.setSuffix(" min")
        tf.addRow("Budget:", self.odTmBudget)
        self.odTmButton = QPushButton("Calcola matrice tempi TP")
        self.odTmButton.clicked.connect(self._od_matrix_run)
        tf.addRow(self.odTmButton)
        self._make_collapsible(tm, collapsed=True)
        layout.addWidget(tm)

        self.odStatus = QLabel("")
        self.odStatus.setWordWrap(True)
        layout.addWidget(self.odStatus)
        layout.addStretch()
        return container

    def _build_access_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("access"))
        form = QFormLayout()
        self.accOriginCombo = QgsMapLayerComboBox()
        self.accOriginCombo.setFilters(QgsMapLayerProxyModel.PointLayer)
        form.addRow("Origini (punti):", self._combo_with_istat(
            self.accOriginCombo, None, "points"))
        self.accDestCombo = QgsMapLayerComboBox()
        self.accDestCombo.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Destinazioni:", self._combo_with_istat(
            self.accDestCombo, lambda: self.accWeightField, "jobs",
            jobs=True))
        self.accWeightField = QgsFieldComboBox()
        self.accWeightField.setAllowEmptyFieldName(True)
        self.accDestCombo.layerChanged.connect(self.accWeightField.setLayer)
        self.accWeightField.setLayer(self.accDestCombo.currentLayer())
        form.addRow("Campo peso (opz.):", self.accWeightField)
        self.accModeCombo = QComboBox()
        self.accModeCombo.addItem("A piedi", 4.5)
        self.accModeCombo.addItem("Bici", 15.0)
        self.accModeCombo.addItem("Auto", 30.0)
        self.accModeCombo.addItem("Trasporto pubblico (GTFS)", "pt")
        form.addRow("Modo:", self.accModeCombo)
        self.accRoadCombo = QgsMapLayerComboBox()
        self.accRoadCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.accRoadCombo.setAllowEmptyLayer(True)
        form.addRow("Rete (per modi su strada):",
                    self._combo_with_osm(self.accRoadCombo, self._acc_osm_mode))
        self.accOneway = QCheckBox("Rispetta i sensi unici")
        self.accOneway.setToolTip("Usa il campo «oneway» della rete (e i "
                                  "sensi unici impliciti OSM).")
        form.addRow("", self.accOneway)
        gr = QHBoxLayout()
        self.accGtfsEdit = QLineEdit()
        self.accGtfsEdit.setPlaceholderText(
            "(vuoto = usa il GTFS caricato nella scheda GTFS)")
        gbtn = QPushButton("Sfoglia...")
        gbtn.clicked.connect(self._acc_browse_gtfs)
        gr.addWidget(self.accGtfsEdit, 1)
        gr.addWidget(gbtn)
        form.addRow("GTFS (TP):", self._wrap(gr))
        self.accStartH = QSpinBox()
        self.accStartH.setRange(0, 23)
        self.accStartH.setValue(8)
        form.addRow("Ora partenza (TP):", self.accStartH)
        self.accTimes = QLineEdit("15,30")
        form.addRow("Tempi (min):", self.accTimes)
        layout.addLayout(form)

        self.accPtBox = QGroupBox("Opzioni multimodali (TP)")
        apf = QFormLayout(self.accPtBox)
        self.accAccessMode = self._pt_leg_combo()
        apf.addRow("Accesso alle fermate:", self.accAccessMode)
        self.accEgressMode = self._pt_leg_combo()
        apf.addRow("Egress dalle fermate:", self.accEgressMode)
        self.accTransferPen = QSpinBox()
        self.accTransferPen.setRange(0, 30)
        self.accTransferPen.setValue(0)
        self.accTransferPen.setSuffix(" min")
        apf.addRow("Penalità trasferimento:", self.accTransferPen)
        self.accPtBox.setVisible(False)
        self.accModeCombo.currentIndexChanged.connect(self._acc_mode_changed)
        layout.addWidget(self.accPtBox)

        self.accRunButton = QPushButton("Calcola accessibilità")
        self.accRunButton.clicked.connect(self._acc_run)
        layout.addWidget(self.accRunButton)
        self.accStatus = QLabel("")
        self.accStatus.setWordWrap(True)
        layout.addWidget(self.accStatus)

        eq_box = QGroupBox("Sintesi ed equità")
        eqf = QFormLayout(eq_box)
        self.eqLayerCombo = QgsMapLayerComboBox()
        self.eqLayerCombo.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        eqf.addRow("Layer (accessibilità/PTAL):", self.eqLayerCombo)
        self.eqValueField = QgsFieldComboBox()
        self.eqLayerCombo.layerChanged.connect(self.eqValueField.setLayer)
        self.eqValueField.setLayer(self.eqLayerCombo.currentLayer())
        eqf.addRow("Campo valore:", self.eqValueField)
        self.eqWeightField = QgsFieldComboBox()
        self.eqWeightField.setAllowEmptyFieldName(True)
        self.eqLayerCombo.layerChanged.connect(self.eqWeightField.setLayer)
        self.eqWeightField.setLayer(self.eqLayerCombo.currentLayer())
        eqf.addRow("Campo peso/popolazione (opz.):", self.eqWeightField)
        self.eqThreshold = QDoubleSpinBox()
        self.eqThreshold.setRange(0, 1e9)
        self.eqThreshold.setDecimals(2)
        self.eqThreshold.setValue(3)
        eqf.addRow("Soglia «servito» (valore ≥):", self.eqThreshold)
        eq_btns = QHBoxLayout()
        self.eqRunButton = QPushButton("Calcola")
        self.eqRunButton.setToolTip("Calcola le metriche di sintesi e "
                                    "di equità.")
        self.eqRunButton.clicked.connect(self._eq_run)
        self.eqChartButton = QPushButton("Lorenz")
        self.eqChartButton.setToolTip("Grafico della curva di Lorenz.")
        self.eqChartButton.setEnabled(False)
        self.eqChartButton.clicked.connect(self._eq_chart)
        self.eqExportButton = QPushButton("Excel")
        self.eqExportButton.setToolTip("Esporta le metriche in Excel.")
        self.eqExportButton.setEnabled(False)
        self.eqExportButton.clicked.connect(self._eq_export)
        eq_btns.addWidget(self.eqRunButton)
        eq_btns.addWidget(self.eqChartButton)
        eq_btns.addWidget(self.eqExportButton)
        eqf.addRow(self._wrap(eq_btns))
        self.eqTable = self._make_table()
        eqf.addRow(self.eqTable)
        self.eqStatus = QLabel("")
        self.eqStatus.setWordWrap(True)
        eqf.addRow(self.eqStatus)
        self._make_collapsible(eq_box, collapsed=True)
        layout.addWidget(eq_box)

        cmp_box = QGroupBox("Confronto scenari (B − A)")
        cf = QFormLayout(cmp_box)
        self.cmpLayerA = QgsMapLayerComboBox()
        self.cmpLayerA.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        cf.addRow("Scenario A:", self.cmpLayerA)
        self.cmpFieldA = QgsFieldComboBox()
        self.cmpLayerA.layerChanged.connect(self.cmpFieldA.setLayer)
        self.cmpFieldA.setLayer(self.cmpLayerA.currentLayer())
        cf.addRow("Campo A:", self.cmpFieldA)
        self.cmpLayerB = QgsMapLayerComboBox()
        self.cmpLayerB.setFilters(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.PolygonLayer)
        cf.addRow("Scenario B:", self.cmpLayerB)
        self.cmpFieldB = QgsFieldComboBox()
        self.cmpLayerB.layerChanged.connect(self.cmpFieldB.setLayer)
        self.cmpFieldB.setLayer(self.cmpLayerB.currentLayer())
        cf.addRow("Campo B:", self.cmpFieldB)
        self.cmpMaxDist = QDoubleSpinBox()
        self.cmpMaxDist.setRange(0, 1e6)
        # di default solo feature sovrapposte o quasi (stessa griglia/punti)
        self.cmpMaxDist.setValue(50)
        self.cmpMaxDist.setSuffix(" m")
        self.cmpMaxDist.setSpecialValueText("nessun limite")
        cf.addRow("Distanza max abbinamento:", self.cmpMaxDist)
        self.cmpButton = QPushButton("Calcola differenza (B − A)")
        self.cmpButton.clicked.connect(self._cmp_run)
        cf.addRow(self.cmpButton)
        self.cmpStatus = QLabel("")
        self.cmpStatus.setWordWrap(True)
        cf.addRow(self.cmpStatus)
        self._make_collapsible(cmp_box, collapsed=True)
        layout.addWidget(cmp_box)

        scn_box = QGroupBox("Scenario A/B fra due reti")
        sf = QFormLayout(scn_box)
        scn_note = QLabel("Confronta due reti (es. stato attuale e "
                          "progetto) con origini, destinazioni, modo e tempi "
                          "indicati sopra.")
        scn_note.setWordWrap(True)
        sf.addRow(scn_note)
        self.scnKind = QComboBox()
        self.scnKind.addItem("Accessibilità (origini → destinazioni)", "acc")
        self.scnKind.addItem("Isocrone (area raggiungibile, differenza "
                             "geometrica)", "iso")
        sf.addRow("Tipo confronto:", self.scnKind)
        self.scnRoadA = QgsMapLayerComboBox()
        self.scnRoadA.setFilters(QgsMapLayerProxyModel.LineLayer)
        sf.addRow("Rete A (attuale):", self._combo_with_osm(self.scnRoadA, "all"))
        self.scnRoadB = QgsMapLayerComboBox()
        self.scnRoadB.setFilters(QgsMapLayerProxyModel.LineLayer)
        sf.addRow("Rete B (progetto):", self._combo_with_osm(self.scnRoadB, "all"))
        self.scnButton = QPushButton("Confronta scenari A/B")
        self.scnButton.clicked.connect(self._scn_run)
        sf.addRow(self.scnButton)
        self.scnStatus = QLabel("")
        self.scnStatus.setWordWrap(True)
        sf.addRow(self.scnStatus)
        self._make_collapsible(scn_box, collapsed=True)
        layout.addWidget(scn_box)
        layout.addStretch()
        return container

    @staticmethod
    def _wrap(layout):
        # riga dentro un modulo: niente margini propri (si sommerebbero a
        # quelli del modulo e allargherebbero il pannello)
        layout.setContentsMargins(0, 0, 0, 0)
        w = QWidget()
        w.setLayout(layout)
        return w

    @staticmethod
    def _pt_leg_combo():
        c = QComboBox()
        c.addItem("A piedi", 4.5)
        c.addItem("In bici", 15.0)
        return c

    @staticmethod
    def _pt_leg_params(combo):
        """(velocità km/h, raggio max m) del modo di accesso/egress al TP."""
        speed = float(combo.currentData())
        radius = 3000.0 if speed >= 15 else 800.0
        return speed, radius

    @staticmethod
    def _road_spec(layer, ctx, respect_oneway=False, clip_wgs=None,
                   radius_m=0.0):
        """Rete da leggere in un task (GtfsIsoTask): sorgente di feature
        thread-safe + CRS + contesto di trasformazione + sensi unici.

        Con `clip_wgs` (ovest, sud, est, nord) il task legge solo le strade
        nel riquadro raggiungibile: riduce la rete alla parte utile invece di
        leggere e pulire tutto il layer (es. una città intera).
        """
        n_layer = max(0, layer.featureCount())
        spec = {"source": QgsVectorLayerFeatureSource(layer),
                "crs": layer.crs(), "ctx": ctx, "count": n_layer,
                "layer_count": n_layer, "radius_m": radius_m,
                # oneway, o junction/highway OSM (sensi unici impliciti)
                "oneway": bool(respect_oneway and {"oneway", "junction",
                                                   "highway"}
                               & {n.lower() for n in layer.fields().names()}),
                "level_of": topology.level_reader(layer.fields().names())}
        if clip_wgs is not None:
            try:
                rect = QgsCoordinateTransform(
                    isochrones.WGS84, layer.crs(), ctx).transformBoundingBox(
                    QgsRectangle(*clip_wgs))
            except Exception:
                rect = None  # CRS non trasformabile: si legge tutto
            if rect is not None:
                ext = layer.extent()
                inter = rect.intersect(ext)
                frac = (inter.area() / ext.area()) if ext.area() > 0 else 1.0
                spec["rect"] = rect
                # stima delle strade da leggere, solo per la barra
                spec["count"] = max(1, int(n_layer * min(1.0, frac)))
        return spec

    def _run_modal(self, title, fn):
        """Esegue fn(task) in un QgsTask con una barra modale e «Annulla»:
        QGIS resta reattivo anche su reti grandi.

        :return: risultato di fn; None se annullato. Rilancia l'errore.
        """
        task = FunctionTask(title, fn)
        dlg = QProgressDialog(title, "Annulla", 0, 100, self)
        dlg.setWindowTitle("MIC - Utilities")
        dlg.setWindowModality(Qt.WindowModal)
        dlg.setMinimumDuration(300)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        state = {"done": False}
        loop = QEventLoop()

        def _finish(*_a):
            state["done"] = True
            loop.quit()
        task.progressChanged.connect(lambda p: dlg.setValue(int(p)))
        dlg.canceled.connect(task.cancel)
        task.taskCompleted.connect(_finish)
        task.taskTerminated.connect(_finish)
        QgsApplication.taskManager().addTask(task)
        if not state["done"]:
            loop.exec_()
        dlg.close()
        dlg.deleteLater()
        if task.exception is not None:
            raise task.exception
        if task.cancelled or task.result is None and dlg.wasCanceled():
            return None
        return task.result

    def _clean_roads_modal(self, layer, ctx, respect_oneway=False,
                           coords=None, title=None):
        """Rete letta, pulita, validata (e preflight sulle sorgenti) in un
        task con barra: prima avveniva sul thread principale.

        :return: (roads, dirs, msg_preflight) o None se annullato.
        :raises ValueError: rete non valida o nessuna sorgente agganciata.
        """
        spec = self._road_spec(layer, ctx, respect_oneway)

        def _job(task):
            raw, dirs = read_spec_roads(spec, task, 0, 60)
            roads, dirs, _st = net_clean.clean_network(raw, 1.0, dirs)
            ok, vmsg, _i = net_iso.validate_network(roads)
            if not ok:
                raise ValueError("Rete non valida: " + vmsg)
            task.setProgress(80)
            msg = ""
            if coords:
                ok, msg = network_diagnostics.preflight(roads, dirs, coords)
                if not ok:
                    raise ValueError(msg)
            return roads, dirs, msg
        return self._run_modal(title or "Lettura della rete…", _job)

    def _read_roads_modal(self, layer, ctx, respect_oneway=True, title=None):
        """Strade lon/lat + sensi + id feature + livelli, lette in un task.

        :return: (roads, dirs, ids, levels) o None se annullato.
        """
        spec = self._road_spec(layer, ctx, respect_oneway)

        def _job(task):
            ids, levels = [], []
            roads, dirs = read_spec_roads(spec, task, 0, 100, ids=ids,
                                          levels=levels)
            return roads, dirs, ids, levels
        return self._run_modal(title or "Lettura della rete…", _job)

    # ------------------------------------------------------- rete da OSM
    def _osm_button(self, target_combo, mode="all"):
        """Bottone che scarica la rete stradale dell'inquadratura da OSM.

        `mode` puo' essere una stringa (all/pedestrian/bicycle/vehicular) o una
        callable che la restituisce (per modo dinamico in base al mezzo scelto).
        """
        btn = QPushButton("🌐 Da OSM")
        btn.setToolTip("Scarica dall'inquadratura corrente la rete stradale "
                       "da OpenStreetMap (filtrata per modo) e la imposta qui.")
        btn.clicked.connect(lambda: self._download_osm_roads(target_combo, mode))
        return btn

    def _istat_button(self, target_combo, field_getter=None, kind="points",
                      jobs=False):
        """Bottone che mette in un campo di popolazione i residenti ISTAT
        2021 dell'inquadratura: `kind` "points" = un punto per sezione di
        censimento, "polygons" = le sezioni, "jobs" = gli addetti 2011.
        `field_getter()` dà la casella del campo del peso. Con `jobs` il
        bottone ha un menu: residenti 2021 o addetti 2011 (il primo è
        `kind`)."""
        btn = QPushButton("🌐 ISTAT")
        if not jobs:
            btn.setToolTip(
                "Scarica dall'ISTAT i residenti 2021 delle sezioni di "
                "censimento dell'inquadratura corrente (solo in Italia; una "
                "volta sola per regione) e li imposta qui: %s, con i "
                "residenti nel campo POP21." % (
                    "un punto per sezione" if kind == "points"
                    else "le sezioni con residenti"))
            btn.clicked.connect(
                lambda: self._istat_fill(target_combo, field_getter, kind))
            return btn
        from qgis.PyQt.QtWidgets import QMenu
        menu = QMenu(btn)
        items = [("points", "Residenti 2021 (un punto per sezione, POP21)"),
                 ("jobs", "Addetti 2011 (un punto per sezione, ADD_TOT)")]
        if kind == "jobs":
            items.reverse()
        for k, label in items:
            act = menu.addAction(label)
            act.triggered.connect(
                lambda _c=False, _k=k: self._istat_fill(
                    target_combo, field_getter, _k))
        btn.setMenu(menu)
        btn.setToolTip(
            "Dati ISTAT dell'inquadratura corrente (solo in Italia; si "
            "scaricano una volta sola per regione): i residenti 2021 o gli "
            "addetti (posti di lavoro) del censimento 2011, un punto per "
            "sezione di censimento con il peso già impostato.")
        return btn

    def _combo_with_istat(self, combo, field_getter=None, kind="points",
                          jobs=False):
        """Riga: combo layer + bottone dei dati ISTAT."""
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(combo, 1)
        row.addWidget(self._istat_button(combo, field_getter, kind, jobs))
        return self._wrap(row)

    def _istat_fill(self, target_combo, field_getter=None, kind="points"):
        """Residenti ISTAT (o addetti, kind "jobs") dell'inquadratura nel
        campo di una scheda. I dati presi per un'inquadratura si riusano
        finché la vista resta dentro (e non è molto più stretta): un
        secondo bottone non riscarica e non crea doppioni."""
        jobs = kind == "jobs"
        weight = "ADD_TOT" if jobs else "POP21"
        bar = self.iface.messageBar()
        canvas = self.iface.mapCanvas()
        ct = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                    isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        r = ct.transformBoundingBox(canvas.extent())
        rect = (r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum())
        regs = istat.regions_for_bbox(*rect)
        if not regs:
            bar.pushWarning("ISTAT", "L'inquadratura non è in Italia: i "
                            "dati ISTAT coprono solo il territorio "
                            "italiano.")
            return
        if len(regs) > 2 and QMessageBox.question(
                self, "Inquadratura ampia", "L'inquadratura tocca %d "
                "regioni (%s): si scaricano i dati di tutte.\n\n"
                "Continuare?" % (len(regs), ", ".join(
                    istat.REGIONS[c] for c in regs))) != QMessageBox.Yes:
            return

        def apply(layer):
            target_combo.setLayer(layer)
            fc = field_getter() if field_getter is not None else None
            if fc is not None:
                fc.setLayer(layer)
                fc.setField(weight)

        proj = QgsProject.instance()
        view = self._jobs_view if jobs else self._istat_view
        data = None
        if view is not None:
            w, s_, e, n = view["rect"]
            inside = (w <= rect[0] and s_ <= rect[1] and e >= rect[2]
                      and n >= rect[3])
            area = max(1e-12, (rect[2] - rect[0]) * (rect[3] - rect[1]))
            if inside and (e - w) * (n - s_) <= 4.0 * area:
                lid = view["layers"].get(kind)
                lay = proj.mapLayer(lid) if lid else None
                if lay is not None:
                    apply(lay)
                    bar.pushInfo("ISTAT", "%s ISTAT già caricati per "
                                 "questa zona: uso «%s»." % (
                                     "Addetti" if jobs else "Residenti",
                                     lay.name()))
                    return
                data = view["data"]
        if data is None:
            try:
                if jobs:
                    data = self._run_modal(
                        "Addetti ISTAT 2011…",
                        lambda task: addetti.fetch(
                            rect=rect, progress=task.setProgress,
                            is_canceled=task.isCanceled))
                else:
                    data = self._run_modal(
                        "Sezioni ISTAT 2021…",
                        lambda task: istat.fetch(
                            rect=rect, indicators=False,
                            progress=task.setProgress,
                            is_canceled=task.isCanceled))
            except Exception as exc:
                self._ist_cache_refresh()
                bar.pushWarning("ISTAT", "Dati ISTAT non scaricati: %s"
                                % exc)
                return
            self._ist_cache_refresh()
            if data is None:
                bar.pushInfo("ISTAT", "Download annullato.")
                return
            ip = data["fields"].index(weight)
            data["rows"] = [x for x in data["rows"] if x[2][ip]]
            if not data["rows"]:
                bar.pushWarning("ISTAT", "Nessuna sezione di censimento con "
                                "%s nell'inquadratura." % (
                                    "addetti" if jobs else "residenti"))
                return
            view = {"rect": rect, "data": data, "layers": {}}
            if jobs:
                self._jobs_view = view
            else:
                self._istat_view = view
        if jobs:
            lay = addetti.build_points_layer(
                data, "ISTAT 2011 – addetti (punti)")
        elif kind == "points":
            lay = istat.build_points_layer(
                data, "ISTAT 2021 – residenti (punti)")
        else:
            lay = istat.build_layer(
                data, "ISTAT 2021 – sezioni con residenti", "dens")
        lay = self._add_output(lay, zoom=False)
        view["layers"][kind] = lay.id()
        apply(lay)
        ip = data["fields"].index(weight)
        if jobs:
            bar.pushSuccess(
                "ISTAT", "Addetti dell'inquadratura (censimento 2011, "
                "l'ultimo per sezione): %s sezioni, %s addetti nel campo "
                "ADD_TOT di «%s». Fonte: ISTAT (CC BY 4.0)." % (
                    istat.fmt(len(data["rows"])),
                    istat.fmt(sum(x[2][ip] for x in data["rows"])),
                    lay.name()))
            return
        bar.pushSuccess(
            "ISTAT", "Residenti 2021 dell'inquadratura: %s sezioni, %s "
            "residenti nel campo POP21 di «%s». Fonte: ISTAT (CC BY 4.0)." % (
                istat.fmt(len(data["rows"])),
                istat.fmt(sum(x[2][ip] for x in data["rows"])), lay.name()))

    def _combo_with_osm(self, combo, mode="all"):
        """Riga: combo layer + bottone 'Rete da OSM'."""
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(combo, 1)
        row.addWidget(self._osm_button(combo, mode))
        return self._wrap(row)

    def _iso_osm_mode(self):
        d = self.isoaModeCombo.currentData()
        if d == "pt":
            return "pedestrian"
        return {4.5: "pedestrian", 15.0: "bicycle",
                30.0: "vehicular"}.get(d, "all")

    def _acc_osm_mode(self):
        d = self.accModeCombo.currentData()
        if d == "pt":
            return "pedestrian"
        return {4.5: "pedestrian", 15.0: "bicycle",
                30.0: "vehicular"}.get(d, "all")

    def _download_osm_roads(self, target_combo, mode="all"):
        if self._osm_task is not None:
            self.iface.messageBar().pushInfo(
                "OSM", "Download della rete gia' in corso.")
            return
        mode = mode() if callable(mode) else mode
        canvas = self.iface.mapCanvas()
        ext = canvas.extent()
        crs = canvas.mapSettings().destinationCrs()
        ct = QgsCoordinateTransform(crs, isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        r = ct.transformBoundingBox(ext)
        south, west = r.yMinimum(), r.xMinimum()
        north, east = r.yMaximum(), r.xMaximum()
        if (north - south) * (east - west) > 0.25:
            res = QMessageBox.question(
                self, "Inquadratura ampia",
                "L'inquadratura e' molto ampia: il download da OSM puo' essere "
                "lento o fallire. Conviene zoomare di piu'.\n\nContinuare comunque?")
            if res != QMessageBox.Yes:
                return
        self._osm_target = target_combo
        self._osm_mode = mode
        task = OsmRoadsTask((south, west, north, east), mode)
        self._osm_task = task
        task.taskCompleted.connect(lambda t=task: self._osm_done(t))
        task.taskTerminated.connect(lambda t=task: self._osm_failed(t))
        label = osm_download.MODE_LABEL.get(mode, "completa")
        self.iface.messageBar().pushInfo(
            "OSM", "Scarico la rete stradale (%s) dell'inquadratura..." % label)
        QgsApplication.taskManager().addTask(task)

    def _osm_done(self, task):
        target = self._osm_target
        mode = getattr(self, "_osm_mode", "all")
        self._osm_task = None
        self._osm_target = None
        ways = task.result or []
        if not ways:
            self.iface.messageBar().pushWarning(
                "OSM", "Nessuna strada trovata nell'inquadratura.")
            return
        label = osm_download.MODE_LABEL.get(mode, "completa")
        layer = osm_download.build_roads_layer(
            ways, name="OSM - Rete %s" % label)
        layer = self._add_output(layer)
        if target is not None:
            target.setLayer(layer)
        src = ("dalla cache (per riscaricarla: Preset area OSM → Svuota "
               "cache)" if getattr(task, "from_cache", False) else "scaricata")
        self.iface.messageBar().pushSuccess(
            "OSM", "Rete %s OSM %s: %d strade." % (label, src, len(ways)))

    def _osm_failed(self, task):
        self._osm_task = None
        self._osm_target = None
        if getattr(task, "cancelled", False):
            self.iface.messageBar().pushInfo("OSM", "Download annullato.")
        else:
            self.iface.messageBar().pushWarning(
                "OSM", "Errore download OSM: %s" % task.exception)

    def _download_osm_crossings(self):
        if self._osm_cross_task is not None:
            self.iface.messageBar().pushInfo("OSM", "Download gia' in corso.")
            return
        canvas = self.iface.mapCanvas()
        ct = QgsCoordinateTransform(
            canvas.mapSettings().destinationCrs(), isochrones.WGS84,
            QgsProject.instance().transformContext())
        r = ct.transformBoundingBox(canvas.extent())
        if (r.yMaximum() - r.yMinimum()) * (r.xMaximum() - r.xMinimum()) > 0.25:
            if QMessageBox.question(
                    self, "Inquadratura ampia",
                    "L'inquadratura e' molto ampia: il download da OSM puo' "
                    "essere lento o fallire.\n\nContinuare comunque?"
                    ) != QMessageBox.Yes:
                return
        task = OsmCrossingsTask((r.yMinimum(), r.xMinimum(),
                                 r.yMaximum(), r.xMaximum()))
        self._osm_cross_task = task
        task.taskCompleted.connect(lambda t=task: self._osm_cross_done(t))
        task.taskTerminated.connect(lambda t=task: self._osm_cross_failed(t))
        self.iface.messageBar().pushInfo(
            "OSM", "Scarico gli attraversamenti pedonali dell'inquadratura...")
        QgsApplication.taskManager().addTask(task)

    def _osm_cross_done(self, task):
        self._osm_cross_task = None
        pts = task.result or []
        if not pts:
            self.iface.messageBar().pushWarning(
                "OSM", "Nessun attraversamento trovato nell'inquadratura.")
            return
        layer = osm_download.build_points_layer(pts)
        layer = self._add_output(layer, zoom=False)
        self.walkCross.setLayer(layer)
        src = "da cache" if getattr(task, "from_cache", False) else "scaricati"
        self.iface.messageBar().pushSuccess(
            "OSM", "Attraversamenti OSM %s: %d." % (src, len(pts)))

    def _osm_cross_failed(self, task):
        self._osm_cross_task = None
        if getattr(task, "cancelled", False):
            self.iface.messageBar().pushInfo("OSM", "Download annullato.")
        else:
            self.iface.messageBar().pushWarning(
                "OSM", "Errore download attraversamenti: %s" % task.exception)

    def _make_collapsible(self, groupbox, collapsed=True):
        """Sezione richiudibile: freccia nel titolo (▸ chiusa, ▾ aperta).

        Il contenuto (layout già riempito) passa in un contenitore unico che
        si mostra o nasconde: i controlli dentro restano visibili o nascosti
        secondo la loro logica (es. le opzioni dell'auto solo in auto) anche
        riaprendo la sezione, cosa che prima non accadeva.
        """
        lay = groupbox.layout()
        inner = QWidget()
        if lay is not None:
            inner.setLayout(lay)  # sposta layout e widget nel contenitore
        outer = QVBoxLayout(groupbox)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)
        groupbox.setCheckable(True)

        def _set(on):
            inner.setVisible(on)
            # chiusa: solo il titolo, senza riquadro vuoto sotto
            groupbox.setProperty("micCollapsed", not on)
            st = groupbox.style()
            st.unpolish(groupbox)
            st.polish(groupbox)
        groupbox.toggled.connect(_set)
        groupbox.setChecked(not collapsed)
        _set(not collapsed)
        groupbox.setToolTip("Clic sul titolo per aprire o chiudere la sezione.")
        return groupbox

    # ------------------------------------------------- output (gruppo + zoom)
    OUTPUT_GROUP = "MIC - Utilities"

    def _add_output(self, layer, zoom=True, save=True):
        """Aggiunge un layer di risultato al gruppo 'MIC - Utilities' e zooma.

        Con save=True lo salva prima su file secondo l'impostazione
        «Risultati» (riga in cima al pannello). Ritorna il layer aggiunto:
        quello su file, se salvato.
        """
        if save:
            layer = self._save_output(layer)
        proj = QgsProject.instance()
        proj.addMapLayer(layer, False)
        root = proj.layerTreeRoot()
        grp = root.findGroup(self.OUTPUT_GROUP)
        if grp is None:
            grp = root.insertGroup(0, self.OUTPUT_GROUP)
        grp.insertLayer(0, layer)
        if zoom:
            self._zoom_to(layer)
        return layer

    def _zoom_to(self, layer):
        try:
            from qgis.core import QgsWkbTypes
            if layer.geometryType() == QgsWkbTypes.NullGeometry:
                return
            ext = layer.extent()
            if ext is None or ext.isEmpty() or ext.isNull():
                return
            canvas = self.iface.mapCanvas()
            ct = QgsCoordinateTransform(
                layer.crs(), canvas.mapSettings().destinationCrs(),
                QgsProject.instance().transformContext())
            canvas.setExtent(ct.transformBoundingBox(ext))
            canvas.refresh()
        except Exception:
            pass

    def _global_gtfs(self):
        """Sorgente GTFS globale (impostata nella scheda GTFS)."""
        return self.gtfsSourceEdit.text().strip()

    def _service_date(self):
        """Data servizio globale (YYYYMMDD) o None."""
        s = self.gtfsServiceDate.text().strip()
        return s if (len(s) == 8 and s.isdigit()) else None

    def _gtfs_validate(self):
        source = self._global_gtfs()
        if not source:
            self._gtfs_set_status("Indica un feed GTFS da validare.", error=True)
            return
        try:
            res = self._run_modal(
                "Validazione del feed…",
                lambda task: gtfs_static.validate_feed(
                    source, progress=task.setProgress,
                    is_canceled=task.isCanceled))
        except Exception as exc:
            self._gtfs_set_status(f"Errore validazione: {exc}", error=True)
            return
        if res is None:
            self._gtfs_set_status("Validazione annullata.")
            return
        ok, msgs, _info = res
        self._gtfs_set_status(("✅ " if ok else "⚠️ ") + " ".join(msgs),
                              error=not ok)

    def _gtfs_override_box(self, edit, browse_cb):
        """Box collassato per puntare a un feed GTFS diverso dal globale."""
        box = QGroupBox("Sorgente GTFS alternativa")
        f = QFormLayout(box)
        note = QLabel("Di default si usa il feed GTFS caricato nella scheda "
                      "<b>GTFS</b>. Imposta qui un feed diverso solo se serve.")
        note.setWordWrap(True)
        f.addRow(note)
        row = QHBoxLayout()
        row.addWidget(edit, 1)
        b = QPushButton("Sfoglia...")
        b.clicked.connect(browse_cb)
        row.addWidget(b)
        f.addRow("Feed (.zip):", self._wrap(row))
        self._make_collapsible(box, collapsed=True)
        return box

    @staticmethod
    def _make_table():
        table = QTableWidget()
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.horizontalHeader().setStretchLastSection(True)
        return table

    def _status(self, text, error=False):
        self._paint_status(self.statusLabel, text, error)

    # ------------------------------------------------------------- analisi
    def run_analysis(self):
        layer = self.roadLayerCombo.currentLayer()
        if layer is None:
            self._status("Seleziona un layer di rete stradale.", error=True)
            return

        type_field = self.typeFieldCombo.currentField() or None
        area_layer = self.areaLayerCombo.currentLayer()
        ctx = QgsProject.instance().transformContext()
        area_geom = None
        area_m2 = 0.0
        ellipsoid = QgsProject.instance().ellipsoid()
        if not ellipsoid or ellipsoid == "NONE":
            ellipsoid = layer.crs().ellipsoidAcronym() or "WGS84"
        try:
            if area_layer is not None:
                area_geom = self._area_union(area_layer, layer.crs(), ctx)
                # area dell'unione: poligoni sovrapposti non contano due
                # volte (prima la somma dimezzava le densità)
                if area_geom is not None:
                    area_m2 = analysis.geometry_area_m2(
                        area_geom, layer.crs(), ctx, ellipsoid)
        except Exception as exc:
            self._status(f"Errore nell'area di progetto: {exc}", error=True)
            return
        source = QgsVectorLayerFeatureSource(layer)
        crs = layer.crs()
        level_of = topology.level_reader(layer.fields().names())
        total = max(0, layer.featureCount())

        def _job(task):
            return analysis.analyze_roads(
                source.getFeatures(), crs, ctx, type_field, area_geom,
                ellipsoid, level_of, progress=task.setProgress,
                is_canceled=task.isCanceled, total=total)
        try:
            res = self._run_modal("Analisi della rete…", _job)
        except Exception as exc:  # pragma: no cover - feedback all'utente
            self._status(f"Errore durante l'analisi: {exc}", error=True)
            return
        if res is None:
            self._status("Analisi annullata.")
            return

        lengths = res["lengths"]
        matrix = res["matrix"]
        ratios = analysis.compute_ratios(
            lengths, res["junctions"], area_m2, res["dead_ends"],
            len(res["unnoded"]))
        all_types = sorted(set(lengths) | set(res["types"]))
        self._results = {
            "lengths": lengths,
            "types": all_types,
            "matrix": matrix,
            "ratios": ratios,
        }
        self._populate_lengths(lengths)
        self._populate_matrix(all_types, matrix)
        self._populate_ratios(ratios)
        self.exportButton.setEnabled(True)
        msg = (f"Analisi completata: {len(all_types)} tipologie, "
               f"{res['junctions']} incroci reali, "
               f"{res['dead_ends']} vicoli ciechi")
        if area_geom is not None:
            msg += " (ritagliati sull'area di progetto)"
        if res["unnoded"]:
            cross = net_layers.build_points_diag_layer(
                [(la, lo, {}) for la, lo in res["unnoded"]],
                "MIC diagnostic - attraversamenti senza vertice comune")
            cross = self._add_output(cross, zoom=False)
            msg += (f". ⚠️ {len(res['unnoded'])} punti dove due strade allo "
                    "stesso livello si attraversano senza vertice comune: "
                    "non contano come incroci (vedi layer). Se sono incroci "
                    "veri usa «Prepara rete»; se sono ponti, tunnel o piani "
                    "diversi servono i campi bridge/tunnel/layer/level")
        self._status(msg + ".")

    @staticmethod
    def _area_union(area_layer, target_crs, ctx):
        """Unione dei poligoni dell'area di progetto nel CRS della rete."""
        ct = QgsCoordinateTransform(area_layer.crs(), target_crs, ctx)
        geoms = []
        for f in area_layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            geoms.append(g)
        if not geoms:
            return None
        u = QgsGeometry.unaryUnion(geoms)
        return None if u is None or u.isEmpty() else u

    # --------------------------------------------------------- popolamento
    def _populate_lengths(self, lengths):
        total = sum(lengths.values()) or 1.0
        table = self.lengthTable
        table.clear()
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(
            ["Tipologia", "Lunghezza (m)", "Lunghezza (km)", "% sul totale"]
        )
        rows = sorted(lengths.items(), key=lambda kv: kv[1], reverse=True)
        table.setRowCount(len(rows) + 1)
        for r, (typ, length_m) in enumerate(rows):
            table.setItem(r, 0, QTableWidgetItem(str(typ)))
            table.setItem(r, 1, self._num(length_m))
            table.setItem(r, 2, self._num(length_m / 1000.0))
            table.setItem(r, 3, self._num(100.0 * length_m / total, suffix=" %"))
        last = len(rows)
        table.setItem(last, 0, QTableWidgetItem("TOTALE"))
        table.setItem(last, 1, self._num(sum(lengths.values())))
        table.setItem(last, 2, self._num(sum(lengths.values()) / 1000.0))
        table.setItem(last, 3, self._num(100.0))
        table.resizeColumnsToContents()

    def _populate_matrix(self, types, matrix):
        table = self.matrixTable
        table.clear()
        n = len(types)
        table.setColumnCount(n)
        table.setRowCount(n)
        table.setHorizontalHeaderLabels(types)
        table.setVerticalHeaderLabels(types)
        for i, t1 in enumerate(types):
            for j, t2 in enumerate(types):
                count = matrix.get(tuple(sorted((t1, t2))), 0)
                item = QTableWidgetItem(str(count))
                item.setTextAlignment(Qt.AlignCenter)
                table.setItem(i, j, item)
        table.resizeColumnsToContents()

    def _populate_ratios(self, ratios):
        table = self.ratiosTable
        table.clear()
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(["Indicatore", "Valore"])
        present = [(k, lbl) for k, lbl in RATIO_LABELS if k in ratios]
        table.setRowCount(len(present))
        for r, (key, label) in enumerate(present):
            table.setItem(r, 0, QTableWidgetItem(label))
            value = ratios[key]
            decimals = 0 if key in RATIO_INTEGER else (
                3 if key == "connected_node_ratio" else 2)
            table.setItem(r, 1, self._num(value, decimals=decimals))
        table.resizeColumnsToContents()

    @staticmethod
    def _num(value, decimals=2, suffix=""):
        item = QTableWidgetItem(f"{value:,.{decimals}f}{suffix}")
        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        return item

    # ----------------------------------------------------------- esporta
    def export_csv(self):
        if not self._results:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Esporta risultati", "analisi_rete_stradale.csv", "CSV (*.csv)"
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as fh:
                writer = csv.writer(fh, delimiter=";")

                writer.writerow(["# LUNGHEZZE PER TIPOLOGIA"])
                writer.writerow(["Tipologia", "Lunghezza_m", "Lunghezza_km"])
                for typ, length_m in sorted(self._results["lengths"].items()):
                    writer.writerow([typ, f"{length_m:.2f}", f"{length_m / 1000.0:.3f}"])

                writer.writerow([])
                writer.writerow(["# MATRICE INCROCI"])
                types = self._results["types"]
                writer.writerow([""] + types)
                for t1 in types:
                    row = [self._results["matrix"].get(tuple(sorted((t1, t2))), 0)
                           for t2 in types]
                    writer.writerow([t1] + row)

                writer.writerow([])
                writer.writerow(["# RAPPORTI"])
                for key, label in RATIO_LABELS:
                    if key in self._results["ratios"]:
                        writer.writerow([label, self._results["ratios"][key]])
            self._status(f"Risultati esportati in: {path}")
        except OSError as exc:
            QMessageBox.warning(self, "Errore esportazione", str(exc))

    # ------------------------------------------- preparazione & diagnostica
    def _prep_status(self, text, error=False):
        self._paint_status(self.prepStatus, text, error)

    def _prepare_wizard(self, raw, dirs, ids=None, levels=None):
        """Procedura guidata: diagnosi → opzioni → anteprima/conferma.

        Calcola l'anteprima (noding) nello step 3 e la riusa al termine, così
        il noding viene eseguito una sola volta. Diagnosi e noding girano in
        un task (barra con «Annulla»). Ritorna (seg, sdir, stats, seg_src)
        oppure None se annullata.
        """
        has_levels = bool(levels) and any(levels)
        wiz = QWizard(self)
        wiz.setWindowTitle("Prepara rete — procedura guidata")
        wiz.setWizardStyle(QWizard.ModernStyle)
        wiz.setOption(QWizard.NoBackButtonOnStartPage, True)
        state = {}

        # opzioni (condivise, mostrate nello step 2)
        snap = QDoubleSpinBox()
        snap.setRange(0.0, 50.0)
        snap.setValue(1.0)
        snap.setSuffix(" m")
        mseg = QDoubleSpinBox()
        mseg.setRange(0.0, 50.0)
        mseg.setValue(0.2)
        mseg.setSuffix(" m")
        split = QCheckBox("Noding alle intersezioni (consigliato)")
        split.setChecked(True)

        # --- step 1: diagnosi iniziale ---
        diag_lbl = QLabel("Analisi della rete in corso…")
        diag_lbl.setWordWrap(True)
        diag_lbl.setTextFormat(Qt.RichText)

        def _init_diag(_page):
            try:
                rep = self._run_modal(
                    "Diagnosi della rete…",
                    lambda task: network_diagnostics.diagnose_network(
                        raw, directions=dirs, levels=levels,
                        progress=task.setProgress,
                        is_canceled=task.isCanceled))
            except Exception as exc:
                diag_lbl.setText("Diagnosi non riuscita: %s" % exc)
                return
            if rep is None:
                diag_lbl.setText("Diagnosi annullata.")
                return
            st = rep["stats"]
            state["diag_before"] = st
            txt = ("<b>Stato attuale della rete</b><br>"
                   "Segmenti: %d &nbsp;·&nbsp; Nodi: %d<br>"
                   "Componenti connesse: <b>%d</b> (principale %.0f%%)<br>"
                   "Incroci non noded: %d &nbsp;·&nbsp; Vicoli ciechi: %d"
                   % (st["segmenti"], st["nodi"], st["componenti"],
                      st["pct_principale"], len(rep.get("crossings", [])),
                      len(rep.get("dead_ends", []))))
            if has_levels:
                txt += ("<br>Livelli (ponti, tunnel, layer, piani) letti "
                        "dagli attributi: gli attraversamenti tra livelli "
                        "diversi non sono incroci.")
            if rep["issues"]:
                txt += ("<br><br>⚠️ "
                        + "<br>⚠️ ".join(i["message"] for i in rep["issues"]))
            else:
                txt += "<br><br>✅ Nessun problema rilevato."
            diag_lbl.setText(txt)

        p1 = _PrepPage(
            "1 · Diagnosi iniziale",
            "Controllo della rete selezionata prima della preparazione.",
            on_init=_init_diag)
        l1 = QVBoxLayout(p1)
        l1.addWidget(diag_lbl)
        l1.addStretch()
        wiz.addPage(p1)

        # --- step 2: opzioni ---
        p2 = _PrepPage("2 · Opzioni",
                       "Tolleranza di snap e noding alle intersezioni.")
        f2 = QFormLayout(p2)
        f2.addRow("Tolleranza snap:", snap)
        f2.addRow("Lunghezza minima segmento:", mseg)
        f2.addRow("", split)
        wiz.addPage(p2)

        # --- step 3: anteprima e conferma ---
        prev_lbl = QLabel("")
        prev_lbl.setWordWrap(True)
        prev_lbl.setTextFormat(Qt.RichText)

        lev_of = dict(zip(ids or [], levels or []))

        def _job_prepare(task):
            seg_src = []
            seg, sdir, stats = network_prepare.node_network(
                raw, snap.value(), mseg.value(), dirs,
                split=split.isChecked(), levels=levels,
                sources=ids, src_out=seg_src,
                progress=lambda p: task.setProgress(0.7 * p),
                is_canceled=task.isCanceled)
            seg_lev = None
            if has_levels:
                seg_lev = [lev_of.get(sv, 0) for sv in seg_src]
            rep2 = network_diagnostics.diagnose_network(
                seg, directions=sdir, levels=seg_lev,
                progress=lambda p: task.setProgress(70 + 0.3 * p),
                is_canceled=task.isCanceled)
            return seg, sdir, stats, seg_src, rep2

        def _init_prev(page):
            state.pop("prepared", None)
            page.completeChanged.emit()
            try:
                res = self._run_modal("Noding della rete…", _job_prepare)
            except Exception as exc:
                prev_lbl.setText("Anteprima non riuscita: %s" % exc)
                page.completeChanged.emit()
                return
            if res is None:
                prev_lbl.setText("Anteprima annullata: torna indietro e "
                                 "riprova.")
                page.completeChanged.emit()
                return
            seg, sdir, stats, seg_src, rep2 = res
            state["prepared"] = (seg, sdir, stats, seg_src)
            before = state.get("diag_before", {})
            st2 = rep2["stats"]
            prev_lbl.setText(
                network_prepare.prepare_summary(stats) + "<br><br>"
                "<b>Componenti connesse:</b> %s → <b>%d</b> "
                "(principale %.0f%%)<br><br>"
                "Premi <b>Fine</b> per creare la rete preparata e impostarla "
                "come rete stradale corrente."
                % (before.get("componenti", "?"), st2["componenti"],
                   st2["pct_principale"]))
            page.completeChanged.emit()

        p3 = _PrepPage("3 · Anteprima e conferma",
                       "Risultato del noding prima di applicarlo alla mappa.",
                       on_init=_init_prev,
                       is_complete=lambda: "prepared" in state)
        l3 = QVBoxLayout(p3)
        l3.addWidget(prev_lbl)
        l3.addStretch()
        wiz.addPage(p3)
        wiz.setButtonText(QWizard.FinishButton, "Fine — crea rete preparata")

        if wiz.exec_() != QWizard.Accepted:
            return None
        return state.get("prepared")

    def _prepare_run(self):
        road = self.roadLayerCombo.currentLayer()
        if road is None:
            self._prep_status("Seleziona la rete stradale in alto.", error=True)
            return
        if road.featureCount() > 60000:
            if QMessageBox.question(
                    self, "Rete grande",
                    "La rete ha %d feature: il noding può essere lento. "
                    "Continuare?" % road.featureCount()) != QMessageBox.Yes:
                return
        ctx = QgsProject.instance().transformContext()
        try:
            read = self._read_roads_modal(road, ctx, respect_oneway=True)
        except Exception as exc:
            self._prep_status(f"Errore lettura rete: {exc}", error=True)
            return
        if read is None:
            self._prep_status("Preparazione annullata.")
            return
        raw, dirs, ids, levels = read
        prepared = self._prepare_wizard(raw, dirs, ids, levels)
        if prepared is None:
            return
        seg, sdir, stats, seg_src = prepared
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            attrs = gtfs_layers.space_syntax_source_attrs(road, seg_src)
            layer = net_layers.build_prepared_layer(
                seg, sdir, seg_src=seg_src, src_fields=road.fields(),
                src_attrs=attrs, stats=stats,
                name="MIC - Rete preparata (%s)" % road.name())
        except Exception as exc:
            self._prep_status(f"Errore preparazione: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        layer = self._add_output(layer)
        # imposta la rete preparata nei combo della categoria Rete stradale
        self.roadLayerCombo.setLayer(layer)
        self.ssRoadCombo.setLayer(layer)
        self._prep_status(network_prepare.prepare_summary(stats)
                          + " — impostata come rete stradale.")

    def _diag_run(self):
        road = self.roadLayerCombo.currentLayer()
        if road is None:
            self._prep_status("Seleziona la rete stradale in alto.", error=True)
            return
        ctx = QgsProject.instance().transformContext()
        sources = None
        slayer = self.diagSources.currentLayer()
        if slayer is not None:
            sources = [(la, lo) for la, lo, _ in self._acc_pts(slayer)]
        spec = self._road_spec(road, ctx, True)

        def _job(task):
            levels = []
            raw, dirs = read_spec_roads(spec, task, 0, 30, levels=levels)
            return network_diagnostics.diagnose_network(
                raw, sources_latlon=sources, directions=dirs, levels=levels,
                progress=lambda p: task.setProgress(30 + 0.7 * p),
                is_canceled=task.isCanceled)
        try:
            rep = self._run_modal("Diagnostica della rete…", _job)
            if rep is None:
                self._prep_status("Diagnostica annullata.")
                return
            comp = net_layers.build_components_layer(
                rep["segments"], rep["comp_of_seg"], rep["main_comp"])
            comp = self._add_output(comp, zoom=False)
            if rep["crossings"]:
                cross = net_layers.build_points_diag_layer(
                    [(la, lo, {}) for la, lo in rep["crossings"]],
                    "MIC diagnostic - incroci non noded")
                cross = self._add_output(cross, zoom=False)
            if sources and rep["snaps"].get("sources"):
                iso = [(s["lat"], s["lon"], {"component": s["component"]})
                       for s in rep["snaps"]["sources"]
                       if not s["snapped"] or s["component"] != rep["main_comp"]]
                if iso:
                    from qgis.PyQt.QtCore import QVariant
                    sl = net_layers.build_points_diag_layer(
                        iso, "MIC diagnostic - sorgenti isolate",
                        [("component", QVariant.Int)])
                    sl = self._add_output(sl, zoom=False)
        except Exception as exc:
            self._prep_status(f"Errore diagnostica: {exc}", error=True)
            return
        st = rep["stats"]
        msg = ("Rete: %d segmenti, %d componenti (principale %.0f%%)."
               % (st["segmenti"], st["componenti"], st["pct_principale"]))
        if rep["issues"]:
            msg += " ⚠️ " + " ".join(i["message"] for i in rep["issues"])
        self._prep_status(msg, error=not rep["ok"])

    def _osm_presets_dialog(self):
        from qgis.core import QgsCoordinateTransform, QgsRectangle
        dlg = QDialog(self)
        dlg.setWindowTitle("Preset area OSM")
        lay = QVBoxLayout(dlg)
        combo = QComboBox()

        def _fill():
            combo.clear()
            for p in osm_cache.list_presets():
                combo.addItem("%s [%s]" % (p["name"], p.get("mode", "all")), p)
        _fill()
        row = QHBoxLayout()
        row.addWidget(QLabel("Preset:"))
        row.addWidget(combo, 1)
        go_btn = QPushButton("Vai")
        del_btn = QPushButton("Elimina")
        row.addWidget(go_btn)
        row.addWidget(del_btn)
        lay.addLayout(row)
        lay.addWidget(QLabel("Salva la vista corrente come:"))
        srow = QHBoxLayout()
        name_edit = QLineEdit()
        save_btn = QPushButton("Salva")
        srow.addWidget(name_edit, 1)
        srow.addWidget(save_btn)
        lay.addLayout(srow)
        clear_btn = QPushButton("Svuota cache OSM (riscarica le aree)")
        clear_btn.setToolTip("Le reti scaricate restano in cache 30 giorni: "
                             "svuotala per riscaricare dati aggiornati.")
        clear_btn.clicked.connect(
            lambda: self.iface.messageBar().pushInfo(
                "OSM", "Cache svuotata: %d download rimossi."
                % osm_cache.clear_cache()))
        lay.addWidget(clear_btn)
        close_btn = QPushButton("Chiudi")
        close_btn.clicked.connect(dlg.accept)
        lay.addWidget(close_btn)

        canvas = self.iface.mapCanvas()
        ctx = QgsProject.instance().transformContext()

        def _go():
            p = combo.currentData()
            if not p:
                return
            s, w, n, e = p["bbox"]
            ct = QgsCoordinateTransform(isochrones.WGS84,
                                        canvas.mapSettings().destinationCrs(), ctx)
            canvas.setExtent(ct.transformBoundingBox(QgsRectangle(w, s, e, n)))
            canvas.refresh()
            dlg.accept()

        def _save():
            nm = name_edit.text().strip()
            if not nm:
                return
            ct = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                        isochrones.WGS84, ctx)
            r = ct.transformBoundingBox(canvas.extent())
            osm_cache.save_preset(
                nm, (r.yMinimum(), r.xMinimum(), r.yMaximum(), r.xMaximum()))
            name_edit.clear()
            _fill()

        def _del():
            p = combo.currentData()
            if p:
                osm_cache.delete_preset(p["name"])
                _fill()

        go_btn.clicked.connect(_go)
        save_btn.clicked.connect(_save)
        del_btn.clicked.connect(_del)
        dlg.exec_()

    # ----------------------------------------------------------- walkability
    def _walk_status(self, text, error=False):
        self._paint_status(self.walkStatus, text, error)

    def _walk_run(self):
        road = self.roadLayerCombo.currentLayer()
        if road is None:
            self._walk_status("Seleziona la rete stradale.", error=True)
            return
        ctx = QgsProject.instance().transformContext()
        spec = self._road_spec(road, ctx)
        zones = self.walkZones.currentLayer()
        zones_latlon = None
        if zones is not None:
            zones_latlon = []
            ct = QgsCoordinateTransform(zones.crs(), isochrones.WGS84, ctx)
            for f in zones.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ct)
                if g.isMultipart():
                    for poly in g.asMultiPolygon():
                        if poly:
                            zones_latlon.append([(p.y(), p.x()) for p in poly[0]])
                else:
                    poly = g.asPolygon()
                    if poly:
                        zones_latlon.append([(p.y(), p.x()) for p in poly[0]])
            if not zones_latlon:
                self._walk_status("Nessuna zona valida.", error=True)
                return
        grid_size = self.walkGridSize.value()
        # POI/destinazioni (opz.)
        pois = None
        poi_layer = self.walkPoi.currentLayer()
        if poi_layer is not None:
            catf = self.walkPoiCat.currentField() or None
            names = poi_layer.fields().names()
            ctp = QgsCoordinateTransform(poi_layer.crs(), isochrones.WGS84, ctx)
            pois = []
            for f in poi_layer.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ctp)
                p = g.centroid().asPoint()
                cat = (str(f[catf]) if catf and catf in names else None)
                pois.append((p.y(), p.x(), cat))
        # DEM per pendenza (opz.)
        elev_sampler = None
        dem = self.walkDem.currentLayer()
        if dem is not None:
            # copia del provider: il campionamento avviene nel task
            dp = dem.dataProvider().clone()
            ctd = QgsCoordinateTransform(isochrones.WGS84, dem.crs(), ctx)

            def elev_sampler(lon, lat, _dp=dp, _ct=ctd):
                from qgis.core import QgsPointXY
                g = QgsGeometry.fromPointXY(QgsPointXY(lon, lat))
                g.transform(_ct)
                pt = g.asPoint()
                val, ok = _dp.sample(pt, 1)
                return val if ok else None

        # attraversamenti pedonali (opz.)
        crossings = None
        cross_layer = self.walkCross.currentLayer()
        if cross_layer is not None:
            ctc = QgsCoordinateTransform(cross_layer.crs(), isochrones.WGS84, ctx)
            crossings = []
            for f in cross_layer.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ctc)
                p = g.centroid().asPoint()
                crossings.append((p.y(), p.x()))
        dest_mode = "network" if self.walkDestNet.isChecked() else "crowfly"
        max_dest = self.walkDestM.value()

        def _job(task):
            raw, _d = read_spec_roads(spec, task, 0, 20)
            roads, _dd, _cs = net_clean.clean_network(raw, 1.0, None)
            ok, vmsg, info = net_iso.validate_network(roads)
            if not ok:
                raise ValueError("Rete non valida: " + vmsg)
            zl = zones_latlon
            if zl is None:
                s_, w_, n_, e_ = info["bbox"]
                _cent, zl = grid_gen.build_grid(s_, n_, w_, e_, grid_size,
                                                "square")
            if not zl:
                raise ValueError("Nessuna zona valida.")
            if len(zl) > 4000:
                raise ValueError("Troppe zone (%d): aumenta la cella o usa "
                                 "zone." % len(zl))
            res = walkability.compute_walkability(
                roads, zl, pois=pois, max_dest_m=max_dest,
                elev_sampler=elev_sampler, crossings=crossings,
                dest_mode=dest_mode,
                progress=lambda p: task.setProgress(20 + 0.8 * p))
            return zl, res
        try:
            out = self._run_modal("Walkability…", _job)
            if out is None:
                self._walk_status("Calcolo annullato.")
                return
            zones_latlon, results = out
            layer = gtfs_layers.build_walkability_layer(zones_latlon, results)
        except Exception as exc:
            self._walk_status(f"Errore walkability: {exc}", error=True)
            return
        layer = self._add_output(layer)
        vals = [r["walkability"] for r in results]
        avg = sum(vals) / len(vals) if vals else 0.0
        dims = ["design"]
        if pois:
            dims.append("destinazioni" + (" su rete" if dest_mode == "network"
                                          else ""))
        if elev_sampler:
            dims.append("pendenza")
        if crossings:
            dims.append("attraversamenti")
        note = (" ⚠️ Con una sola zona l'indice non ha termini di confronto "
                "(è relativo fra le zone): usa più zone o la griglia."
                if len(results) < 2 else "")
        self._walk_status("Walkability su %d zone (media %.0f/100). Dimensioni: "
                          "%s.%s" % (len(results), avg, " + ".join(dims), note))

    # ===================================================================
    #                              GTFS
    # ===================================================================
    def _gtfs_set_status(self, text, error=False):
        self._paint_status(self.gtfsStatus, text, error)

    def _gtfs_live_status(self, text, error=False):
        self._paint_status(self.gtfsLiveStatus, text, error)

    def _gtfs_browse_zip(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleziona feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.gtfsSourceEdit.setText(path)

    def _gtfs_browse_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Seleziona cartella GTFS")
        if path:
            self.gtfsSourceEdit.setText(path)

    def _gtfs_read_routes(self):
        source = self.gtfsSourceEdit.text().strip()
        if not source:
            self._gtfs_set_status("Indica un feed GTFS (.zip o cartella).", error=True)
            return
        try:
            routes = gtfs_static.list_routes(source)
        except Exception as exc:
            self._gtfs_set_status(f"Errore lettura linee: {exc}", error=True)
            return
        self.gtfsRouteCombo.clear()
        self.gtfsRouteCombo.addItem("Tutte le linee", None)
        for r in routes:
            label = (r["short_name"] or r["route_id"])
            if r["long_name"]:
                label += " - " + r["long_name"]
            self.gtfsRouteCombo.addItem(label, r["route_id"])
        self._gtfs_set_status(
            "%d linee trovate. Scegline una per un caricamento leggero." % len(routes))

    def _gtfs_load(self):
        source = self.gtfsSourceEdit.text().strip()
        if not source:
            self._gtfs_set_status("Indica un feed GTFS (.zip o cartella).", error=True)
            return
        if self._load_task is not None:
            self._gtfs_set_status("Caricamento gia in corso...", error=True)
            return
        route_id = self.gtfsRouteCombo.currentData()
        route_ids = [route_id] if route_id else None
        task = GtfsLoadTask(source, route_ids=route_ids,
                            service_date=self._service_date())
        self._load_task = task
        task.progressChanged.connect(self._gtfs_load_progress)
        task.taskCompleted.connect(lambda t=task: self._gtfs_load_done(t))
        task.taskTerminated.connect(lambda t=task: self._gtfs_load_terminated(t))
        self.gtfsLoadButton.setEnabled(False)
        self._gtfs_set_status("Caricamento GTFS in background... 0%")
        QgsApplication.taskManager().addTask(task)

    def _gtfs_load_progress(self, pct):
        self._gtfs_set_status("Caricamento GTFS in background... %d%%" % int(pct))

    def _gtfs_load_done(self, task):
        self._load_task = None
        self.gtfsLoadButton.setEnabled(True)
        res = task.result
        note = ""
        same = (self._gtfs is not None
                and self._gtfs.get("source") == res.get("source")
                and self._gtfs.get("service_date") == res.get("service_date"))
        if same:
            # stesso feed e stesso giorno: le linee si sommano davvero (logger,
            # segmenti, Excel e map-matching vedono tutte quelle caricate)
            gtfs_static.merge_static(self._gtfs, res)
        else:
            if self._gtfs is not None:
                note = (" Feed o giorno diversi dal caricamento precedente: "
                        "le linee caricate prima sono state tolte.")
                if self._logger is not None and self._logger.is_running():
                    self._gtfs_stop_logging()
                    note += " Logging RT fermato: riavvialo sul nuovo feed."
                self._logger = None
            self._gtfs = res
        self._acc = {"shapes": self._gtfs["shapes_geom"],
                     "shape_routes": self._gtfs["shape_routes"],
                     "routes": self._gtfs["routes"],
                     "line_metrics": self._gtfs["line_metrics"]}
        self.gtfsSegButton.setEnabled(True)
        self.gtfsStartButton.setEnabled(
            self._logger is None or not self._logger.is_running())
        self.gtfsScanButton.setEnabled(True)
        self.gtfsExcelButton.setEnabled(True)
        self.mmRunButton.setEnabled(True)
        self._update_lines_layer()
        self._update_metrics_layer()
        self._populate_gtfs_lines()
        fixed = res.get("times_fixed", 0)
        if fixed:
            note += (" %d orari mancanti o a tempo zero ricostruiti per "
                     "distanza." % fixed)
        self._gtfs_set_status(
            "GTFS caricato (%s): %d linee in totale, %d segmenti.%s"
            % (self._gtfs.get("selection", ""), len(self._acc["line_metrics"]),
               len(self._gtfs["segments"]), note))

    def _update_lines_layer(self):
        layer = (QgsProject.instance().mapLayer(self._lines_layer_id)
                 if self._lines_layer_id else None)
        new = layer is None
        layer = gtfs_layers.update_lines_layer(layer, self._acc)
        if new:
            layer = self._add_output(layer, save=False)
            self._lines_layer_id = layer.id()
        else:
            layer.triggerRepaint()

    def _update_metrics_layer(self):
        rt_lines = self._logger.line_results() if self._logger else {}
        layer = (QgsProject.instance().mapLayer(self._metrics_layer_id)
                 if self._metrics_layer_id else None)
        new = layer is None
        layer = gtfs_layers.update_metrics_layer(
            layer, self._acc["line_metrics"], rt_lines)
        if new:
            layer = self._add_output(layer, save=False)
            self._metrics_layer_id = layer.id()

    def _gtfs_load_terminated(self, task):
        self._load_task = None
        self.gtfsLoadButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._gtfs_set_status("Caricamento GTFS annullato.")
        else:
            self._gtfs_set_status(
                f"Errore nel caricamento GTFS: {task.exception}", error=True)

    def _gtfs_create_segments(self):
        if not self._gtfs:
            return
        rt_stats = self._logger.segment_results() if self._logger else None
        if self._gtfs_seg_layer is not None:
            QgsProject.instance().removeMapLayer(self._gtfs_seg_layer)
        layer = gtfs_layers.build_segments_layer(self._gtfs, rt_stats)
        layer = self._add_output(layer)
        self._gtfs_seg_layer = layer.id()
        n_rt = sum(1 for k in (rt_stats or {}) if k in self._gtfs["segments"])
        self.gtfsHighlightButton.setEnabled(n_rt > 0)
        if n_rt:
            suffix = " (%d con dati RT)" % n_rt
        elif self._logger is not None:
            suffix = (" (nessun dato RT ancora: le coppie contano quando la "
                      "fermata è passata)")
        else:
            suffix = ""
        self._gtfs_set_status(
            f"Layer segmenti creato ({layer.featureCount()} segmenti){suffix}.")

    def _gtfs_start_logging(self):
        if not self._gtfs:
            return
        url = self.gtfsRtUrlEdit.text().strip()
        if not url:
            self._gtfs_set_status("Indica l'URL del feed TripUpdates.", error=True)
            return
        if self._logger is not None and self._logger.is_running():
            # già attivo (es. scansione programmata che parte mentre si sta
            # registrando): si continua con lo stesso, niente logger orfani
            self.gtfsRtStatus.setText("Logging già in corso: continua.")
            return
        if self._logger is not None:
            self._logger.stop()
        self._logger = GtfsRealtimeLogger(
            url, self.gtfsIntervalSpin.value(), self._gtfs, self)
        self._logger.polled.connect(self._gtfs_on_poll)
        self._logger.failed.connect(self._gtfs_on_fail)
        self._logger.start()
        self.gtfsStartButton.setEnabled(False)
        self.gtfsStopButton.setEnabled(True)
        self.gtfsRtStatus.setText("Logging avviato...")

    def _gtfs_stop_logging(self):
        if self._logger:
            self._logger.stop()
        self.gtfsStartButton.setEnabled(True)
        self.gtfsStopButton.setEnabled(False)
        self.gtfsRtStatus.setText("Logging fermato.")

    def _gtfs_schedule_scan(self):
        if not self._gtfs:
            self.gtfsRtStatus.setText("Carica prima un GTFS.")
            return
        if not self.gtfsRtUrlEdit.text().strip():
            self.gtfsRtStatus.setStyleSheet("color: #b00020;")
            self.gtfsRtStatus.setText("Indica l'URL del feed TripUpdates.")
            return
        from qgis.PyQt.QtCore import QDateTime
        now = QDateTime.currentDateTime()
        target = QDateTime(now.date(), self.gtfsScanTime.time())
        if target <= now:
            target = target.addDays(1)  # se l'ora e' passata, domani
        ms = now.msecsTo(target)
        dur_min = self.gtfsScanDur.value()
        self._scan_timer = QTimer(self)
        self._scan_timer.setSingleShot(True)
        self._scan_timer.timeout.connect(lambda: self._gtfs_scan_fire(dur_min))
        self._scan_timer.start(ms)
        self.gtfsScanButton.setEnabled(False)
        self.gtfsScanCancel.setEnabled(True)
        self.gtfsRtStatus.setStyleSheet("color: #1b5e20;")
        self.gtfsRtStatus.setText(
            "Scansione programmata per %s (durata %d min)."
            % (target.toString("dd/MM HH:mm"), dur_min))

    def _gtfs_scan_fire(self, dur_min):
        self._gtfs_start_logging()
        stop_timer = QTimer(self)
        stop_timer.setSingleShot(True)
        stop_timer.timeout.connect(self._gtfs_stop_logging)
        stop_timer.start(int(dur_min) * 60 * 1000)
        self._scan_stop_timer = stop_timer
        self.gtfsScanButton.setEnabled(True)
        self.gtfsScanCancel.setEnabled(False)

    def _gtfs_cancel_scan(self):
        if self._scan_timer:
            self._scan_timer.stop()
        self.gtfsScanButton.setEnabled(True)
        self.gtfsScanCancel.setEnabled(False)
        self.gtfsRtStatus.setText("Scansione programmata annullata.")

    def _gtfs_on_poll(self, n_poll, n_obs, msg):
        self.gtfsRtStatus.setStyleSheet("color: #1b5e20;")
        self.gtfsRtStatus.setText(msg)
        self._populate_gtfs_lines()
        self._update_metrics_layer()

    def _gtfs_on_fail(self, msg):
        self.gtfsRtStatus.setStyleSheet("color: #b00020;")
        self.gtfsRtStatus.setText(f"Errore poll RT: {msg}")

    def _populate_gtfs_lines(self):
        metrics = self._acc["line_metrics"]
        if not metrics:
            return
        rt_lines = self._logger.line_results() if self._logger else {}
        table = self.gtfsLineTable
        table.clear()
        headers = ["Linea", "Dir", "Lunghezza (km)", "Commerciale prog. (km/h)",
                   "Esercizio prog. (km/h)", "Effettiva RT (km/h)",
                   "Sosta media (s)", "N corse"]
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        items = sorted(metrics.items())
        table.setRowCount(len(items))
        for r, (key, m) in enumerate(items):
            eff = rt_lines.get(key, {}).get("eff_speed_kmh")
            table.setItem(r, 0, QTableWidgetItem(str(m["route_short_name"] or m["route_id"])))
            table.setItem(r, 1, QTableWidgetItem(str(m["direction_id"])))
            table.setItem(r, 2, self._num(m["mean_length_m"] / 1000.0, decimals=2))
            table.setItem(r, 3, self._num(m["commercial_speed_kmh"]))
            table.setItem(r, 4, self._num(m["running_speed_kmh"]))
            table.setItem(r, 5, self._num(eff) if eff is not None
                          else QTableWidgetItem("-"))
            table.setItem(r, 6, self._num(m["mean_dwell_s"], decimals=0))
            table.setItem(r, 7, self._num(m["n_trips"], decimals=0))
        table.resizeColumnsToContents()

    def _gtfs_highlight(self):
        if self._gtfs_seg_layer is None:
            self._gtfs_live_status("Crea prima il layer segmenti con dati RT.", error=True)
            return
        layer = QgsProject.instance().mapLayer(self._gtfs_seg_layer)
        if layer is None:
            self._gtfs_live_status("Layer segmenti non trovato; ricrealo.", error=True)
            return
        styled = gtfs_layers.style_segments_by_deviation(layer)
        if styled == 0:
            self._gtfs_live_status(
                "Nessun segmento con dati RT: avvia il logging e ricrea il layer.",
                error=True)
            return
        selected = gtfs_layers.select_worst_segments(layer, self.gtfsTopNSpin.value())
        try:
            self.iface.layerTreeView().refreshLayerSymbology(layer.id())
        except Exception:
            pass
        self._gtfs_live_status(
            f"Evidenziati {styled} segmenti; selezionati i {selected} con divario "
            "maggiore (osservata << teorica).")

    def _gtfs_export_excel(self):
        if not self._gtfs:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Esporta Excel velocità", "velocita_linee.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        obs_hourly = self._logger.line_hourly() if self._logger else {}
        rt_lines = self._logger.line_results() if self._logger else {}
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            excel_report.write_line_speed_report(
                path, self._gtfs["line_metrics"], self._gtfs["line_hourly_sched"],
                obs_hourly, rt_lines)
        except Exception as exc:
            self._gtfs_live_status(f"Errore export Excel: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._gtfs_live_status(f"Excel esportato: {path}")

    def _gtfs_map_match(self):
        if not self._gtfs:
            return
        if self._match_task is not None:
            self._gtfs_set_status("Map-matching gia in corso...", error=True)
            return
        road_layer = self.mmRoadCombo.currentLayer()
        if road_layer is None:
            self._gtfs_set_status("Seleziona la rete stradale di destinazione.", error=True)
            return
        # letti nel thread principale e passati al task; il senso unico
        # (campo oneway) separa le carreggiate di un viale
        # e il campo highway (OSM) esclude marciapiedi, ciclabili e scale
        names = road_layer.fields().names()
        direction_of = osm_download.oneway_reader(names)
        has_hw = "highway" in names
        road_geoms = [(f.id(), QgsGeometry(f.geometry()), direction_of(f))
                      for f in road_layer.getFeatures() if f.hasGeometry()
                      and (not has_hw or map_matching.transit_road(f["highway"]))]
        if not road_geoms:
            self._gtfs_set_status("La rete stradale non ha geometrie.", error=True)
            return
        seg_eff = self._logger.segment_results() if self._logger else {}
        task = GtfsMatchTask(
            self._gtfs["segments"], seg_eff, road_geoms, road_layer.crs(),
            QgsProject.instance().transformContext(),
            self.mmTolSpin.value(), self.mmAngleSpin.value(), self.mmSpacingSpin.value(),
            min_cover=self.mmCoverSpin.value() / 100.0)
        self._match_task = task
        self._match_road_layer = road_layer
        task.progressChanged.connect(
            lambda p: self._gtfs_set_status("Map-matching... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._gtfs_match_done(t))
        task.taskTerminated.connect(lambda t=task: self._gtfs_match_failed(t))
        self.mmRunButton.setEnabled(False)
        self._gtfs_set_status("Map-matching in background... 0%")
        QgsApplication.taskManager().addTask(task)

    def _gtfs_match_done(self, task):
        self._match_task = None
        self.mmRunButton.setEnabled(True)
        results = task.result or {}
        layer = gtfs_layers.build_matched_roads_layer(self._match_road_layer, results)
        layer = self._add_output(layer)
        n_rt = sum(1 for r in results.values() if r["v_eff"] is not None)
        self._gtfs_set_status(
            "Map-matching completato: %d strade con velocità trasporto "
            "(%d anche con dati RT)." % (len(results), n_rt))

    def _gtfs_match_failed(self, task):
        self._match_task = None
        self.mmRunButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._gtfs_set_status("Map-matching annullato.")
        else:
            self._gtfs_set_status(f"Errore map-matching: {task.exception}", error=True)

    # ----------------------------------------------------- Da linee a GTFS
    def _l2g_browse_out(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Salva GTFS", "gtfs_generato.zip", "GTFS zip (*.zip)")
        if path:
            self.l2gOutEdit.setText(path)

    def _l2g_generate(self):
        line_layer = self.l2gLineCombo.currentLayer()
        stops_layer = self.l2gStopsCombo.currentLayer()
        out_path = self.l2gOutEdit.text().strip()
        if line_layer is None or stops_layer is None:
            self._l2g_status("Seleziona il layer linee e il layer fermate.",
                             error=True)
            return
        if not out_path:
            self._l2g_status("Indica il file GTFS di output (.zip).", error=True)
            return
        params = {
            "agency_name": self.l2gAgency.text().strip() or "Agenzia",
            "route_type": self.l2gTypeCombo.currentData(),
            "speed_kmh": self.l2gSpeed.value(),
            "headway_min": self.l2gHeadway.value(),
            "start_h": self.l2gStart.value(),
            "end_h": self.l2gEnd.value(),
            "dwell_s": self.l2gDwell.value(),
            "snap_m": self.l2gSnap.value(),
            "route_field": self.l2gRouteField.currentField() or None,
            "stop_name_field": self.l2gStopField.currentField() or None,
            "directions": self.l2gDirections.currentData(),
            "drive_side": self.l2gSide.currentData(),
            "timezone": self.l2gTz.currentText().strip(),
            "start_date": self.l2gFrom.date().toString("yyyyMMdd"),
            "end_date": self.l2gTo.date().toString("yyyyMMdd"),
            "days": self.l2gDays.currentData(),
        }
        ctx = QgsProject.instance().transformContext()
        try:
            inputs = gtfs_builder.collect_inputs(line_layer, stops_layer,
                                                 params)
            res = self._run_modal(
                "Generazione GTFS…",
                lambda task: gtfs_builder.build_gtfs(
                    inputs, params, out_path, ctx, progress=task.setProgress,
                    is_canceled=task.isCanceled))
        except Exception as exc:
            self._l2g_status(f"Errore generazione GTFS: {exc}", error=True)
            return
        if res is None:
            self._l2g_status("Generazione annullata.")
            return
        saved, st = res
        self.gtfsSourceEdit.setText(saved)
        self._l2g_status(
            "GTFS generato: %s (%d linee, %d direzioni, %d corse; validità "
            "%s). Percorso impostato nella scheda GTFS."
            % (saved, st["linee"], st["direzioni"], st["corse"], st["date"]))

    def _l2g_status(self, text, error=False):
        self._paint_status(self.l2gStatus, text, error)

    # ------------------------------------------------------- Space syntax
    def _ss_run(self):
        road_layer = self.ssRoadCombo.currentLayer()
        if road_layer is None:
            self._ss_status("Seleziona la rete stradale.", error=True)
            return
        nfeat = road_layer.featureCount()
        if nfeat > 15000 and self.ssRadius.value() == 0:
            if QMessageBox.question(
                    self, "Rete molto grande",
                    "La rete ha %d strade: il calcolo globale (choice) cresce "
                    "con il quadrato dei segmenti e può durare diversi minuti "
                    "(es. 23 000 segmenti ≈ 4 min). Un raggio locale (es. "
                    "3-10) richiede pochi secondi.\n\n"
                    "Procedere con il calcolo globale? Gira in background e "
                    "si può annullare dalla barra delle attività." % nfeat,
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No) != QMessageBox.Yes:
                self._ss_status("Imposta un raggio locale oppure riduci "
                                "l'area e riprova.")
                return
        ctx = QgsProject.instance().transformContext()
        self._ss_road = road_layer
        task = SpaceSyntaxTask(self._road_spec(road_layer, ctx),
                               radius=self.ssRadius.value())
        self._ss_task = task
        task.progressChanged.connect(
            lambda p: self._ss_status("Calcolo space syntax... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._ss_done(t))
        task.taskTerminated.connect(lambda t=task: self._ss_failed(t))
        self.ssRunButton.setEnabled(False)
        self._ss_status("Calcolo space syntax in background... 0%")
        QgsApplication.taskManager().addTask(task)

    def _ss_done(self, task):
        self.ssRunButton.setEnabled(True)
        res = task.result
        attrs = gtfs_layers.space_syntax_source_attrs(self._ss_road,
                                                      res["src"])
        layer = gtfs_layers.build_space_syntax_layer(
            self._ss_road, res, attrs)
        layer = self._add_output(layer)
        self._ss_status(
            "Space syntax calcolato su %d segmenti tra %d incroci reali "
            "(da %d strade; campi: connettivita, profondita_media, "
            "integrazione, choice, nain, nach)."
            % (len(res["src"]), res["n_junctions"], res["n_features_in"]))

    def _ss_failed(self, task):
        self.ssRunButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._ss_status("Calcolo annullato.")
        else:
            self._ss_status(f"Errore space syntax: {task.exception}", error=True)

    def _ss_status(self, text, error=False):
        self._paint_status(self.ssStatus, text, error)

    # ---------------------------------------------------------------- OD
    def _od_browse_csv(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Matrice OD", "", "CSV (*.csv *.txt)")
        if path:
            self.odCsvEdit.setText(path)

    def _od_run(self):
        zones = self.odZonesCombo.currentLayer()
        idf = self.odIdField.currentField()
        csv_path = self.odCsvEdit.text().strip()
        if zones is None or not idf:
            self._od_status("Seleziona zone e campo ID.", error=True)
            return
        if not csv_path:
            self._od_status("Indica il file CSV della matrice OD.", error=True)
            return
        try:
            rows = self._od_read_csv(csv_path)
        except Exception as exc:
            self._od_status(f"Errore lettura CSV: {exc}", error=True)
            return
        rows = od_viz.filter_rows(
            rows, min_flow=self.odMinFlow.value(), top_n=self.odTopN.value(),
            origin=self.odFilterO.text().strip() or None,
            dest=self.odFilterD.text().strip() or None)
        if not rows:
            self._od_status("Nessuna riga OD valida (dopo i filtri).", error=True)
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            layer, n, missing = od_viz.build_desire_lines(
                zones, idf, rows, QgsProject.instance().transformContext(),
                arc=self.odArc.isChecked())
        except Exception as exc:
            self._od_status(f"Errore creazione desire lines: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        layer = self._add_output(layer)
        self._od_status("Desire lines create: %d linee (%d coppie scartate)."
                        % (n, missing))

    def _od_read_csv(self, path):
        # codifica, separatore e numeri in formato italiano gestiti da od_viz
        rows, _bad = od_viz.read_od_csv(path, self.odColO.text().strip(),
                                        self.odColD.text().strip(),
                                        self.odColV.text().strip())
        return rows

    def _od_status(self, text, error=False):
        self._paint_status(self.odStatus, text, error)

    def _od_tm_browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.odTmGtfs.setText(path)

    def _od_matrix_run(self):
        zones = self.odZonesCombo.currentLayer()
        idf = self.odIdField.currentField()
        src = self.odTmGtfs.text().strip() or self.gtfsSourceEdit.text().strip()
        if zones is None or not idf:
            self._od_status("Seleziona zone e campo ID.", error=True)
            return
        if not src:
            self._od_status("Indica il feed GTFS.", error=True)
            return
        ct = QgsCoordinateTransform(zones.crs(), isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        zl = []
        for f in zones.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            p = g.centroid().asPoint()
            zl.append((str(f[idf]), p.y(), p.x()))
        if len(zl) < 2:
            self._od_status("Servono almeno due zone.", error=True)
            return
        self._od_zones_layer = zones
        self._od_zones_idf = idf
        task = OdMatrixTask(zl, src, self.odTmStart.value(),
                            self.odTmBudget.value(), 4.8,
                            service_date=self._service_date())
        self._od_tm_task = task
        task.progressChanged.connect(
            lambda p: self._od_status("Matrice TP... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._od_matrix_done(t))
        task.taskTerminated.connect(lambda t=task: self._od_matrix_failed(t))
        self.odTmButton.setEnabled(False)
        self._od_status("Calcolo matrice TP in background... 0%")
        QgsApplication.taskManager().addTask(task)

    def _od_matrix_done(self, task):
        self.odTmButton.setEnabled(True)
        layer, n = od_viz.build_od_time_lines(
            self._od_zones_layer, self._od_zones_idf, task.result,
            QgsProject.instance().transformContext())
        layer = self._add_output(layer)
        self._od_status("Matrice TP: %d coppie raggiungibili." % n)

    def _od_matrix_failed(self, task):
        self.odTmButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._od_status("Calcolo annullato.")
        else:
            self._od_status(f"Errore matrice TP: {task.exception}", error=True)

    # ------------------------------------------------ Matrice OD su strada
    def _odr_points(self, layer, id_field):
        """[(id, lat, lon)] dal centro di ogni feature (centroide)."""
        ct = QgsCoordinateTransform(layer.crs(), isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        names = layer.fields().names()
        out = []
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            p = g.centroid().asPoint()
            fid = (f[id_field] if id_field and id_field in names else f.id())
            out.append((od_viz.norm_id(fid), p.y(), p.x()))
        return out

    def _odr_run(self):
        orig = self.odrOrig.currentLayer()
        road = self.odrRoad.currentLayer()
        if orig is None or road is None:
            self._od_status("Scegli origini e rete stradale.", error=True)
            return
        O = self._odr_points(orig, self.odrOrigId.currentField())
        dest = self.odrDest.currentLayer()
        Dd = (self._odr_points(dest, self.odrDestId.currentField())
              if dest is not None else list(O))
        if not O or not Dd:
            self._od_status("Nessun punto valido fra origini o destinazioni.",
                            error=True)
            return
        n_pairs = len(O) * len(Dd)
        if n_pairs > 1000000:
            self._od_status("Troppe coppie (%d × %d): al massimo un milione."
                            % (len(O), len(Dd)), error=True)
            return
        ctx = QgsProject.instance().transformContext()
        try:
            cost, _vmax, desc = self.odrTravel.cost(road, ctx)
        except ValueError as exc:
            self._od_status(str(exc), error=True)
            return
        path, _f = QFileDialog.getSaveFileName(
            self, "Matrice OD su strada", "matrice_od.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        # rete: riquadro dei punti con un margine (deviazioni dei percorsi)
        pts = [(la, lo) for _i, la, lo in O + Dd]
        diag = fifteen.haversine_m(min(p[0] for p in pts), min(p[1] for p in pts),
                                   max(p[0] for p in pts), max(p[1] for p in pts))
        margin = max(2000.0, 0.3 * diag)
        clip = net_iso.reach_bbox(pts, margin)
        spec = self._road_spec(road, ctx, self.odrTravel.oneway.isChecked(),
                               clip, margin)
        max_min = self.odrMax.value() or None

        def _job(task):
            roads, dirs, ec, st, _cs = read_costed_network(spec, cost, task,
                                                           0, 35)
            res = od_road.road_od_matrix(
                roads, O, Dd, dirs, ec, max_min=max_min,
                progress=lambda p: task.setProgress(35 + 0.65 * p),
                is_canceled=task.isCanceled)
            return res, st
        try:
            out = self._run_modal("Matrice OD su strada…", _job)
        except Exception as exc:
            self._od_status("Errore matrice su strada: %s" % exc, error=True)
            return
        if out is None:
            self._od_status("Calcolo annullato.")
            return
        res, st = out
        import datetime
        params = [
            ("Rete stradale", road.name()),
            ("Mezzo", desc),
            ("Sensi unici", "rispettati" if self.odrTravel.oneway.isChecked()
             else "ignorati"),
            ("Tempo massimo", "%d min" % max_min if max_min else "nessuno"),
            ("Origini", "%s (%d)" % (orig.name(), len(O))),
            ("Destinazioni", "%s (%d)" % (dest.name() if dest else
                                          "= origini", len(Dd))),
            ("Percorso", "il più veloce; distanza = lunghezza di quel "
                         "percorso"),
            ("Calcolata il", datetime.datetime.now().strftime(
                "%d/%m/%Y %H:%M")),
        ]
        try:
            od_road.write_excel(path, [o[0] for o in O], [d[0] for d in Dd],
                                res, params)
        except Exception as exc:
            self._od_status("Matrice calcolata ma Excel non salvato (%s): il "
                            "file è aperto in Excel?" % exc, error=True)
            return
        T = res["time_s"]
        vals = [t for row in T for t in row if t is not None]
        n_ok = len(vals)
        msg = ("Matrice %d × %d %s: %d coppie raggiungibili su %d"
               % (len(O), len(Dd), desc, n_ok, n_pairs))
        if vals:
            msg += ", tempo medio %.1f min" % (sum(vals) / len(vals) / 60.0)
        msg += ". Excel: %s" % path
        if self.odrLines.isChecked():
            if n_pairs <= 20000:
                self._add_output(od_road.build_lines_layer(O, Dd, res))
            else:
                msg += " (linee non disegnate: più di 20 000 coppie)"
        miss = sum(1 for s_ in res["o_snap"] + res["d_snap"] if s_ is None)
        moved = sum(1 for m in res["o_moved"] + res["d_moved"] if m)
        n_diag = len(O) if dest is None else 0
        if (n_ok - n_diag) < 0.9 * (n_pairs - n_diag) and                 self.odrTravel.oneway.isChecked():
            msg += (". Molte coppie senza percorso: spesso sono strade a senso "
                    "unico che escono dalla rete ritagliata; allarga la rete o "
                    "togli «Rispetta i sensi unici» per verificarlo")
        if miss:
            msg += (". ⚠️ %d punti a più di 500 m dalla rete: righe/colonne "
                    "vuote" % miss)
        if moved:
            msg += (". %d punti agganciati alla rete principale (vicino c'era "
                    "solo un pezzo di rete isolato)" % moved)
        self._od_status(msg + "." + self._cost_note(st), error=(n_ok == 0))

    # ------------------------------------------------- Città dei 15 minuti
    def _build_fifteen_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("fifteen"))
        form = QFormLayout()
        self.f15Road = QgsMapLayerComboBox()
        self.f15Road.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Rete stradale:", self._combo_with_osm(
            self.f15Road, lambda: self.f15Travel.osm_mode()))
        poi_row = QHBoxLayout()
        poi_row.setContentsMargins(0, 0, 0, 0)
        self.f15Poi = QgsMapLayerComboBox()
        self.f15Poi.setFilters(QgsMapLayerProxyModel.PointLayer
                               | QgsMapLayerProxyModel.PolygonLayer)
        poi_row.addWidget(self.f15Poi, 1)
        poi_btn = QPushButton("🌐 Da OSM")
        poi_btn.setToolTip("Scarica dall'inquadratura i servizi OSM divisi in "
                           "categorie: alimentari, scuole, salute, parchi, "
                           "sport, trasporto pubblico, cultura, bar e "
                           "ristoranti, uffici.")
        poi_btn.clicked.connect(self._f15_download)
        poi_row.addWidget(poi_btn)
        form.addRow("Servizi:", self._wrap(poi_row))
        self.f15Cat = QgsFieldComboBox()
        self.f15Poi.layerChanged.connect(self._f15_poi_changed)
        self.f15Cat.setLayer(self.f15Poi.currentLayer())
        form.addRow("Campo categoria:", self.f15Cat)
        self.f15Zones = QgsMapLayerComboBox()
        self.f15Zones.setFilters(QgsMapLayerProxyModel.PointLayer
                                 | QgsMapLayerProxyModel.PolygonLayer)
        self.f15Zones.setAllowEmptyLayer(True)
        self.f15Zones.setLayer(None)
        self.f15Zones.setToolTip("Zone (es. sezioni di censimento) o punti "
                                 "(es. edifici). Vuoto = griglia esagonale.")
        form.addRow("Zone o punti (vuoto = griglia):",
                    self._combo_with_istat(self.f15Zones,
                                           lambda: self.f15Pop, "polygons"))
        self.f15Area = QgsMapLayerComboBox()
        self.f15Area.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.f15Area.setAllowEmptyLayer(True)
        self.f15Area.setLayer(None)
        self.f15Area.setToolTip("Solo per la griglia: celle dentro questi "
                                "poligoni. Vuoto = tutta l'area della rete.")
        form.addRow("Area della griglia (opz.):", self.f15Area)
        self.f15Cell = QSpinBox()
        self.f15Cell.setRange(25, 5000)
        self.f15Cell.setValue(150)
        self.f15Cell.setSingleStep(25)
        self.f15Cell.setSuffix(" m")
        form.addRow("Cella della griglia (raggio):", self.f15Cell)
        self.f15Travel = travel_ui.TravelControls(form, self.f15Road,
                                                  modes=("walk", "bike"))
        self.f15Minutes = QSpinBox()
        self.f15Minutes.setRange(1, 120)
        self.f15Minutes.setValue(15)
        self.f15Minutes.setSuffix(" min")
        form.addRow("Soglia:", self.f15Minutes)
        self.f15Pop = QgsFieldComboBox()
        self.f15Pop.setAllowEmptyFieldName(True)
        self.f15Pop.setFilters(QgsFieldProxyModel.Numeric)
        self.f15Zones.layerChanged.connect(self.f15Pop.setLayer)
        form.addRow("Popolazione delle zone (opz.):", self.f15Pop)
        layout.addLayout(form)
        self.f15Button = QPushButton("Calcola indice 15 minuti")
        self.f15Button.clicked.connect(self._f15_run)
        layout.addWidget(self.f15Button)
        self.f15Status = QLabel("")
        self.f15Status.setWordWrap(True)
        layout.addWidget(self.f15Status)
        layout.addStretch()
        return container

    def _f15_status(self, text, error=False):
        self._paint_status(self.f15Status, text, error)

    def _f15_poi_changed(self, layer):
        self.f15Cat.setLayer(layer)
        if layer is not None:
            names = layer.fields().names()
            for cand in ("categoria", "category", "tipo", "type"):
                if cand in names:
                    self.f15Cat.setField(cand)
                    break

    def _f15_download(self):
        if getattr(self, "_f15_osm_task", None) is not None:
            self.iface.messageBar().pushInfo("OSM", "Download già in corso.")
            return
        canvas = self.iface.mapCanvas()
        ct = QgsCoordinateTransform(
            canvas.mapSettings().destinationCrs(), isochrones.WGS84,
            QgsProject.instance().transformContext())
        r = ct.transformBoundingBox(canvas.extent())
        if (r.yMaximum() - r.yMinimum()) * (r.xMaximum() - r.xMinimum()) > 0.1:
            if QMessageBox.question(
                    self, "Inquadratura ampia",
                    "L'inquadratura è molto ampia: il download dei servizi da "
                    "OSM può essere lento o fallire.\n\nContinuare comunque?"
                    ) != QMessageBox.Yes:
                return
        task = OsmServicesTask((r.yMinimum(), r.xMinimum(), r.yMaximum(),
                                r.xMaximum()))
        self._f15_osm_task = task
        task.taskCompleted.connect(lambda t=task: self._f15_osm_done(t))
        task.taskTerminated.connect(lambda t=task: self._f15_osm_failed(t))
        self._f15_status("Scarico i servizi OSM dell'inquadratura…")
        QgsApplication.taskManager().addTask(task)

    def _f15_osm_done(self, task):
        self._f15_osm_task = None
        rows = task.result or []
        if not rows:
            self._f15_status("Nessun servizio OSM nell'inquadratura.",
                             error=True)
            return
        layer = self._add_output(fifteen.build_services_layer(rows),
                                 zoom=False)
        self.f15Poi.setLayer(layer)
        self.f15Cat.setField("categoria")
        cnt = {}
        for r in rows:
            cnt[r[3]] = cnt.get(r[3], 0) + 1
        src = " (dalla cache)" if task.from_cache else ""
        self._f15_status("Servizi OSM%s: %d — %s." % (
            src, len(rows), ", ".join("%s %d" % (c, cnt[c])
                                      for c in fifteen.order_categories(cnt))))

    def _f15_osm_failed(self, task):
        self._f15_osm_task = None
        if task.cancelled:
            self._f15_status("Download annullato.")
        else:
            self._f15_status("Errore download servizi: %s" % task.exception,
                             error=True)

    def _f15_run(self):
        road = self.f15Road.currentLayer()
        poi = self.f15Poi.currentLayer()
        catf = self.f15Cat.currentField()
        if road is None or poi is None:
            self._f15_status("Scegli la rete stradale e il layer dei servizi.",
                             error=True)
            return
        if not catf:
            self._f15_status("Scegli il campo della categoria dei servizi "
                             "(per i servizi OSM: «categoria»).", error=True)
            return
        ctx = QgsProject.instance().transformContext()
        to_wgs = QgsCoordinateTransform(poi.crs(), isochrones.WGS84, ctx)
        pois = []
        for f in poi.getFeatures():
            g = f.geometry()
            c = f[catf]
            if g is None or g.isEmpty() or c is None or str(c).strip() in (
                    "", "NULL"):
                continue
            g = QgsGeometry(g)
            g.transform(to_wgs)
            p = g.pointOnSurface().asPoint()
            pois.append((p.y(), p.x(), str(c).strip()))
        cats = fifteen.order_categories({c for _a, _b, c in pois})
        if not cats:
            self._f15_status("Nessun servizio con categoria nel layer.",
                             error=True)
            return
        if len(cats) > 25:
            self._f15_status("Il campo «%s» ha %d valori diversi: scegli un "
                             "campo con poche categorie (tipo di servizio)."
                             % (catf, len(cats)), error=True)
            return
        # zone: layer scelto, altrimenti griglia sull'area. Copia delle zone
        # al lancio: il risultato resta allineato anche se il layer cambia
        zones = self.f15Zones.currentLayer()
        popf = self.f15Pop.currentField() if zones is not None else ""
        if zones is not None:
            zones = gtfs_layers.FeatureSnapshot(zones)
        cells = None
        if zones is not None:
            ctz = QgsCoordinateTransform(zones.crs(), isochrones.WGS84, ctx)
            origins = []
            for f in zones.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ctz)
                p = g.pointOnSurface().asPoint()
                origins.append((p.y(), p.x()))
        else:
            area = self.f15Area.currentLayer()
            src = area if area is not None else road
            ext = QgsCoordinateTransform(src.crs(), isochrones.WGS84,
                                         ctx).transformBoundingBox(src.extent())
            origins, cells = grid_gen.build_grid(
                ext.yMinimum(), ext.yMaximum(), ext.xMinimum(), ext.xMaximum(),
                self.f15Cell.value(), "hex")
            if area is not None:
                union = self._area_union(area, isochrones.WGS84, ctx)
                if union is not None:
                    from qgis.core import QgsPointXY
                    eng = QgsGeometry.createGeometryEngine(union.constGet())
                    eng.prepareGeometry()
                    keep = []
                    for k, (la, lo) in enumerate(origins):
                        # la geometria resta viva durante il test (constGet
                        # di un temporaneo punterebbe a memoria liberata)
                        pg = QgsGeometry.fromPointXY(QgsPointXY(lo, la))
                        if eng.intersects(pg.constGet()):
                            keep.append(k)
                    origins = [origins[k] for k in keep]
                    cells = [cells[k] for k in keep]
        if not origins:
            self._f15_status("Nessuna zona o cella da analizzare.", error=True)
            return
        if len(origins) > 60000:
            self._f15_status("Troppe celle (%d): aumenta la cella o indica "
                             "un'area più piccola." % len(origins), error=True)
            return
        try:
            cost, vmax, desc = self.f15Travel.cost(road, ctx)
        except ValueError as exc:
            self._f15_status(str(exc), error=True)
            return
        thr = self.f15Minutes.value()
        # oltre la soglia si cerca ancora un po': utile sapere quanto manca
        max_s = max(2 * thr, thr + 15) * 60.0
        radius = vmax / 3.6 * max_s + 500.0
        spec = self._road_spec(road, ctx, self.f15Travel.oneway.isChecked(),
                               net_iso.reach_bbox(origins, radius), radius)

        def _job(task):
            roads, dirs, ec, st, _cs = read_costed_network(spec, cost, task,
                                                           0, 40)
            res = fifteen.nearest_times(
                roads, dirs, ec, origins, pois, cats, max_s,
                progress=lambda p: task.setProgress(40 + 0.6 * p),
                is_canceled=task.isCanceled)
            return res, st
        try:
            out = self._run_modal("Città dei 15 minuti…", _job)
        except Exception as exc:
            self._f15_status("Errore: %s" % exc, error=True)
            return
        if out is None:
            self._f15_status("Calcolo annullato.")
            return
        (times, n_out, n_poi_out), st = out
        summ = fifteen.summarize(times, cats, thr * 60.0)
        name = "Città %d minuti" % thr
        layer = fifteen.build_layer(cats, summ, thr, cells=cells,
                                    source_layer=zones, name=name)
        layer = self._add_output(layer)
        K = len(cats)
        idx = [s_["indice"] for s_ in summ]
        full = sum(1 for s_ in summ if s_["n"] == K)
        msg = ("%s: %d %s, %s, %d categorie. Indice medio %.0f/100; con tutti "
               "i servizi entro %d min: %d (%.0f %%)."
               % (name, len(summ), "celle" if cells else "zone", desc, K,
                  sum(idx) / len(idx), thr, full, 100.0 * full / len(summ)))
        if popf:
            pops = []
            for f in zones.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                try:
                    pops.append(float(f[popf]))
                except (TypeError, ValueError):
                    pops.append(0.0)
            tot = sum(pops)
            if tot > 0:
                pf = sum(p_ for p_, s_ in zip(pops, summ) if s_["n"] == K)
                msg += (" Popolazione con tutti i servizi: %.0f %% (%.0f su "
                        "%.0f)." % (100.0 * pf / tot, pf, tot))
        # la categoria che manca più spesso
        miss = [sum(1 for s_ in summ if s_["tempi_min"][k] is None
                    or s_["tempi_min"][k] > thr) for k in range(K)]
        if max(miss):
            k = miss.index(max(miss))
            msg += " Manca più spesso: %s (%d)." % (cats[k], miss[k])
        if n_out:
            msg += (" ⚠️ %d %s a più di 500 m dalla rete: indice 0."
                    % (n_out, "celle" if cells else "zone"))
        if n_poi_out:
            msg += " %d servizi lontani dalla rete ignorati." % n_poi_out
        self._f15_status(msg + self._cost_note(st))

    # ------------------------------------------------- Report di un'area
    def _build_report_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("report"))
        form = QFormLayout()
        self.repName = QLineEdit()
        self.repName.setPlaceholderText("es. San Lorenzo")
        self.repName.setToolTip("Titolo del report. Vuoto = dal campo nome "
                                "della feature o dal nome del layer.")
        form.addRow("Nome:", self.repName)
        self.repAreaMode = QComboBox()
        self.repAreaMode.addItem("Poligoni di un layer", "layer")
        self.repAreaMode.addItem("Disegnata sulla mappa", "draw")
        self.repAreaMode.addItem("Inquadratura della mappa", "view")
        form.addRow("Area:", self.repAreaMode)
        self.repAreaLayer = QgsMapLayerComboBox()
        self.repAreaLayer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Layer:", self.repAreaLayer)
        self.repSelected = QCheckBox("Solo le feature selezionate")
        self.repSelected.setChecked(True)
        self.repSelected.setToolTip("Con più feature l'area è la loro "
                                    "unione. Senza selezione: tutto il "
                                    "layer.")
        form.addRow("", self.repSelected)
        self.repNameField = QgsFieldComboBox()
        self.repNameField.setAllowEmptyFieldName(True)
        self.repAreaLayer.layerChanged.connect(self.repNameField.setLayer)
        self.repNameField.setLayer(self.repAreaLayer.currentLayer())
        form.addRow("Campo nome:", self.repNameField)
        draw = QHBoxLayout()
        draw.setContentsMargins(0, 0, 0, 0)
        self.repDrawButton = QPushButton("✏️ Disegna")
        self.repDrawButton.setCheckable(True)
        self.repDrawButton.setToolTip(
            "Clic sinistro: vertice; clic destro o doppio clic: chiude "
            "l'area; Backspace: toglie l'ultimo vertice; Esc: annulla.")
        self.repDrawButton.toggled.connect(self._rep_toggle_draw)
        draw.addWidget(self.repDrawButton)
        clr = QPushButton("Cancella")
        clr.clicked.connect(self._rep_clear_draw)
        draw.addWidget(clr)
        draw.addStretch(1)
        self.repDrawRow = self._wrap(draw)
        form.addRow("Sulla mappa:", self.repDrawRow)
        self.repDrawLabel = QLabel("nessuna area disegnata")
        self.repDrawLabel.setWordWrap(True)
        form.addRow("", self.repDrawLabel)
        self.repRoad = QgsMapLayerComboBox()
        self.repRoad.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.repRoad.setAllowEmptyLayer(True)
        self.repRoad.setLayer(None)
        self.repRoad.setToolTip("Vuoto = la rete si scarica da OSM per "
                                "l'area più un margine (serve per isocrone "
                                "e 15 minuti).")
        form.addRow("Rete (vuoto = OSM):", self.repRoad)
        self.repTypeField = QgsFieldComboBox()
        self.repTypeField.setAllowEmptyFieldName(True)
        self.repRoad.layerChanged.connect(self._rep_road_changed)
        form.addRow("Tipo strada:", self.repTypeField)
        self.repIstat = QCheckBox("Dati ISTAT 2021")
        self.repIstat.setToolTip(
            "Spuntata: il report scarica dall'ISTAT le sezioni di "
            "censimento della regione dell'area (una volta sola) e ne usa "
            "i residenti per densità e quote di abitanti; aggiunge la "
            "pagina «Popolazione» (età, famiglie, istruzione, lavoro, "
            "confronto con il comune). Solo per aree in Italia.\n"
            "Non spuntata: nessun dato ISTAT; qui sotto puoi indicare un "
            "tuo layer di poligoni con gli abitanti, o lasciare vuoto.")
        form.addRow("Popolazione:", self.repIstat)
        self.repPop = QgsMapLayerComboBox()
        self.repPop.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.repPop.setAllowEmptyLayer(True)
        self.repPop.setLayer(None)
        self.repPop.setToolTip("Es. sezioni di censimento: la popolazione "
                               "si ripartisce per area di sovrapposizione.")
        form.addRow("Oppure layer:", self.repPop)
        self.repPopField = QgsFieldComboBox()
        self.repPopField.setFilters(QgsFieldProxyModel.Numeric)
        self.repPop.layerChanged.connect(self.repPopField.setLayer)
        form.addRow("Abitanti:", self.repPopField)
        from qgis.core import QgsSettings
        self.repIstat.setChecked(QgsSettings().value(
            self._OUT_KEY + "report_istat", True, type=bool))
        self.repIstat.toggled.connect(self._rep_pop_mode_changed)
        self._rep_pop_mode_changed()
        self.repServ = QgsMapLayerComboBox()
        self.repServ.setFilters(QgsMapLayerProxyModel.PointLayer
                                | QgsMapLayerProxyModel.PolygonLayer)
        self.repServ.setAllowEmptyLayer(True)
        self.repServ.setLayer(None)
        self.repServ.setToolTip("Vuoto = servizi da OSM in 9 categorie "
                                "(come nella scheda 15 min).")
        form.addRow("Servizi (vuoto = OSM):", self.repServ)
        self.repServCat = QgsFieldComboBox()
        self.repServ.layerChanged.connect(self._rep_serv_changed)
        form.addRow("Categoria:", self.repServCat)
        gt = QHBoxLayout()
        gt.setContentsMargins(0, 0, 0, 0)
        self.repGtfs = QLineEdit()
        self.repGtfs.setPlaceholderText("vuoto = GTFS della scheda Trasporti")
        gtb = QPushButton("…")
        gtb.setMaximumWidth(32)
        gtb.clicked.connect(self._rep_browse_gtfs)
        gt.addWidget(self.repGtfs, 1)
        gt.addWidget(gtb)
        form.addRow("GTFS (opz.):", self._wrap(gt))
        self.repDem = travel_ui.dem_combo()
        form.addRow("DEM (opz.):", self.repDem)
        layout.addLayout(form)

        from . import report_layout
        from qgis.core import QgsSettings
        st = QgsSettings()
        maps = QGroupBox("Mappe")
        mf = QFormLayout(maps)
        self.repStyle = QComboBox()
        for key, lab in report_layout.MAP_STYLES:
            self.repStyle.addItem(lab, key)
        self.repStyle.setToolTip(
            "Carta chiara: base disegnata dal plugin con i dati OSM "
            "(edifici, verde, acqua, ferrovie), nitida e senza bisogno di "
            "internet dopo il primo download.\n"
            "OpenStreetMap: la mappa standard come sfondo; serve internet.\n"
            "Satellite: foto aerea Esri; serve internet.\n"
            "Se la base non è raggiungibile le mappe escono con le sole "
            "strade di contesto.")
        mf.addRow("Stile:", self.repStyle)
        self.repLabels = QComboBox()
        for key, lab in report_layout.LABEL_MODES:
            self.repLabels.addItem(lab, key)
        self.repLabels.setToolTip(
            "Nomi delle vie sulle mappe. Automatico: solo le vie principali "
            "sulle mappe a celle e sulle isocrone, tutte sulle mappe della "
            "rete e dei servizi. Con lo stile OpenStreetMap i nomi sono "
            "già nello sfondo.")
        mf.addRow("Nomi delle vie:", self.repLabels)
        self.repLabelSize = QComboBox()
        for key, lab, _pt in report_layout.LABEL_SIZES:
            self.repLabelSize.addItem(lab, key)
        mf.addRow("Dimensione dei nomi:", self.repLabelSize)
        for combo, key, default in (
                (self.repStyle, "report_style", "chiara"),
                (self.repLabels, "report_labels", "auto"),
                (self.repLabelSize, "report_label_size", "medi")):
            k = combo.findData(st.value(self._OUT_KEY + key, default))
            combo.setCurrentIndex(k if k >= 0 else combo.findData(default))
        self.repStyle.currentIndexChanged.connect(self._rep_style_changed)
        self.repLabels.currentIndexChanged.connect(self._rep_style_changed)
        self._rep_style_changed()
        layout.addWidget(maps)

        sec = QGroupBox("Sezioni")
        sf = QVBoxLayout(sec)
        self.repSections = {}
        for key, lab in area_report.SECTIONS:
            cb = QCheckBox(lab)
            cb.setChecked(True)
            sf.addWidget(cb)
            self.repSections[key] = cb
        self.repSections["demo"].setToolTip(
            "Età, famiglie, istruzione e lavoro dei residenti, con il "
            "confronto con il comune: solo con «Dati ISTAT 2021» spuntata "
            "(aree in Italia).")
        self._rep_pop_mode_changed()
        self._make_collapsible(sec, collapsed=True)
        layout.addWidget(sec)

        par = QGroupBox("Parametri")
        pf = QFormLayout(par)
        self.repPreset = QComboBox()
        self.repPreset.addItem("Quartiere (celle di 70 m)", 70)
        self.repPreset.addItem("Città (celle di 250 m)", 250)
        self.repPreset.addItem("Personalizzato", 0)
        pf.addRow("Dettaglio:", self.repPreset)
        self.repCell = QSpinBox()
        self.repCell.setRange(25, 2000)
        self.repCell.setSingleStep(10)
        self.repCell.setValue(70)
        self.repCell.setSuffix(" m")
        pf.addRow("Cella (raggio):", self.repCell)
        self.repPreset.currentIndexChanged.connect(self._rep_preset_changed)
        self.repCell.valueChanged.connect(self._rep_cell_changed)
        self.repWalk = QDoubleSpinBox()
        self.repWalk.setRange(1.0, 10.0)
        self.repWalk.setDecimals(1)
        self.repWalk.setSingleStep(0.5)
        self.repWalk.setValue(4.5)
        self.repWalk.setSuffix(" km/h")
        pf.addRow("A piedi:", self.repWalk)
        self.repTimes = QLineEdit("5,10,15")
        pf.addRow("Isocrone (min):", self.repTimes)
        self.repF15 = QSpinBox()
        self.repF15.setRange(1, 60)
        self.repF15.setValue(15)
        self.repF15.setSuffix(" min")
        pf.addRow("Città dei … minuti:", self.repF15)
        band = QHBoxLayout()
        band.setContentsMargins(0, 0, 0, 0)
        self.repPtalFrom = QTimeEdit(QTime(8, 15))
        self.repPtalFrom.setDisplayFormat("HH:mm")
        self.repPtalTo = QTimeEdit(QTime(9, 15))
        self.repPtalTo.setDisplayFormat("HH:mm")
        band.addWidget(self.repPtalFrom)
        band.addWidget(QLabel("–"))
        band.addWidget(self.repPtalTo)
        pf.addRow("Fascia PTAL:", self._wrap(band))
        self.repOpen = QCheckBox("Apri il PDF alla fine")
        self.repOpen.setChecked(True)
        pf.addRow("", self.repOpen)
        self._make_collapsible(par, collapsed=True)
        layout.addWidget(par)

        self.repButton = QPushButton("Crea report…")
        self.repButton.clicked.connect(self._rep_run)
        layout.addWidget(self.repButton)
        self.repStatus = QLabel("")
        self.repStatus.setWordWrap(True)
        layout.addWidget(self.repStatus)
        layout.addStretch()
        self.repAreaMode.currentIndexChanged.connect(self._rep_mode_changed)
        self._rep_mode_changed()
        return container

    def _rep_status(self, text, error=False):
        self._paint_status(self.repStatus, text, error)

    # ---------------------------------------------- residenti serviti dal TP
    def _comune_edit(self):
        """Casella per il nome di un comune, con il completamento
        sull'elenco ISTAT."""
        from qgis.PyQt.QtWidgets import QCompleter
        edit = QLineEdit()
        edit.setPlaceholderText("scrivi il nome, es. Roma")
        edit.setClearButtonEnabled(True)
        comp = QCompleter([istat.comune_label(c) for c in istat.comuni()],
                          edit)
        comp.setCaseSensitivity(Qt.CaseInsensitive)
        comp.setFilterMode(Qt.MatchContains)
        comp.setMaxVisibleItems(12)
        edit.setCompleter(comp)
        return edit

    def _build_coverage_tab(self):
        from qgis.core import QgsSettings
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("coverage"))
        intro = QLabel(
            "Quanti residenti hanno una fermata a portata di piedi, e con "
            "quante corse all'ora. Usa il feed della scheda GTFS.")
        intro.setWordWrap(True)
        layout.addWidget(intro)
        form = QFormLayout()
        self._cov_form = form
        self.covIstat = QCheckBox("Popolazione dai dati ISTAT 2021")
        self.covIstat.setToolTip(
            "Spuntata: i residenti sono quelli delle sezioni di censimento "
            "ISTAT dell'area scelta (si scaricano una volta sola); solo in "
            "Italia.\n"
            "Non spuntata: indica un tuo layer di poligoni o punti con un "
            "campo di abitanti.")
        self.covIstat.setChecked(QgsSettings().value(
            self._OUT_KEY + "cov_istat", True, type=bool))
        form.addRow(self.covIstat)
        self.covMode = QComboBox()
        self.covMode.addItem("Un comune", "comune")
        self.covMode.addItem("Inquadratura della mappa", "view")
        self.covMode.addItem("Poligoni di un layer", "layer")
        form.addRow("Area:", self.covMode)
        self.covComune = self._comune_edit()
        self.covComune.returnPressed.connect(self._cov_run)
        form.addRow("Comune:", self.covComune)
        self.covLayer = QgsMapLayerComboBox()
        self.covLayer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Layer:", self.covLayer)
        self.covSelected = QCheckBox("Solo le feature selezionate")
        self.covSelected.setChecked(True)
        form.addRow("", self.covSelected)
        self.covPop = QgsMapLayerComboBox()
        self.covPop.setFilters(QgsMapLayerProxyModel.PolygonLayer
                               | QgsMapLayerProxyModel.PointLayer)
        self.covPop.setToolTip("Poligoni (sezioni, isolati) o punti "
                               "(edifici) con il numero di abitanti.")
        form.addRow("Layer abitanti:", self.covPop)
        self.covPopField = QgsFieldComboBox()
        self.covPopField.setFilters(QgsFieldProxyModel.Numeric)
        self.covPop.layerChanged.connect(self.covPopField.setLayer)
        self.covPopField.setLayer(self.covPop.currentLayer())
        form.addRow("Abitanti:", self.covPopField)
        self.covAir = QCheckBox("Distanze in linea d'aria")
        self.covAir.setToolTip(
            "Non spuntata: la distanza dalla fermata è misurata a piedi "
            "lungo la rete (più realistica).\n"
            "Spuntata: in linea d'aria, senza rete: più rapido, ma conta "
            "come vicine anche fermate oltre un fiume o una ferrovia.")
        form.addRow("", self.covAir)
        self.covRoad = QgsMapLayerComboBox()
        self.covRoad.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.covRoad.setAllowEmptyLayer(True)
        self.covRoad.setLayer(None)
        self.covRoad.setToolTip("Vuoto = la rete si scarica da OSM per "
                                "l'area più un margine.")
        form.addRow("Rete (vuoto = OSM):", self.covRoad)
        hours = QHBoxLayout()
        hours.setContentsMargins(0, 0, 0, 0)
        self.covStart = QTimeEdit(QTime(7, 0))
        self.covStart.setDisplayFormat("HH:mm")
        self.covEnd = QTimeEdit(QTime(9, 0))
        self.covEnd.setDisplayFormat("HH:mm")
        hours.addWidget(self.covStart)
        hours.addWidget(QLabel("–"))
        hours.addWidget(self.covEnd)
        hours.addStretch(1)
        form.addRow("Fascia oraria:", self._wrap(hours))
        self.covBus = QSpinBox()
        self.covBus.setRange(50, 3000)
        self.covBus.setSingleStep(50)
        self.covBus.setValue(400)
        self.covBus.setSuffix(" m")
        form.addRow("Bus e tram entro:", self.covBus)
        self.covRail = QSpinBox()
        self.covRail.setRange(50, 5000)
        self.covRail.setSingleStep(50)
        self.covRail.setValue(800)
        self.covRail.setSuffix(" m")
        form.addRow("Metro e treno entro:", self.covRail)
        layout.addLayout(form)
        self.covSourceEdit = QLineEdit()
        layout.addWidget(self._gtfs_override_box(self.covSourceEdit,
                                                 self._cov_browse))
        self.covButton = QPushButton("Calcola i residenti serviti")
        self.covButton.clicked.connect(self._cov_run)
        layout.addWidget(self.covButton)
        self.covStatus = QLabel("")
        self.covStatus.setWordWrap(True)
        layout.addWidget(self.covStatus)
        self.covTable = QTableWidget()
        self.covTable.setColumnCount(2)
        self.covTable.setHorizontalHeaderLabels(["Residenti", "Numero"])
        self.covTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.covTable.setSelectionMode(QAbstractItemView.NoSelection)
        self.covTable.verticalHeader().setVisible(False)
        self.covTable.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.covTable.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.covTable.setWordWrap(True)
        hh = self.covTable.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.covTable.setVisible(False)
        layout.addWidget(self.covTable)
        self.covCopy = QPushButton("Copia il riepilogo")
        self.covCopy.setFlat(True)
        self.covCopy.clicked.connect(self._cov_copy)
        self.covCopy.setVisible(False)
        layout.addWidget(self.covCopy)
        layout.addStretch()
        self.covIstat.toggled.connect(self._cov_mode_changed)
        self.covMode.currentIndexChanged.connect(self._cov_mode_changed)
        self.covAir.toggled.connect(self._cov_mode_changed)
        self._cov_mode_changed()
        return container

    def _cov_status(self, text, error=False):
        self._paint_status(self.covStatus, text, error)

    def _cov_browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.covSourceEdit.setText(path)

    def _cov_mode_changed(self, *_a):
        """Si vedono solo i controlli che servono."""
        ist = self.covIstat.isChecked()
        mode = self.covMode.currentData()
        for w, on in ((self.covMode, ist),
                      (self.covComune, ist and mode == "comune"),
                      (self.covLayer, ist and mode == "layer"),
                      (self.covSelected, ist and mode == "layer"),
                      (self.covPop, not ist), (self.covPopField, not ist),
                      (self.covRoad, not self.covAir.isChecked())):
            w.setVisible(on)
            w.setEnabled(on)
            lab = self._cov_form.labelForField(w)
            if lab is not None:
                lab.setVisible(on)

    def _cov_units(self, layer, field):
        """Unità di popolazione da un layer: [(geometria WGS84, codice,
        residenti, lat, lon)] per le feature con abitanti."""
        from qgis.core import QgsWkbTypes
        ct = QgsCoordinateTransform(layer.crs(), isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        poly = layer.geometryType() == QgsWkbTypes.PolygonGeometry
        out = []
        for f in layer.getFeatures():
            g = f.geometry()
            try:
                v = float(f[field])
            except (TypeError, ValueError):
                continue
            if g is None or g.isEmpty() or v <= 0:
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            pt = (g.pointOnSurface() if poly else g.centroid()).asPoint()
            out.append((g, f.id(), v, pt.y(), pt.x()))
        return out

    def _cov_run(self):
        from qgis.core import QgsSettings, QgsWkbTypes
        ctx = QgsProject.instance().transformContext()
        source = self.covSourceEdit.text().strip() or self._global_gtfs()
        if not source:
            self._cov_status("Indica il feed GTFS nella scheda GTFS (o qui "
                             "sotto, in «Sorgente GTFS alternativa»).",
                             error=True)
            return
        t0, t1 = self.covStart.time(), self.covEnd.time()
        if t1 <= t0:
            self._cov_status("La fascia oraria deve finire dopo l'inizio.",
                             error=True)
            return
        sh = t0.hour() + t0.minute() / 60.0
        eh = t1.hour() + t1.minute() / 60.0
        dist = tp_coverage.thresholds(self.covBus.value(),
                                      self.covRail.value())
        use_istat = self.covIstat.isChecked()
        QgsSettings().setValue(self._OUT_KEY + "cov_istat", use_istat)
        kwargs = units = None
        partial = False
        if use_istat:
            try:
                kwargs, name, partial = self._istat_area(
                    self.covMode, self.covComune, self.covLayer,
                    self.covSelected)
            except ValueError as exc:
                self._cov_status(str(exc), error=True)
                return
            if "pro_com" in kwargs:
                box = istat.comune_bbox(kwargs["pro_com"])
            elif "rect" in kwargs:
                box = kwargs["rect"]
            else:
                bb = QgsGeometry.fromWkt(kwargs["wkt"]).boundingBox()
                box = (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(),
                       bb.yMaximum())
            if "pro_com" not in kwargs and not istat.regions_for_bbox(*box):
                self._cov_status("L'area non è in Italia: togli la spunta da "
                                 "«Popolazione dai dati ISTAT 2021» e "
                                 "indica un tuo layer "
                                 "di abitanti.", error=True)
                return
            geom, crs_id = "MultiPolygon", "EPSG:%d" % istat.EPSG
        else:
            pl = self.covPop.currentLayer()
            pf = self.covPopField.currentField()
            if pl is None or not pf:
                self._cov_status("Indica il layer degli abitanti e il campo "
                                 "(o spunta «Popolazione dai dati ISTAT "
                                 "2021»).", error=True)
                return
            units = self._cov_units(pl, pf)
            if not units:
                self._cov_status("Il layer degli abitanti non ha feature "
                                 "con un numero di abitanti.", error=True)
                return
            name = pl.name()
            box = (min(u[4] for u in units), min(u[3] for u in units),
                   max(u[4] for u in units), max(u[3] for u in units))
            geom = ("MultiPolygon" if pl.geometryType()
                    == QgsWkbTypes.PolygonGeometry else "Point")
            crs_id = "EPSG:4326"
        margin = max(dist.values()) + 500.0
        clip = net_iso.reach_bbox([(box[1], box[0]), (box[3], box[2])],
                                  margin)
        air = self.covAir.isChecked()
        road = None if air else self.covRoad.currentLayer()
        spec = None
        keep = None
        if not air:
            if road is None:
                km2 = analysis.geometry_area_m2(
                    QgsGeometry.fromRect(QgsRectangle(*clip)),
                    isochrones.WGS84, ctx) / 1e6
                if km2 > 300 and QMessageBox.question(
                        self, "Area ampia", "La rete da scaricare da OSM "
                        "copre %s km²: può richiedere alcuni minuti o non "
                        "riuscire. In alternativa indica un layer di strade "
                        "o spunta «Distanze in linea d'aria».\n\n"
                        "Scaricare lo stesso?" % area_report.fmt(km2, 0)
                        ) != QMessageBox.Yes:
                    return
                try:
                    road = self._rep_osm_roads(clip, name)
                except Exception as exc:
                    self._cov_status("Rete da OSM non scaricata: %s. Indica "
                                     "un layer di strade o spunta «Distanze "
                                     "in linea d'aria»." % exc, error=True)
                    return
                if road is None:
                    self._cov_status("Download annullato.")
                    return
            spec = self._road_spec(road, ctx, False, clip, margin)
            hw = {n.lower(): n for n in road.fields().names()}.get("highway")
            if hw:   # a piedi non si usano autostrade e superstrade
                keep = (lambda f, _hw=hw: str(f[_hw])
                        not in area_report.WALK_EXCLUDE)
        sdate = self._service_date()

        def _job(task):
            data = None
            if use_istat:
                data = istat.fetch(
                    indicators=False, is_canceled=task.isCanceled,
                    progress=lambda p: task.setProgress(0.25 * p), **kwargs)
                if data is None:
                    return None
                ip = data["fields"].index("POP21")
                keep_rows = [r for r in data["rows"] if r[2][ip]]
                data["rows"] = keep_rows
                ll = istat.points_of(data)
                pts = [(ll[i][0], ll[i][1], r[1] * r[2][ip])
                       for i, r in enumerate(keep_rows)]
            else:
                pts = [(u[3], u[4], u[2]) for u in units]
            task.setProgress(25)
            info = {}
            stop_routes, stops_xy = ptal.compute_stop_frequencies(
                source, sh, eh, service_date=sdate, info=info)
            task.setProgress(45)
            roads = None
            if spec is not None:
                raw, _d = read_spec_roads(spec, task, 45, 58, keep=keep)
                roads, _d2, _st = net_clean.clean_network(raw, 1.0, None)
                if not roads:
                    raise ValueError("nessuna strada nell'area: indica "
                                     "un'altra rete o spunta «Distanze in "
                                     "linea d'aria»")
            res = tp_coverage.compute(
                pts, stop_routes, stops_xy, roads, dist,
                progress=lambda p: task.setProgress(60 + 0.38 * p),
                is_canceled=task.isCanceled)
            return {"data": data, "pts": pts, "res": res,
                    "names": tp_coverage.gtfs_names(source),
                    "selection": info.get("selection", "")}
        try:
            out = self._run_modal("Residenti serviti dal trasporto "
                                  "pubblico…", _job)
        except Exception as exc:
            self._cov_status("Calcolo non riuscito: %s" % exc, error=True)
            return
        if out is None:
            self._cov_status("Calcolo annullato.")
            return
        res = out["res"]
        sm = res["summary"]
        if not sm["points"] or not sm["pop"]:
            self._cov_status("Nessun residente nell'area.", error=True)
            return
        if use_istat:
            i_id = out["data"]["fields"].index("SEZ21_ID")
            ulist = [(r[0], r[2][i_id], pt[2])
                     for r, pt in zip(out["data"]["rows"], out["pts"])]
        else:
            ulist = [(u[0], u[1], u[2]) for u in units]
        stop_names, route_names = out["names"]
        lay_u = tp_coverage.build_units_layer(
            ulist, res, "Residenti serviti – %s" % name, geom, crs_id)
        lay_s = tp_coverage.build_stops_layer(
            res, stop_names, "Fermate e residenti – %s" % name)
        lay_r = tp_coverage.build_routes_table(
            res, route_names, "Linee e residenti – %s" % name)
        self._add_output(lay_r, zoom=False)
        # con l'inquadratura la vista resta com'è (vedi scheda ISTAT)
        lay_u = self._add_output(
            lay_u, zoom=not (use_istat and "rect" in kwargs))
        self._add_output(lay_s, zoom=False)
        rows = tp_coverage.summary_rows(sm, area_report.fmt)
        self._cov_rows = rows
        t = self.covTable
        t.setRowCount(len(rows))
        for r, (k, v) in enumerate(rows):
            t.setItem(r, 0, QTableWidgetItem(k))
            it = QTableWidgetItem(v)
            it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            t.setItem(r, 1, it)
        t.setVisible(True)
        self.covCopy.setVisible(True)
        t.resizeRowsToContents()
        t.setFixedHeight(t.horizontalHeader().height() + 4 + sum(
            t.rowHeight(r) for r in range(len(rows))))
        good = sm["by_class"]["A"] + sm["by_class"]["B"]
        msg = ("«%s»: %s residenti; il %s %% ha una fermata a portata "
               "(bus e tram entro %d m, metro e treno entro %d m, %s), il "
               "%s %% con almeno 6 corse l'ora. Fascia %s–%s%s.\n"
               "Layer: sezioni per classe di servizio, fermate (cerchi "
               "proporzionali ai residenti) e tabella delle linee." % (
                   lay_u.name(), area_report.fmt(sm["pop"], 0),
                   area_report.fmt(100.0 * sm["served"] / sm["pop"], 1),
                   self.covBus.value(), self.covRail.value(),
                   "in linea d'aria" if not sm["network"]
                   else "a piedi sulla rete",
                   area_report.fmt(100.0 * good / sm["pop"], 1),
                   t0.toString("HH:mm"), t1.toString("HH:mm"),
                   ", " + out["selection"] if out["selection"] else ""))
        if not res["stops"]:
            msg += (" ⚠️ Nessuna fermata del feed è a portata dei "
                    "residenti: il feed copre quest'area?")
        if sm["off_network"]:
            msg += (" ⚠️ %d unità di popolazione sono a più di 500 m dalla "
                    "rete: contate come non servite." % sm["off_network"])
        if use_istat and partial:
            msg += (" Le sezioni a cavallo del confine contano per la "
                    "parte dentro l'area.")
        if use_istat:
            msg += "\nPopolazione: %s." % istat.SOURCE
            for x in out["data"]["notes"]:
                msg += " ⚠️ %s." % (x[0].upper() + x[1:])
        self._cov_status(msg)

    def _cov_copy(self):
        rows = getattr(self, "_cov_rows", None) or []
        QApplication.clipboard().setText(
            "\n".join("%s\t%s" % (k, v) for k, v in rows))
        self._cov_status("Riepilogo copiato negli appunti.")

    # ------------------------------------------------------------- ISTAT
    def _build_istat_tab(self):
        from qgis.PyQt.QtWidgets import QCompleter
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.addWidget(self._help_button("istat"))
        intro = QLabel(
            "Sezioni di censimento ISTAT 2021 con residenti, famiglie, "
            "abitazioni, edifici e indicatori demografici. Si scaricano "
            "dall'ISTAT una regione alla volta, una volta sola.")
        intro.setWordWrap(True)
        layout.addWidget(intro)
        form = QFormLayout()
        self.istMode = QComboBox()
        self.istMode.addItem("Un comune", "comune")
        self.istMode.addItem("Inquadratura della mappa", "view")
        self.istMode.addItem("Poligoni di un layer", "layer")
        form.addRow("Area:", self.istMode)
        self.istComune = QLineEdit()
        self.istComune.setPlaceholderText("scrivi il nome, es. Roma")
        self.istComune.setClearButtonEnabled(True)
        comp = QCompleter([istat.comune_label(c) for c in istat.comuni()],
                          self.istComune)
        comp.setCaseSensitivity(Qt.CaseInsensitive)
        comp.setFilterMode(Qt.MatchContains)
        comp.setMaxVisibleItems(12)
        self.istComune.setCompleter(comp)
        self.istComune.returnPressed.connect(self._ist_run)
        form.addRow("Comune:", self.istComune)
        self._ist_form = form
        self.istLayer = QgsMapLayerComboBox()
        self.istLayer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Layer:", self.istLayer)
        self.istSelected = QCheckBox("Solo le feature selezionate")
        self.istSelected.setChecked(True)
        self.istSelected.setToolTip("Senza selezione: tutto il layer.")
        form.addRow("", self.istSelected)
        self.istIndicators = QCheckBox("Con gli indicatori demografici")
        self.istIndicators.setChecked(True)
        self.istIndicators.setToolTip(
            "Età, sesso, istruzione, lavoro, cittadinanza, famiglie per "
            "numero di componenti, abitazioni: 119 colonne in più.\n"
            "Senza: solo residenti, famiglie, abitazioni ed edifici (il "
            "primo download della regione è più rapido).")
        form.addRow("", self.istIndicators)
        self.istTheme = QComboBox()
        for key, lab, _f, _d, _lo, _hi in istat.THEMES:
            self.istTheme.addItem(lab, key)
        self.istTheme.setToolTip(
            "Tema della mappa: cinque classi con lo stesso numero di "
            "sezioni. Si può cambiare anche dopo, senza riscaricare.")
        form.addRow("Colora per:", self.istTheme)
        layout.addLayout(form)
        self.istButton = QPushButton("Scarica e carica le sezioni")
        self.istButton.clicked.connect(self._ist_run)
        layout.addWidget(self.istButton)
        self.istStatus = QLabel("")
        self.istStatus.setWordWrap(True)
        layout.addWidget(self.istStatus)
        self.istTable = QTableWidget()
        self.istTable.setColumnCount(2)
        self.istTable.setHorizontalHeaderLabels(["Indicatore", "Valore"])
        self.istTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.istTable.setSelectionMode(QAbstractItemView.NoSelection)
        self.istTable.verticalHeader().setVisible(False)
        self.istTable.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.istTable.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.istTable.setWordWrap(True)
        hh = self.istTable.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.istTable.setVisible(False)
        layout.addWidget(self.istTable)
        self.istCopy = QPushButton("Copia il riepilogo")
        self.istCopy.setFlat(True)
        self.istCopy.setToolTip("Copia la tabella negli appunti (si incolla "
                                "in Excel o in un testo).")
        self.istCopy.clicked.connect(self._ist_copy)
        self.istCopy.setVisible(False)
        layout.addWidget(self.istCopy)
        jobs = QGroupBox("Addetti (posti di lavoro, 2011)")
        jv = QVBoxLayout(jobs)
        jnote = QLabel(
            "Addetti delle imprese, delle istituzioni pubbliche e delle non "
            "profit per sezione di censimento 2011: l'ultimo dato ISTAT per "
            "sezione. Usa l'area scelta sopra.")
        jnote.setWordWrap(True)
        jv.addWidget(jnote)
        jf = QFormLayout()
        self.jobsTheme = QComboBox()
        for key, lab, _f, _d, _lo, _hi in addetti.THEMES:
            self.jobsTheme.addItem(lab, key)
        self.jobsTheme.setToolTip(
            "Tema della mappa; si può cambiare anche dopo, senza "
            "riscaricare.")
        jf.addRow("Colora per:", self.jobsTheme)
        jv.addLayout(jf)
        self.jobsButton = QPushButton("Scarica e carica gli addetti")
        self.jobsButton.clicked.connect(self._jobs_run)
        jv.addWidget(self.jobsButton)
        self.jobsStatus = QLabel("")
        self.jobsStatus.setWordWrap(True)
        jv.addWidget(self.jobsStatus)
        self.jobsTable = QTableWidget()
        self.jobsTable.setColumnCount(2)
        self.jobsTable.setHorizontalHeaderLabels(["Addetti", "Numero"])
        self.jobsTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.jobsTable.setSelectionMode(QAbstractItemView.NoSelection)
        self.jobsTable.verticalHeader().setVisible(False)
        self.jobsTable.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.jobsTable.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.jobsTable.setWordWrap(True)
        jh = self.jobsTable.horizontalHeader()
        jh.setSectionResizeMode(0, QHeaderView.Stretch)
        jh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.jobsTable.setVisible(False)
        jv.addWidget(self.jobsTable)
        self.jobsTheme.currentIndexChanged.connect(self._jobs_theme_changed)
        self._make_collapsible(jobs, collapsed=True)
        layout.addWidget(jobs)
        pend = QGroupBox("Pendolarismo fra comuni (2021)")
        pv = QVBoxLayout(pend)
        pnote = QLabel(
            "Quante persone si spostano ogni giorno per lavoro o studio "
            "fra un comune e gli altri: linee di desiderio dalla matrice "
            "ISTAT 2021.")
        pnote.setWordWrap(True)
        pv.addWidget(pnote)
        pf = QFormLayout()
        self.pendComune = self._comune_edit()
        self.pendComune.returnPressed.connect(self._pend_run)
        pf.addRow("Comune:", self.pendComune)
        self.pendDir = QComboBox()
        for key, lab in pendolarismo.DIRECTIONS:
            self.pendDir.addItem(lab, key)
        pf.addRow("Flussi:", self.pendDir)
        self.pendKind = QComboBox()
        for key, lab in pendolarismo.KINDS:
            self.pendKind.addItem(lab, key)
        pf.addRow("Motivo:", self.pendKind)
        self.pendMin = QSpinBox()
        self.pendMin.setRange(1, 1000000)
        self.pendMin.setValue(50)
        self.pendMin.setSuffix(" persone")
        self.pendMin.setToolTip(
            "Si disegnano solo i flussi con almeno queste persone. La "
            "matrice è una stima e contiene moltissimi flussi di una o due "
            "persone, anche da centinaia di chilometri: senza una soglia "
            "la mappa non si legge.")
        pf.addRow("Almeno:", self.pendMin)
        self.pendTop = QSpinBox()
        self.pendTop.setRange(0, 10000)
        self.pendTop.setValue(0)
        self.pendTop.setSpecialValueText("tutti")
        self.pendTop.setToolTip("Solo i flussi più grandi, per ciascun "
                                "verso.")
        pf.addRow("Primi:", self.pendTop)
        self.pendArc = QCheckBox("Linee arcuate")
        self.pendArc.setChecked(True)
        self.pendArc.setToolTip("Curve: andata e ritorno fra due comuni "
                                "non si sovrappongono.")
        pf.addRow("", self.pendArc)
        pv.addLayout(pf)
        self.pendButton = QPushButton("Scarica e disegna i flussi")
        self.pendButton.clicked.connect(self._pend_run)
        pv.addWidget(self.pendButton)
        self.pendStatus = QLabel("")
        self.pendStatus.setWordWrap(True)
        pv.addWidget(self.pendStatus)
        self.pendTable = QTableWidget()
        self.pendTable.setColumnCount(2)
        self.pendTable.setHorizontalHeaderLabels(["Pendolari", "Persone"])
        self.pendTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.pendTable.setSelectionMode(QAbstractItemView.NoSelection)
        self.pendTable.verticalHeader().setVisible(False)
        self.pendTable.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.pendTable.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.pendTable.setWordWrap(True)
        ph = self.pendTable.horizontalHeader()
        ph.setSectionResizeMode(0, QHeaderView.Stretch)
        ph.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.pendTable.setVisible(False)
        pv.addWidget(self.pendTable)
        self._make_collapsible(pend, collapsed=True)
        layout.addWidget(pend)
        cache = QGroupBox("Dati scaricati")
        cl = QVBoxLayout(cache)
        self.istCacheLabel = QLabel("")
        self.istCacheLabel.setWordWrap(True)
        cl.addWidget(self.istCacheLabel)
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        ob = QPushButton("Apri la cartella")
        ob.clicked.connect(self._ist_cache_open)
        row.addWidget(ob)
        cb = QPushButton("Cancella")
        cb.setToolTip("Cancella i dati ISTAT scaricati: si riscaricano "
                      "alla prossima richiesta.")
        cb.clicked.connect(self._ist_cache_clear)
        row.addWidget(cb)
        row.addStretch(1)
        cl.addWidget(self._wrap(row))
        self._make_collapsible(cache, collapsed=True)
        layout.addWidget(cache)
        layout.addStretch()
        self.istMode.currentIndexChanged.connect(self._ist_mode_changed)
        self.istTheme.currentIndexChanged.connect(self._ist_theme_changed)
        self._ist_mode_changed()
        self._ist_cache_refresh()
        return container

    def _ist_status(self, text, error=False):
        self._paint_status(self.istStatus, text, error)

    def _ist_mode_changed(self, *_a):
        """Si vedono solo i controlli dell'area scelta."""
        mode = self.istMode.currentData()
        for w, on in ((self.istComune, mode == "comune"),
                      (self.istLayer, mode == "layer"),
                      (self.istSelected, mode == "layer")):
            w.setVisible(on)
            w.setEnabled(on)
            lab = self._ist_form.labelForField(w)
            if lab is not None:
                lab.setVisible(on)

    def _ist_area(self):
        return self._istat_area(self.istMode, self.istComune, self.istLayer,
                                self.istSelected)

    def _istat_area(self, mode_combo, comune_edit, layer_combo, sel_check):
        """(argomenti per istat.fetch, nome, True se l'area taglia le
        sezioni). ValueError con il motivo se manca qualcosa."""
        ctx = QgsProject.instance().transformContext()
        mode = mode_combo.currentData()
        if mode == "comune":
            c, err = istat.find_comune(comune_edit.text())
            if c is None:
                raise ValueError(err)
            comune_edit.setText(istat.comune_label(c))
            return {"pro_com": c["pro_com"]}, c["nome"], False
        if mode == "view":
            canvas = self.iface.mapCanvas()
            ct = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                        isochrones.WGS84, ctx)
            r = ct.transformBoundingBox(canvas.extent())
            return ({"rect": (r.xMinimum(), r.yMinimum(), r.xMaximum(),
                              r.yMaximum())}, "inquadratura", True)
        lay = layer_combo.currentLayer()
        if lay is None:
            raise ValueError("Scegli il layer di poligoni dell'area.")
        feats = (list(lay.selectedFeatures())
                 if sel_check.isChecked() and lay.selectedFeatureCount()
                 else list(lay.getFeatures()))
        ct = QgsCoordinateTransform(lay.crs(), isochrones.WGS84, ctx)
        geoms = []
        for f in feats:
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            geoms.append(g)
        geom = QgsGeometry.unaryUnion(geoms) if geoms else None
        if geom is None or geom.isEmpty():
            raise ValueError("Il layer dell'area non ha poligoni.")
        return {"wkt": geom.asWkt(7)}, lay.name(), True

    def _ist_run(self):
        try:
            kwargs, name, partial = self._ist_area()
        except ValueError as exc:
            self._ist_status(str(exc), error=True)
            return
        if "pro_com" not in kwargs:
            if "rect" in kwargs:
                w, s_, e, n = kwargs["rect"]
            else:
                bb = QgsGeometry.fromWkt(kwargs["wkt"]).boundingBox()
                w, s_, e, n = (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(),
                               bb.yMaximum())
            regs = istat.regions_for_bbox(w, s_, e, n)
            if not regs:
                self._ist_status("L'area non è in Italia: i dati ISTAT "
                                 "coprono solo il territorio italiano.",
                                 error=True)
                return
            if len(regs) > 2 and QMessageBox.question(
                    self, "Area ampia", "L'area tocca %d regioni (%s): si "
                    "scaricano i dati di tutte e il layer può avere decine "
                    "di migliaia di sezioni.\n\nContinuare?" % (
                        len(regs), ", ".join(istat.REGIONS[c] for c in regs))
                    ) != QMessageBox.Yes:
                return
        ind = self.istIndicators.isChecked()
        try:
            data = self._run_modal(
                "Sezioni ISTAT 2021…",
                lambda task: istat.fetch(indicators=ind,
                                         progress=task.setProgress,
                                         is_canceled=task.isCanceled,
                                         **kwargs))
        except Exception as exc:
            self._ist_cache_refresh()
            self._ist_status("Dati ISTAT non scaricati: %s" % exc,
                             error=True)
            return
        self._ist_cache_refresh()
        if data is None:
            self._ist_status("Download annullato.")
            return
        if not data["rows"]:
            self._ist_status("Nessuna sezione di censimento nell'area.",
                             error=True)
            return
        theme = self.istTheme.currentData()
        layer = istat.build_layer(data, "ISTAT 2021 – %s" % name, theme)
        note = ""
        if not istat.theme_available(layer, theme):
            istat.apply_theme(layer, "dens")
            note = (" ⚠️ Il tema «%s» richiede gli indicatori demografici: "
                    "sezioni colorate per densità." % self.istTheme
                    .currentText())
        # con l'inquadratura la vista resta com'è: zoomare sulle sezioni
        # (intere, quindi più larghe) allargherebbe l'area del lancio dopo
        layer = self._add_output(layer, zoom="rect" not in kwargs)
        self._ist_layer_id = layer.id()
        rows = istat.summary(data)
        self._ist_rows = rows
        t = self.istTable
        t.setRowCount(len(rows))
        for r, (k, v) in enumerate(rows):
            t.setItem(r, 0, QTableWidgetItem(k))
            it = QTableWidgetItem(v)
            it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            t.setItem(r, 1, it)
        t.setVisible(True)
        self.istCopy.setVisible(True)
        t.resizeRowsToContents()
        t.setFixedHeight(t.horizontalHeader().height() + 4 + sum(
            t.rowHeight(r) for r in range(len(rows))))
        tot = istat.totals(data)
        msg = "«%s»: %s sezioni, %s residenti%s." % (
            layer.name(), istat.fmt(tot["_sections"]),
            istat.fmt(tot["POP21"]),
            " nell'area" if partial else "")
        if partial:
            msg += (" Le sezioni a cavallo del confine sono intere nel "
                    "layer; nel riepilogo contano per la parte dentro "
                    "l'area (campo QUOTA).")
        msg += "\nFonte: %s." % istat.SOURCE
        msg += note
        for x in data["notes"]:
            msg += " ⚠️ %s." % (x[0].upper() + x[1:])
        self._ist_status(msg)

    def _ist_theme_changed(self, *_a):
        """Ricolora l'ultimo layer di sezioni caricato, senza riscaricare."""
        lay = QgsProject.instance().mapLayer(self._ist_layer_id) \
            if self._ist_layer_id else None
        if lay is None:
            return
        key = self.istTheme.currentData()
        if not istat.theme_available(lay, key):
            self._ist_status("Il tema «%s» richiede gli indicatori "
                             "demografici: ricarica le sezioni con la "
                             "casella spuntata." % self.istTheme
                             .currentText(), error=True)
            return
        istat.apply_theme(lay, key)
        lay.triggerRepaint()
        try:
            self.iface.layerTreeView().refreshLayerSymbology(lay.id())
        except Exception:
            pass
        self._ist_status("«%s» colorato per: %s." % (
            lay.name(), self.istTheme.currentText()))

    def _ist_copy(self):
        rows = getattr(self, "_ist_rows", None) or []
        QApplication.clipboard().setText(
            "\n".join("%s\t%s" % (k, v) for k, v in rows))
        self._ist_status("Riepilogo copiato negli appunti.")

    def _jobs_status(self, text, error=False):
        self._paint_status(self.jobsStatus, text, error)

    def _jobs_run(self):
        """Addetti 2011 dell'area scelta nella scheda ISTAT: layer delle
        sezioni 2011, riepilogo e confronto con il dato comunale recente."""
        try:
            kwargs, name, partial = self._ist_area()
        except ValueError as exc:
            self._jobs_status(str(exc), error=True)
            return
        if "pro_com" not in kwargs:
            if "rect" in kwargs:
                box = kwargs["rect"]
            else:
                bb = QgsGeometry.fromWkt(kwargs["wkt"]).boundingBox()
                box = (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(),
                       bb.yMaximum())
            regs = istat.regions_for_bbox(*box)
            if not regs:
                self._jobs_status("L'area non è in Italia: i dati ISTAT "
                                  "coprono solo il territorio italiano.",
                                  error=True)
                return
            if len(regs) > 2 and QMessageBox.question(
                    self, "Area ampia", "L'area tocca %d regioni (%s): si "
                    "scaricano i dati di tutte.\n\nContinuare?" % (
                        len(regs), ", ".join(istat.REGIONS[c]
                                             for c in regs))
                    ) != QMessageBox.Yes:
                return
        try:
            data = self._run_modal(
                "Addetti ISTAT 2011…",
                lambda task: addetti.fetch(progress=task.setProgress,
                                           is_canceled=task.isCanceled,
                                           **kwargs))
        except Exception as exc:
            self._ist_cache_refresh()
            self._jobs_status("Addetti ISTAT non scaricati: %s" % exc,
                              error=True)
            return
        self._ist_cache_refresh()
        if data is None:
            self._jobs_status("Download annullato.")
            return
        if not data["rows"]:
            self._jobs_status("Nessuna sezione di censimento 2011 "
                              "nell'area.", error=True)
            return
        # confronto con il dato comunale recente: il comune scelto o
        # quello con più addetti nell'area (solo se il codice c'è ancora)
        main = kwargs.get("pro_com") or addetti.main_comune(data)
        cmp_note = ""
        recent_data = None
        c = istat._comuni_index().get(main) if main else None
        if c is not None:
            def _recent(task):
                t11 = addetti.totals(data) if "pro_com" in kwargs else \
                    addetti.totals(addetti.fetch(pro_com=main))
                rc = addetti.recent([main], task.setProgress,
                                    task.isCanceled)
                return t11, rc
            try:
                got = self._run_modal("Dati comunali recenti ISTAT "
                                      "(la prima volta anche un minuto)…",
                                      _recent)
            except Exception as exc:
                got = None
                cmp_note = (" ⚠️ Confronto con il dato comunale recente "
                            "non disponibile (%s)." % exc)
            if got is not None:
                recent_data = (c["nome"], got[0], got[1].get(main))
        tot = addetti.totals(data)
        theme = self.jobsTheme.currentData()
        layer = addetti.build_layer(
            data, "ISTAT 2011 – addetti – %s" % name, theme)
        layer = self._add_output(layer, zoom="rect" not in kwargs)
        self._jobs_layer_id = layer.id()
        rows = addetti.summary(data, area_report.fmt, recent_data)
        t = self.jobsTable
        t.setRowCount(len(rows))
        for r, (k, v) in enumerate(rows):
            t.setItem(r, 0, QTableWidgetItem(k))
            it = QTableWidgetItem(v)
            it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            t.setItem(r, 1, it)
        t.setVisible(True)
        t.resizeRowsToContents()
        t.setFixedHeight(t.horizontalHeader().height() + 4 + sum(
            t.rowHeight(r) for r in range(len(rows))))
        fmt = area_report.fmt
        msg = ("«%s»: %s sezioni 2011, %s addetti%s (imprese %s, "
               "istituzioni pubbliche %s, non profit %s). Dato del "
               "censimento 2011, l'ultimo per sezione; le sezioni 2011 hanno "
               "confini diversi da quelle 2021." % (
                   layer.name(), fmt(tot["_sections"], 0),
                   fmt(tot["ADD_TOT"], 0), " nell'area" if partial else "",
                   fmt(tot["ADD_IM"], 0), fmt(tot["ADD_IP"], 0),
                   fmt(tot["ADD_NP"], 0)))
        if partial:
            msg += (" Le sezioni a cavallo del confine contano per la parte "
                    "dentro l'area (campo QUOTA).")
        if data.get("by_point"):
            msg += (" Il comune è cambiato dopo il 2011: sezioni scelte con "
                    "i confini attuali.")
        msg += "\nFonte: %s." % addetti.SOURCE
        if recent_data:
            msg += " Confronto: %s." % addetti.RECENT_SOURCE
        self._jobs_status(msg + cmp_note)

    def _jobs_theme_changed(self, *_a):
        """Ricolora l'ultimo layer degli addetti, senza riscaricare."""
        lay = QgsProject.instance().mapLayer(self._jobs_layer_id) \
            if self._jobs_layer_id else None
        if lay is None:
            return
        addetti.apply_theme(lay, self.jobsTheme.currentData())
        lay.triggerRepaint()
        try:
            self.iface.layerTreeView().refreshLayerSymbology(lay.id())
        except Exception:
            pass
        self._jobs_status("«%s» colorato per: %s." % (
            lay.name(), self.jobsTheme.currentText()))

    def _pend_status(self, text, error=False):
        self._paint_status(self.pendStatus, text, error)

    def _pend_run(self):
        """Flussi di pendolarismo di un comune: linee e comuni collegati."""
        c, err = istat.find_comune(self.pendComune.text())
        if c is None:
            self._pend_status(err, error=True)
            return
        self.pendComune.setText(istat.comune_label(c))
        kinds = pendolarismo.kinds_of(self.pendKind.currentData())
        try:
            fl = self._run_modal(
                "Pendolarismo ISTAT 2021…",
                lambda task: pendolarismo.flows(
                    c["pro_com"], kinds, task.setProgress, task.isCanceled))
        except Exception as exc:
            self._ist_cache_refresh()
            self._pend_status("Dati del pendolarismo non scaricati: %s"
                              % exc, error=True)
            return
        self._ist_cache_refresh()
        if fl is None:
            self._pend_status("Download annullato.")
            return
        direction = self.pendDir.currentData()
        flow_rows = pendolarismo.rows(fl, direction, self.pendMin.value(),
                                      self.pendTop.value())
        tot = pendolarismo.totals(fl)
        srows = pendolarismo.summary_rows(fl, area_report.fmt)
        t = self.pendTable
        t.setRowCount(len(srows))
        for r, (k, v) in enumerate(srows):
            t.setItem(r, 0, QTableWidgetItem(k))
            it = QTableWidgetItem(v)
            it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            t.setItem(r, 1, it)
        t.setVisible(True)
        t.resizeRowsToContents()
        t.setFixedHeight(t.horizontalHeader().height() + 4 + sum(
            t.rowHeight(r) for r in range(len(srows))))
        why = self.pendKind.currentText().lower()
        head = ("%s, pendolari per %s (2021): %s restano nel comune, %s "
                "escono verso %s comuni, %s entrano da %s comuni." % (
                    c["nome"], why, area_report.fmt(tot["internal"], 0),
                    area_report.fmt(tot["out"], 0),
                    area_report.fmt(tot["n_out"], 0),
                    area_report.fmt(tot["in"], 0),
                    area_report.fmt(tot["n_in"], 0)))
        if not flow_rows:
            self._pend_status(head + " ⚠️ Nessun flusso con almeno %d "
                              "persone: abbassa la soglia."
                              % self.pendMin.value())
            return
        name = "Pendolari 2021 – %s" % c["nome"]
        lines, missing = pendolarismo.build_lines(
            fl, flow_rows, name + " (flussi)", self.pendArc.isChecked())
        points = pendolarismo.build_points(fl, flow_rows,
                                           name + " (comuni)")
        self._add_output(lines)
        self._add_output(points, zoom=False)
        shown = sum(r[4] for r in flow_rows)
        base = sum(tot[k] for k in ("out", "in")
                   if direction in ("both", k)) or 1
        msg = head + ("\nDisegnati %s flussi con almeno %d persone: il "
                      "%s %% delle persone che si spostano fra comuni "
                      "(arancio in uscita, blu in entrata)." % (
                          area_report.fmt(len(flow_rows), 0),
                          self.pendMin.value(),
                          area_report.fmt(100.0 * shown / base, 0)))
        msg += "\nFonte: %s." % pendolarismo.SOURCE
        if missing:
            msg += " ⚠️ %d flussi senza posizione del comune." % missing
        self._pend_status(msg)

    def _ist_cache_refresh(self):
        info = istat.cache_info()
        pend = pendolarismo.cached_size()
        jobs = addetti.cached_size()
        if not info and not pend and not jobs:
            self.istCacheLabel.setText("Nessun dato ISTAT scaricato.")
            return
        parts = ["%s (%s MB%s)" % (
            name, istat.fmt(st["size"] / 1e6, 0),
            "" if st.get("indicators") else ", senza indicatori")
            for _c, name, st in info]
        if jobs:
            parts.append("addetti 2011 (%s MB)" % istat.fmt(jobs / 1e6, 0))
        if pend:
            parts.append("pendolarismo 2021 (%s MB)"
                         % istat.fmt(pend / 1e6, 1))
        self.istCacheLabel.setText("%s.\nIn tutto %s MB in %s" % (
            ", ".join(parts),
            istat.fmt((sum(st["size"] for _c, _n, st in info) + pend
                       + jobs) / 1e6, 0),
            istat.cache_dir()))

    def _ist_cache_open(self):
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(istat.cache_dir()))

    def _ist_cache_clear(self):
        if not istat.cache_info() and not pendolarismo.cached_size() \
                and not addetti.cached_size():
            self._ist_cache_refresh()
            return
        if QMessageBox.question(
                self, "Dati ISTAT", "Cancellare i dati ISTAT scaricati? I "
                "layer già caricati restano; i dati si riscaricano alla "
                "prossima richiesta.") != QMessageBox.Yes:
            return
        freed = istat.clear_cache()
        self._ist_cache_refresh()
        self._ist_status("Dati ISTAT cancellati: %s MB liberati."
                         % istat.fmt(freed / 1e6, 0))

    def _rep_mode_changed(self, *_a):
        mode = self.repAreaMode.currentData()
        for w in (self.repAreaLayer, self.repSelected, self.repNameField):
            w.setEnabled(mode == "layer")
        self.repDrawRow.setEnabled(mode == "draw")
        self.repDrawLabel.setEnabled(mode == "draw")
        if mode != "draw" and self.repDrawButton.isChecked():
            self.repDrawButton.setChecked(False)

    def _rep_pop_mode_changed(self, *_a):
        """Con i dati ISTAT il layer di popolazione non serve; senza, la
        pagina «Popolazione» non si può fare."""
        on = self.repIstat.isChecked()
        self.repPop.setEnabled(not on)
        self.repPopField.setEnabled(not on)
        secs = getattr(self, "repSections", None)
        if secs and "demo" in secs:
            secs["demo"].setEnabled(on)

    def _rep_style_changed(self, *_a):
        """Con OpenStreetMap i nomi delle vie sono già nello sfondo."""
        own = self.repStyle.currentData() != "osm"
        self.repLabels.setEnabled(own)
        self.repLabelSize.setEnabled(
            own and self.repLabels.currentData() != "nessuno")

    def _rep_preset_changed(self, *_a):
        v = self.repPreset.currentData()
        if v:
            self.repCell.blockSignals(True)
            self.repCell.setValue(int(v))
            self.repCell.blockSignals(False)

    def _rep_cell_changed(self, value):
        k = self.repPreset.findData(int(value))
        self.repPreset.blockSignals(True)
        self.repPreset.setCurrentIndex(k if k >= 0 else
                                       self.repPreset.findData(0))
        self.repPreset.blockSignals(False)

    def _rep_road_changed(self, layer):
        self.repTypeField.setLayer(layer)
        if layer is not None:
            low = {n.lower(): n for n in layer.fields().names()}
            for cand in ("highway", "tipo", "type", "fclass", "classe"):
                if cand in low:
                    self.repTypeField.setField(low[cand])
                    break

    def _rep_serv_changed(self, layer):
        self.repServCat.setLayer(layer)
        if layer is not None:
            names = layer.fields().names()
            for cand in ("categoria", "category", "tipo", "type"):
                if cand in names:
                    self.repServCat.setField(cand)
                    break

    def _rep_browse_gtfs(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.repGtfs.setText(path)

    def _rep_toggle_draw(self, on):
        canvas = self.iface.mapCanvas()
        if on:
            if self._rep_tool is None:
                self._rep_tool = map_tools.PolygonDrawTool(
                    canvas, self._rep_drawn,
                    lambda: self.repDrawButton.setChecked(False))
            self._rep_tool.clear()
            canvas.setMapTool(self._rep_tool)
            self._rep_status("Clicca i vertici dell'area; clic destro o "
                             "doppio clic per chiuderla.")
        elif self._rep_tool is not None and canvas.mapTool() is self._rep_tool:
            canvas.unsetMapTool(self._rep_tool)

    def _rep_drawn(self, geom):
        ct = QgsCoordinateTransform(
            self.iface.mapCanvas().mapSettings().destinationCrs(),
            isochrones.WGS84, QgsProject.instance().transformContext())
        g = QgsGeometry(geom)
        g.transform(ct)
        self._rep_geom = g
        km2 = analysis.geometry_area_m2(
            g, isochrones.WGS84, QgsProject.instance().transformContext()) / 1e6
        self.repDrawLabel.setText("area di %s km²" % area_report.fmt(km2, 2))
        self.repDrawButton.setChecked(False)
        if self._rep_tool is not None:
            self._rep_tool.show_geometry(geom)
        self._rep_status("Area disegnata (%s km²): premi «Crea report…»."
                         % area_report.fmt(km2, 2))

    def _rep_clear_draw(self):
        self._rep_geom = None
        self.repDrawLabel.setText("nessuna area disegnata")
        if self._rep_tool is not None:
            self._rep_tool.clear()

    def _rep_area(self):
        """(geometria WGS84, nome proposto) dell'area scelta.
        ValueError con il motivo se manca."""
        ctx = QgsProject.instance().transformContext()
        mode = self.repAreaMode.currentData()
        if mode == "draw":
            if self._rep_geom is None:
                raise ValueError("Disegna l'area sulla mappa (✏️ Disegna).")
            return QgsGeometry(self._rep_geom), ""
        if mode == "view":
            canvas = self.iface.mapCanvas()
            ct = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                        isochrones.WGS84, ctx)
            return (QgsGeometry.fromRect(ct.transformBoundingBox(
                canvas.extent())), "Area inquadrata")
        lay = self.repAreaLayer.currentLayer()
        if lay is None:
            raise ValueError("Scegli il layer di poligoni dell'area.")
        feats = (list(lay.selectedFeatures())
                 if self.repSelected.isChecked() and lay.selectedFeatureCount()
                 else list(lay.getFeatures()))
        ct = QgsCoordinateTransform(lay.crs(), isochrones.WGS84, ctx)
        geoms = []
        for f in feats:
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            geoms.append(g)
        if not geoms:
            raise ValueError("Il layer dell'area non ha poligoni.")
        name = lay.name()
        nf = self.repNameField.currentField()
        if nf and len(feats) == 1 and feats[0][nf] not in (None, ""):
            name = str(feats[0][nf])
        elif nf and len(feats) > 1:
            name = "%s (%d zone)" % (lay.name(), len(feats))
        geom = QgsGeometry.unaryUnion(geoms)
        if geom is None or geom.isEmpty():
            raise ValueError("Area non valida.")
        return geom, name

    def _rep_run(self):
        ctx = QgsProject.instance().transformContext()
        try:
            area, auto_name = self._rep_area()
        except ValueError as exc:
            self._rep_status(str(exc), error=True)
            return
        name = self.repName.text().strip() or auto_name or "Area"
        km2 = analysis.geometry_area_m2(area, isochrones.WGS84, ctx) / 1e6
        if km2 > 60 and QMessageBox.question(
                self, "Area ampia", "L'area è di %s km²: il calcolo e il "
                "download da OSM possono richiedere molti minuti.\n\n"
                "Continuare?" % area_report.fmt(km2, 0)) != QMessageBox.Yes:
            return
        try:
            times = sorted({float(x) for x in self.repTimes.text()
                            .replace(";", ",").split(",") if x.strip()})
        except ValueError:
            self._rep_status("Tempi delle isocrone non validi.", error=True)
            return
        try:
            dem = travel_ui.dem_spec(self.repDem.currentLayer(), ctx)
        except ValueError as exc:
            self._rep_status(str(exc), error=True)
            return
        safe = re.sub(r"[^\w\-]+", "_", name).strip("_") or "area"
        last = os.path.join(self._rep_last_dir(), "report_%s.pdf" % safe)
        pdf, _f = QFileDialog.getSaveFileName(self, "Salva il report",
                                              last, "PDF (*.pdf)")
        if not pdf:
            return
        if not pdf.lower().endswith(".pdf"):
            pdf += ".pdf"
        from qgis.core import QgsSettings
        QgsSettings().setValue(self._OUT_KEY + "report_dir",
                               os.path.dirname(pdf))
        sections = [k for k, cb in self.repSections.items() if cb.isChecked()]
        f15 = self.repF15.value()
        margin = area_report.margin_m(self.repWalk.value(), times, f15,
                                      dem is not None)
        bb = area.boundingBox()
        clip = net_iso.reach_bbox([(bb.yMinimum(), bb.xMinimum()),
                                   (bb.yMaximum(), bb.xMaximum())], margin)
        sources = []
        try:
            road = self.repRoad.currentLayer()
            if road is None:
                road = self._rep_osm_roads(clip, name)
                if road is None:
                    self._rep_status("Download annullato.")
                    return
                sources.append("Rete stradale e servizi: © OpenStreetMap "
                               "contributors (ODbL)")
            else:
                sources.append("Rete stradale: %s" % road.name())
            services, serv_src = self._rep_services(clip, sections)
            if services is None:
                self._rep_status("Download annullato.")
                return
            if serv_src and "OpenStreetMap" in serv_src and not any(
                    "OpenStreetMap" in x for x in sources):
                sources.append("Servizi: © OpenStreetMap contributors (ODbL)")
            elif serv_src and "OpenStreetMap" not in serv_src:
                sources.append("Servizi: %s" % serv_src)
        except Exception as exc:
            self._rep_status("Errore nella preparazione dei dati (rete, "
                             "servizi o download da OSM): %s" % exc,
                             error=True)
            return
        pop = None
        pop_note = ""
        pmode = "istat" if self.repIstat.isChecked() else "layer"
        QgsSettings().setValue(self._OUT_KEY + "report_istat",
                               self.repIstat.isChecked())
        pl = self.repPop.currentLayer()
        pf = self.repPopField.currentField()
        demo = None
        demo_skip = ""
        jobs = None
        if pmode == "istat":
            want_demo = "demo" in sections
            area_wkt = area.asWkt(8)
            try:
                got = self._run_modal(
                    "Dati ISTAT 2021…",
                    lambda task: istat.report_data(
                        clip, area_wkt, want_demo, task.setProgress,
                        task.isCanceled))
            except Exception as exc:
                pop_note = (" ⚠️ Dati ISTAT non disponibili (%s): report "
                            "senza popolazione." % exc)
                demo_skip = "dati ISTAT non disponibili"
            else:
                if got is None:
                    self._rep_status("Download annullato.")
                    return
                if got["pop"]:
                    pop = got["pop"]
                    sources.append("Popolazione: " + istat.SOURCE)
                elif not got["regions"]:
                    pop_note = (" ⚠️ L'area non è in Italia: niente dati "
                                "ISTAT (togli la spunta per usare un tuo "
                                "layer di abitanti).")
                else:
                    pop_note = (" ⚠️ Nessuna sezione ISTAT con residenti "
                                "nell'area.")
                demo, demo_skip = got["demo"], got["demo_skip"]
                for x in got["notes"]:
                    pop_note += " ⚠️ %s." % (x[0].upper() + x[1:])
                if want_demo and got["regions"]:
                    # addetti 2011 dell'area (per la sintesi e la pagina
                    # «Popolazione»): un errore non ferma il report
                    try:
                        jd = self._run_modal(
                            "Addetti ISTAT 2011…",
                            lambda task: addetti.fetch(
                                wkt=area_wkt, progress=task.setProgress,
                                is_canceled=task.isCanceled))
                    except Exception as exc:
                        pop_note += (" ⚠️ Addetti ISTAT 2011 non disponibili "
                                     "(%s)." % exc)
                    else:
                        if jd is None:
                            self._rep_status("Download annullato.")
                            return
                        if jd["rows"]:
                            jobs = addetti.report_totals(jd)
                            sources.append("Addetti: " + addetti.SOURCE)
        else:
            # la pagina «Popolazione» esiste solo con i dati ISTAT
            sections = [k for k in sections if k != "demo"]
            if pmode == "layer" and pl is not None and pf:
                pop = self._rep_pop(pl, pf, clip)
                sources.append("Popolazione: %s (campo %s)" % (pl.name(),
                                                               pf))
        gtfs = None
        if "tp" in sections:
            src = self.repGtfs.text().strip() or self._global_gtfs()
            if src:
                t0, t1 = self.repPtalFrom.time(), self.repPtalTo.time()
                gtfs = {"source": src, "service_date": self._service_date(),
                        "start_h": t0.hour() + t0.minute() / 60.0,
                        "end_h": t1.hour() + t1.minute() / 60.0}
                sources.append("Trasporto pubblico: GTFS %s"
                               % os.path.basename(src))
        if dem is not None:
            sources.append("DEM: %s" % dem["name"])
        tf = self.repTypeField.currentField() or None
        cfg = {"name": name, "area_wkt": area.asWkt(8), "ctx": ctx,
               "road": self._road_spec(road, ctx, False, clip, margin),
               "type_field": tf, "pop": pop, "services": services,
               "services_source": serv_src, "gtfs": gtfs, "dem": dem,
               "walk_kmh": self.repWalk.value(), "iso_times": times,
               "f15_min": f15, "cell_m": self.repCell.value(),
               "sections": sections, "demo": demo, "demo_skip": demo_skip,
               "jobs": jobs}
        try:
            res = self._run_modal("Report dell'area…",
                                  lambda task: area_report.compute(cfg, task))
        except Exception as exc:
            self._rep_status("Errore nel calcolo del report: %s" % exc,
                             error=True)
            return
        if res is None:
            self._rep_status("Calcolo annullato.")
            return
        style, base, style_note = self._rep_map_base(res, sources)
        if style is None:
            self._rep_status("Calcolo annullato.")
            return
        try:
            out = self._rep_outputs(res, pdf, sources, style, base)
        except Exception as exc:
            self._rep_status("Report calcolato ma non salvato: %s" % exc,
                             error=True)
            return
        msg = ("Report «%s» creato: %d pagine.\nPDF: %s\nExcel: %s\nLayer "
               "nel gruppo «%s» (spento); layout «%s» nel progetto, "
               "modificabile e riesportabile." % (
                   name, out["pages"], pdf, out["xlsx"], out["group"],
                   out["layout"]))
        msg += style_note + pop_note
        for k, v in res.get("skipped", {}).items():
            if k == "demo" and pop_note:
                continue   # il motivo è già nell'avviso sui dati ISTAT
            msg += " ⚠️ %s non calcolata: %s." % (
                area_report.SECTION_LABEL.get(k, k), v)
        for n in res.get("notes", []):
            msg += " ⚠️ " + n
        self._rep_status(msg)
        if self.repOpen.isChecked():
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl.fromLocalFile(pdf))

    def _rep_last_dir(self):
        from qgis.core import QgsSettings
        return QgsSettings().value(self._OUT_KEY + "report_dir", "") or \
            os.path.expanduser("~")

    def _rep_osm_roads(self, clip, name):
        """Rete OSM completa per il riquadro (con la cache), come layer."""
        w, s_, e, n = clip
        bbox = (s_, w, n, e)

        def _job(task):
            from .core import osm_cache
            c = osm_cache.get_cached("roads", bbox, "all")
            if c:
                return c["features"]
            ways = osm_download.fetch_ways(*bbox, mode="all",
                                           progress=task.setProgress,
                                           is_canceled=task.isCanceled)
            if ways:
                osm_cache.put_cached("roads", bbox, "all", ways)
            return ways
        ways = self._run_modal("Download della rete da OSM…", _job)
        if ways is None:
            return None
        if not ways:
            raise ValueError("nessuna strada OSM nell'area")
        return osm_download.build_roads_layer(
            ways, name="OSM - Rete (report %s)" % name)

    def _rep_services(self, clip, sections):
        """([(lat, lon, categoria)], fonte) dal layer scelto o da OSM;
        ([], "") se nessuna sezione li usa; (None, "") se annullato."""
        if not {"walk", "iso", "f15", "servizi"} & set(sections):
            return [], ""
        lay = self.repServ.currentLayer()
        if lay is not None:
            catf = self.repServCat.currentField()
            if not catf:
                raise ValueError("scegli il campo categoria dei servizi")
            ct = QgsCoordinateTransform(lay.crs(), isochrones.WGS84,
                                        QgsProject.instance()
                                        .transformContext())
            w, s_, e, n = clip
            out = []
            for f in lay.getFeatures():
                g = f.geometry()
                c = f[catf]
                if g is None or g.isEmpty() or c is None or \
                        str(c).strip() in ("", "NULL"):
                    continue
                g = QgsGeometry(g)
                g.transform(ct)
                pt = g.pointOnSurface().asPoint()
                if w <= pt.x() <= e and s_ <= pt.y() <= n:
                    out.append((pt.y(), pt.x(), str(c).strip()))
            return out, lay.name()
        w, s_, e, n = clip
        bbox = (s_, w, n, e)

        def _job(task):
            from .core import osm_cache
            c = osm_cache.get_cached("services", bbox, "all")
            if c:
                return [tuple(r) for r in c["features"]]
            rows = fifteen.fetch_services(*bbox, progress=task.setProgress,
                                          is_canceled=task.isCanceled)
            if rows:
                osm_cache.put_cached("services", bbox, "all", rows)
            return rows
        rows = self._run_modal("Download dei servizi da OSM…", _job)
        if rows is None:
            return None, ""
        return [(r[7], r[6], r[3]) for r in rows], "OpenStreetMap"

    @staticmethod
    def _rep_pop(layer, field, clip):
        """[(wkt WGS84, abitanti)] dei poligoni nel riquadro."""
        from qgis.core import QgsFeatureRequest
        ctx = QgsProject.instance().transformContext()
        to_l = QgsCoordinateTransform(isochrones.WGS84, layer.crs(), ctx)
        to_w = QgsCoordinateTransform(layer.crs(), isochrones.WGS84, ctx)
        req = QgsFeatureRequest().setFilterRect(
            to_l.transformBoundingBox(QgsRectangle(*clip)))
        out = []
        for f in layer.getFeatures(req):
            g = f.geometry()
            try:
                v = float(f[field])
            except (TypeError, ValueError):
                continue
            if g is None or g.isEmpty() or v <= 0:
                continue
            g = QgsGeometry(g)
            g.transform(to_w)
            out.append((g.asWkt(8), v))
        return out

    def _rep_map_base(self, res, sources):
        """Stile delle mappe da usare davvero e la sua base.

        La carta chiara scarica (o prende dalla cache) edifici, verde, acqua
        e ferrovie da OSM per il riquadro delle mappe; gli stili a
        piastrelle controllano che il server risponda. Se la base non c'è
        si ripiega sullo stile essenziale (sole strade di contesto), con un
        avviso.
        :return: (stile, base o None, avviso); (None, None, "") se
            annullato.
        """
        from . import report_layout
        from qgis.core import QgsSettings
        style = self.repStyle.currentData() or "chiara"
        st = QgsSettings()
        st.setValue(self._OUT_KEY + "report_style", style)
        st.setValue(self._OUT_KEY + "report_labels",
                    self.repLabels.currentData())
        st.setValue(self._OUT_KEY + "report_label_size",
                    self.repLabelSize.currentData())
        label = dict(report_layout.MAP_STYLES).get(style, style)
        base = None
        try:
            if style == "chiara":
                bb = QgsGeometry.fromWkt(res["area_wkt"]).boundingBox()
                for b in (res.get("iso") or {}).get("bands", []):
                    bb.combineExtentWith(
                        QgsGeometry.fromWkt(b["wkt"]).boundingBox())
                dx, dy = 0.2 * bb.width(), 0.2 * bb.height()
                bbox = (bb.yMinimum() - dy, bb.xMinimum() - dx,
                        bb.yMaximum() + dy, bb.xMaximum() + dx)
                out = self._run_modal(
                    "Base delle mappe da OSM…",
                    lambda task: osm_basemap.cached_base(
                        bbox, task.setProgress, task.isCanceled))
                if out is None or out[0] is None:
                    return None, None, ""
                base = out[0]
                note = ""
                if not base.get("buildings", True):
                    note = (" Area ampia: la base delle mappe è senza "
                            "edifici.")
            else:
                ok = self._run_modal(
                    "Controllo dello sfondo delle mappe…",
                    lambda task: (osm_basemap.tiles_reachable(style),))
                if ok is None:
                    return None, None, ""
                if not ok[0]:
                    raise RuntimeError("il server dello sfondo non risponde "
                                       "(serve internet)")
                note = ""
        except Exception as exc:
            return "essenziale", None, (
                " ⚠️ Stile «%s» non disponibile (%s): mappe con le sole "
                "strade di contesto." % (label, exc))
        src = report_layout.MAP_SOURCE.get(style)
        if src and not any("OpenStreetMap" in x for x in sources) or (
                src and style == "satellite"):
            sources.append(src)
        return style, base, note

    def _rep_outputs(self, res, pdf, sources, style="essenziale",
                     base_data=None):
        """Layer (in un GeoPackage accanto al PDF), layout nel progetto,
        PDF ed Excel."""
        from . import report_layout
        from .core import report_excel
        from qgis.core import (QgsMapLayerStyle, QgsVectorFileWriter,
                               QgsVectorLayer)
        proj = QgsProject.instance()
        base = os.path.splitext(pdf)[0]
        gpkg = base + "_dati.gpkg"
        layers = report_layout.build_layers(
            res, style, base_data, self.repLabelSize.currentData() or "medi")
        root = proj.layerTreeRoot()
        gname = "Report – %s" % res["name"]
        # un report rifatto con lo stesso nome sostituisce il precedente:
        # via il gruppo con i suoi layer (anche lo sfondo a piastrelle)
        old = root.findGroup(gname)
        if old is not None:
            ids = [n.layerId() for n in old.findLayers()]
            root.removeChildNode(old)
            proj.removeMapLayers(ids)
        for lid, lay in list(proj.mapLayers().items()):
            if lay.source().replace("\\", "/").split("|")[0].lower() == \
                    gpkg.replace("\\", "/").lower():
                proj.removeMapLayer(lid)
        if os.path.exists(gpkg):
            try:
                os.remove(gpkg)
            except OSError:
                pass
        saved = {}
        first = not os.path.exists(gpkg)
        for key, lay in layers.items():
            if not isinstance(lay, QgsVectorLayer):
                saved[key] = lay   # sfondo a piastrelle: resta com'è
                continue
            opts = QgsVectorFileWriter.SaveVectorOptions()
            opts.driverName = "GPKG"
            opts.fileEncoding = "UTF-8"
            opts.layerName = key
            opts.actionOnExistingFile = (
                QgsVectorFileWriter.CreateOrOverwriteFile if first
                else QgsVectorFileWriter.CreateOrOverwriteLayer)
            r = QgsVectorFileWriter.writeAsVectorFormatV3(
                lay, gpkg, proj.transformContext(), opts)
            if r[0] != QgsVectorFileWriter.NoError:
                saved[key] = lay   # resta in memoria
                continue
            first = False
            sl = QgsVectorLayer("%s|layername=%s" % (gpkg, key), lay.name(),
                                "ogr")
            if not sl.isValid():
                saved[key] = lay
                continue
            st = QgsMapLayerStyle()
            st.readFromLayer(lay)
            st.writeToLayer(sl)
            saved[key] = sl
        grp = root.insertGroup(0, gname)
        order = ["centro", "fermate", "servizi", "area", "maschera",
                 "b_labels_all", "b_labels_main", "rete", "contesto", "iso",
                 "f15", "ptal", "walk", "demo", "b_roads", "b_rail",
                 "b_build",
                 "b_waterl", "b_water", "b_green", "tiles"]
        for key in order + [k for k in saved if k not in order]:
            if key in saved:
                proj.addMapLayer(saved[key], False)
                grp.addLayer(saved[key])
        grp.setItemVisibilityChecked(False)
        grp.setExpanded(False)
        meta = report_layout.report_meta(res, self._plugin_version(),
                                         sources)
        logo = os.path.join(os.path.dirname(__file__), "icon.svg")
        builder = report_layout.ReportBuilder(
            proj, res, saved, meta, logo, style,
            self.repLabels.currentData() or "auto")
        layout = builder.build()
        lm = proj.layoutManager()
        prev = lm.layoutByName(layout.name())
        if prev is not None:
            lm.removeLayout(prev)
        lm.addLayout(layout)
        ok, err = report_layout.export_pdf(layout, pdf)
        if not ok:
            raise ValueError("PDF non creato (%s): il file è aperto in un "
                             "lettore PDF?" % err)
        xlsx = base + ".xlsx"
        report_excel.write(xlsx, res, [
            ("Area", res["name"]), ("Generato il", meta["date"]),
            ("Versione", "MIC - Utilities %s" % meta["version"])]
            + [("Fonte", x) for x in sources])
        return {"pages": layout.pageCollection().pageCount(), "xlsx": xlsx,
                "group": gname, "layout": layout.name()}

    @staticmethod
    def _plugin_version():
        try:
            from . import updater
            return updater.installed_version()
        except Exception:
            return ""

    # ----------------------------------------------------------- Percorsi
    def _rt_status(self, text, error=False):
        self._paint_status(self.rtStatus, text, error)

    def _rt_toggle_pick(self, on):
        canvas = self.iface.mapCanvas()
        if on:
            if self._rt_tool is None:
                self._rt_tool = QgsMapToolEmitPoint(canvas)
                self._rt_tool.canvasClicked.connect(self._rt_on_click)
            canvas.setMapTool(self._rt_tool)
            self._rt_status("Clicca sulla mappa i punti, nell'ordine.")
        elif self._rt_tool is not None:
            canvas.unsetMapTool(self._rt_tool)

    def _rt_on_click(self, point, button):
        ct = QgsCoordinateTransform(
            self.iface.mapCanvas().mapSettings().destinationCrs(),
            isochrones.WGS84, QgsProject.instance().transformContext())
        g = QgsGeometry.fromPointXY(point)
        g.transform(ct)
        p = g.asPoint()
        self._rt_picked.append((p.y(), p.x()))
        self.rtPickLabel.setText("%d punti" % len(self._rt_picked))

    def _rt_clear_pick(self):
        self._rt_picked = []
        self.rtPickLabel.setText("0 punti")

    def _rt_points(self):
        """Punti (lat, lon) nell'ordine: cliccati, altrimenti dal layer
        (campo ordine se indicato, altrimenti ordine delle feature)."""
        if self._rt_picked:
            return list(self._rt_picked)
        layer = self.rtPointsCombo.currentLayer()
        if layer is None:
            return []
        of = self.rtOrderField.currentField() or None
        ct = QgsCoordinateTransform(layer.crs(), isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        rows = []
        for k, f in enumerate(layer.getFeatures()):
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            p = g.centroid().asPoint()
            key = k
            if of:
                try:
                    key = float(f[of])
                except (TypeError, ValueError):
                    key = float("inf")
            rows.append((key, k, (p.y(), p.x())))
        rows.sort(key=lambda r: (r[0], r[1]))
        return [r[2] for r in rows]

    def _rt_run(self):
        road = self.rtRoadCombo.currentLayer()
        if road is None:
            self._rt_status("Seleziona la rete stradale.", error=True)
            return
        pts = self._rt_points()
        if len(pts) < 2:
            self._rt_status("Servono almeno due punti (layer o clic sulla "
                            "mappa).", error=True)
            return
        pairs = self.rtPairs.currentData()
        if pairs == "all" and len(pts) > 60:
            self._rt_status("Con «Tutte le coppie» al massimo 60 punti "
                            "(%d indicati)." % len(pts), error=True)
            return
        mode = self.rtModeCombo.currentData()
        ctx = QgsProject.instance().transformContext()
        source = QgsVectorLayerFeatureSource(road)
        ct = QgsCoordinateTransform(road.crs(), isochrones.WGS84, ctx)
        speed_of = routing.speed_reader(
            road.fields().names(), self.rtSpeedField.currentField() or None,
            float(self.rtDefSpeed.value()), self.rtFactor.value() / 100.0,
            walk_only_ways=(mode == "shortest"))
        oneway = self.rtOneway.isChecked()

        def _job(task):
            roads, dirs, speeds = routing.read_roads_for_routing(
                source.getFeatures(), ct, oneway, speed_of,
                cars_only=(mode == "fastest"), is_canceled=task.isCanceled)
            task.setProgress(20)
            return routing.compute_routes(
                roads, pts, mode, pairs, directions=dirs, speeds=speeds,
                progress=lambda p: task.setProgress(20 + 0.8 * p),
                is_canceled=task.isCanceled)
        try:
            legs = self._run_modal("Calcolo dei percorsi…", _job)
        except Exception as exc:
            self._rt_status(f"Errore percorsi: {exc}", error=True)
            return
        if legs is None:
            self._rt_status("Calcolo annullato.")
            return
        label = self.rtModeCombo.currentText()
        layer = net_layers.build_routes_layer(legs, label)
        layer = self._add_output(layer)
        ok = [g for g in legs if g["ok"]]
        msg = "%d percorsi su %d" % (len(ok), len(legs))
        if ok and pairs == "sequence":
            tot_m = sum(g["length_m"] for g in ok)
            tt = [g["time_s"] for g in ok if g["time_s"] is not None]
            msg += (": totale %.2f km" % (tot_m / 1000.0)
                    + (", %.1f min" % (sum(tt) / 60.0) if tt else ""))
        bad = [g for g in legs if not g["ok"]]
        if bad:
            msg += ". ⚠️ %s → %s: %s" % (bad[0]["da"], bad[0]["a"],
                                          bad[0]["msg"])
        self._rt_status(msg + ".", error=not ok)

    # ---------------------------------------------------- Isocrone avanzate
    def _isoa_toggle_pick(self, on):
        canvas = self.iface.mapCanvas()
        if on:
            if self._isoa_tool is None:
                self._isoa_tool = QgsMapToolEmitPoint(canvas)
                self._isoa_tool.canvasClicked.connect(self._isoa_on_click)
            canvas.setMapTool(self._isoa_tool)
            self._isoa_status("Clicca sulla mappa per aggiungere punti.")
        elif self._isoa_tool is not None:
            canvas.unsetMapTool(self._isoa_tool)

    def _isoa_on_click(self, point, button):
        from qgis.core import QgsCoordinateTransform
        ct = QgsCoordinateTransform(
            self.iface.mapCanvas().mapSettings().destinationCrs(),
            isochrones.WGS84, QgsProject.instance().transformContext())
        g = QgsGeometry.fromPointXY(point)
        g.transform(ct)
        p = g.asPoint()
        if self.isoaInteractive.isChecked():
            self._isoa_interactive_run((p.y(), p.x()))
            return
        self._isoa_picked.append((p.y(), p.x()))
        self.isoaPickLabel.setText("%d punti" % len(self._isoa_picked))

    def _isoa_clear_pick(self):
        self._isoa_picked = []
        self.isoaPickLabel.setText("0 punti")

    def _isoa_interactive_toggled(self, on):
        if on:
            self.isoaPickButton.setChecked(True)  # attiva lo strumento click
            self._isoa_status("Modalità interattiva attiva: clicca sulla mappa "
                              "(serve una rete stradale selezionata).")

    # ------------------------------------------- avanzamento e annullamento
    def _isoa_track(self, task):
        """Mostra la barra di avanzamento del task (fase + %) e Annulla."""
        self._isoa_task = task
        self.isoaProgress.setValue(0)
        self.isoaProgress.setFormat("%p% · avvio")
        self.isoaProgressRow.setVisible(True)
        self.isoaCancel.setEnabled(True)

        def on_progress(p, t=task):
            if self._isoa_task is t:
                self.isoaProgress.setValue(int(p))
                self.isoaProgress.setFormat(
                    "%p% · " + getattr(t, "phase", "calcolo"))

        task.progressChanged.connect(on_progress)

    def _isoa_untrack(self, task):
        """Nasconde la barra se il task concluso è quello mostrato."""
        if self._isoa_task is task:
            self._isoa_task = None
            self.isoaProgressRow.setVisible(False)

    def _isoa_cancel(self):
        task = getattr(self, "_isoa_task", None)
        if task is not None:
            self.isoaCancel.setEnabled(False)
            self.isoaProgress.setFormat("%p% · annullamento…")
            task.cancel()

    def _isoa_interactive_run(self, latlon):
        """Isocrona al click: calcolo in background (prima il blocco della GUI
        durava finché il calcolo non finiva, anche minuti su reti grandi).
        Un click durante un calcolo annulla il precedente: vale l'ultimo."""
        if self.isoaModeCombo.currentData() == "pt":
            self._isoa_status("La modalità interattiva è solo per il modo rete.",
                              error=True)
            return
        road = self.isoaRoadCombo.currentLayer()
        if road is None:
            self._isoa_status("Seleziona una rete stradale.", error=True)
            return
        try:
            times = [float(x) for x in self.isoaTimes.text().replace(";", ",")
                     .split(",") if x.strip()]
        except ValueError:
            self._isoa_status("Tempi non validi.", error=True)
            return
        if not times:
            return
        prev = getattr(self, "_isoa_task", None)
        if prev is not None:
            prev.cancel()
        ctx = QgsProject.instance().transformContext()
        try:
            cost, vmax, _note, cost_key = self._isoa_cost(road, ctx)
        except ValueError as exc:
            self._isoa_status(str(exc), error=True)
            return
        key = (road.id(), self.isoaOneway.isChecked(), cost_key)
        radius = net_iso.reach_radius_m(vmax, times)
        need = net_iso.reach_bbox([latlon], radius)
        params = {"sources": [latlon], "speed": self.isoaSpeed.value(),
                  "times": times,
                  "geom": {"output_mode": self.isoaOutput.currentData(),
                           "access_m": self.isoaAccess.value(),
                           "dissolve": True, "ctx": ctx}}
        cached = getattr(self, "_iso_roads_cache", None)
        if (getattr(self, "_iso_roads_key", None) == key and cached
                and net_iso.bbox_contains(cached[2], need)):
            # rete già letta e pulita da un click precedente, area coperta
            params["roads"], params["directions"] = cached[0], cached[1]
            params["edge_costs"], params["cost_stats"] = cached[3], cached[4]
            clip = None
        else:
            # si legge un'area doppia: i click vicini riusano la cache
            clip = net_iso.reach_bbox([latlon], 2.0 * radius)
            params["road"] = self._road_spec(
                road, ctx, self.isoaOneway.isChecked(), clip, radius)
            params["cost"] = cost
        task = GtfsIsoTask("net", params)
        task.taskCompleted.connect(
            lambda t=task, k=key, c=clip: self._isoa_interactive_done(t, k, c))
        task.taskTerminated.connect(lambda t=task: self._isoa_failed(t))
        self._isoa_track(task)
        self._isoa_status("Isocrona interattiva in calcolo…")
        QgsApplication.taskManager().addTask(task)

    def _isoa_interactive_done(self, task, key, clip=None):
        self._isoa_untrack(task)
        if task.roads is not None and clip is not None:
            self._iso_roads_key = key
            self._iso_roads_cache = (task.roads, task.directions, clip,
                                     task.edge_costs, task.cost_stats)
        if not task.n_snapped:
            self._isoa_status("Sorgente non agganciata alla rete entro 500 m "
                              "(o componente isolata).", error=True)
            return
        layer = isochrones.layer_from_band_geoms(
            task.geoms or [], self.isoaSpeed.value(), "interattivo",
            self.isoaOutput.currentData(), name="MIC - Isocrona interattiva")
        # rimpiazza il layer interattivo precedente
        old = getattr(self, "_isoa_interactive_id", None)
        if old and QgsProject.instance().mapLayer(old) is not None:
            QgsProject.instance().removeMapLayer(old)
        layer = self._add_output(layer, zoom=False, save=False)
        self._isoa_interactive_id = layer.id()
        self._isoa_status("Isocrona interattiva aggiornata (%d fasce)."
                          % layer.featureCount())

    def _isoa_run(self):
        from qgis.core import QgsCoordinateTransform
        ctx = QgsProject.instance().transformContext()
        is_pt = (self.isoaModeCombo.currentData() == "pt")
        # sorgenti (priorità: punti scelti in mappa > fermate GTFS > layer)
        coords = []
        src_label = ""
        if self._isoa_picked:
            coords = list(self._isoa_picked)
            src_label = ("sorgenti = %d punti scelti sulla mappa (Cancella per "
                         "usare il layer). " % len(coords))
        elif self.isoaUseGtfs.isChecked() and self._gtfs:
            sm = self._gtfs["stops"]
            ids = set()
            for s in self._gtfs["segments"].values():
                ids.add(s["from_stop"])
                ids.add(s["to_stop"])
            coords = [(sm[i][0], sm[i][1]) for i in ids
                      if sm.get(i) and sm[i][0] is not None]
            src_label = "sorgenti = %d fermate GTFS. " % len(coords)
        else:
            pts = self.isoaSourceCombo.currentLayer()
            if pts is not None:
                ct = QgsCoordinateTransform(pts.crs(), isochrones.WGS84, ctx)
                for f in pts.getFeatures():
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    g = QgsGeometry(g)
                    g.transform(ct)
                    # MultiPoint: ogni parte è una sorgente
                    for p in (g.asMultiPoint() if g.isMultipart()
                              else [g.asPoint()]):
                        coords.append((p.y(), p.x()))
        if not coords:
            self._isoa_status("Nessuna sorgente (layer/mappa/fermate GTFS).",
                              error=True)
            return
        try:
            times = [float(x) for x in self.isoaTimes.text().replace(";", ",")
                     .split(",") if x.strip()]
        except ValueError:
            self._isoa_status("Tempi non validi.", error=True)
            return
        if not times:
            self._isoa_status("Indica almeno un tempo.", error=True)
            return

        # geometrie (buffer/unione, la parte pesante) calcolate nel task
        geom = {"output_mode": self.isoaOutput.currentData(),
                "access_m": self.isoaAccess.value(),
                "dissolve": self.isoaDissolve.isChecked(), "ctx": ctx}
        pre_msg = src_label
        egr_r = 800.0
        pt_label = ""
        if is_pt:
            source_path = (self.isoaGtfsEdit.text().strip()
                           or self.gtfsSourceEdit.text().strip())
            if not source_path:
                self._isoa_status("Per il TP indica un feed GTFS.", error=True)
                return
            acc_speed, acc_r = self._pt_leg_params(self.isoaAccessMode)
            egr_speed, egr_r = self._pt_leg_params(self.isoaEgressMode)
            # rete pedonale opzionale: accesso alle fermate ed egress lungo le
            # strade (letta e pulita nel task)
            road = self.isoaRoadCombo.currentLayer()
            egress = self._road_spec(road, ctx) if road is not None else None
            t0 = self.isoaStartH.time()
            window = self.isoaWindow.value()
            pre_msg += ("accesso ed egress lungo la rete. " if egress
                        else "accesso ed egress in linea d'aria. ")
            if window:
                pre_msg += ("partenze %s–%s ogni 5 min, tempi mediani. "
                            % (t0.toString("HH:mm"),
                               t0.addSecs(window * 60).toString("HH:mm")))
            task = GtfsIsoTask("pt", {
                "sources": coords, "times": times, "source_path": source_path,
                "start_h": t0.hour() + t0.minute() / 60.0,
                "window_min": window, "step_min": 5,
                "divide_lines": self.isoaDivideLines.isChecked(),
                "walk_speed": self.isoaSpeed.value(),
                "transfer_m": 200.0, "max_access_m": acc_r,
                "access_speed": acc_speed, "egress_speed": egr_speed,
                "transfer_penalty_s": self.isoaTransferPen.value() * 60.0,
                "service_date": self._service_date(),
                "egress_road": egress, "egress_r": egr_r,
                # l'egress TP è sempre dissolto (unione per fascia); senza
                # rete i bacini sono cerchi, uniti anch'essi nel task
                "geom": (dict(geom, dissolve=True) if egress
                         else dict(geom, dissolve=True,
                                   output_mode="concave"))})
            pt_label = "TP+rete" if egress else "TP"
        else:
            road = self.isoaRoadCombo.currentLayer()
            if road is None:
                self._isoa_status("Per la rete indica un layer stradale.",
                                  error=True)
                return
            try:
                cost, vmax, cost_note, _k = self._isoa_cost(road, ctx)
            except ValueError as exc:
                self._isoa_status(str(exc), error=True)
                return
            pre_msg += cost_note
            # lettura (solo il riquadro raggiungibile), pulizia, validazione
            # e controllo di aggancio nel task: su reti grandi richiedono
            # secondi e bloccherebbero QGIS
            radius = net_iso.reach_radius_m(vmax, times)
            task = GtfsIsoTask("net", {
                "road": self._road_spec(
                    road, ctx, self.isoaOneway.isChecked(),
                    net_iso.reach_bbox(coords, radius), radius),
                "sources": coords, "speed": self.isoaSpeed.value(),
                "times": times, "geom": geom, "cost": cost})

        prev = getattr(self, "_isoa_task", None)
        if prev is not None:
            prev.cancel()
        mode_label = self.isoaModeCombo.currentText()
        if not is_pt and task.params.get("cost"):
            mode_label += (" (limiti per strada)" if self._isoa_kind() == "car"
                           else " (pendenza DEM)")
        self._isoa_cfg = {
            "is_pt": is_pt, "speed": self.isoaSpeed.value(),
            "mode_label": mode_label,
            "output_mode": self.isoaOutput.currentData(),
            "access_m": self.isoaAccess.value(),
            "dissolve": self.isoaDissolve.isChecked(),
            "times": times, "sources": coords,
            "max_access_m": egr_r, "pre_msg": pre_msg, "pt_label": pt_label}
        task.taskCompleted.connect(lambda t=task: self._isoa_done(t))
        task.taskTerminated.connect(lambda t=task: self._isoa_failed(t))
        self._isoa_track(task)
        self.isoaRunButton.setEnabled(False)
        self._isoa_status("%sCalcolo in background: puoi continuare a usare "
                          "QGIS." % pre_msg)
        QgsApplication.taskManager().addTask(task)

    def _isoa_done(self, task):
        self._isoa_untrack(task)
        self.isoaRunButton.setEnabled(True)
        cfg = self._isoa_cfg
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # geometrie già calcolate nel task: qui solo la creazione del layer
            if cfg["is_pt"]:
                name = ("Isocrona TP" if cfg["pt_label"] == "TP"
                        else "Isocrone (rete)")
                if task.n_lines:
                    name = "Isocrone TP per linea"
                layer = isochrones.layer_from_band_geoms(
                    task.geoms or [], 0.0, cfg["pt_label"],
                    cfg["output_mode"] if cfg["pt_label"] == "TP+rete"
                    else "concave", name=name)
            else:
                layer = isochrones.layer_from_band_geoms(
                    task.geoms or [], cfg["speed"], cfg["mode_label"],
                    cfg["output_mode"])
        except Exception as exc:
            self._isoa_status(f"Errore costruzione layer: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        n_feat = layer.featureCount()
        if n_feat == 0:
            n_snap = getattr(task, "n_snapped", None)
            if not cfg["is_pt"] and n_snap == 0:
                self._isoa_status(
                    "Nessuna sorgente aggancia la rete entro 500 m: avvicina i "
                    "punti alle strade o scarica la rete con 'Rete da OSM'.",
                    error=True)
            else:
                self._isoa_status(
                    "Nessuna isocrona generata: aumenta i tempi/velocità o "
                    "verifica la rete stradale.", error=True)
            return
        poi_msg = ""
        poi = self.isoaPoiCombo.currentLayer()
        from qgis.core import QgsWkbTypes
        if poi is not None and layer.geometryType() == QgsWkbTypes.PolygonGeometry:
            try:
                opportunities.count_in_polygons(
                    layer, poi, self.isoaPoiWeight.currentField() or None,
                    QgsProject.instance().transformContext())
                # per fascia: le fasce sono annidate (15 min contiene 5 min),
                # quindi un totale su tutte le fasce conterebbe più volte
                by_t = {}
                for f in layer.getFeatures():
                    n, w = by_t.get(f["time_min"], (0, 0.0))
                    by_t[f["time_min"]] = (n + (f["n_poi"] or 0),
                                           w + (f["peso_poi"] or 0.0))
                poi_msg = " · opportunità per fascia: " + ", ".join(
                    "%g min %d (peso %.0f)" % (t, n, w)
                    for t, (n, w) in sorted(by_t.items()))
                if (not cfg["is_pt"] and not cfg["dissolve"]
                        and len(cfg["sources"]) > 1):
                    poi_msg += " (somma sulle sorgenti)"
                elif task.n_lines > 1:
                    poi_msg += " (somma sulle linee: vedi n_poi per linea)"
            except Exception as exc:
                poi_msg = " · conteggio POI non riuscito: %s" % exc
        layer = self._add_output(layer)
        extra = ""
        if not cfg["is_pt"] and getattr(task, "n_snapped", None) is not None:
            extra = " (%d/%d sorgenti agganciate)" % (
                task.n_snapped, len(cfg["sources"]))
        if cfg["is_pt"]:
            extra = " (%s%s)" % (
                task.selection,
                ", %d linee" % task.n_lines if task.n_lines else "")
        self._isoa_status("%sIsocrone create: %d sorgenti, %d geometrie.%s%s%s"
                          % (cfg.get("pre_msg", "") + task.pre_msg,
                             len(cfg["sources"]), n_feat, extra, poi_msg,
                             self._cost_note(task.cost_stats)))

    def _isoa_failed(self, task):
        current = self._isoa_task is task
        self._isoa_untrack(task)
        self.isoaRunButton.setEnabled(True)
        if not current:
            return  # sostituito da un calcolo più recente (es. nuovo click)
        if getattr(task, "cancelled", False) or task.isCanceled():
            self._isoa_status("Calcolo annullato.")
        else:
            self._isoa_status(f"Errore isocrone: {task.exception}", error=True)

    def _isoa_status(self, text, error=False):
        self._paint_status(self.isoaStatus, text, error)

    # ------------------------------------------------------------------ PTAL
    def _ptal_browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.ptalSourceEdit.setText(path)

    def _ptal_mode_changed(self):
        self.ptalPedBox.setVisible(
            self.ptalDistCombo.currentData() == "network")

    def _ptal_service_changed(self, *_a):
        manual = self.ptalServiceCombo.currentData() == "manual"
        self.ptalManBox.setVisible(manual)
        self.ptalGtfsBox.setVisible(not manual)
        # con dati forniti la frequenza è già della fascia: niente profili
        self.ptalProfilesCheck.setEnabled(not manual)
        if manual:
            self.ptalProfilesCheck.setChecked(False)

    def _ptal_manual_service(self):
        """(stop_routes, stops_xy) dal layer di fermate fornito."""
        layer = self.ptalManLayer.currentLayer()
        ff = self.ptalManFreq.currentField()
        if layer is None or not ff:
            raise ValueError("Indica il layer delle fermate e il campo "
                             "corse/ora.")
        rf = self.ptalManRoute.currentField() or None
        mfld = self.ptalManMode.currentField() or None
        sf = self.ptalManStop.currentField() or None
        dmode = self.ptalManDefMode.currentData()
        ct = QgsCoordinateTransform(layer.crs(), isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        recs = []
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            p = g.centroid().asPoint()
            recs.append((p.y(), p.x(), f[sf] if sf else None,
                         f[rf] if rf else None,
                         ptal.mode_code(f[mfld], dmode) if mfld else dmode,
                         f[ff]))
        stop_routes, stops_xy = ptal.stops_from_records(recs)
        if not stop_routes:
            raise ValueError("Nessuna fermata con corse/ora valide (> 0).")
        return stop_routes, stops_xy

    def _ptal_run(self):
        manual = self.ptalServiceCombo.currentData() == "manual"
        source = self.ptalSourceEdit.text().strip() or self.gtfsSourceEdit.text().strip()
        if manual:
            try:
                manual_service = self._ptal_manual_service()
            except Exception as exc:
                self._ptal_status(str(exc), error=True)
                return
        elif not source:
            self._ptal_status("Indica il feed GTFS (o usa «Dati forniti»).",
                              error=True)
            return
        from qgis.core import QgsCoordinateTransform
        self._ptal_cells = None
        self._ptal_points = None
        # evita che la Gap analysis usi un vecchio PTAL a griglia
        self._ptal_grid_layer_id = None
        if self.ptalGridCheck.isChecked():
            # estensione in WGS84
            ext_layer = self.ptalExtentCombo.currentLayer()
            if ext_layer is not None:
                ext = ext_layer.extent()
                src_crs = ext_layer.crs()
            else:
                ext = self.iface.mapCanvas().extent()
                src_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
            ct = QgsCoordinateTransform(src_crs, isochrones.WGS84,
                                        QgsProject.instance().transformContext())
            r = ct.transformBoundingBox(ext)
            centroids, cells = grid_gen.build_grid(
                r.yMinimum(), r.yMaximum(), r.xMinimum(), r.xMaximum(),
                self.ptalGridSize.value(), self.ptalGridShape.currentData())
            if not centroids:
                self._ptal_status("Estensione/cella non valide.", error=True)
                return
            if len(centroids) > 8000:
                self._ptal_status("Troppe celle (%d): aumenta la dimensione "
                                  "cella o riduci l'estensione." % len(centroids),
                                  error=True)
                return
            pts_ll = centroids
            self._ptal_cells = cells
        else:
            points = self.ptalPointsCombo.currentLayer()
            if points is None:
                self._ptal_status("Indica i punti di analisi o usa la griglia.",
                                  error=True)
                return
            # copia presa ora: se durante il calcolo il layer viene
            # filtrato o modificato i risultati restano sui punti giusti
            points = gtfs_layers.FeatureSnapshot(points)
            ct = QgsCoordinateTransform(points.crs(), isochrones.WGS84,
                                        QgsProject.instance().transformContext())
            pts_ll = []
            for f in points.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ct)
                # centroide: un valore per feature anche con MultiPoint
                p = g.centroid().asPoint()
                pts_ll.append((p.y(), p.x()))
            self._ptal_points = points
        if not pts_ll:
            self._ptal_status("Nessun punto valido.", error=True)
            return
        thresholds = {}
        reliability = {}
        for rtype, (sthr, srel) in self.ptalModeWidgets.items():
            thresholds[rtype] = sthr.value()
            reliability[rtype] = srel.value()
        # route_type 4 (ferry) -> come treno
        thresholds.setdefault("4", thresholds.get("2", 960))
        reliability.setdefault("4", reliability.get("2", 0.75))
        t_start, t_end = self.ptalStart.time(), self.ptalEnd.time()
        if not self.ptalProfilesCheck.isChecked() and t_end <= t_start:
            self._ptal_status("La fascia oraria deve finire dopo l'inizio.",
                              error=True)
            return
        params = {
            "start_h": t_start.hour() + t_start.minute() / 60.0,
            "end_h": t_end.hour() + t_end.minute() / 60.0,
            "walk_speed_kmh": self.ptalWalk.value() / 10.0,
            "thresholds": thresholds,
            "reliability": reliability,
            "default_threshold": thresholds.get("3", 640),
            "default_reliability": reliability.get("3", 2.0),
            "weight_primary": 1.0, "weight_secondary": 0.5,
            "service_date": self._service_date(),
        }
        self._ptal_note = ""
        if manual:
            params["manual"] = manual_service
            if not self.ptalManRoute.currentField():
                self._ptal_note = (
                    " Attenzione: senza campo linea ogni fermata conta come "
                    "una linea diversa, e più fermate vicine della stessa "
                    "linea alzano il PTAL: indica il campo linea se c'è.")
        if self.ptalDistCombo.currentData() == "network":
            road_layer = self.ptalRoadCombo.currentLayer()
            if road_layer is None:
                self._ptal_status("Modalità su rete: seleziona una rete pedonale "
                                  "(o scaricala con 'Rete da OSM').", error=True)
                return
            try:
                read = self._clean_roads_modal(
                    road_layer, QgsProject.instance().transformContext())
            except Exception as exc:
                self._ptal_status(str(exc), error=True)
                return
            if read is None:
                self._ptal_status("Calcolo annullato.")
                return
            params["roads"] = read[0]
        if self.ptalProfilesCheck.isChecked():
            params["bands"] = [(lbl, sh, eh)
                               for lbl, sh, eh, _d in ptal.TIME_BANDS]
        task = PtalTask(source, pts_ll, params)
        self._ptal_task = task
        task.progressChanged.connect(
            lambda p: self._ptal_status("Calcolo PTAL... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._ptal_done(t))
        task.taskTerminated.connect(lambda t=task: self._ptal_failed(t))
        self.ptalRunButton.setEnabled(False)
        self._ptal_status("Calcolo PTAL in background... 0%")
        QgsApplication.taskManager().addTask(task)

    def _ptal_done(self, task):
        self.ptalRunButton.setEnabled(True)
        results = task.result  # lista di (label, results_list); [0] = primario
        _plabel, primary = results[0]
        profiles = results if len(results) > 1 else None
        if self._ptal_cells is not None:
            layer = gtfs_layers.build_ptal_grid_layer(
                self._ptal_cells, primary, profiles=profiles)
        else:
            layer = gtfs_layers.build_ptal_layer(
                self._ptal_points, primary, profiles=profiles)
        layer = self._add_output(layer)
        if self._ptal_cells is not None:
            self._ptal_grid_layer_id = layer.id()
        bands = {}
        for r in primary:
            bands[r["band"]] = bands.get(r["band"], 0) + 1
        summary = ", ".join("%s:%d" % (b, bands[b]) for b in sorted(bands))
        extra = ""
        if profiles:
            extra = " · profili: " + ", ".join(lbl for lbl, _ in profiles)
        self._ptal_status("PTAL calcolato su %d punti%s (%s). Fasce "
                          "(primaria): %s%s" % (len(primary), extra,
                                                task.selection or "orari GTFS",
                                                summary,
                                                getattr(self, "_ptal_note",
                                                        "")))

    def _ptal_failed(self, task):
        self.ptalRunButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._ptal_status("Calcolo annullato.")
        else:
            self._ptal_status(f"Errore PTAL: {task.exception}", error=True)

    def _ptal_status(self, text, error=False):
        self._paint_status(self.ptalStatus, text, error)

    def _gap_run(self):
        lid = self._ptal_grid_layer_id
        ptal_layer = QgsProject.instance().mapLayer(lid) if lid else None
        if ptal_layer is None:
            self._ptal_status("Esegui prima un PTAL a celle (griglia).",
                              error=True)
            return
        pop = self.gapPopCombo.currentLayer()
        if pop is None:
            self._ptal_status("Seleziona il layer popolazione.", error=True)
            return
        field = self.gapPopField.currentField() or None
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            layer = gap_mod.compute_gap(
                ptal_layer, pop, field,
                QgsProject.instance().transformContext())
        except Exception as exc:
            self._ptal_status(f"Errore gap: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        layer = self._add_output(layer)
        self._ptal_status("Gap analysis creata (campi popolazione, gap).")

    # --------------------------------------------------- Accessibilita
    def _acc_browse_gtfs(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Feed GTFS", "", "GTFS zip (*.zip)")
        if path:
            self.accGtfsEdit.setText(path)

    def _acc_mode_changed(self):
        self.accPtBox.setVisible(self.accModeCombo.currentData() == "pt")

    def _acc_pts(self, layer, weight_field=None):
        ct = QgsCoordinateTransform(layer.crs(), isochrones.WGS84,
                                    QgsProject.instance().transformContext())
        out = []
        names = layer.fields().names()
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            p = g.centroid().asPoint()
            if weight_field and weight_field in names:
                try:
                    w = float(f[weight_field])
                except (TypeError, ValueError):
                    w = 0.0  # peso mancante (NULL): non conta
            else:
                w = 1.0
            out.append((p.y(), p.x(), w))
        return out

    def _acc_run(self):
        origins = self.accOriginCombo.currentLayer()
        dests = self.accDestCombo.currentLayer()
        if origins is None or dests is None:
            self._acc_status("Seleziona origini e destinazioni.", error=True)
            return
        try:
            times = [float(x) for x in self.accTimes.text().replace(";", ",")
                     .split(",") if x.strip()]
        except ValueError:
            self._acc_status("Tempi non validi.", error=True)
            return
        if not times:
            self._acc_status("Indica almeno un tempo.", error=True)
            return
        # copia presa ora (vedi PTAL): risultati sempre sulle origini giuste
        origins = gtfs_layers.FeatureSnapshot(origins)
        origin_pts = [(la, lo) for la, lo, _ in self._acc_pts(origins)]
        dest_pts = self._acc_pts(dests, self.accWeightField.currentField() or None)
        if not origin_pts or not dest_pts:
            self._acc_status("Origini/destinazioni vuote.", error=True)
            return
        is_pt = (self.accModeCombo.currentData() == "pt")
        if is_pt:
            src = self.accGtfsEdit.text().strip() or self.gtfsSourceEdit.text().strip()
            if not src:
                self._acc_status("Per il TP indica un feed GTFS.", error=True)
                return
            acc_speed, acc_r = self._pt_leg_params(self.accAccessMode)
            egr_speed, egr_r = self._pt_leg_params(self.accEgressMode)
            task = AccessTask("pt", {
                "origins": origin_pts, "dests": dest_pts, "source_path": src,
                "start_h": self.accStartH.value(),
                "walk_speed": self.accModeCombo.itemData(0),
                "times": times, "access_m": acc_r, "egress_m": egr_r,
                "access_speed": acc_speed, "egress_speed": egr_speed,
                "transfer_penalty_s": self.accTransferPen.value() * 60.0,
                "service_date": self._service_date()})
        else:
            road = self.accRoadCombo.currentLayer()
            if road is None:
                self._acc_status("Per i modi su strada indica una rete.",
                                 error=True)
                return
            try:
                read = self._clean_roads_modal(
                    road, QgsProject.instance().transformContext(),
                    self.accOneway.isChecked(), coords=origin_pts)
            except Exception as exc:
                self._acc_status(str(exc), error=True)
                return
            if read is None:
                self._acc_status("Calcolo annullato.")
                return
            roads, directions, pf_msg = read
            if pf_msg:
                self._acc_status(pf_msg + "Calcolo in corso...")
            task = AccessTask("net", {
                "origins": origin_pts, "dests": dest_pts, "roads": roads,
                "speed": self.accModeCombo.currentData(), "times": times,
                "directions": directions})
        self._acc_origin_layer = origins
        self._acc_task = task
        task.progressChanged.connect(
            lambda p: self._acc_status("Calcolo accessibilità... %d%%" % int(p)))
        task.taskCompleted.connect(lambda t=task: self._acc_done(t))
        task.taskTerminated.connect(lambda t=task: self._acc_failed(t))
        self.accRunButton.setEnabled(False)
        self._acc_status("Calcolo in background... 0%")
        QgsApplication.taskManager().addTask(task)

    def _acc_done(self, task):
        self.accRunButton.setEnabled(True)
        layer = gtfs_layers.build_access_layer(
            self._acc_origin_layer, task.result, task.times)
        layer = self._add_output(layer)
        self._acc_status("Accessibilità calcolata su %d origini (campi "
                         "acc_*min)." % len(task.result))

    def _acc_failed(self, task):
        self.accRunButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._acc_status("Calcolo annullato.")
        else:
            self._acc_status(f"Errore accessibilità: {task.exception}", error=True)

    def _acc_status(self, text, error=False):
        self._paint_status(self.accStatus, text, error)

    # --------------------------------------------- metriche sintesi & equità
    def _eq_status(self, text, error=False):
        self._paint_status(self.eqStatus, text, error)

    def _eq_run(self):
        layer = self.eqLayerCombo.currentLayer()
        vfield = self.eqValueField.currentField()
        if layer is None or not vfield:
            self._eq_status("Seleziona layer e campo valore.", error=True)
            return
        wfield = self.eqWeightField.currentField() or None
        values, weights = [], []
        for f in layer.getFeatures():
            try:
                values.append(float(f[vfield]))
            except (TypeError, ValueError):
                continue
            if wfield:
                try:
                    weights.append(float(f[wfield]))
                except (TypeError, ValueError):
                    weights.append(0.0)
        if not values:
            self._eq_status("Nessun valore numerico nel campo scelto.",
                            error=True)
            return
        summary = equity.compute_equity(
            values, weights if wfield else None, self.eqThreshold.value())
        self._eq_summary = summary
        self._eq_value_name = vfield
        rows = [
            ("N. feature", "%d" % summary["n"]),
            ("Peso totale", "%.1f" % summary["peso_totale"]),
            ("Media pesata", "%.2f" % summary["media"]),
            ("Mediana pesata", "%.2f" % summary["mediana"]),
            ("Indice di Gini", "%.3f" % summary["gini"]),
        ]
        if summary["pct_servita"] is not None:
            rows.append(("%% servita (≥ %.2f)" % self.eqThreshold.value(),
                         "%.1f %%" % summary["pct_servita"]))
        t = self.eqTable
        t.clear()
        t.setColumnCount(2)
        t.setHorizontalHeaderLabels(["Metrica", "Valore"])
        t.setRowCount(len(rows))
        for r, (k, v) in enumerate(rows):
            t.setItem(r, 0, QTableWidgetItem(k))
            it = QTableWidgetItem(v)
            it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            t.setItem(r, 1, it)
        t.resizeColumnsToContents()
        self.eqExportButton.setEnabled(True)
        self.eqChartButton.setEnabled(True)
        wnote = "pesata per %s" % wfield if wfield else "non pesata"
        self._eq_status("Metriche calcolate (%s). Gini=%.3f."
                        % (wnote, summary["gini"]))

    def _eq_export(self):
        if not getattr(self, "_eq_summary", None):
            self._eq_status("Calcola prima le metriche.", error=True)
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Esporta equità", "equita_lorenz.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            excel_report.write_equity_report(
                path, self._eq_summary, self._eq_value_name)
        except Exception as exc:
            self._eq_status(f"Errore export: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        self._eq_status(f"Esportato: {path}")

    # ------------------------------------------------------------- grafici
    def _show_chart(self, title, plot_fn):
        """Mostra un grafico matplotlib in un dialog (se matplotlib è presente)."""
        try:
            from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
            from matplotlib.figure import Figure
        except Exception:
            QMessageBox.information(
                self, "Grafico",
                "matplotlib non è disponibile in questo Python di QGIS.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.resize(660, 500)
        lay = QVBoxLayout(dlg)
        fig = Figure(figsize=(6, 4.5))
        canvas = FigureCanvasQTAgg(fig)
        ax = fig.add_subplot(111)
        try:
            plot_fn(ax)
            fig.tight_layout()
        except Exception as exc:
            QMessageBox.warning(self, "Grafico", "Errore nel grafico: %s" % exc)
            return
        lay.addWidget(canvas)
        btn = QPushButton("Chiudi")
        btn.clicked.connect(dlg.accept)
        lay.addWidget(btn)
        dlg.exec_()

    def _eq_chart(self):
        s = getattr(self, "_eq_summary", None)
        if not s or not s.get("lorenz"):
            self._eq_status("Calcola prima le metriche.", error=True)
            return
        lor = s["lorenz"]
        gini = s["gini"]

        def plot(ax):
            xs = [p[0] for p in lor]
            ys = [p[1] for p in lor]
            ax.plot(xs, ys, "-", color="#2171b5", linewidth=2, label="Lorenz")
            ax.plot([0, 1], [0, 1], "--", color="#999", label="Uguaglianza")
            ax.fill_between(xs, ys, xs, color="#2171b5", alpha=0.15)
            ax.set_xlabel("Quota cumulata di popolazione")
            ax.set_ylabel("Quota cumulata di accessibilità")
            ax.set_title("Curva di Lorenz (Gini = %.3f)" % gini)
            ax.legend(loc="upper left")
            ax.grid(alpha=0.3)

        self._show_chart("Curva di Lorenz", plot)

    # ---------------------------------------------------- confronto scenari
    def _cmp_run(self):
        la = self.cmpLayerA.currentLayer()
        lb = self.cmpLayerB.currentLayer()
        fa = self.cmpFieldA.currentField()
        fb = self.cmpFieldB.currentField()
        if la is None or lb is None or not fa or not fb:
            self._cmp_status("Seleziona i due scenari e i rispettivi campi.",
                             error=True)
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            layer, matched, total = compare.compute_difference(
                la, fa, lb, fb, QgsProject.instance().transformContext(),
                max_dist_m=self.cmpMaxDist.value() or None)
        except Exception as exc:
            self._cmp_status(f"Errore confronto: {exc}", error=True)
            return
        finally:
            QApplication.restoreOverrideCursor()
        layer = self._add_output(layer)
        self._cmp_status("Differenza creata: %d/%d feature abbinate "
                         "(delta = B − A)." % (matched, total))

    def _cmp_status(self, text, error=False):
        self._paint_status(self.cmpStatus, text, error)

    # ----------------------------------------------------- scenario A/B rete
    def _scn_status(self, text, error=False):
        self._paint_status(self.scnStatus, text, error)

    def _scn_run(self):
        origins = self.accOriginCombo.currentLayer()
        dests = self.accDestCombo.currentLayer()
        ra_l = self.scnRoadA.currentLayer()
        rb_l = self.scnRoadB.currentLayer()
        if origins is None or dests is None or ra_l is None or rb_l is None:
            self._scn_status("Servono origini, destinazioni e le due reti A/B.",
                             error=True)
            return
        try:
            times = [float(x) for x in self.accTimes.text().replace(";", ",")
                     .split(",") if x.strip()]
        except ValueError:
            self._scn_status("Tempi non validi.", error=True)
            return
        if not times:
            self._scn_status("Indica almeno un tempo.", error=True)
            return
        speed = self.accModeCombo.currentData()
        if speed == "pt":
            speed = 4.5
        ctx = QgsProject.instance().transformContext()
        origin_pts = [(la, lo) for la, lo, _ in self._acc_pts(origins)]
        dest_pts = self._acc_pts(dests, self.accWeightField.currentField() or None)
        if not origin_pts or not dest_pts:
            self._scn_status("Origini/destinazioni vuote.", error=True)
            return
        # sensi unici come nella scheda Accessibilità; le due reti si leggono
        # e puliscono in un task (prima sul thread principale)
        ow = self.accOneway.isChecked()
        spec_a = self._road_spec(ra_l, ctx, ow)
        spec_b = self._road_spec(rb_l, ctx, ow)

        def _read(task):
            out = []
            for k, spec in enumerate((spec_a, spec_b)):
                raw, dirs = read_spec_roads(spec, task, 50 * k, 50 * k + 40)
                roads, dirs, _st = net_clean.clean_network(raw, 1.0, dirs)
                ok, vmsg, _i = net_iso.validate_network(roads)
                if not ok:
                    raise ValueError("Rete %s non valida: %s" % ("AB"[k], vmsg))
                out.append((roads, dirs))
            return out
        try:
            read = self._run_modal("Lettura delle reti A e B…", _read)
        except Exception as exc:
            self._scn_status(f"Errore scenario: {exc}", error=True)
            return
        if read is None:
            self._scn_status("Scenario annullato.")
            return
        (ra, da), (rb, db) = read
        kind = self.scnKind.currentData()
        if kind == "iso":
            # calcolo pesante (union+buffer ×2 reti) in background con progress
            t = max(times)
            task = ScenarioIsoTask({
                "roads_a": ra, "roads_b": rb, "sources": origin_pts,
                "speed": float(speed), "time_min": t, "dir_a": da, "dir_b": db,
                "ctx": ctx})
            self._scn_iso_time = t
            self.scnButton.setEnabled(False)
            task.progressChanged.connect(
                lambda p: self._scn_status("Scenario isocrone... %d%%" % int(p)))
            task.taskCompleted.connect(lambda tk=task: self._scn_iso_done(tk))
            task.taskTerminated.connect(lambda tk=task: self._scn_iso_failed(tk))
            self._scn_status("Calcolo scenario isocrone in background... 0%")
            QgsApplication.taskManager().addTask(task)
            return
        try:
            res = self._run_modal(
                "Scenario A/B — accessibilità…",
                lambda task: scenarios.accessibility_ab(
                    origin_pts, dest_pts, ra, rb, float(speed), times,
                    dir_a=da, dir_b=db, progress=task.setProgress,
                    is_canceled=task.isCanceled))
            if res is None:
                self._scn_status("Scenario annullato.")
                return
            rows, t = res
            layer = net_layers.build_scenario_layer(origins, rows)
        except Exception as exc:
            self._scn_status(f"Errore scenario: {exc}", error=True)
            return
        layer = self._add_output(layer)
        s = scenarios.scenario_summary(rows)
        self._scn_status("A/B @%g min: %d migliorate, %d peggiorate, %d "
                         "invariate; delta medio %.2f."
                         % (t, s["migliorate"], s["peggiorate"],
                            s["invariate"], s["delta_medio"]))

    def _scn_iso_done(self, task):
        self.scnButton.setEnabled(True)
        if task.n_snap_a == 0 and task.n_snap_b == 0:
            self._scn_status("Nessuna sorgente agganciata alle reti entro 500 m.",
                             error=True)
            return
        t = getattr(self, "_scn_iso_time", 0)
        layer, summary = isochrones.build_isochrone_diff_layer(
            task.geom_a, task.geom_b, t,
            QgsProject.instance().transformContext())
        layer = self._add_output(layer)
        self._scn_status(
            "Isocrone A/B @%g min: +%.2f ha (guadagno), −%.2f ha (perdita), "
            "%.2f ha in comune."
            % (t, summary["guadagno"] / 1e4, summary["perdita"] / 1e4,
               summary["comune"] / 1e4))

    def _scn_iso_failed(self, task):
        self.scnButton.setEnabled(True)
        if getattr(task, "cancelled", False):
            self._scn_status("Scenario isocrone annullato.")
        else:
            self._scn_status("Errore scenario isocrone: %s" % task.exception,
                             error=True)

    def release_map_tools(self):
        """Toglie dalla mappa gli strumenti «clic sulla mappa» del pannello:
        uno rimasto attivo dopo la chiusura (o lo scaricamento del plugin)
        chiamerebbe un pannello che non c'è più."""
        canvas = self.iface.mapCanvas()
        for btn in (self.rtPickButton, self.isoaPickButton,
                    self.repDrawButton):
            btn.blockSignals(True)
            btn.setChecked(False)
            btn.blockSignals(False)
        for tool in (self._rt_tool, self._isoa_tool, self._rep_tool):
            if tool is not None and canvas.mapTool() is tool:
                canvas.unsetMapTool(tool)
        if self._rep_tool is not None:
            self._rep_tool.clear()

    def closeEvent(self, event):  # noqa: N802 (API Qt)
        self.release_map_tools()
        if self._scan_timer:
            self._scan_timer.stop()
        if self._logger:
            self._logger.stop()
        self.closingPlugin.emit()
        event.accept()
