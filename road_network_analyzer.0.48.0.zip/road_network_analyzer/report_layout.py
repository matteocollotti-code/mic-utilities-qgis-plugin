# -*- coding: utf-8 -*-
"""Report d'area: layer delle mappe e layout di stampa (PDF).

Dal risultato di core.area_report.compute costruisce sul thread principale:
- i layer delle mappe (area, velo fuori area, strade di contesto, rete per
  classe, camminabilità, PTAL, fermate, isocrone, città dei 15 minuti,
  servizi);
- un layout di stampa QGIS A4 verticale, una pagina per sezione.

La grafica segue il linguaggio di shadcn/ui (che è una libreria web e non
può girare in un layout di stampa): schede bianche con bordo sottile e
angoli arrotondati, numeri grandi con etichetta piccola, badge colorati
per il giudizio, tabelle senza griglia verticale, barre al posto dei
grafici. Tutto è disegnato con elementi nativi del layout (vettoriale,
stesso carattere ovunque): niente immagini, niente matplotlib. Il layout
resta nel progetto e si può ritoccare nel compositore e riesportare.
"""
import datetime
import math
import os
from contextlib import contextmanager

from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import (QColor, QFont, QFontDatabase, QFontMetricsF,
                             QPainter)
from qgis.core import (
    QgsApplication, QgsCategorizedSymbolRenderer,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature,
    QgsField, QgsFillSymbol, QgsGeometry, QgsGraduatedSymbolRenderer,
    QgsInvertedPolygonRenderer, QgsLabeling, QgsLayoutExporter,
    QgsLayoutItemLabel, QgsLayoutItemMap, QgsLayoutItemPage,
    QgsLayoutItemPicture, QgsLayoutItemScaleBar, QgsLayoutItemShape,
    QgsLayoutMeasurement, QgsLayoutPoint, QgsLayoutSize, QgsLineSymbol,
    QgsMarkerSymbol, QgsNullSymbolRenderer, QgsPalLayerSettings, QgsPointXY,
    QgsPrintLayout, QgsRasterLayer, QgsRectangle, QgsRendererCategory,
    QgsRendererRange, QgsSimpleLineSymbolLayer, QgsSingleSymbolRenderer,
    QgsTextBufferSettings, QgsTextFormat, QgsUnitTypes,
    QgsVectorLayerSimpleLabeling, QgsWkbTypes,
)

from .core import area_report, fifteen, gtfs_layers, isochrones, style_util
from .core.area_report import fmt

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")

# ------------------------------------------------------------------ stile
FG = "#09090b"          # testo
MUTED = "#71717a"       # testo secondario
BORDER = "#e4e4e7"      # bordi delle schede
RULE = "#d4d4d8"        # riga sotto l'intestazione delle tabelle
SUBTLE = "#f4f4f5"      # fondi tenui, binari delle barre
CARD = "#ffffff"
ACCENT = "#4f46e5"
BADGE = {"verde": ("#dcfce7", "#166534", "Buono"),
         "giallo": ("#fef3c7", "#92400e", "Migliorabile"),
         "rosso": ("#fee2e2", "#991b1b", "Critico")}
DOT = {"verde": "#22c55e", "giallo": "#f59e0b", "rosso": "#ef4444"}
INDEX_COLORS = ["#ef4444", "#f97316", "#facc15", "#84cc16", "#16a34a"]
F15_CLASSES = [(0, 20, "#ef4444", "0–20"), (20, 40, "#f97316", "20–40"),
               (40, 60, "#facc15", "40–60"), (60, 80, "#a3e635", "60–80"),
               (80, 99.99, "#4ade80", "80–99"),
               (99.99, 100.0, "#16a34a", "100 · tutti i servizi")]
ISO_COLORS = ["#4338ca", "#6366f1", "#818cf8", "#a5b4fc", "#c7d2fe"]
ZONE = {"verde": "#bbf7d0", "giallo": "#fde68a", "rosso": "#fecaca"}
# densità dei residenti (dal chiaro allo scuro) e maschi / femmine
DEMO_COLORS = ["#ffedd5", "#fdba74", "#fb923c", "#ea580c", "#9a3412"]
SEX_COLORS = ("#6366f1", "#14b8a6")
SERV_COLORS = ["#f97316", "#3b82f6", "#ef4444", "#22c55e", "#14b8a6",
               "#8b5cf6", "#ec4899", "#eab308", "#64748b", "#06b6d4"]
TYPE_COLORS = ["#e11d48", "#f97316", "#f59e0b", "#84cc16", "#06b6d4",
               "#6366f1", "#a855f7", "#a1a1aa"]
# classi di strade OSM (highway), dalla più importante
ROAD_CLASSES = [
    ("Autostrade e superstrade", {"motorway", "motorway_link", "trunk",
                                  "trunk_link"}, "#e11d48", 1.5),
    ("Principali", {"primary", "primary_link"}, "#f97316", 1.25),
    ("Secondarie", {"secondary", "secondary_link"}, "#f59e0b", 1.05),
    ("Terziarie", {"tertiary", "tertiary_link"}, "#ca8a04", 0.85),
    ("Locali", {"residential", "unclassified", "living_street", "road"},
     "#3f3f46", 0.55),
    ("Di servizio", {"service"}, "#a1a1aa", 0.35),
    ("Pedonali e ciclabili", {"pedestrian", "footway", "path", "steps",
                              "cycleway", "bridleway", "corridor",
                              "platform", "sidewalk", "crossing", "track"},
     "#10b981", 0.3),
]
# stili delle mappe selezionabili nel pannello; «essenziale» (solo strade
# di contesto, nessun download) è il ripiego automatico quando la base non
# si può scaricare o manca internet
MAP_STYLES = [("chiara", "Carta chiara"), ("osm", "OpenStreetMap"),
              ("satellite", "Satellite")]
LABEL_MODES = [("auto", "Automatico"), ("nessuno", "Nessuno"),
               ("principali", "Solo vie principali"),
               ("tutte", "Tutte le vie")]
LABEL_SIZES = [("piccoli", "Piccoli", 4.1), ("medi", "Medi", 4.8),
               ("grandi", "Grandi", 5.7)]
MAP_BG = {"essenziale": "#fafafa", "chiara": "#f6f5f2", "osm": "#f2efe9",
          "satellite": "#111111"}
MAP_CREDIT = {"chiara": "© OpenStreetMap", "osm": "© OpenStreetMap",
              "satellite": "Esri World Imagery"}
MAP_SOURCE = {
    "chiara": "Base delle mappe: © OpenStreetMap contributors (ODbL)",
    "osm": "Base delle mappe: © OpenStreetMap contributors (ODbL)",
    "satellite": "Immagini satellitari: Esri World Imagery (Esri, Maxar, "
                 "Earthstar Geographics)"}
TILES = {
    "osm": ("https://tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png"
            "&tilePixelRatio=1", "OpenStreetMap (sfondo)"),
    "satellite": ("https://server.arcgisonline.com/ArcGIS/rest/services/"
                  "World_Imagery/MapServer/tile/%7Bz%7D/%7By%7D/%7Bx%7D",
                  "Satellite (sfondo)"),
}
# colori della carta chiara
LAND = {"land": "#f6f5f2", "green": "#dcead6", "water": "#c9def0",
        "build": "#e6e3de", "build_line": "#d5d1ca", "road": "#ffffff",
        "casing": "#cdc9c2", "path": "#bcb7af", "rail": "#a8a29e",
        "label": "#6b6862", "halo": "#f6f5f2"}
# strade della base: classe, tipi OSM, spessore (mm a scala 1:7 000)
BASE_ROADS = [
    ("major", {"motorway", "motorway_link", "trunk", "trunk_link",
               "primary", "primary_link"}, 1.5),
    ("secondary", {"secondary", "secondary_link"}, 1.2),
    ("tertiary", {"tertiary", "tertiary_link"}, 1.0),
    ("local", {"residential", "unclassified", "living_street", "road",
               "pedestrian"}, 0.75),
    ("service", {"service"}, 0.4),
]
MAIN_ROADS = {"major", "secondary", "tertiary"}
BASE_STACK = ["b_roads", "b_rail", "b_build", "b_waterl", "b_water",
              "b_green"]
PTAL_MEANING = [("0 – 1b", "molto basso"), ("2 – 3", "medio"),
                ("4 – 5", "buono"), ("6a – 6b", "eccellente")]
MM = QgsUnitTypes.LayoutMillimeters
PAGE_W, PAGE_H, M = 210.0, 297.0, 14.0
CW = PAGE_W - 2 * M          # larghezza utile
TOP = 36.0                   # inizio del contenuto sotto l'intestazione
BOTTOM = 280.0               # fine del contenuto sopra il piè di pagina
GAP = 4.0
_WEIGHT = {"regular": QFont.Normal, "medium": QFont.Medium,
           "semibold": QFont.DemiBold, "bold": QFont.Bold}
_FAMILY = []


def _family():
    """Carattere del report: il più vicino a Inter fra quelli installati."""
    if not _FAMILY:
        try:
            fams = set(QFontDatabase().families())
        except Exception:
            fams = set()
        for name in ("Inter", "Segoe UI", "Helvetica Neue", "Arial",
                     "DejaVu Sans"):
            if name in fams:
                _FAMILY.append(name)
                break
        else:
            _FAMILY.append("Arial")
    return _FAMILY[0]


def _font(size, weight="regular", spacing=0.0):
    f = QFont(_family())
    f.setPointSizeF(size)
    f.setWeight(_WEIGHT.get(weight, QFont.Normal))
    if spacing:
        f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
    return f


def _dpi():
    try:
        return float(QgsApplication.primaryScreen().logicalDotsPerInch()) \
            or 96.0
    except Exception:
        return 96.0


def text_w(text, size, weight="regular"):
    """Larghezza del testo in millimetri."""
    fm = QFontMetricsF(_font(size, weight))
    try:
        px = fm.horizontalAdvance(str(text))
    except AttributeError:
        px = fm.width(str(text))
    return px * 25.4 / _dpi() * 1.03


def line_h(size):
    """Altezza di una riga di testo in millimetri."""
    return size * 0.3528 * 1.32


def wrap(text, size, w, weight="regular"):
    """Righe del testo a capo automatico in una larghezza (mm)."""
    lines = []
    for par in str(text).split("\n"):
        cur = ""
        for word in par.split(" "):
            t = (cur + " " + word).strip()
            if cur and text_w(t, size, weight) > w:
                lines.append(cur)
                cur = word
            else:
                cur = t
        lines.append(cur)
    return lines


def elide(text, size, w, weight="regular"):
    text = str(text)
    if text_w(text, size, weight) <= w:
        return text
    while len(text) > 1 and text_w(text + "…", size, weight) > w:
        text = text[:-1]
    return text.rstrip() + "…"


# ------------------------------------------------------------------ layer
def _mem(geom, name, fields):
    lay = style_util.memory_layer(geom, WGS84, name)
    lay.dataProvider().addAttributes(fields)
    lay.updateFields()
    return lay


def _fill(color, stroke="#ffffff", sw=0.15):
    return QgsFillSymbol.createSimple({
        "color": color, "outline_color": stroke, "outline_width": str(sw),
        "joinstyle": "round"})


def road_classes(rete):
    """(funzione tipo → classe, [(classe, colore, spessore)]) per la mappa
    e la composizione della rete: classi OSM se il tipo è l'highway di
    OSM, altrimenti i 7 tipi più lunghi più «Altro»."""
    types = list(rete["lengths"])
    known = {t for _l, ts, _c, _w in ROAD_CLASSES for t in ts}
    tot = sum(rete["lengths"].values()) or 1.0
    osm = sum(v for t, v in rete["lengths"].items()
              if str(t).lower() in known) >= 0.6 * tot
    if osm:
        def classe(t):
            for lab, ts, _c, _w in ROAD_CLASSES:
                if str(t).lower() in ts:
                    return lab
            return "Altro"
        styles = [(lab, c, w) for lab, _ts, c, w in ROAD_CLASSES] + [
            ("Altro", "#a8a29e", 0.3)]
    else:
        top = types[:7]

        def classe(t):
            return str(t) if t in top else "Altro"
        styles = [(str(t), TYPE_COLORS[min(i, len(TYPE_COLORS) - 1)],
                   max(0.35, 1.1 - 0.12 * i)) for i, t in enumerate(top)] + [
            ("Altro", "#a8a29e", 0.3)]
    return classe, styles


def quantile_ranges(values, n=5):
    """Estremi (arrotondati) di al più n classi a quantili."""
    vals = sorted(v for v in values if v is not None)
    if not vals:
        return []
    n = min(n, len(set(vals)))
    if n < 2:
        return [(vals[0], vals[-1])]
    br = [vals[0]] + [vals[int(round(k * (len(vals) - 1) / float(n)))]
                      for k in range(1, n)] + [vals[-1]]
    br = sorted(set(round(b) for b in br))
    if len(br) < 2:
        return [(vals[0], vals[-1])]
    out = []
    for i in range(len(br) - 1):
        lo = min(vals[0], br[0]) if i == 0 else br[i]
        hi = max(vals[-1], br[-1]) if i == len(br) - 2 else br[i + 1]
        out.append((lo, hi))
    return out


def service_color(cat, i=0):
    k = fifteen.LABELS.index(cat) if cat in fifteen.LABELS else i
    return SERV_COLORS[k % len(SERV_COLORS)]


def base_road_class(kind):
    """Classe della strada nella base: dai tipi OSM; un tipo sconosciuto
    (rete non OSM) vale come strada locale, un percorso pedonale o
    ciclabile come sentiero."""
    for name, kinds, _w in BASE_ROADS:
        if kind in kinds:
            return name
    return "path" if kind in ROAD_CLASSES[-1][1] else "local"


def map_scale(res):
    """Denominatore di scala tipico delle mappe del report (l'area in un
    riquadro di circa 179 × 120 mm, con un po' di margine)."""
    bb = QgsGeometry.fromWkt(res["area_wkt"]).boundingBox()
    lat = math.radians(bb.center().y())
    w_m = bb.width() * 111320.0 * max(0.05, math.cos(lat))
    h_m = bb.height() * 111320.0
    return max(w_m * 1.2 / 0.179, h_m * 1.2 / 0.120, 500.0)


def _lines_layer(name, wkts, symbol):
    lay = _mem("MultiLineString", name, [QgsField("id", QVariant.Int)])
    feats = []
    for i, wkt in enumerate(wkts):
        g = QgsGeometry.fromWkt(wkt)
        if g is None or g.isEmpty():
            continue
        g.convertToMultiType()
        ft = QgsFeature(lay.fields())
        ft.setGeometry(g)
        ft.setAttributes([i])
        feats.append(ft)
    lay.dataProvider().addFeatures(feats)
    lay.updateExtents()
    lay.setRenderer(QgsSingleSymbolRenderer(symbol))
    return lay


def _polys_layer(name, wkts, symbol):
    lay = _mem("MultiPolygon", name, [QgsField("id", QVariant.Int)])
    feats = []
    for i, wkt in enumerate(wkts):
        g = QgsGeometry.fromWkt(wkt)
        if g is None or g.isEmpty():
            continue
        g.convertToMultiType()
        if g.type() != QgsWkbTypes.PolygonGeometry:
            continue
        ft = QgsFeature(lay.fields())
        ft.setGeometry(g)
        ft.setAttributes([i])
        feats.append(ft)
    lay.dataProvider().addFeatures(feats)
    lay.updateExtents()
    lay.setRenderer(QgsSingleSymbolRenderer(symbol))
    return lay


def base_layers(res, base):
    """Layer della «carta chiara»: verde, acqua, edifici e ferrovie dalla
    base OSM (osm_basemap), strade bianche con bordo dalla rete letta per
    il report. Gli spessori seguono la scala della mappa: a scala di città
    le strade si assottigliano e spariscono sentieri e strade di servizio.
    """
    T = LAND
    out = {}
    scale = map_scale(res)
    k = min(1.1, max(0.3, (7000.0 / scale) ** 0.55))
    base = base or {}
    out["b_green"] = _polys_layer("Verde", base.get("green", []),
                                  QgsFillSymbol.createSimple({
                                      "color": T["green"],
                                      "outline_style": "no"}))
    out["b_water"] = _polys_layer("Acqua", base.get("water", []),
                                  QgsFillSymbol.createSimple({
                                      "color": T["water"],
                                      "outline_style": "no"}))
    out["b_waterl"] = _lines_layer("Corsi d'acqua", base.get("waterl", []),
                                   QgsLineSymbol.createSimple({
                                       "line_color": T["water"],
                                       "line_width": "%.2f" % (0.8 * k),
                                       "capstyle": "round"}))
    out["b_build"] = _polys_layer("Edifici", base.get("build", []),
                                  QgsFillSymbol.createSimple({
                                      "color": T["build"],
                                      "outline_color": T["build_line"],
                                      "outline_width": "0.08",
                                      "joinstyle": "round"}))
    rail = QgsLineSymbol.createSimple({"line_color": T["rail"],
                                       "line_width": "%.2f" % (0.45 * k)})
    dash = QgsSimpleLineSymbolLayer(QColor(T["land"]), 0.25 * k)
    dash.setUseCustomDashPattern(True)
    dash.setCustomDashVector([2.2, 2.2])
    rail.appendSymbolLayer(dash)
    out["b_rail"] = _lines_layer("Ferrovie", base.get("rail", []), rail)

    lay = _mem("MultiLineString", "Strade (base)",
               [QgsField("classe", QVariant.String)])
    feats = []
    skip = set()
    if scale > 15000:
        skip.add("path")
    if scale > 30000:
        skip.add("service")
    for wkt, kind, _name, level in res.get("context") or []:
        cls = base_road_class(kind)
        if cls in skip or (level or 0) < 0:   # in galleria: non si vede
            continue
        g = QgsGeometry.fromWkt(wkt)
        if g is None or g.isEmpty():
            continue
        g.convertToMultiType()
        ft = QgsFeature(lay.fields())
        ft.setGeometry(g)
        ft.setAttributes([cls])
        feats.append(ft)
    lay.dataProvider().addFeatures(feats)
    lay.updateExtents()
    widths = dict((nm, wd) for nm, _ts, wd in BASE_ROADS)
    cats = []
    for rank, nm in enumerate(["path", "service", "local", "tertiary",
                               "secondary", "major"]):
        if nm == "path":
            sym = QgsLineSymbol.createSimple({
                "line_color": T["path"], "line_width": "%.2f" % (0.18 * k),
                "capstyle": "round"})
            sym.symbolLayer(0).setRenderingPass(0)
        else:
            wd = widths[nm] * k
            sym = QgsLineSymbol.createSimple({
                "line_color": T["casing"],
                "line_width": "%.2f" % (wd + 0.3 * max(k, 0.6)),
                "capstyle": "round", "joinstyle": "round"})
            sym.symbolLayer(0).setRenderingPass(1 + rank)
            fill = QgsSimpleLineSymbolLayer(QColor(T["road"]), wd)
            fill.setPenCapStyle(Qt.RoundCap)
            fill.setPenJoinStyle(Qt.RoundJoin)
            fill.setRenderingPass(20 + rank)   # i bordi stanno tutti sotto
            sym.appendSymbolLayer(fill)
        cats.append(QgsRendererCategory(nm, sym, nm))
    rend = QgsCategorizedSymbolRenderer("classe", cats)
    rend.setUsingSymbolLevels(True)
    lay.setRenderer(rend)
    out["b_roads"] = lay
    return out


def labels_layer(res, title, main_only, color, halo, size):
    """Nomi delle vie lungo le strade (dal campo «name» della rete).
    Con main_only solo le vie principali; se la rete non le distingue
    (non è OSM) valgono tutte."""
    rows = [(wkt, base_road_class(kind), name)
            for wkt, kind, name, level in res.get("context") or []
            if name and (level or 0) >= 0]
    rows = [r for r in rows if r[1] not in ("path", "service")]
    if main_only and any(r[1] in MAIN_ROADS for r in rows):
        rows = [r for r in rows if r[1] in MAIN_ROADS]
    lay = _mem("MultiLineString", title, [QgsField("name", QVariant.String)])
    feats = []
    for wkt, _cls, name in rows:
        g = QgsGeometry.fromWkt(wkt)
        if g is None or g.isEmpty():
            continue
        g.convertToMultiType()
        ft = QgsFeature(lay.fields())
        ft.setGeometry(g)
        ft.setAttributes([name])
        feats.append(ft)
    lay.dataProvider().addFeatures(feats)
    lay.updateExtents()
    lay.setRenderer(QgsNullSymbolRenderer())
    pal = QgsPalLayerSettings()
    pal.fieldName = "name"
    pal.placement = QgsPalLayerSettings.Curved
    pal.lineSettings().setPlacementFlags(QgsLabeling.OnLine)
    pal.lineSettings().setMergeLines(True)
    pal.repeatDistance = 70
    pal.repeatDistanceUnit = QgsUnitTypes.RenderMillimeters
    pal.maxCurvedCharAngleIn = 22
    pal.maxCurvedCharAngleOut = -22
    tf = QgsTextFormat()
    tf.setFont(_font(size))
    tf.setSize(size)
    tf.setSizeUnit(QgsUnitTypes.RenderPoints)
    tf.setColor(QColor(color))
    buf = QgsTextBufferSettings()
    buf.setEnabled(True)
    buf.setSize(0.45)
    buf.setColor(QColor(halo))
    tf.setBuffer(buf)
    pal.setFormat(tf)
    lay.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    lay.setLabelsEnabled(True)
    return lay


def tiles_layer(style):
    """Sfondo a piastrelle (OpenStreetMap standard attenuata, o foto
    satellitare). Serve internet quando la mappa viene disegnata."""
    url, name = TILES[style]
    lay = QgsRasterLayer("type=xyz&url=%s&zmax=19&zmin=0" % url, name, "wms")
    if style == "osm" and lay.isValid():
        try:  # colori attenuati: i temi sopra restano leggibili
            lay.hueSaturationFilter().setSaturation(-45)
            lay.brightnessFilter().setBrightness(12)
            lay.brightnessFilter().setContrast(-8)
        except Exception:
            pass
    return lay


def _veil(layer, rgba):
    layer.setRenderer(QgsInvertedPolygonRenderer(QgsSingleSymbolRenderer(
        QgsFillSymbol.createSimple({"color": rgba, "outline_style": "no"}))))


def _outline(layer, inner, outer):
    sym = QgsFillSymbol()
    sym.deleteSymbolLayer(0)
    for col, wd in ((outer, 1.5), (inner, 0.55)):
        sl = QgsSimpleLineSymbolLayer(QColor(col), wd)
        sl.setPenJoinStyle(Qt.RoundJoin)
        sym.appendSymbolLayer(sl)
    layer.setRenderer(QgsSingleSymbolRenderer(sym))


def apply_map_style(out, res, style, base=None, label_size="medi"):
    """Aggiunge la base dello stile e adatta i temi: sopra una base chiara
    le celle e le isocrone si fondono «in moltiplicazione» (la città si
    vede attraverso il colore), sopra la foto sono semitrasparenti."""
    if style not in ("chiara", "osm", "satellite"):
        return
    size = dict((k, v) for k, _l, v in LABEL_SIZES).get(label_size, 4.8)
    cells = [out[k] for k in ("walk", "ptal", "f15", "demo") if k in out]
    if style in ("chiara", "osm"):
        for lay in cells:
            lay.setBlendMode(QPainter.CompositionMode_Multiply)
            lay.setOpacity(0.74)
        if "iso" in out:
            out["iso"].setBlendMode(QPainter.CompositionMode_Multiply)
            out["iso"].setOpacity(0.7)
    if style == "chiara":
        out.update(base_layers(res, base))
        _veil(out["maschera"], "246,245,242,115")
        col, halo = LAND["label"], LAND["halo"]
    elif style == "osm":
        out["tiles"] = tiles_layer("osm")
        _veil(out["maschera"], "255,255,255,105")
        return   # i nomi delle vie sono già nella mappa di sfondo
    else:
        out["tiles"] = tiles_layer("satellite")
        for lay in cells:
            lay.setOpacity(0.55)
        if "iso" in out:
            out["iso"].setOpacity(0.5)
        _outline(out["area"], "#ffffff", "#111111")
        _veil(out["maschera"], "0,0,0,70")
        col, halo = "#ffffff", "#111111"
    out["b_labels_all"] = labels_layer(res, "Nomi delle vie", False, col,
                                       halo, size)
    out["b_labels_main"] = labels_layer(res, "Nomi delle vie principali",
                                        True, col, halo, size)


def build_layers(res, style="essenziale", base=None, label_size="medi"):
    """Layer delle mappe del report, in memoria e con lo stile.

    :param style: "chiara" (base vettoriale da OSM: serve `base` da
        osm_basemap), "osm" o "satellite" (sfondo a piastrelle),
        "essenziale" (solo strade di contesto).
    :return: dict chiave → layer (solo le sezioni calcolate).
    """
    out = {}
    area_g = QgsGeometry.fromWkt(res["area_wkt"])

    area = _mem("Polygon", "Area", [QgsField("nome", QVariant.String)])
    f = QgsFeature(area.fields())
    f.setGeometry(area_g)
    f.setAttributes([res["name"]])
    area.dataProvider().addFeatures([f])
    area.updateExtents()
    sym = QgsFillSymbol()
    sym.deleteSymbolLayer(0)
    for col, wd in (("#ffffff", 1.5), (FG, 0.55)):
        sl = QgsSimpleLineSymbolLayer(QColor(col), wd)
        sl.setPenJoinStyle(Qt.RoundJoin)
        sym.appendSymbolLayer(sl)
    area.setRenderer(QgsSingleSymbolRenderer(sym))
    out["area"] = area

    # velo bianco fuori dall'area: l'attenzione resta dentro
    mask = _mem("Polygon", "Fuori area (velo)", [QgsField("nome",
                                                          QVariant.String)])
    f = QgsFeature(mask.fields())
    f.setGeometry(area_g)
    f.setAttributes([res["name"]])
    mask.dataProvider().addFeatures([f])
    mask.updateExtents()
    mask.setRenderer(QgsInvertedPolygonRenderer(QgsSingleSymbolRenderer(
        QgsFillSymbol.createSimple({"color": "255,255,255,120",
                                    "outline_style": "no"}))))
    out["maschera"] = mask

    if res.get("context"):
        lay = _mem("MultiLineString", "Strade (contesto)",
                   [QgsField("id", QVariant.Int)])
        feats = []
        for k, row in enumerate(res["context"]):
            g = QgsGeometry.fromWkt(row[0])
            if g is None or g.isEmpty():
                continue
            g.convertToMultiType()
            ft = QgsFeature(lay.fields())
            ft.setGeometry(g)
            ft.setAttributes([k])
            feats.append(ft)
        lay.dataProvider().addFeatures(feats)
        lay.updateExtents()
        lay.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple({
            "line_color": "63,63,70,140", "line_width": "0.2",
            "capstyle": "round", "joinstyle": "round"})))
        out["contesto"] = lay

    rete = res.get("rete")
    if rete and rete.get("clip"):
        classe, styles = road_classes(rete)
        lay = _mem("MultiLineString", "Rete stradale",
                   [QgsField("tipo", QVariant.String),
                    QgsField("classe", QVariant.String)])
        feats = []
        for wkt, typ in rete["clip"]:
            g = QgsGeometry.fromWkt(wkt)
            g.convertToMultiType()
            ft = QgsFeature(lay.fields())
            ft.setGeometry(g)
            ft.setAttributes([str(typ), classe(typ)])
            feats.append(ft)
        lay.dataProvider().addFeatures(feats)
        lay.updateExtents()
        present = {ft["classe"] for ft in feats}
        cats = [QgsRendererCategory(lab, QgsLineSymbol.createSimple({
            "line_color": col, "line_width": str(wd), "capstyle": "round",
            "joinstyle": "round"}), lab)
            for lab, col, wd in styles if lab in present]
        rend = QgsCategorizedSymbolRenderer("classe", cats)
        try:  # strade importanti sopra le altre
            rend.setUsingSymbolLevels(True)
            for i, cat in enumerate(rend.categories()):
                for sl in cat.symbol().symbolLayers():
                    sl.setRenderingPass(len(cats) - i)
        except Exception:
            pass
        lay.setRenderer(rend)
        out["rete"] = lay

    if res.get("walk"):
        lay = gtfs_layers.build_walkability_layer(
            res["cells"], res["walk"]["cells"], name="Camminabilità")
        rngs = quantile_ranges([c["walkability"]
                                for c in res["walk"]["cells"]])
        cols = INDEX_COLORS if len(rngs) == 5 else [
            INDEX_COLORS[int(round(i * 4.0 / max(1, len(rngs) - 1)))]
            for i in range(len(rngs))]
        lay.setRenderer(QgsGraduatedSymbolRenderer("walkability", [
            QgsRendererRange(lo, hi, _fill(c), "%s – %s" % (fmt(lo, 0),
                                                            fmt(hi, 0)))
            for (lo, hi), c in zip(rngs, cols)]))
        lay.setOpacity(0.9)
        out["walk"] = lay

    tp = res.get("tp")
    if tp:
        lay = gtfs_layers.build_ptal_grid_layer(res["cells"], tp["cells"],
                                                name="PTAL")
        present = {c["band"] for c in tp["cells"]}
        lay.setRenderer(QgsCategorizedSymbolRenderer("ptal", [
            QgsRendererCategory(b, _fill(col), "PTAL " + b)
            for b, col in gtfs_layers.PTAL_COLORS if b in present]))
        lay.setOpacity(0.9)
        out["ptal"] = lay
        lay = _mem("Point", "Fermate", [
            QgsField("fermata", QVariant.String),
            QgsField("linee", QVariant.Int),
            QgsField("corse_h", QVariant.Double)])
        feats = []
        for sid, la, lo, nl, fh in tp.get("stops", []):
            ft = QgsFeature(lay.fields())
            ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lo, la)))
            ft.setAttributes([str(sid), int(nl), round(float(fh), 1)])
            feats.append(ft)
        lay.dataProvider().addFeatures(feats)
        lay.updateExtents()
        lay.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "#ffffff", "outline_color": FG,
            "outline_width": "0.45", "size": "2.3"})))
        out["fermate"] = lay

    iso = res.get("iso")
    if iso and iso.get("bands"):
        bands = sorted(iso["bands"], key=lambda b: b["t"])
        items = [(0, b["t"], QgsGeometry.fromWkt(b["wkt"]))
                 for b in reversed(bands)]
        lay = isochrones.layer_from_band_geoms(
            items, res["params"]["walk_kmh"], "Piedi", "polygon",
            name="Isocrone a piedi")
        step = 2 if len(bands) <= 3 else 1
        lay.setRenderer(QgsCategorizedSymbolRenderer("time_min", [
            QgsRendererCategory(b["t"], _fill(
                ISO_COLORS[min(i * step, len(ISO_COLORS) - 1)], "#ffffff",
                0.25), "entro %g min" % b["t"])
            for i, b in enumerate(bands)]))
        lay.setOpacity(0.8)
        out["iso"] = lay
        lay = _mem("Point", "Centro dell'area", [QgsField("nome",
                                                          QVariant.String)])
        ft = QgsFeature(lay.fields())
        la, lo = iso["centre"]
        ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lo, la)))
        ft.setAttributes(["centro"])
        lay.dataProvider().addFeatures([ft])
        lay.updateExtents()
        lay.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
            "name": "circle", "color": FG, "outline_color": "#ffffff",
            "outline_width": "0.7", "size": "3.2"})))
        out["centro"] = lay

    f15 = res.get("f15")
    if f15:
        lay = fifteen.build_layer(
            f15["categories"], f15["summary"], res["params"]["f15_min"],
            cells=res["cells"],
            name="Città dei %g minuti" % res["params"]["f15_min"])
        vals = [s["indice"] for s in f15["summary"]]
        lay.setRenderer(QgsGraduatedSymbolRenderer("indice", [
            QgsRendererRange(lo, hi, _fill(col), lab)
            for lo, hi, col, lab in F15_CLASSES
            if any(lo <= v <= hi for v in vals)]))
        lay.setOpacity(0.9)
        out["f15"] = lay

    serv = res.get("servizi")
    if serv:
        lay = _mem("Point", "Servizi", [QgsField("categoria",
                                                 QVariant.String)])
        feats = []
        for la, lo, cc in serv["points"]:
            ft = QgsFeature(lay.fields())
            ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lo, la)))
            ft.setAttributes([cc])
            feats.append(ft)
        lay.dataProvider().addFeatures(feats)
        lay.updateExtents()
        lay.setRenderer(QgsCategorizedSymbolRenderer("categoria", [
            QgsRendererCategory(cc, QgsMarkerSymbol.createSimple({
                "name": "circle", "color": service_color(cc, i),
                "outline_color": "#ffffff", "outline_width": "0.3",
                "size": "2.3"}), cc)
            for i, (cc, n, _p) in enumerate(serv["rows"]) if n]))
        out["servizi"] = lay
    demo = res.get("demo")
    if demo and demo.get("sections"):
        lay = _mem("MultiPolygon", "Sezioni di censimento (ISTAT 2021)", [
            QgsField("sez21_id", QVariant.LongLong),
            QgsField("residenti", QVariant.Double),
            QgsField("ab_ettaro", QVariant.Double),
            QgsField("quota", QVariant.Double),
            QgsField("pct_0_14", QVariant.Double),
            QgsField("pct_65", QVariant.Double),
            QgsField("pct_stranieri", QVariant.Double),
            QgsField("pct_terziario", QVariant.Double),
            QgsField("pct_occupati", QVariant.Double)])
        feats = []
        for x in demo["sections"]:
            g = QgsGeometry.fromWkt(x["wkt"])
            if g is None or g.isEmpty():
                continue
            g.convertToMultiType()
            ft = QgsFeature(lay.fields())
            ft.setGeometry(g)
            ft.setAttributes(
                [x["id"], round(x["pop"] * x["quota"], 1)]
                + [None if v is None else round(v, 2) for v in (
                    x["dens_ha"], x["quota"], x["pct_0_14"], x["pct_65"],
                    x["pct_stran"], x["pct_laurea"], x["occ"])])
            feats.append(ft)
        lay.dataProvider().addFeatures(feats)
        lay.updateExtents()
        rngs = quantile_ranges([x["dens_ha"] for x in demo["sections"]
                                if x["dens_ha"]])
        cols = DEMO_COLORS if len(rngs) == 5 else [
            DEMO_COLORS[int(round(i * 4.0 / max(1, len(rngs) - 1)))]
            for i in range(len(rngs))]
        lay.setRenderer(QgsGraduatedSymbolRenderer("ab_ettaro", [
            QgsRendererRange(lo, hi, _fill(c), "%s – %s" % (fmt(lo, 0),
                                                            fmt(hi, 0)))
            for (lo, hi), c in zip(rngs, cols)]))
        lay.setOpacity(0.9)
        out["demo"] = lay
    apply_map_style(out, res, style, base, label_size)
    return out


def legend_items(layer):
    """[(etichetta, colore, tipo)] dalle classi del renderer del layer."""
    kind = {QgsWkbTypes.PointGeometry: "point",
            QgsWkbTypes.LineGeometry: "line"}.get(layer.geometryType(),
                                                  "fill")
    out = []
    for it in layer.renderer().legendSymbolItems():
        sym = it.symbol()
        if sym is None:
            continue
        out.append((it.label() or layer.name(), sym.color().name(), kind))
    return out


# ------------------------------------------------------------------ layout
class ReportBuilder(object):
    """Costruisce il layout di stampa del report."""

    def __init__(self, project, res, layers, meta, logo=None,
                 style="essenziale", labels="auto"):
        self.project = project
        self.res = res
        self.layers = layers
        self.style = style if style in MAP_BG else "essenziale"
        self.labels = labels
        self.meta = meta  # dict: version, date, sources (lista di testi)
        self.logo = logo
        self.layout = QgsPrintLayout(project)
        self.layout.initializeDefaults()
        pc = self.layout.pageCollection()
        while pc.pageCount():   # la pagina orizzontale di default
            pc.deletePage(0)
        self.layout.setName("Report – %s" % res["name"])
        self.utm = QgsCoordinateReferenceSystem(res["utm"])
        self.area = QgsGeometry.fromWkt(res["area_wkt"])
        self.pages = []      # (titolo, indice pagina)
        self._foot = []      # etichette «pagina / totale»
        self._bag = None
        self._toc_y = 240.0

    # -------------------------------------------------------- primitive
    def _add(self, item):
        self.layout.addLayoutItem(item)
        if self._bag is not None:
            self._bag.append(item)

    @contextmanager
    def group(self):
        """Gli elementi creati nel blocco diventano un gruppo: nel
        compositore una scheda si sposta in un pezzo solo."""
        if self._bag is not None:
            yield
            return
        self._bag = []
        try:
            yield
        finally:
            items, self._bag = self._bag, None
            if len(items) > 1:
                try:
                    self.layout.groupItems(items)
                except Exception:
                    pass

    def _place(self, item, page, x, y, w, h):
        item.attemptMove(QgsLayoutPoint(x, y, MM), True, False, page)
        item.attemptResize(QgsLayoutSize(w, h, MM))

    def text(self, p, x, y, w, h, s, size=8.0, weight="regular", color=FG,
             align="l", valign="t", spacing=0.0):
        lab = QgsLayoutItemLabel(self.layout)
        lab.setText(str(s))
        try:
            tf = QgsTextFormat()
            tf.setFont(_font(size, weight, spacing))
            tf.setSize(size)
            tf.setSizeUnit(QgsUnitTypes.RenderPoints)
            tf.setColor(QColor(color))
            lab.setTextFormat(tf)
        except AttributeError:  # QGIS < 3.24
            lab.setFont(_font(size, weight, spacing))
            lab.setFontColor(QColor(color))
        lab.setHAlign({"l": Qt.AlignLeft, "r": Qt.AlignRight,
                       "c": Qt.AlignHCenter}[align])
        lab.setVAlign({"t": Qt.AlignTop, "m": Qt.AlignVCenter,
                       "b": Qt.AlignBottom}[valign])
        lab.setMarginX(0)
        lab.setMarginY(0)
        self._add(lab)
        self._place(lab, p, x, y, w, h)
        return lab

    def para(self, p, x, y, w, s, size=7.8, color=FG, weight="regular"):
        """Testo a capo automatico; ritorna l'altezza occupata."""
        n = len(wrap(s, size, w - 0.5, weight))
        h = n * line_h(size) + 0.8
        self.text(p, x, y, w, h + 1.5, s, size, weight, color)
        return h

    def box(self, p, x, y, w, h, fill=CARD, stroke=None, radius=0.0,
            sw=0.25, ellipse=False):
        sh = QgsLayoutItemShape(self.layout)
        sh.setShapeType(QgsLayoutItemShape.Ellipse if ellipse
                        else QgsLayoutItemShape.Rectangle)
        props = {"color": fill, "outline_style": "no"} if stroke is None \
            else {"color": fill, "outline_color": stroke,
                  "outline_width": str(sw), "joinstyle": "round"}
        sh.setSymbol(QgsFillSymbol.createSimple(props))
        if radius and not ellipse:
            sh.setCornerRadius(QgsLayoutMeasurement(radius, MM))
        self._add(sh)
        self._place(sh, p, x, y, max(w, 0.05), max(h, 0.05))
        return sh

    def card(self, p, x, y, w, h, fill=CARD):
        return self.box(p, x, y, w, h, fill, BORDER, 2.2, 0.25)

    def hline(self, p, x, y, w, color=BORDER, t=0.2):
        return self.box(p, x, y, w, t, color)

    def picture(self, p, x, y, w, h, path):
        pic = QgsLayoutItemPicture(self.layout)
        pic.setPicturePath(path)
        pic.setResizeMode(QgsLayoutItemPicture.Zoom)
        self._add(pic)
        self._place(pic, p, x, y, w, h)
        return pic

    def badge(self, p, x, y, s, bg, fg, size=6.2, anchor="l"):
        w = text_w(s, size, "semibold") + 4.6
        h = 4.3
        if anchor == "r":
            x -= w
        self.box(p, x, y, w, h, bg, None, h / 2.0)
        self.text(p, x, y - 0.15, w, h, s, size, "semibold", fg, "c", "m")
        return w

    # -------------------------------------------------------- componenti
    def stat(self, p, x, y, w, h, title, value, note="", light=None,
             vsize=15.0):
        """Scheda con un numero: etichetta piccola, valore grande, nota."""
        with self.group():
            self.card(p, x, y, w, h)
            bw = 0.0
            if light in BADGE:
                bg, fg, word = BADGE[light]
                bw = self.badge(p, x + w - 3.2, y + 3.0, word, bg, fg,
                                anchor="r") + 1.5
            self.text(p, x + 3.6, y + 3.2, w - 7.2 - bw, 4.2,
                      elide(title, 7.0, w - 7.2 - bw, "medium"), 7.0,
                      "medium", MUTED, valign="m")
            size = vsize
            while size > 8.5 and text_w(value, size, "bold") > w - 7.2:
                size -= 0.5
            self.text(p, x + 3.6, y + 8.2, w - 7.2, 8.0, value, size, "bold",
                      FG, valign="m")
            if note:
                lines = wrap(note, 6.6, w - 7.4)[:2]
                if len(lines) == 2:
                    lines[1] = elide(lines[1], 6.6, w - 7.4)
                self.text(p, x + 3.6, y + 17.0, w - 7.2, h - 17.5,
                          "\n".join(lines), 6.6, "regular", MUTED)

    def stats(self, p, y, cards, h=25.0):
        """Riga di schede numeriche a tutta larghezza; ritorna la y sotto."""
        n = max(1, len(cards))
        w = (CW - GAP * (n - 1)) / n
        for i, c in enumerate(cards):
            self.stat(p, M + i * (w + GAP), y, w, h, c[0], c[1],
                      c[2] if len(c) > 2 else "",
                      c[3] if len(c) > 3 else None)
        return y + h + GAP

    def titled(self, p, x, y, w, h, title):
        """Scheda con titolo; ritorna (x, y, w) dell'area interna."""
        self.card(p, x, y, w, h)
        self.text(p, x + 4, y + 3.4, w - 8, 4.6, title, 8.6, "semibold", FG,
                  valign="m")
        return x + 4, y + 10.2, w - 8

    def table(self, p, x, y, w, headers, rows, widths, aligns=None,
              row_h=5.5, size=7.4, bar_col=None, bar_max=100.0,
              bar_color=ACCENT, bold_last=False):
        """Tabella senza griglia verticale. Una colonna (bar_col) può
        essere una barra: il valore della cella è allora un numero."""
        aligns = aligns or ["l"] * len(headers)
        cx = x
        for hd, wd, al in zip(headers, widths, aligns):
            if hd:
                self.text(p, cx, y, wd - 1, row_h,
                          elide(hd, 6.4, wd - 1, "semibold"), 6.4,
                          "semibold", MUTED, al, "m")
            cx += wd
        self.hline(p, x, y + row_h, w, RULE, 0.25)
        for r, row in enumerate(rows):
            yy = y + row_h * (r + 1) + 0.3
            cx = x
            last = bold_last and r == len(rows) - 1
            for c, (v, wd) in enumerate(zip(row, widths)):
                al = aligns[c]
                if c == bar_col:
                    bw = wd - 4
                    self.box(p, cx + 2, yy + row_h / 2 - 0.9, bw, 1.8,
                             SUBTLE, None, 0.9)
                    if v:
                        fw = max(1.8, bw * min(1.0, v / float(bar_max)))
                        self.box(p, cx + 2, yy + row_h / 2 - 0.9, fw, 1.8,
                                 bar_color, None, 0.9)
                elif v is not None:
                    wt = "semibold" if last else "regular"
                    self.text(p, cx, yy, wd - 1, row_h,
                              elide(v, size, wd - 1, wt), size, wt, FG, al,
                              "m")
                cx += wd
            if r < len(rows) - 1:
                self.hline(p, x, yy + row_h - 0.1, w, BORDER, 0.15)
        return row_h * (len(rows) + 1) + 0.6

    def bars(self, p, x, y, w, rows, vmax=None, label_w=40.0, value_w=20.0,
             extra_w=0.0, row_h=6.2, ref=None, ref_label=""):
        """Barre orizzontali: [(etichetta, valore o None, testo, colore,
        testo in più)]. `ref` disegna una linea di riferimento."""
        vals = [r[1] for r in rows if r[1] is not None]
        vmax = vmax or max(vals + [ref or 0.0, 1e-9])
        tx = x + label_w
        tw = w - label_w - value_w - extra_w
        top = y + (4.4 if ref is not None and ref_label else 0.0)
        for i, r in enumerate(rows):
            yy = top + i * row_h
            lab, v, txt, col = r[0], r[1], r[2], r[3]
            self.text(p, x, yy, label_w - 2, row_h,
                      elide(lab, 7.3, label_w - 2), 7.3, "regular", FG,
                      "l", "m")
            self.box(p, tx, yy + row_h / 2 - 1.3, tw, 2.6, SUBTLE, None, 1.3)
            if v:
                fw = max(2.6, tw * min(1.0, v / float(vmax)))
                self.box(p, tx, yy + row_h / 2 - 1.3, fw, 2.6, col, None,
                         1.3)
            self.text(p, tx + tw + 1, yy, value_w - 1, row_h, txt, 7.3,
                      "semibold", FG if v is not None else MUTED, "r", "m")
            if extra_w and len(r) > 4:
                self.text(p, tx + tw + value_w + 1, yy, extra_w - 1, row_h,
                          r[4], 6.8, "regular", MUTED, "r", "m")
        h = len(rows) * row_h
        if ref is not None and ref <= vmax:
            rx = tx + tw * ref / float(vmax)
            self.box(p, rx - 0.15, top - 0.4, 0.3, h + 0.8, FG)
            if ref_label:
                self.text(p, rx - 20, y - 0.4, 40, 4, ref_label, 6.2,
                          "semibold", FG, "c", "m")
        return (top - y) + h

    def stacked(self, p, x, y, w, parts, h=4.6):
        """Barra unica divisa in parti: [(etichetta, valore, colore)]."""
        tot = sum(v for _l, v, _c in parts) or 1.0
        cx = x
        gap = 0.45
        for _l, v, col in parts:
            pw = w * v / tot
            if pw > gap + 0.2:
                self.box(p, cx, y, pw - gap, h, col, None, 0.9)
            cx += pw
        return h

    def pyramid(self, p, x, y, w, rows, row_h=3.3):
        """Piramide delle età: [(classe, maschi, femmine)] dalla più
        giovane; i più anziani in alto. Ritorna l'altezza occupata."""
        tot = float(sum(m + f for _l, m, f in rows) or 1.0)
        vmax = max([max(m, f) for _l, m, f in rows] + [1e-9])
        lw, vw = 12.0, 9.5           # classi al centro, percentuali ai lati
        bw = (w - lw) / 2.0 - vw     # lunghezza massima di una barra
        cx = x + w / 2.0
        males = sum(m for _l, m, _f in rows)
        for lab, v, col, x0, al in (
                ("Maschi", males, SEX_COLORS[0], x, "r"),
                ("Femmine", tot - males, SEX_COLORS[1], cx + lw / 2.0, "l")):
            self.text(p, x0, y, w / 2.0 - lw / 2.0, 4.2, "%s · %s %%" % (
                lab, fmt(100.0 * v / tot, 1)), 6.8, "semibold", col, al, "m")
        top = y + 5.2
        bh = row_h - 0.9
        for i, (lab, m, f) in enumerate(reversed(rows)):
            yy = top + i * row_h
            self.text(p, cx - lw / 2.0, yy, lw, row_h, lab, 5.9, "regular",
                      FG, "c", "m")
            mw = bw * m / vmax
            fw = bw * f / vmax
            if mw > 0.15:
                self.box(p, cx - lw / 2.0 - mw, yy + 0.45, mw, bh,
                         SEX_COLORS[0], None, 0.6)
            if fw > 0.15:
                self.box(p, cx + lw / 2.0, yy + 0.45, fw, bh, SEX_COLORS[1],
                         None, 0.6)
            self.text(p, cx - lw / 2.0 - mw - vw - 0.8, yy, vw, row_h,
                      fmt(100.0 * m / tot, 1), 5.6, "regular", MUTED, "r",
                      "m")
            self.text(p, cx + lw / 2.0 + fw + 0.8, yy, vw, row_h,
                      fmt(100.0 * f / tot, 1), 5.6, "regular", MUTED, "l",
                      "m")
        return 5.2 + len(rows) * row_h

    def chips_height(self, items, w, size=6.9, row_h=4.8, prefix=""):
        cx = (text_w(prefix, size, "semibold") + 3.0) if prefix else 0.0
        rows = 1
        for lab, _c, _k in items:
            iw = 6.2 + text_w(lab, size) + 4.0
            if cx + iw > w and cx > 0:
                cx, rows = 0.0, rows + 1
            cx += iw
        return rows * row_h

    def chips(self, p, x, y, w, items, size=6.9, row_h=4.8, prefix=""):
        """Legenda in riga: tassello colorato + etichetta, a capo."""
        cx, cy = x, y
        if prefix:
            pw = text_w(prefix, size, "semibold") + 3.0
            self.text(p, cx, cy, pw, row_h, prefix, size, "semibold", MUTED,
                      "l", "m")
            cx += pw
        for lab, col, kind in items:
            lw = text_w(lab, size)
            iw = 6.2 + lw + 4.0
            if cx + iw > x + w and cx > x:
                cx, cy = x, cy + row_h
            mid = cy + row_h / 2.0
            if kind == "line":
                self.box(p, cx, mid - 0.5, 4.4, 1.0, col, None, 0.5)
            elif kind == "point":
                pale = QColor(col).lightness() > 235
                self.box(p, cx + 0.9, mid - 1.3, 2.6, 2.6, col,
                         FG if pale else None, 0, 0.35, ellipse=True)
            else:
                self.box(p, cx + 0.6, mid - 1.5, 3.0, 3.0, col, None, 0.7)
            self.text(p, cx + 5.6, cy, lw + 2, row_h, lab, size, "regular",
                      FG, "l", "m")
            cx += iw
        return cy - y + row_h

    # -------------------------------------------------------- mappe
    def extent(self, keys=(), pad=0.08):
        ct = QgsCoordinateTransform(WGS84, self.utm, self.project)
        r = ct.transformBoundingBox(self.area.boundingBox())
        for k in keys:
            lay = self.layers.get(k)
            if lay is not None and lay.featureCount():
                lay.updateExtents()
                r.combineExtentWith(ct.transformBoundingBox(lay.extent()))
        d = pad * max(r.width(), r.height(), 50.0)
        return QgsRectangle(r.xMinimum() - d, r.yMinimum() - d,
                            r.xMaximum() + d, r.yMaximum() + d)

    def stack(self, kind, theme=(), top=(), mask=True):
        """Layer di una mappa, dall'alto in basso, secondo lo stile.

        :param kind: "cells" (celle), "iso" (isocrone), "lines" (rete),
            "points" (servizi): decide dove vanno i nomi delle vie e, nello
            stile essenziale, le strade di contesto.
        :param theme: layer del tema; top: punti da tenere sopra a tutto.
        """
        keys = list(top) + ["area"] + (["maschera"] if mask else [])
        st = self.style
        if st == "essenziale":
            if kind in ("cells", "iso"):
                return keys + ["contesto"] + list(theme)
            return keys + list(theme) + ["contesto"]
        mode = self.labels
        if st != "osm" and mode != "nessuno":
            main = mode == "principali" or (mode == "auto" and kind in (
                "cells", "iso"))
            keys.append("b_labels_main" if main else "b_labels_all")
        keys += list(theme)
        return keys + (BASE_STACK if st == "chiara" else ["tiles"])

    def map(self, p, x, y, w, h, keys, ext_keys=(), pad=0.08):
        m = QgsLayoutItemMap(self.layout)
        self.layout.addLayoutItem(m)
        self._place(m, p, x, y, w, h)
        m.setCrs(self.utm)
        m.setLayers([self.layers[k] for k in keys if k in self.layers])
        m.setKeepLayerSet(True)
        m.setBackgroundColor(QColor(MAP_BG[self.style]))
        m.setFrameEnabled(False)
        # angoli arrotondati come la scheda: la mappa è ritagliata su una
        # forma invisibile
        try:
            clip = self.box(p, x, y, w, h, "255,255,255,0", None, 1.7)
            cs = m.itemClippingSettings()
            cs.setEnabled(True)
            cs.setSourceItem(clip)
        except Exception:
            pass
        # estensione con le proporzioni del riquadro (zoomToExtent su una
        # mappa nuova divide per l'estensione iniziale, vuota → mappa vuota)
        r = self.extent(ext_keys, pad)
        ratio = w / float(h)
        ew, eh = r.width(), r.height()
        if ew / eh > ratio:
            eh = ew / ratio
        else:
            ew = eh * ratio
        cx, cy = r.center().x(), r.center().y()
        m.setExtent(QgsRectangle(cx - ew / 2, cy - eh / 2, cx + ew / 2,
                                 cy + eh / 2))
        self._place(m, p, x, y, w, h)
        sb = QgsLayoutItemScaleBar(self.layout)
        sb.setStyle("Single Box")
        sb.setLinkedMap(m)
        self.layout.addLayoutItem(sb)
        sb.applyDefaultSize(QgsUnitTypes.DistanceMeters)
        try:
            sb.setNumberOfSegments(2)
            sb.setNumberOfSegmentsLeft(0)
            sb.setHeight(0.9)
            sb.setLabelBarSpace(0.9)
            sb.setBoxContentSpace(1.2)
            tf = QgsTextFormat()
            tf.setFont(_font(6.0))
            tf.setSize(6.0)
            tf.setSizeUnit(QgsUnitTypes.RenderPoints)
            tf.setColor(QColor(FG))
            sb.setTextFormat(tf)
            sb.setFillColor(QColor(FG))
            sb.setFillColor2(QColor("#ffffff"))
            sb.setLineWidth(0.15)
            sb.setLineColor(QColor(FG))
        except Exception:
            pass
        sb.setBackgroundEnabled(True)
        sb.setBackgroundColor(QColor(255, 255, 255, 215))
        try:   # il riquadro segue i due segmenti, non i quattro di default
            sb.resizeToMinimumWidth()
        except Exception:
            pass
        sb.update()
        sb.attemptMove(QgsLayoutPoint(x + 2.5, y + h - 9.5, MM), True, False,
                       p)
        north = _north_arrow()
        if north:
            self.box(p, x + w - 9.5, y + 2.5, 7, 7, "#ffffff", BORDER, 0,
                     0.2, ellipse=True)
            self.picture(p, x + w - 8.4, y + 3.6, 4.8, 4.8, north)
        credit = MAP_CREDIT.get(self.style)
        if credit:   # attribuzione della base, in basso a destra
            cw = text_w(credit, 5.2) + 3.0
            self.box(p, x + w - cw - 2.0, y + h - 5.6, cw, 3.6,
                     "255,255,255,205", None, 1.8)
            self.text(p, x + w - cw - 2.0, y + h - 5.7, cw, 3.6, credit,
                      5.2, "regular", "#52525b", "c", "m")
        return m

    def map_card(self, p, y, h, keys, legend=(), ext_keys=(), pad=0.08,
                 prefix=""):
        """Scheda con la mappa e, sotto, la legenda in riga. Ritorna la y
        sotto la scheda."""
        items = []
        for k in legend:
            if k in self.layers:
                items += legend_items(self.layers[k])
        lh = (self.chips_height(items, CW - 8, prefix=prefix) + 3.2) \
            if items else 0.0
        self.card(p, M, y, CW, h)
        self.map(p, M + 1.6, y + 1.6, CW - 3.2, h - 3.2 - lh, keys, ext_keys,
                 pad)
        if items:
            with self.group():
                self.hline(p, M + 0.2, y + h - lh - 1.6, CW - 0.4, BORDER,
                           0.2)
                self.chips(p, M + 4, y + h - lh - 0.2, CW - 8, items,
                           prefix=prefix)
        return y + h + GAP

    def split(self, y, need, map_max=162.0, map_min=96.0):
        """Altezza della scheda della mappa, lasciando sotto `need` mm per
        le schede in basso (alte quanto il loro contenuto)."""
        return min(map_max, max(map_min, BOTTOM - y - need - GAP))

    def gauges(self, p, x, y, w, cards, row_h=9.4):
        """Confronto con le soglie: una riga per indicatore, con le zone
        critico / migliorabile / buono e un segno sul valore."""
        lw, vw, bw = 50.0, 22.0, 24.0
        tx, tw = x + lw, w - lw - vw - bw
        for i, cd in enumerate(cards):
            yy = y + i * row_h
            good, mid, higher = area_report.THRESHOLDS[cd["lkey"]]
            v = float(cd["raw"])
            pct = cd["lkey"] in ("ptal4_share", "f15_index",
                                 "f15_full_share")
            if higher:
                vmax = 100.0 if pct else max(v * 1.1, good * 2.0)
                zones = [(0.0, mid, "rosso"), (mid, good, "giallo"),
                         (good, vmax, "verde")]
            else:
                vmax = max(v * 1.15, mid * 2.0)
                zones = [(0.0, good, "verde"), (good, mid, "giallo"),
                         (mid, vmax, "rosso")]
            self.text(p, x, yy, lw - 3, 5.2, elide(cd["title"], 7.4, lw - 3),
                      7.4, "regular", FG, valign="m")
            for lo, hi, lv in zones:
                x0 = tx + tw * lo / vmax
                x1 = tx + tw * min(hi, vmax) / vmax
                if x1 - x0 > 0.5:
                    self.box(p, x0 + 0.2, yy + 1.4, x1 - x0 - 0.4, 2.4,
                             ZONE[lv], None, 1.0)
            for t in (good, mid):
                self.text(p, tx + tw * t / vmax - 8, yy + 4.5, 16, 3.4,
                          fmt(t, 0), 5.6, "regular", MUTED, "c", "m")
            mx = tx + tw * min(v, vmax) / vmax
            self.box(p, mx - 1.7, yy + 0.9, 3.4, 3.4, FG, "#ffffff", 0, 0.5,
                     ellipse=True)
            self.text(p, tx + tw + 1, yy, vw - 2, 5.2, cd["value"], 7.6,
                      "semibold", FG, "r", "m")
            if cd.get("light") in BADGE:
                bg, fg, word = BADGE[cd["light"]]
                self.badge(p, x + w, yy + 0.45, word, bg, fg, anchor="r")
        return len(cards) * row_h

    # -------------------------------------------------------- pagine
    def page(self, title, desc=""):
        pg = QgsLayoutItemPage(self.layout)
        pg.setPageSize("A4", QgsLayoutItemPage.Portrait)
        self.layout.pageCollection().addPage(pg)
        p = self.layout.pageCollection().pageCount() - 1
        if title:
            self.text(p, M, 10.4, 140, 4, ("Report · %s" % self.res[
                "name"]).upper(), 6.2, "semibold", MUTED, spacing=0.5)
            self.text(p, M, 15.2, CW, 9.5, title, 18, "bold", FG, valign="m")
            if desc:
                self.text(p, M, 25.6, CW, 8.5, desc, 8.0, "regular", MUTED)
            self.pages.append((title, p))
        self.hline(p, M, 284.6, CW, BORDER, 0.2)
        self.text(p, M, 286.4, 130, 4, "MIC - Utilities %s · %s" % (
            self.meta.get("version", ""), self.meta.get("date", "")), 6.2,
            "regular", MUTED, valign="m")
        self._foot.append((p, self.text(p, PAGE_W - M - 40, 286.4, 40, 4, "",
                                        6.2, "semibold", MUTED, "r", "m")))
        return p

    def build(self):
        r = self.res
        self.cover()
        self.summary()
        if r.get("demo"):
            self.page_demo()
        if r.get("rete"):
            self.page_rete()
        if r.get("walk"):
            self.page_walk()
        if r.get("tp"):
            self.page_tp()
        if r.get("iso"):
            self.page_iso()
        if r.get("f15"):
            self.page_f15()
        if r.get("servizi"):
            self.page_servizi()
        self.page_notes()
        n = self.layout.pageCollection().pageCount()
        for p, lab in self._foot:
            lab.setText("%d / %d" % (p + 1, n))
        self._contents()
        return self.layout

    def cover(self):
        r = self.res
        p = self.page("")
        if self.logo and os.path.exists(self.logo):
            self.picture(p, M, 13.5, 8.5, 8.5, self.logo)
        self.text(p, M + 11.5, 13.5, 80, 8.5, "MIC - Utilities", 9.5,
                  "semibold", FG, valign="m")
        self.badge(p, PAGE_W - M, 15.6, self.meta.get("date", ""), SUBTLE,
                   "#3f3f46", 6.6, anchor="r")
        self.text(p, M, 33, CW, 5, "REPORT DELL'AREA", 7.2, "semibold",
                  ACCENT, spacing=0.8)
        size = 30.0
        while size > 16 and text_w(r["name"], size, "bold") > CW:
            size -= 1.0
        self.text(p, M, 38.5, CW, 15, r["name"], size, "bold", FG,
                  valign="m")
        secs = [area_report.SECTION_LABEL[k].lower()
                for k, _l in area_report.SECTIONS if r.get(k)]
        self.text(p, M, 55, CW, 6, "Analisi di " + ", ".join(secs) + ".",
                  9.2, "regular", MUTED)
        y = self.map_card(p, 66, 140, self.stack("lines", ["rete"]),
                          legend=["rete"], pad=0.14)
        by = {c["key"]: c for c in r.get("summary", [])}
        cards = [(by[k]["title"], by[k]["value"], by[k]["note"])
                 for k in ("area", "pop", "net", "int", "serv", "f15",
                           "ptal", "iso") if k in by][:4]
        self._toc_y = self.stats(p, y, cards, h=24.0)

    def _contents(self):
        """Indice in copertina (scritto alla fine: servono le pagine)."""
        p, y = 0, self._toc_y
        h = BOTTOM - y
        with self.group():
            x, yy, w = self.titled(p, M, y, CW, h, "Contenuto")
            half = (len(self.pages) + 1) // 2
            colw = (w - 6) / 2.0
            for i, (t, pg) in enumerate(self.pages):
                cx = x + (0 if i < half else colw + 6)
                cy = yy + (i if i < half else i - half) * 5.4
                self.text(p, cx, cy, 8, 5, "%02d" % (pg + 1), 7.4,
                          "semibold", ACCENT, valign="m")
                self.text(p, cx + 8, cy, colw - 8, 5, t, 7.8, "regular", FG,
                          valign="m")
            src = " · ".join(self.meta.get("sources", []))
            sy = yy + half * 5.4 + 2.0
            if src and sy + 8 < y + h:
                self.hline(p, x, sy, w, BORDER, 0.2)
                lines = wrap("Fonti: " + src, 6.6, w)[:max(1, int(
                    (y + h - sy - 3) // line_h(6.6)))]
                self.text(p, x, sy + 1.8, w, y + h - sy - 2.5,
                          "\n".join(lines), 6.6, "regular", MUTED)

    def summary(self):
        r = self.res
        p = self.page("Sintesi", "Gli indicatori principali dell'area. Il "
                      "giudizio confronta il valore con soglie indicative, "
                      "elencate nelle note.")
        y = TOP
        ins = r.get("insights") or {}
        lines = [(lv, lab, "; ".join(ins.get(lv) or []))
                 for lv, lab in (("verde", "Punti di forza"),
                                 ("giallo", "Da migliorare"),
                                 ("rosso", "Criticità")) if ins.get(lv)]
        if lines:
            tw = CW - 8 - 34
            hs = [max(5.2, len(wrap(t, 7.9, tw)) * line_h(7.9) + 1.8)
                  for _lv, _lab, t in lines]
            h = 12.5 + sum(hs) + 2.0
            with self.group():
                x, yy, w = self.titled(p, M, y, CW, h, "In sintesi")
                for (lv, lab, t), hh in zip(lines, hs):
                    self.box(p, x, yy + 1.15, 2.4, 2.4, DOT[lv], None, 0,
                             ellipse=True)
                    self.text(p, x + 4.5, yy, 29, 4.7, lab, 7.6, "semibold",
                              FG, valign="m")
                    self.text(p, x + 34, yy + 0.3, tw, hh,
                              t[:1].upper() + t[1:] + ".", 7.9, "regular",
                              FG)
                    yy += hh
            y += h + GAP
        cards = r.get("summary", [])
        cols = 3
        w = (CW - GAP * (cols - 1)) / cols
        h = 26.0
        for i, cd in enumerate(cards):
            self.stat(p, M + (i % cols) * (w + GAP),
                      y + (i // cols) * (h + GAP), w, h, cd["title"],
                      cd["value"], cd["note"], cd.get("light"), 16.0)
        y += ((len(cards) + cols - 1) // cols) * (h + GAP)
        judged = [c for c in cards if c.get("lkey") and c.get("raw")
                  is not None]
        gh = 10.2 + len(judged) * 9.4 + 2.5
        if judged and y + gh <= BOTTOM:
            with self.group():
                x, yy, w = self.titled(p, M, y, CW, gh, "Rispetto alle "
                                       "soglie")
                self.gauges(p, x, yy, w, judged)
            y += gh + GAP
        sk = r.get("skipped") or {}
        if sk and y + 8 <= BOTTOM:
            self.para(p, M, y, CW, "Sezioni non calcolate: " + "; ".join(
                "%s (%s)" % (area_report.SECTION_LABEL.get(k, k), v)
                for k, v in sk.items()) + ".", 7.2, MUTED)

    def page_demo(self):
        r = self.res
        d = r["demo"]
        pa, com = d["profile"], d["comune"]
        pc = com["profile"]
        pop = r.get("pop") or pa["pop"]
        p = self.page("Popolazione", "Chi abita nell'area secondo il "
                      "Censimento permanente ISTAT 2021, per sezione di "
                      "censimento. Delle sezioni a cavallo del confine "
                      "conta la parte dentro l'area.")

        def pct(v, dec=1):
            return "%s %%" % fmt(v, dec)
        nome = com["nome"]
        cards = [
            ("Residenti", fmt(pop, 0),
             "%s abitanti per km²" % fmt(pa.get("density"), 0)),
            ("Famiglie", fmt(pa["fam"], 0),
             "%s componenti in media" % fmt(pa.get("COMP_FAM"), 2))]
        jobs = r.get("jobs")
        if jobs:
            cards.append(("Addetti (2011)", fmt(jobs["total"], 0),
                          "%s ogni 100 residenti" % fmt(
                              100.0 * jobs["total"] / pop, 0)
                          if pop else "posti di lavoro"))
        cards += [
            ("65 anni e più", pct(pa.get("PCT_65P")),
             "%s: %s" % (nome, pct(pc.get("PCT_65P")))),
            ("Stranieri", pct(pa.get("PCT_STRAN")),
             "%s: %s" % (nome, pct(pc.get("PCT_STRAN"))))]
        y = self.stats(p, TOP, cards)
        h_mid, h_low = 71.0, 36.0
        y = self.map_card(p, y, self.split(y, h_mid + GAP + h_low),
                          self.stack("cells", ["demo"]), legend=["demo"],
                          prefix="Abitanti per ettaro")
        lw = 86.0
        with self.group():
            x, yy, w = self.titled(p, M, y, lw, h_mid, "Età e sesso (% dei "
                                   "residenti)")
            self.pyramid(p, x, yy - 1.2, w, pa["age"])
        with self.group():
            x, yy, w = self.titled(
                p, M + lw + GAP, y, CW - lw - GAP, h_mid,
                elide("Confronto con il comune di %s" % nome, 8.6,
                      CW - lw - GAP - 8, "semibold"))
            rows = [("%s%s" % (lab, " (%s)" % unit if unit else ""),
                     fmt(a, dec), fmt(c, dec))
                    for lab, a, c, unit, dec in d["compare"]]
            th = self.table(p, x, yy - 1, w, ["Indicatore", "Area",
                                              elide(nome, 6.4, 23,
                                                    "semibold")],
                            rows, [w - 42, 19, 23], ["l", "r", "r"],
                            row_h=5.3, size=7.2)
            if com.get("others"):
                self.text(p, x, yy - 1 + th + 0.4, w, 4.0, elide(
                    "L'area tocca più comuni: qui abita il %s %% dei "
                    "residenti." % fmt(100.0 * com["share"], 0), 6.2, w),
                    6.2, "regular", MUTED, valign="m")
        y += h_mid + GAP
        cw3 = (CW - 2 * GAP) / 3.0
        fam = list(pa["families"])
        fam = fam[:4] + [("5 o più", fam[4][1] + fam[5][1],
                          (fam[4][2] or 0) + (fam[5][2] or 0))]
        blocks = [("Famiglie per componenti", [
                      (lab.replace("componenti", "persone").replace(
                          "componente", "persona"), sh, pct(sh, 0),
                       DEMO_COLORS[3]) for lab, _n, sh in fam]),
                  ("Titolo di studio (9 anni e più)", [
                      (lab, sh, pct(sh, 0), ACCENT)
                      for lab, _n, sh in pa["education"]])]
        for i, (title, rows) in enumerate(blocks):
            with self.group():
                x, yy, w = self.titled(p, M + i * (cw3 + GAP), y, cw3,
                                       h_low, title)
                self.bars(p, x, yy - 0.6, w, rows, label_w=23, value_w=11,
                          row_h=4.6)
        with self.group():
            x, yy, w = self.titled(p, M + 2 * (cw3 + GAP), y, cw3, h_low,
                                   "Occupati di 15-64 anni")
            rows = [("Totale", pa.get("TASSO_OCC"),
                     pct(pa.get("TASSO_OCC"), 0), "#52525b"),
                    ("Maschi", pa.get("occ_m"), pct(pa.get("occ_m"), 0),
                     SEX_COLORS[0]),
                    ("Femmine", pa.get("occ_f"), pct(pa.get("occ_f"), 0),
                     SEX_COLORS[1])]
            ref = pc.get("TASSO_OCC")
            bh = self.bars(p, x, yy - 0.6, w, rows, vmax=100.0, label_w=17,
                           value_w=11, row_h=4.6, ref=ref,
                           ref_label="comune %s" % pct(ref, 0)
                           if ref is not None else "")
            self.text(p, x, yy + bh + 0.6, w, 7.0, "\n".join(wrap(
                "Sui residenti della stessa età; la linea è il valore del "
                "comune.", 6.2, w)[:2]), 6.2, "regular", MUTED)

    def page_rete(self):
        rete = self.res["rete"]
        rt = rete["ratios"]
        p = self.page("Rete stradale", "Le strade dell'area per tipo. Gli "
                      "incroci reali sono i punti in cui si incontrano "
                      "almeno tre strade: ponti e sottopassi non contano.")
        idn = rt.get("intersection_density_per_km2")
        y = self.stats(p, TOP, [
            ("Strade nell'area", "%s km" % fmt(rt.get("total_length_km"), 1),
             "lunghezza totale"),
            ("Densità della rete",
             "%s km/km²" % fmt(rt.get("density_km_per_km2"), 1),
             "chilometri di strade per km²"),
            ("Incroci reali", "%s /km²" % fmt(idn, 0),
             "%d incroci" % rt.get("junctions", 0),
             area_report.light("int_density", idn)),
            ("Vicoli ciechi", "%s %%" % fmt(rete.get("dead_end_share"), 0),
             "%d sui nodi della rete" % rt.get("dead_ends", 0),
             area_report.light("dead_end_share",
                               rete.get("dead_end_share")))])
        lw = 108.0
        tot = sum(rete["lengths"].values()) or 1.0
        items = list(rete["lengths"].items())
        nmax = 9
        top, rest = items[:nmax], items[nmax:]
        if len(rest) == 1:
            top, rest = items[:nmax + 1], []
        classe, styles = road_classes(rete)
        by = {}
        for t, v in rete["lengths"].items():
            by[classe(t)] = by.get(classe(t), 0.0) + v
        parts = [(lab, by[lab], col) for lab, col, _w in styles
                 if by.get(lab)]
        need = max(10.2 + (len(top) + (1 if rest else 0) + 1) * 5.5 + 3.0,
                   10.2 + 7.6 + len(parts) * 5.0 + 3.3 + 10.0 + 3.0)
        y = self.map_card(p, y, self.split(y, need),
                          self.stack("lines", ["rete"]), legend=["rete"])
        h = BOTTOM - y
        rows = [(str(t), fmt(v / 1000.0, 2), 100.0 * v / tot,
                 "%s %%" % fmt(100.0 * v / tot, 1)) for t, v in top]
        if rest:
            v = sum(x for _t, x in rest)
            rows.append(("altri %d tipi" % len(rest), fmt(v / 1000.0, 2),
                         100.0 * v / tot, "%s %%" % fmt(100.0 * v / tot, 1)))
        with self.group():
            x, yy, w = self.titled(p, M, y, lw, h, "Lunghezza per tipo")
            self.table(p, x, yy, w, ["Tipo (%s)" % (rete.get("type_field")
                                                    or "tutte"), "km", "",
                                     "quota"], rows,
                       [w - 62, 16, 30, 16], ["l", "r", "l", "r"],
                       bar_col=2, bar_max=max(r_[2] for r_ in rows),
                       bar_color="#3f3f46")
        with self.group():
            x, yy, w = self.titled(p, M + lw + GAP, y, CW - lw - GAP, h,
                                   "Composizione")
            yy += self.stacked(p, x, yy, w, parts) + 3.0
            for lab, v, col in parts:
                self.box(p, x, yy + 1.2, 2.6, 2.6, col, None, 0.6)
                self.text(p, x + 4.4, yy, w - 18, 5, elide(lab, 7.2, w - 18),
                          7.2, "regular", FG, valign="m")
                self.text(p, x + w - 14, yy, 14, 5,
                          "%s %%" % fmt(100.0 * v / tot, 0), 7.2, "semibold",
                          FG, "r", "m")
                yy += 5.0
            yy += 1.5
            self.hline(p, x, yy, w, BORDER, 0.2)
            yy += 1.8
            for lab, val in (
                    ("Nodi che sono incroci", "%s %%" % fmt(100.0 * rt.get(
                        "connected_node_ratio", 0.0), 0)),
                    ("Attraversamenti da verificare", "%d" % rt.get(
                        "unnoded_crossings", 0))):
                if yy + 5 > y + h - 2:
                    break
                self.text(p, x, yy, w - 12, 5, lab, 7.0, "regular", MUTED,
                          valign="m")
                self.text(p, x + w - 12, yy, 12, 5, val, 7.2, "semibold", FG,
                          "r", "m")
                yy += 5.0

    def page_walk(self):
        r = self.res
        w_ = r["walk"]
        cells = w_["cells"]
        p = self.page("Camminabilità", "Quanto la rete invita a camminare, "
                      "cella per cella: forma della rete, vicinanza dei "
                      "servizi%s." % (" e pendenza" if r.get("dem_used")
                                      else ""))
        idn = area_report._median([c["int_density"] for c in cells])
        cards = [("Indice medio", fmt(w_["mean_index"], 0),
                  "da 0 a 100, relativo fra le celle"),
                 ("Incroci per km²", fmt(idn, 0), "mediana delle celle"),
                 ("Collegamenti per nodo", fmt(w_.get("link_node"), 2),
                  "mediana; più alto = più scelte di percorso")]
        if w_.get("grade_mean") is not None:
            cards.append(("Pendenza media", "%s %%" % fmt(w_["grade_mean"],
                                                          1),
                          "delle strade, dal DEM",
                          area_report.light("grade_mean", w_["grade_mean"])))
        else:
            cards.append(("Celle analizzate", "%d" % len(cells),
                          "esagoni di %s m di raggio" % fmt(
                              r["params"]["cell_m"], 0)))
        y = self.stats(p, TOP, cards)
        lay = self.layers.get("walk")
        nr = len(lay.renderer().ranges()) if lay is not None else 5
        y = self.map_card(p, y, self.split(y, 10.2 + nr * 6.2 + 4.0),
                          self.stack("cells", ["walk"]), legend=["walk"],
                          prefix="Indice")
        h = BOTTOM - y
        lw = 104.0
        rows = []
        if lay is not None:
            rngs = list(lay.renderer().ranges())
            n = float(len(cells)) or 1.0
            for i, rg in enumerate(rngs):
                last = i == len(rngs) - 1
                k = sum(1 for c in cells if rg.lowerValue() <= c[
                    "walkability"] and (c["walkability"] < rg.upperValue()
                                        or (last and c["walkability"]
                                            <= rg.upperValue())))
                rows.append((rg.label(), 100.0 * k / n,
                             "%s %%" % fmt(100.0 * k / n, 0),
                             rg.symbol().color().name(), "%d celle" % k))
        with self.group():
            x, yy, w = self.titled(p, M, y, lw, h, "Celle per classe "
                                   "dell'indice")
            self.bars(p, x, yy, w, rows, vmax=100.0, label_w=22,
                      value_w=14, extra_w=18,
                      row_h=min(6.2, (h - 13) / max(1, len(rows))))
        with self.group():
            x, yy, w = self.titled(p, M + lw + GAP, y, CW - lw - GAP, h,
                                   "Come si legge")
            yy += self.para(
                p, x, yy, w, "L'indice è relativo: 100 è la cella migliore "
                "di quest'area, non un valore assoluto.", 7.3) + 1.6
            self.para(
                p, x, yy, w, "Per confrontare aree diverse usa i valori "
                "qui sopra: incroci per km², collegamenti per nodo, "
                "pendenza.", 7.3, MUTED)

    def page_tp(self):
        r = self.res
        tp = r["tp"]
        use_pop = any(sp is not None for _b, _sc, sp in tp["by_band"])
        who = "della popolazione" if use_pop else "dell'area"
        v4 = tp["ptal4_pop"] if tp.get("ptal4_pop") is not None \
            else tp["ptal4_cells"]
        sel = tp.get("selection", "") or ""
        p = self.page("Trasporto pubblico", "Livello di accessibilità al "
                      "trasporto pubblico (PTAL) per cella, fascia %s. %s."
                      % (tp.get("band_label", ""),
                         sel[:1].upper() + sel[1:]))
        cards = [("Fermate e linee", "%d · %d" % (tp["n_stops"],
                                                  tp["n_lines"]),
                  "fermate nell'area · linee che le servono"),
                 ("Corse all'ora", fmt(tp["deps_h"], 0),
                  "partenze dalle fermate, %s" % tp.get("band_label", ""))]
        if tp.get("served_cells") is not None:
            vs = tp["served_pop"] if use_pop else tp["served_cells"]
            v6 = tp["served6_pop"] if use_pop else tp["served6_cells"]
            cards.append((
                "Residenti serviti" if use_pop else "Area servita",
                "%s %%" % fmt(vs, 0),
                "entro 400 m (800 m metro, treno); %s %% con 6 o più corse "
                "l'ora" % fmt(v6, 0)))
        y = self.stats(p, TOP, cards + [
            ("PTAL 4 o più", "%s %%" % fmt(v4, 0), who,
             area_report.light("ptal4_share", v4))])
        y = self.map_card(p, y, self.split(
            y, 10.2 + len(tp["by_band"]) * 5.6 + 4.0),
            self.stack("cells", ["ptal"], ["fermate"]),
            legend=["ptal", "fermate"])
        h = BOTTOM - y
        lw = 108.0
        cols = dict(gtfs_layers.PTAL_COLORS)
        rows = [("PTAL " + b, (sp if use_pop else sc),
                 "%s %%" % fmt(sp if use_pop else sc, 0),
                 cols.get(b, "#a1a1aa")) for b, sc, sp in tp["by_band"]]
        with self.group():
            x, yy, w = self.titled(p, M, y, lw, h, "Quota %s per fascia"
                                   % who)
            self.bars(p, x, yy, w, rows, vmax=100.0, label_w=18, value_w=14,
                      row_h=min(5.6, (h - 13) / max(1, len(rows))))
        with self.group():
            x, yy, w = self.titled(p, M + lw + GAP, y, CW - lw - GAP, h,
                                   "Come si legge")
            yy += self.table(p, x, yy - 1, w, ["Fascia", "Accessibilità"],
                             PTAL_MEANING, [w * 0.42, w * 0.58], ["l", "l"],
                             row_h=5.0) + 2.0
            self.para(p, x, yy, w, "Il PTAL (metodo Transport for London) "
                      "unisce la distanza a piedi dalle fermate e la "
                      "frequenza delle linee. Indice medio dell'area: %s."
                      % fmt(tp["mean_ai"], 1), 7.0, MUTED)

    def page_iso(self):
        r = self.res
        iso = r["iso"]
        bands = iso["bands"]
        has_pop = any(b.get("pop") is not None for b in bands)
        p = self.page("Accessibilità a piedi", "Fin dove si arriva a piedi "
                      "dal centro dell'area, a %s km/h%s."
                      % (fmt(r["params"]["walk_kmh"], 1),
                         " in piano e con la pendenza del terreno"
                         if r.get("dem_used") else ""))
        cards = []
        for b in bands[-4:]:
            ns = sum(b["services"].values())
            if has_pop:
                cards.append(("Entro %g minuti" % b["t"],
                              "%s ab." % fmt(b["pop"], 0),
                              "%s ettari · %d servizi" % (fmt(b["area_ha"],
                                                              0), ns)))
            else:
                cards.append(("Entro %g minuti" % b["t"],
                              "%s ha" % fmt(b["area_ha"], 0),
                              "%d servizi raggiunti" % ns))
        y = self.stats(p, TOP, cards)
        cats = fifteen.order_categories({c for b in bands
                                         for c in b["services"]})
        nb = len(bands)
        need = max(10.2 + 5.3 * (len(cats) + 2) + 3.0 if cats else 0.0,
                   10.2 + nb * 6.2 + 4.0 + ((6.8 + nb * 6.2 + 3.0)
                                            if has_pop else 0.0))
        y = self.map_card(p, y, self.split(y, need),
                          self.stack("iso", ["iso"], ["centro"], mask=False),
                          legend=["iso", "centro"], ext_keys=["iso"],
                          pad=0.05)
        h = BOTTOM - y
        lay = self.layers.get("iso")
        cols = [it[1] for it in legend_items(lay)] if lay is not None else []
        lw = 112.0 if cats else 0.0
        if cats:
            rows = [[c] + ["%d" % b["services"].get(c, 0) for b in bands]
                    for c in cats]
            rows.append(["Totale"] + ["%d" % sum(b["services"].values())
                                      for b in bands])
            with self.group():
                x, yy, w = self.titled(p, M, y, lw, h, "Servizi raggiunti "
                                       "per categoria")
                bw = min(18.0, (w - 40) / len(bands))
                self.table(p, x, yy - 1, w, ["Categoria"] + [
                    "%g min" % b["t"] for b in bands], rows,
                    [w - bw * len(bands)] + [bw] * len(bands),
                    ["l"] + ["r"] * len(bands),
                    row_h=min(5.3, (h - 12) / (len(rows) + 1.2)),
                    bold_last=True)
        with self.group():
            off = lw + GAP if cats else 0.0
            x, yy, w = self.titled(p, M + off, y, CW - off, h,
                                   "Area raggiunta")
            rows = [("%g min" % b["t"], b["area_ha"],
                     "%s ha" % fmt(b["area_ha"], 0),
                     cols[i] if i < len(cols) else ACCENT)
                    for i, b in enumerate(bands)]
            yy += self.bars(p, x, yy, w, rows, label_w=13, value_w=15) + 3
            if has_pop and yy + 6.8 + 6.2 * len(bands) <= y + h - 1:
                self.text(p, x, yy, w, 4.6, "Abitanti raggiunti", 8.6,
                          "semibold", FG, valign="m")
                rows = [("%g min" % b["t"], b["pop"], fmt(b["pop"], 0),
                         cols[i] if i < len(cols) else ACCENT)
                        for i, b in enumerate(bands)]
                self.bars(p, x, yy + 6.8, w, rows, label_w=13, value_w=15)

    def page_f15(self):
        r = self.res
        f = r["f15"]
        thr = r["params"]["f15_min"]
        use_pop = f.get("full_pop") is not None
        who = "della popolazione" if use_pop else "delle celle"
        p = self.page("Città dei %g minuti" % thr, "Per ogni cella, la "
                      "quota di categorie di servizi raggiungibili a piedi "
                      "entro %g minuti: 100 significa tutte." % thr)
        vfull = f["full_pop"] if use_pop else f["full_cells"]
        far = [c for c in f["per_cat"] if c["mediana_min"] is not None]
        far = max(far, key=lambda c: c["mediana_min"]) if far else None
        y = self.stats(p, TOP, [
            ("Indice medio", "%s / 100" % fmt(f["mean_index"], 0),
             "media %s" % ("pesata sugli abitanti" if use_pop
                           else "delle celle"),
             area_report.light("f15_index", f["mean_index"])),
            ("Tutti i servizi", "%s %%" % fmt(vfull, 0),
             "%s li ha entro %g minuti" % (who, thr),
             area_report.light("f15_full_share", vfull)),
            ("Il più lontano", far["categoria"] if far else "–",
             "%s minuti, mediana delle celle" % fmt(far["mediana_min"], 1)
             if far else ""),
            ("Manca più spesso", f.get("worst") or "Nessuna",
             "categoria oltre la soglia in più celle" if f.get("worst")
             else "ogni categoria è entro la soglia")])
        nrows = len(f["per_cat"])
        y = self.map_card(p, y, self.split(y, 10.2 + 4.4 + 6.0 * nrows
                                           + 4.0),
                          self.stack("cells", ["f15"]), legend=["f15"],
                          prefix="Indice")
        vmax = max([thr * 1.4] + [c["mediana_min"] or 0
                                  for c in f["per_cat"]])
        rows = []
        for c in f["per_cat"]:
            v = c["mediana_min"]
            sh = c["pop_pct"] if use_pop and c["pop_pct"] is not None \
                else c["celle_pct"]
            rows.append((c["categoria"], v,
                         "oltre" if v is None else "%s min" % fmt(v, 1),
                         "#16a34a" if (v is not None and v <= thr)
                         else "#ef4444",
                         "%s %% entro %g min" % (fmt(sh, 0), thr)))
        with self.group():
            x, yy, w = self.titled(p, M, y, CW, BOTTOM - y, "Minuti a piedi "
                                   "fino al servizio più vicino (mediana "
                                   "delle celle)")
            self.bars(p, x, yy, w, rows, vmax=vmax, label_w=42, value_w=18,
                      extra_w=36,
                      row_h=min(6.0, (BOTTOM - y - 19) / max(1, nrows)),
                      ref=thr, ref_label="soglia %g min" % thr)

    def page_servizi(self):
        r = self.res
        s = r["servizi"]
        pop = r.get("pop")
        rows_ = s["rows"]
        present = [x for x in rows_ if x[1]]
        best = max(present, key=lambda x: x[1]) if present else None
        p = self.page("Servizi", "I servizi dentro l'area, per categoria "
                      "(fonte: %s)." % (s.get("source") or "layer indicato"))
        cards = [("Servizi nell'area", "%d" % s["total"], "in %d categorie"
                  % len(present))]
        if pop:
            cards.append(("Ogni 1 000 abitanti",
                          fmt(1000.0 * s["total"] / pop, 1),
                          "servizi rispetto ai residenti"))
        else:
            cards.append(("Per km²", fmt(s["total"] / r["area_km2"], 0)
                          if r["area_km2"] else "–", "densità dei servizi"))
        cards.append(("Categorie presenti", "%d su %d" % (len(present),
                                                          len(rows_)),
                      "mancano: " + ", ".join(x[0] for x in rows_
                                              if not x[1])
                      if len(present) < len(rows_) else "nessuna mancante"))
        cards.append(("La più diffusa", best[0] if best else "–",
                      "%d servizi" % best[1] if best else ""))
        y = self.stats(p, TOP, cards)
        n = len(rows_)
        y = self.map_card(p, y, self.split(y, 10.2 + 6.0 * n + 4.0),
                          self.stack("points", [], ["servizi"]),
                          legend=["servizi"])
        rows = [(c, float(k), "%d" % k, service_color(c, i),
                 ("%s ogni 1 000 ab." % fmt(per, 1)) if per is not None
                 else "") for i, (c, k, per) in enumerate(rows_)]
        with self.group():
            x, yy, w = self.titled(p, M, y, CW, BOTTOM - y, "Servizi per "
                                   "categoria")
            self.bars(p, x, yy, w, rows, label_w=42, value_w=14,
                      extra_w=36 if pop else 0,
                      row_h=min(6.0, (BOTTOM - y - 13) / max(1, n)))

    def page_notes(self):
        r = self.res
        pr = r["params"]
        p = self.page("Note e fonti", "Parametri del calcolo, soglie del "
                      "giudizio e origine dei dati.")
        y = TOP
        lw = 78.0
        rows = [("Area", r["name"]),
                ("Superficie", "%s km²" % fmt(r["area_km2"], 2))]
        if r.get("pop") is not None:
            rows.append(("Abitanti stimati", fmt(r["pop"], 0)))
        rows += [("Celle", "esagoni, raggio %s m" % fmt(pr["cell_m"], 0)),
                 ("Velocità a piedi", "%s km/h%s" % (
                     fmt(pr["walk_kmh"], 1),
                     " in piano" if r.get("dem_used") else "")),
                 ("Isocrone", ", ".join("%g" % t for t in pr["iso_times"])
                  + " minuti"),
                 ("Soglia dei servizi", "%g minuti" % pr["f15_min"])]
        if r.get("tp"):
            rows.append(("Fascia del PTAL", r["tp"]["band_label"]))
        if r.get("dem_used"):
            rows.append(("Pendenza", "DEM «%s»" % pr["dem"]))
        thr_rows = []
        for k, (good, mid, higher) in area_report.THRESHOLDS.items():
            lab, unit = area_report.THRESHOLD_LABEL[k]
            lab = lab.replace("15 minuti", "%g minuti" % pr["f15_min"])
            sgn = "da" if higher else "fino a"
            thr_rows.append((lab, "%s %s%s" % (sgn, fmt(good, 0), unit),
                             "%s %s%s" % (sgn, fmt(mid, 0), unit)))
        h1 = 12.0 + max(len(rows) * 5.3, (len(thr_rows) + 1) * 5.5) + 3.5
        with self.group():
            x, yy, w = self.titled(p, M, y, lw, h1, "Area e parametri")
            for lab, val in rows:
                self.text(p, x, yy, 28, 5.3, lab, 7.2, "regular", MUTED,
                          valign="m")
                self.text(p, x + 28, yy, w - 28, 5.3,
                          elide(val, 7.4, w - 28, "medium"), 7.4, "medium",
                          FG, "r", "m")
                yy += 5.3
        with self.group():
            x, yy, w = self.titled(p, M + lw + GAP, y, CW - lw - GAP, h1,
                                   "Soglie del giudizio")
            self.table(p, x, yy - 1, w, ["Indicatore", "Buono",
                                         "Migliorabile"], thr_rows,
                       [w - 44, 21, 23], ["l", "r", "r"], size=7.0)
        y += h1 + GAP
        notes = [
            "Le soglie sono indicative e vanno adattate al contesto: oltre "
            "la soglia «migliorabile» il giudizio è «critico».",
            "Le celle sono esagoni ritagliati sul bordo dell'area: insieme "
            "la coprono esattamente.",
        ]
        if r.get("pop") is not None:
            notes.append("La popolazione è ripartita per area di "
                         "sovrapposizione: una sezione che cade per metà "
                         "nell'area conta per metà dei suoi abitanti.")
        if r.get("jobs"):
            notes.append("Gli addetti (posti di lavoro di imprese, "
                         "istituzioni pubbliche e non profit) sono quelli del "
                         "censimento 2011, l'ultimo dato ISTAT per sezione "
                         "di censimento: sezioni 2011 ripartite per "
                         "superficie come la popolazione.")
        if r.get("demo"):
            notes.append("La pagina «Popolazione» usa gli indicatori ISTAT "
                         "per sezione di censimento (2021), ripartiti allo "
                         "stesso modo; i conteggi piccoli sono perturbati "
                         "dall'ISTAT per riservatezza, quindi le percentuali "
                         "di aree con pochi residenti sono indicative.")
        if r.get("tp"):
            notes.append("PTAL secondo il metodo Transport for London, con "
                         "le distanze a piedi misurate sulla rete; %s."
                         % r["tp"]["selection"])
        if r.get("dem_used"):
            notes.append("Con il DEM la velocità a piedi segue la pendenza "
                         "(funzione di Tobler); ponti e gallerie usano la "
                         "pendenza fra i loro estremi.")
        notes.append("Rete e servizi sono letti anche attorno all'area, per "
                     "il percorso a piedi più lungo considerato: isocrone e "
                     "servizi non si fermano al confine.")
        y = self._list_card(p, y, "Metodo in breve", notes)
        warn = ["%s non calcolata: %s." % (area_report.SECTION_LABEL.get(
            k, k), v) for k, v in (r.get("skipped") or {}).items()] + \
            list(r.get("notes") or [])
        if warn:
            y = self._list_card(p, y, "Avvertenze", warn, DOT["giallo"])
        y = self._list_card(p, y, "Fonti", list(self.meta.get("sources",
                                                              []))
                            + ["Metodi: scheda «Spiegazione campi» del "
                               "plugin e file METHODOLOGY.md."])
        terms = []
        if r.get("demo"):
            terms += [("Indice di vecchiaia", "Residenti di 65 anni e più "
                       "ogni 100 di 0-14 anni: sopra 100 gli anziani sono "
                       "più dei bambini e ragazzi."),
                      ("Titolo terziario", "Laurea o titolo superiore, sui "
                       "residenti di 9 anni e più.")]
        if r.get("rete"):
            terms += [("Incroci reali", "Punti in cui si incontrano almeno "
                       "tre strade. Più incroci per km² significa isolati "
                       "piccoli e percorsi diretti."),
                      ("Vicoli ciechi", "Strade senza uscita, in quota sui "
                       "nodi della rete: allungano i percorsi a piedi.")]
        if r.get("walk"):
            terms.append(("Camminabilità", "Indice relativo fra le celle "
                          "dell'area: forma della rete, servizi vicini e "
                          "pendenza."))
        if r.get("tp") and r["tp"].get("served_cells") is not None:
            terms.append(("Residenti serviti", "Chi ha una fermata con "
                          "corse nella fascia entro 400 m a piedi lungo la "
                          "rete (800 m per metro e treno)."))
        if r.get("tp"):
            terms.append(("PTAL", "Livello di accessibilità al trasporto "
                          "pubblico, da 0 a 6b: distanza a piedi dalle "
                          "fermate e frequenza delle linee."))
        if r.get("iso"):
            terms.append(("Isocrona", "L'area raggiungibile entro un certo "
                          "tempo camminando lungo le strade."))
        if r.get("f15"):
            terms.append(("Indice %g minuti" % pr["f15_min"], "Quota delle "
                          "categorie di servizi raggiungibili a piedi entro "
                          "%g minuti: 100 significa tutte." % pr["f15_min"]))
        hs = [len(wrap(d, 7.4, CW - 8 - 36)) * line_h(7.4) + 1.8
              for _t, d in terms]
        gh = 12.0 + sum(hs) + 2.0
        if terms and y + gh > BOTTOM:
            # non c'è più spazio: il glossario va su una pagina sua invece
            # di sparire
            p = self.page("Glossario", "I termini usati nel report.")
            y = TOP
        if terms:
            with self.group():
                x, yy, w = self.titled(p, M, y, CW, gh, "Glossario")
                for (t, d), hh in zip(terms, hs):
                    self.text(p, x, yy, 34, 4.8, t, 7.4, "semibold", FG,
                              valign="m")
                    self.text(p, x + 36, yy + 0.3, w - 36, hh + 1, d, 7.4,
                              "regular", FG)
                    yy += hh

    def _list_card(self, p, y, title, lines, dot="#a1a1aa"):
        hs = [len(wrap(t, 7.5, CW - 13.5)) * line_h(7.5) + 1.7
              for t in lines]
        h = 12.0 + sum(hs) + 2.0
        with self.group():
            x, yy, w = self.titled(p, M, y, CW, h, title)
            for t, hh in zip(lines, hs):
                self.box(p, x + 0.3, yy + 1.3, 1.5, 1.5, dot, None, 0,
                         ellipse=True)
                self.text(p, x + 5, yy, w - 5, hh + 1, t, 7.5, "regular", FG)
                yy += hh
        return y + h + GAP


def _north_arrow():
    """SVG della freccia del nord fornita da QGIS, se c'è."""
    for base in QgsApplication.svgPaths():
        for name in ("arrows/NorthArrow_02.svg", "arrows/NorthArrow_11.svg"):
            path = os.path.join(base, name)
            if os.path.exists(path):
                return path
    return None


def export_pdf(layout, path):
    """Esporta il layout in PDF. :return: (ok, messaggio)."""
    exp = QgsLayoutExporter(layout)
    st = QgsLayoutExporter.PdfExportSettings()
    st.dpi = 200
    st.rasterizeWholeImage = False
    res = exp.exportToPdf(path, st)
    if res != QgsLayoutExporter.Success:
        return False, exp.errorMessage() if hasattr(exp, "errorMessage") \
            else "errore %s" % res
    return True, ""


def report_meta(res, version, sources):
    return {"version": version,
            "date": datetime.date.today().strftime("%d/%m/%Y"),
            "sources": sources}
