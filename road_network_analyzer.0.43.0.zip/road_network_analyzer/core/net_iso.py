# -*- coding: utf-8 -*-
"""Grafo metrico locale e isocrone su rete in puro Python (thread-safe).

Costruisce un grafo metrico dalle geometrie stradali (liste di coordinate
lon/lat estratte sul thread principale) ed esegue Dijkstra. Riusato da:
isocrone su rete, PTAL su rete pedonale, accessibilita' cumulativa.
"""
import heapq
import math
from collections import defaultdict


def _projector(lat0):
    mlat = 111320.0
    mlon = 111320.0 * math.cos(math.radians(lat0))

    def to_m(lon, lat):
        return lon * mlon, lat * mlat

    def to_ll(x, y):
        return x / mlon, y / mlat

    return to_m, to_ll


class MetricGraph:
    """Grafo metrico (nodi in metri locali) con snap e Dijkstra."""

    def __init__(self, node_xy, adj, edges, to_m, to_ll, edge_dir=None):
        self.node_xy = node_xy
        self.adj = adj
        self.edges = edges
        # senso di marcia di ogni arco rispetto a (a, b): 0 doppio, 1 solo
        # a->b, -1 solo b->a (allineato a edges)
        self.edge_dir = edge_dir if edge_dir is not None else [0] * len(edges)
        self.to_m = to_m
        self.to_ll = to_ll
        self.n = len(node_xy)
        self.cell = 60.0
        self.grid = defaultdict(list)
        for i, (x, y) in enumerate(node_xy):
            self.grid[(int(x // self.cell), int(y // self.cell))].append(i)
        self._egrid = None
        self._long_edges = []
        # opzionali (build_metric_graph con speeds): tempi per arco
        self.adj_t = None
        self.edge_speed = None

    # archi piu' lunghi di cosi' non vanno nella griglia ma in una lista a
    # parte, controllata per intero a ogni snap (sono pochi). Senza questo
    # limite un arco lunghissimo (es. rete con CRS dichiarato sbagliato:
    # metri letti come gradi) richiederebbe miliardi di celle e bloccherebbe.
    LONG_EDGE_M = 5000.0

    def _edge_grid(self):
        """Indice a griglia degli archi (costruito al primo uso).

        Ogni arco e' registrato in tutte le celle che attraversa, cosi' anche un
        arco lungo con gli estremi lontani viene trovato dallo snap.
        """
        if self._egrid is None:
            eg = defaultdict(list)
            c = self.cell
            seen = set()
            for a, b, _d in self.edges:
                key = (a, b) if a < b else (b, a)
                if key in seen:
                    continue
                seen.add(key)
                ax, ay = self.node_xy[a]
                bx, by = self.node_xy[b]
                L = math.hypot(bx - ax, by - ay)
                if L > self.LONG_EDGE_M:
                    self._long_edges.append(key)
                    continue
                n = int(L / (0.5 * c)) + 1
                cells = {(int((ax + (bx - ax) * k / n) // c),
                          int((ay + (by - ay) * k / n) // c))
                         for k in range(n + 1)}
                for k in cells:
                    eg[k].append(key)
            self._egrid = eg
        return self._egrid

    def can_go(self, u, v):
        """True se l'arco u->v e' percorribile in quel verso."""
        return any(w == v for w, _d in self.adj[u])

    def source_seeds(self, info):
        """Seed di Dijkstra per una SORGENTE agganciata con snap_edge.

        Come info["seeds"], ma rispetta i sensi unici: dal piede si raggiunge
        l'estremo a solo se l'arco e' percorribile b->a (e viceversa). Un piede
        che coincide con un estremo lo semina sempre.
        """
        a, b = info["edge"]
        out = []
        for node, off in info["seeds"]:
            other = b if node == a else a
            if off < 0.01 or self.can_go(other, node):
                out.append((node, off))
        return out

    def dest_seeds(self, info):
        """Estremi da cui si ARRIVA al piede di una destinazione (snap_edge).

        Dall'estremo a si arriva al piede percorrendo l'arco a->b (e da b con
        b->a): con i sensi unici l'estremo da cui si andrebbe contromano non
        vale. Un piede che coincide con un estremo vale sempre.
        """
        a, b = info["edge"]
        out = []
        for node, off in info["seeds"]:
            other = b if node == a else a
            if off < 0.01 or self.can_go(node, other):
                out.append((node, off))
        return out

    def reach_pieces(self, cost, thr, sources=()):
        """Tratti di rete raggiunti entro `thr` metri (lista di segmenti lon/lat).

        Copertura esatta per arco: dall'estremo a si percorre l'arco per
        thr-cost[a] (se percorribile a->b), dall'estremo b per thr-cost[b]; se
        le due parti si toccano l'arco e' coperto tutto, altrimenti resta
        scoperta la parte centrale (prima veniva disegnato intero).

        :param sources: lista di (info snap_edge, budget_m): aggiunge i tratti
            percorsi direttamente dal piede della sorgente lungo il proprio
            arco (altrimenti una sorgente a meta' di un arco lungo non
            coprirebbe nulla finche' non raggiunge un estremo).
        """
        segs = []
        xy = self.node_xy
        ll = self.to_ll
        for (a, b, d), dr in zip(self.edges, self.edge_dir):
            ca, cb = cost[a], cost[b]
            if (ca > thr and cb > thr) or d <= 0:
                continue
            fa = min(1.0, (thr - ca) / d) if (ca <= thr and dr != -1) else 0.0
            fb = min(1.0, (thr - cb) / d) if (cb <= thr and dr != 1) else 0.0
            ax, ay = xy[a]
            bx, by = xy[b]
            if fa + fb >= 1.0:
                segs.append([ll(ax, ay), ll(bx, by)])
                continue
            if fa > 0:
                segs.append([ll(ax, ay),
                             ll(ax + fa * (bx - ax), ay + fa * (by - ay))])
            if fb > 0:
                segs.append([ll(bx, by),
                             ll(bx + fb * (ax - bx), by + fb * (ay - by))])
        for info, budget in sources:
            L = info["L"]
            if budget <= 0 or L <= 0:
                continue
            a, b = info["edge"]
            t = info["t"]
            fx, fy = info["foot"]
            ux = (xy[b][0] - xy[a][0]) / L
            uy = (xy[b][1] - xy[a][1]) / L
            for target, other, room, sign in ((b, a, (1.0 - t) * L, 1.0),
                                              (a, b, t * L, -1.0)):
                run = min(room, budget)
                if run > 0.01 and self.can_go(other, target):
                    segs.append([ll(fx, fy), ll(fx + sign * run * ux,
                                                fy + sign * run * uy)])
        return segs

    def snap(self, px, py, max_r=200.0):
        best, bestd = None, max_r * max_r
        cx, cy = int(px // self.cell), int(py // self.cell)
        span = int(max_r // self.cell) + 1
        for dx in range(-span, span + 1):
            for dy in range(-span, span + 1):
                for i in self.grid.get((cx + dx, cy + dy), ()):
                    x, y = self.node_xy[i]
                    dd = (x - px) ** 2 + (y - py) ** 2
                    if dd < bestd:
                        best, bestd = i, dd
        return best

    def snap_ll(self, lat, lon, max_r=200.0):
        x, y = self.to_m(lon, lat)
        return self.snap(x, y, max_r)

    def snap_edge_ll(self, lat, lon, max_r=500.0, accept=None):
        x, y = self.to_m(lon, lat)
        return self.snap_edge(x, y, max_r, accept)

    def snap_edge(self, px, py, max_r=500.0, accept=None):
        """Aggancio preciso del punto all'arco stradale piu' vicino.

        Ritorna un dict (o None se nessun arco entro max_r):
          edge  = (a, b) estremi dell'arco (a<b);
          t     = frazione del piede lungo a->b (0=a, 1=b);
          L     = lunghezza dell'arco (m);
          foot  = (x, y) del piede della proiezione (metri locali);
          seeds = [(a, t*L), (b, (1-t)*L)] per seed di Dijkstra.
        Cosi' un punto a meta' di una strada lunga aggancia esattamente la rete
        e la distanza puo' essere calcolata in modo preciso (vedi edge_distance).
        Con `accept(edge)` si considerano solo gli archi accettati.
        """
        best = None
        bestd = max_r * max_r
        cx, cy = int(px // self.cell), int(py // self.cell)
        span = int(max_r // self.cell) + 1
        egrid = self._edge_grid()
        seen = set()
        near = [egrid.get((cx + dx, cy + dy), ())
                for dx in range(-span, span + 1)
                for dy in range(-span, span + 1)]
        near.append(self._long_edges)
        for keys in near:
            for key in keys:
                if key in seen:
                    continue
                seen.add(key)
                if accept is not None and not accept(key):
                    continue
                a, b = key
                ax, ay = self.node_xy[a]
                bx, by = self.node_xy[b]
                vx, vy = bx - ax, by - ay
                L2 = vx * vx + vy * vy
                if L2 == 0:
                    continue
                t = ((px - ax) * vx + (py - ay) * vy) / L2
                t = 0.0 if t < 0 else (1.0 if t > 1.0 else t)
                fx, fy = ax + t * vx, ay + t * vy
                dd = (px - fx) ** 2 + (py - fy) ** 2
                if dd < bestd:
                    bestd = dd
                    L = math.sqrt(L2)
                    best = {"edge": key, "t": t, "L": L,
                            "foot": (fx, fy),
                            "seeds": [(a, t * L), (b, (1.0 - t) * L)]}
        return best

    def edge_distance(self, cost, src_info, dst_info):
        """Distanza di rete precisa dal piede sorgente a quello destinazione.

        cost = vettore Dijkstra seedato con source_seeds(src_info). Per il caso
        in cui sorgente e destinazione cadono sullo STESSO arco si usa la
        distanza diretta lungo l'arco (evita la deviazione via estremo), se il
        verso è percorribile. Con i sensi unici l'arrivo al piede vale solo
        dagli estremi da cui l'arco si percorre nel verso giusto (dest_seeds).
        """
        arr = dst_info.get("arr_seeds")
        if arr is None:
            arr = dst_info["arr_seeds"] = self.dest_seeds(dst_info)
        d = min((cost[n] + off for n, off in arr), default=float("inf"))
        if src_info is not None and src_info["edge"] == dst_info["edge"]:
            a, b = dst_info["edge"]
            ts, td = src_info["t"], dst_info["t"]
            if ((td >= ts and self.can_go(a, b))
                    or (td <= ts and self.can_go(b, a))):
                d = min(d, abs(ts - td) * dst_info["L"])
        return d

    def dijkstra(self, start, max_dist):
        if start is None:
            return [float("inf")] * self.n
        seeds = start if isinstance(start, list) else [(start, 0.0)]
        return self.dijkstra_multi(seeds, max_dist)

    def dijkstra_multi(self, seeds, max_dist):
        """Dijkstra da piu' seed [(nodo, costo_iniziale)]."""
        cost = [float("inf")] * self.n
        pq = []
        for node, init in seeds:
            if node is not None and init < cost[node]:
                cost[node] = init
                heapq.heappush(pq, (init, node))
        while pq:
            c, v = heapq.heappop(pq)
            if c > cost[v] or c > max_dist:
                continue
            for w, d in self.adj[v]:
                nc = c + d
                if nc < cost[w] and nc <= max_dist:
                    cost[w] = nc
                    heapq.heappush(pq, (nc, w))
        return cost


def build_metric_graph(roads_lonlat, lat0, bbox_m=None, directions=None,
                       speeds=None):
    """Costruisce un MetricGraph dalle polilinee (lon/lat).

    :param bbox_m: (minx, miny, maxx, maxy) in metri locali per prefiltrare:
        si tengono i tratti il cui ingombro interseca il riquadro (anche se
        entrambi i vertici cadono fuori, es. un arco lungo che lo attraversa).
    :param directions: opzionale, lista allineata a roads_lonlat con il senso di
        marcia di ogni polilinea: 0 = doppio senso, 1 = solo avanti (ordine dei
        vertici), -1 = solo indietro. La geometria (edges) resta sempre
        bidirezionale per il disegno; cambia solo la percorribilità (adj) e
        il senso dell'arco in edge_dir.
    """
    to_m, to_ll = _projector(lat0)
    node_id = {}
    node_xy = []
    adj = defaultdict(list)
    adj_t = defaultdict(list) if speeds is not None else None
    edge_speed = [] if speeds is not None else None
    edges = []
    edge_dir = []

    def nid(x, y):
        k = (round(x, 1), round(y, 1))
        i = node_id.get(k)
        if i is None:
            i = len(node_xy)
            node_id[k] = i
            node_xy.append((x, y))
        return i

    minx = miny = -float("inf")
    maxx = maxy = float("inf")
    if bbox_m:
        minx, miny, maxx, maxy = bbox_m

    for ri, road in enumerate(roads_lonlat):
        direction = directions[ri] if directions and ri < len(directions) else 0
        if direction not in (1, -1):
            direction = 0
        sp = None
        if speeds is not None:
            sp = speeds[ri] if ri < len(speeds) and speeds[ri] else 1.0
        prev_xy = None
        for lon, lat in road:
            x, y = to_m(lon, lat)
            if prev_xy is not None:
                px, py = prev_xy
                if (min(px, x) <= maxx and max(px, x) >= minx
                        and min(py, y) <= maxy and max(py, y) >= miny):
                    a = nid(px, py)
                    i = nid(x, y)
                    d = math.hypot(node_xy[i][0] - node_xy[a][0],
                                   node_xy[i][1] - node_xy[a][1])
                    if d > 0:
                        # avanti = a -> i ; indietro = i -> a
                        if direction in (0, 1):
                            adj[a].append((i, d))
                        if direction in (0, -1):
                            adj[i].append((a, d))
                        if sp is not None:
                            # tempi (s) per il percorso più veloce
                            if direction in (0, 1):
                                adj_t[a].append((i, d / sp))
                            if direction in (0, -1):
                                adj_t[i].append((a, d / sp))
                            edge_speed.append(sp)
                        edges.append((a, i, d))
                        edge_dir.append(direction)
            prev_xy = (x, y)
    graph = MetricGraph(node_xy, adj, edges, to_m, to_ll, edge_dir)
    graph.adj_t = adj_t
    graph.edge_speed = edge_speed
    return graph


def compute_union_reach(roads_lonlat, sources_budget, progress=None):
    """Reach unione da piu' sorgenti, ciascuna con un budget (metri) proprio.

    Usata per l'egress pedonale multimodale (TP): ogni fermata raggiunta e' una
    sorgente con il tempo residuo. Multi-source Dijkstra con costi iniziali
    spostati di (MAX - budget_s).

    :param sources_budget: lista di (lat, lon, budget_m).
    :return: lista di segmenti [[(lon,lat),(lon,lat)], ...].
    """
    import heapq
    srcs = [(la, lo, b) for la, lo, b in sources_budget if b and b > 0]
    if not srcs:
        return []
    lat0 = sum(s[0] for s in srcs) / len(srcs)
    to_m, _ = _projector(lat0)
    max_b = max(s[2] for s in srcs)
    pts = [(to_m(lo, la), b) for la, lo, b in srcs]
    minx = min(p[0][0] for p in pts) - max_b
    maxx = max(p[0][0] for p in pts) + max_b
    miny = min(p[0][1] for p in pts) - max_b
    maxy = max(p[0][1] for p in pts) + max_b
    graph = build_metric_graph(roads_lonlat, lat0, (minx, miny, maxx, maxy))

    cost = [float("inf")] * graph.n
    pq = []
    feet = []
    for (x, y), b in pts:
        info = graph.snap_edge(x, y, 500.0)
        if info is None:
            continue
        base = max_b - b
        feet.append((info, b))
        for node, off in info["seeds"]:
            init = base + off
            if init < cost[node]:
                cost[node] = init
                heapq.heappush(pq, (init, node))
    while pq:
        c, v = heapq.heappop(pq)
        if c > cost[v] or c > max_b:
            continue
        for w, d in graph.adj[v]:
            nc = c + d
            if nc < cost[w] and nc <= max_b:
                cost[w] = nc
                heapq.heappush(pq, (nc, w))

    segs = graph.reach_pieces(cost, max_b, feet)
    if progress:
        progress(100)
    return segs


def reach_radius_m(speed_kmh, times_min, snap_m=500.0):
    """Distanza massima utile attorno alle sorgenti: percorso massimo
    (velocità × tempo più lungo) + raggio di aggancio + un piccolo margine.
    Una strada più lontana di così non può essere raggiunta."""
    return speed_kmh * 1000.0 / 60.0 * max(times_min) + snap_m + 50.0


def reach_bbox(sources_latlon, radius_m):
    """Riquadro WGS84 (ovest, sud, est, nord) delle sorgenti allargato di
    radius_m: l'unica parte di rete che serve leggere."""
    lats = [la for la, _lo in sources_latlon]
    lons = [lo for _la, lo in sources_latlon]
    lat_ref = max(abs(min(lats)), abs(max(lats)))
    dlat = radius_m / 111320.0
    dlon = radius_m / (111320.0 * max(0.05, math.cos(math.radians(lat_ref))))
    return (min(lons) - dlon, min(lats) - dlat,
            max(lons) + dlon, max(lats) + dlat)


def bbox_contains(outer, inner):
    """True se il riquadro inner (w, s, e, n) sta dentro outer."""
    return (outer[0] <= inner[0] and outer[1] <= inner[1]
            and outer[2] >= inner[2] and outer[3] >= inner[3])


def read_roads(features, transform=None, oneway=False, progress=None,
               is_canceled=None, stats=None, ids=None, levels=None,
               level_of=None):
    """Polilinee lon/lat (e sensi unici) da un iteratore di feature lineari.

    Accetta anche le feature di un QgsVectorLayerFeatureSource, quindi si può
    chiamare dentro un QgsTask (la lettura di una rete grande non blocca la
    GUI). `transform` porta le geometrie in EPSG:4326; con `oneway` legge il
    campo «oneway» (yes/no/-1/reverse o numerico).

    :param progress: opzionale, callback(n_feature_lette) ogni 1000 feature
        (su reti grandi la lettura dura decine di secondi).
    :param stats: opzionale, dict in cui scrivere {"features": n lette}.
    :param ids: opzionale, lista in cui aggiungere l'id della feature per
        ogni polilinea restituita (le multiparti danno più polilinee).
    :param levels: opzionale, lista in cui aggiungere il livello (ponte,
        tunnel, layer OSM) per polilinea, letto con `level_of(feature)`.
    :return: (roads, directions) con directions None se oneway è False.
    """
    from qgis.core import QgsGeometry
    from .osm_download import _oneway_value
    roads = []
    directions = [] if oneway else None
    n_read = 0
    for i, f in enumerate(features):
        n_read = i + 1
        if i and i % 1000 == 0:
            if is_canceled and is_canceled():
                from .gtfs_static import GtfsCancelled
                raise GtfsCancelled()
            if progress:
                progress(i)
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        if transform is not None:
            g.transform(transform)
        d = _oneway_value(f["oneway"]) if oneway else 0
        lev = level_of(f) if (levels is not None and level_of) else 0
        for part in (g.asMultiPolyline() if g.isMultipart()
                     else [g.asPolyline()]):
            roads.append([(p.x(), p.y()) for p in part])
            if oneway:
                directions.append(d)
            if ids is not None:
                ids.append(f.id())
            if levels is not None:
                levels.append(lev)
    if stats is not None:
        stats["features"] = n_read
    return roads, directions


def validate_network(roads_lonlat):
    """Controlli base sulla rete stradale. Ritorna (ok, messaggio, info).

    info = {n_polilinee, n_archi, lunghezza_km, bbox=(s,w,n,e)}.
    """
    polys = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    if not polys:
        return False, "La rete stradale e' vuota o senza linee valide.", {}
    lat0 = polys[0][0][1]
    to_m, _ = _projector(lat0)
    n_edges = 0
    length_m = 0.0
    lons = []
    lats = []
    for road in polys:
        prev = None
        for lon, lat in road:
            lons.append(lon)
            lats.append(lat)
            x, y = to_m(lon, lat)
            if prev is not None:
                length_m += math.hypot(x - prev[0], y - prev[1])
                n_edges += 1
            prev = (x, y)
    info = {
        "n_polilinee": len(polys),
        "n_archi": n_edges,
        "lunghezza_km": length_m / 1000.0,
        "bbox": (min(lats), min(lons), max(lats), max(lons)),
    }
    if n_edges == 0:
        return False, "La rete non contiene archi percorribili.", info
    s, w, n, e = info["bbox"]
    if s < -90 or n > 90 or w < -180 or e > 180:
        return False, ("le coordinate non sono valide dopo la riproiezione "
                       "(es. metri letti come gradi): controlla il sistema di "
                       "riferimento (CRS) assegnato al layer della rete."), info
    msg = ("Rete valida: %d linee, %d archi, %.1f km."
           % (info["n_polilinee"], info["n_archi"], info["lunghezza_km"]))
    return True, msg, info


def _nearest_source_dist_m(graph, src_m):
    """Distanza minima (m) di una sorgente da un qualsiasi nodo della rete."""
    best = float("inf")
    for px, py in src_m:
        node = graph.snap(px, py, 1e9)
        if node is not None:
            nx, ny = graph.node_xy[node]
            best = min(best, math.hypot(nx - px, ny - py))
    return best


def compute_reachable_segments(roads_lonlat, sources_latlon, speed_kmh,
                               times_min, progress=None, is_canceled=None,
                               snap_m=500.0, directions=None, dissolve=False,
                               on_source=None):
    """Segmenti raggiunti per sorgente e fascia (lon/lat).

    :param dissolve: True = un solo Dijkstra multi-sorgente. L'unione delle
        aree raggiunte dalle singole sorgenti coincide con l'area raggiunta
        partendo da tutte insieme, quindi il risultato dissolto è identico ma
        costa come una sola sorgente (tempo e memoria non crescono con il
        numero di sorgenti). per_source ha allora un solo elemento.
    :param on_source: opzionale (solo non dissolto), callback(indice, bands)
        chiamata appena una sorgente è calcolata; per_source riceve None al
        suo posto, così i tratti di una sorgente non restano in memoria
        (con molte sorgenti sarebbero milioni di oggetti).
    :return: (per_source, n_snapped) dove per_source[i] = {t_min: [segmenti]}
             e n_snapped = quante sorgenti hanno agganciato la rete.
    """
    times = sorted({float(t) for t in times_min if float(t) > 0})
    if not sources_latlon or not times:
        raise ValueError("Servono almeno una sorgente e un tempo valido.")
    if not any(r and len(r) >= 2 for r in (roads_lonlat or [])):
        raise ValueError("Rete stradale vuota: nessuna linea da percorrere.")
    if any(abs(la) > 90 or abs(lo) > 180 for la, lo in sources_latlon):
        raise ValueError("Coordinate delle sorgenti non valide dopo la "
                         "riproiezione: controlla il CRS del layer dei punti.")
    lat0 = sum(la for la, lo in sources_latlon) / len(sources_latlon)
    max_dist = speed_kmh * 1000.0 / 60.0 * max(times)
    to_m, _ = _projector(lat0)
    src_m = [to_m(lo, la) for la, lo in sources_latlon]
    pad = max_dist + snap_m
    minx = min(p[0] for p in src_m) - pad
    maxx = max(p[0] for p in src_m) + pad
    miny = min(p[1] for p in src_m) - pad
    maxy = max(p[1] for p in src_m) + pad
    if progress:
        progress(15)
    graph = build_metric_graph(roads_lonlat, lat0, (minx, miny, maxx, maxy),
                               directions=directions)
    if progress:
        progress(40)
    if graph.n == 0:
        raise ValueError("Nessun tratto stradale vicino alle sorgenti.")

    n_snapped = 0
    if dissolve:
        seeds, feet = [], []
        for si, (px, py) in enumerate(src_m):
            if is_canceled and si % 200 == 0 and is_canceled():
                from .gtfs_static import GtfsCancelled
                raise GtfsCancelled()
            info = graph.snap_edge(px, py, snap_m)
            s = graph.source_seeds(info) if info is not None else []
            if s:
                n_snapped += 1
                seeds.extend(s)
                feet.append(info)
        bands = {t: [] for t in times}
        if seeds:
            cost = graph.dijkstra_multi(seeds, max_dist)
            if progress:
                progress(70)
            for t in times:
                thr = speed_kmh * 1000.0 / 60.0 * t
                bands[t] = graph.reach_pieces(cost, thr,
                                              [(f, thr) for f in feet])
        if progress:
            progress(100)
        return [bands], n_snapped

    per_source = []
    for si, (px, py) in enumerate(src_m):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        info = graph.snap_edge(px, py, snap_m)
        seeds = graph.source_seeds(info) if info is not None else []
        if not seeds:
            per_source.append(None if on_source else {t: [] for t in times})
            if progress:
                progress(40 + int(55 * (si + 1) / len(src_m)))
            continue
        n_snapped += 1
        cost = graph.dijkstra_multi(seeds, max_dist)
        bands = {}
        for t in times:
            thr = speed_kmh * 1000.0 / 60.0 * t
            bands[t] = graph.reach_pieces(cost, thr, [(info, thr)])
        if on_source is not None:
            on_source(si, bands)
            per_source.append(None)
        else:
            per_source.append(bands)
        if progress:
            progress(40 + int(55 * (si + 1) / len(src_m)))
    if progress:
        progress(100)
    return per_source, n_snapped
