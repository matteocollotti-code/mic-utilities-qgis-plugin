# -*- coding: utf-8 -*-
"""Costruzione di layer QGIS per la rete preparata e la diagnostica.

Solo creazione/stile di layer dai risultati dei core (network_prepare,
network_diagnostics). Nessuna logica di analisi qui.
"""
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsPointXY,
    QgsRendererCategory,
    QgsSymbol,
    QgsVectorLayer,
    QgsWkbTypes,
)

from . import style_util


def build_prepared_layer(segments, directions=None,
                         name="MIC - Rete preparata", seg_src=None,
                         src_fields=None, src_attrs=None, stats=None):
    """Layer di linee (EPSG:4326) dalla rete preparata (noded/snap).

    I segmenti elementari vengono riuniti in tratti: ogni feature d'origine
    è spezzata solo agli incroci (e dove cambia il senso unico). Con
    `src_fields` (QgsFields del layer d'origine) e `src_attrs`
    ({id d'origine: attributi}) i tratti conservano tutti gli attributi;
    `seg_src` dà l'origine di ogni segmento.

    Campi aggiunti: oneway (−1/0/1, relativo al verso del tratto; sovrascrive
    quello d'origine), mic_prepared=1, src_fid (id della feature d'origine).
    """
    from . import topology
    n = len(segments)
    srcs = seg_src if seg_src is not None and len(seg_src) == n else [0] * n
    topo = topology.build_topology(segments, sources=srcs, snap_tol_m=0.001,
                                   directions=directions, keep_features=True)
    out_fields = QgsFields()
    copy_idx = []        # (indice nel layer d'origine, indice in uscita)
    ow_out = None
    ow_is_text = False
    if src_fields is not None:
        for i in range(src_fields.count()):
            fld = src_fields.at(i)
            low = fld.name().lower()
            if low in ("fid", "src_fid", "mic_prepared"):
                continue
            out_fields.append(QgsField(fld))
            j = out_fields.count() - 1
            copy_idx.append((i, j))
            if low == "oneway":
                ow_out = j
                ow_is_text = fld.type() == QVariant.String
    if ow_out is None:
        out_fields.append(QgsField("oneway", QVariant.Int))
        ow_out = out_fields.count() - 1
    out_fields.append(QgsField("mic_prepared", QVariant.Int))
    i_prep = out_fields.count() - 1
    has_src = src_attrs is not None and seg_src is not None
    if has_src:
        out_fields.append(QgsField("src_fid", QVariant.LongLong))
    i_src = out_fields.count() - 1

    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes(out_fields.toList())
    layer.updateFields()
    feats = []
    nf = out_fields.count()
    for ci, ch in enumerate(topo.chains):
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY(
            [QgsPointXY(lo, la) for lo, la in topo.chain_coords(ci)]))
        vals = [None] * nf
        if has_src:
            attrs = src_attrs.get(ch["src"])
            if attrs is not None:
                for i, j in copy_idx:
                    if i < len(attrs):
                        vals[j] = attrs[i]
            vals[i_src] = ch["src"]
        d = int(ch["dir"] or 0)
        vals[ow_out] = str(d) if ow_is_text else d
        vals[i_prep] = 1
        f.setAttributes(vals)
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    if stats is not None:
        stats["tratti"] = len(feats)
    return layer


# ---------------------------------------------------------------- diagnostica
_SEV_COLOR = {"error": "#d73027", "warning": "#fc8d59", "info": "#4575b4"}


def build_components_layer(segments, comp_of_seg, main_comp,
                           name="MIC diagnostic - componenti"):
    """Linee colorate per componente connessa; la principale in verde."""
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("component", QVariant.Int),
        QgsField("main_comp", QVariant.Int),
    ])
    layer.updateFields()
    feats = []
    comps = set()
    for seg, comp in zip(segments, comp_of_seg):
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY(
            [QgsPointXY(lo, la) for lo, la in seg]))
        f.setAttributes([int(comp), 1 if comp == main_comp else 0])
        feats.append(f)
        comps.add(comp)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    # stile: principale verde, le altre con colori ciclici
    palette = ["#7b3294", "#e66101", "#1b9e77", "#d95f02", "#7570b3",
               "#e7298a", "#66a61e", "#a6761d"]
    cats = []
    for c in sorted(comps):
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        if c == main_comp:
            sym.setColor(QColor("#1a9850"))
            sym.setWidth(0.6)
            lbl = "principale"
        else:
            sym.setColor(QColor(palette[c % len(palette)]))
            lbl = "componente %d" % c
        cats.append(QgsRendererCategory(int(c), sym, lbl))
    layer.setRenderer(QgsCategorizedSymbolRenderer("component", cats))
    return layer


def build_points_diag_layer(points, name, extra_fields=None):
    """Punti diagnostici con campi liberi.

    :param points: lista di (lat, lon, attrs_dict).
    :param extra_fields: lista di (nome, QVariant.type).
    """
    layer = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    fields = QgsFields()
    for nm, typ in (extra_fields or []):
        fields.append(QgsField(nm, typ))
    layer.dataProvider().addAttributes(fields)
    layer.updateFields()
    feats = []
    names = [f.name() for f in layer.fields()]
    for la, lo, attrs in points:
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lo, la)))
        f.setAttributes([attrs.get(nm) for nm in names])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    return layer


def build_scenario_layer(origins_layer, rows, name="MIC scenario A/B (delta)"):
    """Copia le origini con a_value/b_value/delta/delta_pct/classe.

    Salta le origini con geometria vuota per restare allineate a `rows`.
    """
    wkb = QgsWkbTypes.displayString(origins_layer.wkbType()) or "Point"
    layer = QgsVectorLayer("%s?crs=%s" % (wkb, origins_layer.crs().authid()),
                           name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("a_value", QVariant.Double),
        QgsField("b_value", QVariant.Double),
        QgsField("delta", QVariant.Double),
        QgsField("delta_pct", QVariant.Double),
        QgsField("classe", QVariant.String),
    ])
    layer.updateFields()
    feats = []
    it = iter(rows)
    for src in origins_layer.getFeatures():
        g = src.geometry()
        if g is None or g.isEmpty():
            continue
        r = next(it, None)
        if r is None:
            break
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        f.setAttributes([r["a"], r["b"], r["delta"], r["delta_pct"],
                         r["classe"]])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    values = [f["delta"] for f in layer.getFeatures() if f["delta"] is not None]
    n = min(7, len(set(values)))
    if n >= 1:
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        ramp = QgsGradientColorRamp(QColor(202, 0, 32), QColor(5, 113, 176))
        r = style_util.graduated_from(layer, "delta", n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer


def build_summary_table(issues, name="MIC diagnostic - sintesi"):
    """Tabella senza geometria dei problemi diagnostici."""
    layer = QgsVectorLayer("None", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("code", QVariant.String),
        QgsField("severity", QVariant.String),
        QgsField("message", QVariant.String),
        QgsField("count", QVariant.Int),
    ])
    layer.updateFields()
    feats = []
    for it in issues:
        f = QgsFeature(layer.fields())
        f.setAttributes([it.get("code", ""), it.get("severity", ""),
                         it.get("message", ""), int(it.get("count", 0))])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    return layer


def build_routes_layer(legs, mode_label="", name="MIC - Percorsi"):
    """Layer di linee (EPSG:4326) dei percorsi di routing.compute_routes.

    Campi: da, a (numero del punto), lunghezza_m, tempo_min, vel_kmh, modo,
    esito. I percorsi non trovati sono righe senza geometria con il motivo.
    """
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("da", QVariant.Int),
        QgsField("a", QVariant.Int),
        QgsField("lunghezza_m", QVariant.Double),
        QgsField("tempo_min", QVariant.Double),
        QgsField("vel_kmh", QVariant.Double),
        QgsField("modo", QVariant.String),
        QgsField("esito", QVariant.String),
    ])
    layer.updateFields()
    feats = []
    for leg in legs:
        f = QgsFeature(layer.fields())
        if leg["ok"] and len(leg["coords"]) >= 2:
            f.setGeometry(QgsGeometry.fromPolylineXY(
                [QgsPointXY(lo, la) for lo, la in leg["coords"]]))
        t = leg.get("time_s")
        ln = leg.get("length_m")
        f.setAttributes([
            leg["da"], leg["a"],
            round(ln, 1) if ln is not None else None,
            round(t / 60.0, 2) if t is not None else None,
            round(ln / t * 3.6, 1) if t and ln is not None else None,
            mode_label, "ok" if leg["ok"] else leg.get("msg", ""),
        ])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    sym = QgsSymbol.defaultSymbol(layer.geometryType())
    sym.setColor(QColor("#c2185b"))
    sym.setWidth(1.2)
    from qgis.core import QgsSingleSymbolRenderer
    layer.setRenderer(QgsSingleSymbolRenderer(sym))
    return layer
