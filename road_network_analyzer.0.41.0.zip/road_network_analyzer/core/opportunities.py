# -*- coding: utf-8 -*-
"""Conteggio di opportunità/popolazione dentro poligoni (es. isocrone).

Per ogni poligono conta i punti (POI) contenuti e somma un campo peso opzionale
(es. popolazione). Usato per misurare cosa raggiunge un'isocrona.
"""
from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsSpatialIndex,
)


def count_in_polygons(poly_layer, point_layer, weight_field=None,
                      transform_context=None):
    """Aggiunge n_poi (conteggio) e peso_poi (somma peso) a ogni poligono.

    Modifica il layer poligonale in-place (aggiunge i campi) e ritorna
    (n_poi_totale, peso_totale).
    """
    if transform_context is None:
        from qgis.core import QgsProject
        transform_context = QgsProject.instance().transformContext()
    ct = QgsCoordinateTransform(point_layer.crs(), poly_layer.crs(),
                                transform_context)
    names = point_layer.fields().names()
    use_w = bool(weight_field) and weight_field in names

    pts = []
    index = QgsSpatialIndex()
    for f in point_layer.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        c = g.centroid()
        w = 1.0
        if use_w:
            try:
                w = float(f[weight_field])
            except (TypeError, ValueError):
                w = 0.0  # peso mancante (NULL): non conta
        feat = QgsFeature(len(pts))
        feat.setGeometry(c)
        pts.append((c.asPoint(), w))
        index.addFeature(feat)

    poly_layer.startEditing()
    poly_layer.dataProvider().addAttributes([
        QgsField("n_poi", QVariant.Int),
        QgsField("peso_poi", QVariant.Double),
    ])
    poly_layer.updateFields()
    i_n = poly_layer.fields().indexOf("n_poi")
    i_w = poly_layer.fields().indexOf("peso_poi")

    tot_n = 0
    tot_w = 0.0
    for cell in poly_layer.getFeatures():
        g = cell.geometry()
        if g is None or g.isEmpty():
            continue
        cnt = 0
        wsum = 0.0
        for fid in index.intersects(g.boundingBox()):
            p, w = pts[fid]
            if g.contains(QgsGeometry.fromPointXY(p)):
                cnt += 1
                wsum += w
        poly_layer.changeAttributeValue(cell.id(), i_n, cnt)
        poly_layer.changeAttributeValue(cell.id(), i_w, round(wsum, 2))
        tot_n += cnt
        tot_w += wsum
    poly_layer.commitChanges()
    return tot_n, tot_w
