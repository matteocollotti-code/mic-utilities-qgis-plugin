# -*- coding: utf-8 -*-
"""Grafo degli incroci reali della rete stradale.

Un incrocio è un vertice CONDIVISO in cui si incontrano almeno tre bracci di
strada; i vertici intermedi (grado 2) servono solo a disegnare la forma e non
contano. Da qui si ricavano:

- nodi: vertici dopo lo snap, con grado = numero di vicini distinti;
- catene: i tratti di strada tra due nodi "di rottura" (incroci e vicoli
  ciechi), indipendenti da quanti vertici o feature li disegnano.

Le metriche che contano incroci o tratti (space syntax, densità incroci,
walkability) usano le catene: il risultato non cambia se una strada è
spezzata in dieci feature o disegnata con una sola. Due strade che si
attraversano senza un vertice comune (ponte, sottopasso o rete non "noded")
NON sono connesse. Puro Python, thread-safe.
"""
import math


# campi che indicano il livello di una strada: numerici (layer OSM e simili)
# o sì/no (ponte, tunnel). Due strade a livelli diversi che si incrociano
# senza vertice comune sono un cavalcavia/sottopasso, non un incrocio.
LEVEL_NUMERIC = ("layer", "livello", "z_level", "zlev", "z_order_level")
LEVEL_FLOOR = ("level", "piano")      # piano degli spazi interni (OSM indoor)
LEVEL_BRIDGE = ("bridge", "ponte", "viadotto")
LEVEL_TUNNEL = ("tunnel", "galleria", "sottopasso")
_NO = ("", "no", "false", "0", "null", "none")


def _yes(v):
    if v is None:
        return False
    try:
        from qgis.PyQt.QtCore import QVariant
        if isinstance(v, QVariant) and v.isNull():
            return False
    except Exception:
        pass
    return str(v).strip().lower() not in _NO


def _first_number(v):
    """Primo numero di un valore di campo ("1", "-1", "0;1", 2.0) o None."""
    if v is None:
        return None
    t = str(v).strip()
    if t in ("", "NULL"):
        return None
    try:
        return float(t.split(";")[0].split(",")[0].strip())
    except (TypeError, ValueError):
        return None


def level_reader(field_names):
    """Funzione feature → livello (int) dai campi presenti, o None se il
    layer non ha campi di livello.

    Priorità: campo numerico (layer OSM); altrimenti ponte = +1, tunnel = −1
    (con il tag layer assente OSM sottintende +1 sui ponti e −1 nei tunnel).
    Il piano degli spazi interni (level OSM) distingue in più i percorsi su
    piani diversi: livello = layer × 1000 + piano × 10 (0 = piano strada).
    """
    low = {n.lower(): n for n in field_names}
    num = [low[k] for k in LEVEL_NUMERIC if k in low]
    flo = [low[k] for k in LEVEL_FLOOR if k in low]
    brg = [low[k] for k in LEVEL_BRIDGE if k in low]
    tun = [low[k] for k in LEVEL_TUNNEL if k in low]
    if not (num or flo or brg or tun):
        return None

    def level_of(f):
        lay = None
        for k in num:
            lay = _first_number(f[k])
            if lay is not None:
                break
        if lay is None:
            if any(_yes(f[k]) for k in brg):
                lay = 1
            elif any(_yes(f[k]) for k in tun):
                lay = -1
            else:
                lay = 0
        floor = 0.0
        for k in flo:
            v = _first_number(f[k])
            if v is not None:
                floor = v
                break
        return int(round(lay)) * 1000 + int(round(floor * 10))
    return level_of


def _check_cancel(is_canceled):
    if is_canceled and is_canceled():
        from .gtfs_static import GtfsCancelled
        raise GtfsCancelled()


class Topology(object):
    """Risultato di build_topology.

    node_ll[n] = (lon, lat); degree[n] = bracci; edges[e] = [a, b, src, dir]
    (arco elementare deduplicato, dir relativo ad a→b); inc[n] = archi
    incidenti; chains = lista di dict {u, v, nodes, edges, length_m, src,
    srcs, dir}.
    """

    def __init__(self):
        self.node_ll = []
        self.node_xy = []
        self.degree = []
        self.edges = []
        self.edge_len = []
        self.inc = []
        self.chains = []

    def junctions(self):
        """Nodi con almeno tre bracci (incroci reali)."""
        return [n for n, d in enumerate(self.degree) if d >= 3]

    def dead_ends(self):
        return [n for n, d in enumerate(self.degree) if d == 1]

    def chain_adjacency(self):
        """Catene adiacenti = catene che condividono un nodo estremo."""
        at = {}
        for ci, c in enumerate(self.chains):
            at.setdefault(c["u"], []).append(ci)
            if c["v"] != c["u"]:
                at.setdefault(c["v"], []).append(ci)
        adj = [set() for _ in self.chains]
        for lst in at.values():
            if len(lst) < 2:
                continue
            for i in lst:
                for j in lst:
                    if i != j:
                        adj[i].add(j)
        return [sorted(s) for s in adj]

    def chain_coords(self, ci):
        """Coordinate lon/lat della catena ci."""
        return [self.node_ll[n] for n in self.chains[ci]["nodes"]]


def build_topology(roads_lonlat, sources=None, snap_tol_m=1.0,
                   directions=None, keep_features=False, progress=None,
                   is_canceled=None):
    """Costruisce nodi, archi e catene da polilinee lon/lat.

    :param sources: id di origine per polilinea (default: indice).
    :param directions: senso di marcia per polilinea (1/-1/0) o None.
    :param keep_features: se True le catene si fermano anche dove cambia la
        feature d'origine o il senso unico (rete preparata che conserva gli
        attributi); se False seguono solo la geometria (metriche).
    """
    topo = Topology()
    polys = [(ri, r) for ri, r in enumerate(roads_lonlat or [])
             if r and len(r) >= 2]
    if not polys:
        return topo
    lat0 = polys[0][1][0][1]
    mlat = 111320.0
    mlon = 111320.0 * math.cos(math.radians(lat0))
    cell = max(0.001, float(snap_tol_m))
    key_node = {}
    node_ll = topo.node_ll
    node_xy = topo.node_xy

    def node_of(lon, lat):
        k = (int(round(lon * mlon / cell)), int(round(lat * mlat / cell)))
        n = key_node.get(k)
        if n is None:
            n = len(node_ll)
            key_node[k] = n
            node_ll.append((lon, lat))
            node_xy.append((lon * mlon, lat * mlat))
        return n

    edges = topo.edges
    eidx = {}
    npoly = len(polys)
    for pi, (ri, road) in enumerate(polys):
        if pi % 2000 == 0:
            _check_cancel(is_canceled)
            if progress and npoly:
                progress(int(50 * pi / npoly))
        src = sources[ri] if sources is not None else ri
        d = directions[ri] if directions and ri < len(directions) else 0
        prev = node_of(road[0][0], road[0][1])
        for pt in road[1:]:
            cur = node_of(pt[0], pt[1])
            if cur == prev:
                continue
            k = (prev, cur) if prev < cur else (cur, prev)
            e = eidx.get(k)
            if e is None:
                eidx[k] = len(edges)
                edges.append([prev, cur, src, d])
            else:
                # stesso tratto due volte: sensi in conflitto → doppio senso
                d_this = d if edges[e][0] == prev else (
                    -d if d in (1, -1) else 0)
                if edges[e][3] != d_this:
                    edges[e][3] = 0
            prev = cur

    n_nodes = len(node_ll)
    inc = [[] for _ in range(n_nodes)]
    elen = []
    for e, (a, b, _s, _d) in enumerate(edges):
        inc[a].append(e)
        inc[b].append(e)
        (ax, ay), (bx, by) = node_xy[a], node_xy[b]
        elen.append(math.hypot(bx - ax, by - ay))
    topo.inc = inc
    topo.edge_len = elen
    topo.degree = [len(x) for x in inc]

    def rel_dir(e, frm):
        """Senso dell'arco e percorso partendo dal nodo frm."""
        d = edges[e][3]
        if not d or edges[e][0] == frm:
            return d
        return -d

    brk = [len(x) != 2 for x in inc]
    if keep_features:
        for n in range(n_nodes):
            if brk[n]:
                continue
            e1, e2 = inc[n]
            if edges[e1][2] != edges[e2][2]:
                brk[n] = True
                continue
            # senso entrando in n con e1 e uscendo con e2
            other1 = edges[e1][0] if edges[e1][1] == n else edges[e1][1]
            if rel_dir(e1, other1) != rel_dir(e2, n):
                brk[n] = True

    used = [False] * len(edges)

    def walk(start, e0):
        nodes = [start]
        es = []
        n = start
        e = e0
        while True:
            used[e] = True
            a, b = edges[e][0], edges[e][1]
            nxt = b if a == n else a
            es.append(e)
            nodes.append(nxt)
            if brk[nxt] or nxt == start:
                break
            i0, i1 = inc[nxt]
            e = i1 if i0 == e else i0
            if used[e]:
                break
            n = nxt
        return nodes, es

    raw_chains = []
    for n in range(n_nodes):
        if n % 20000 == 0:
            _check_cancel(is_canceled)
        if not brk[n]:
            continue
        for e in inc[n]:
            if not used[e]:
                raw_chains.append(walk(n, e))
    for e in range(len(edges)):
        if not used[e]:
            # anello isolato senza incroci né vicoli ciechi
            raw_chains.append(walk(edges[e][0], e))
    if progress:
        progress(80)

    for nodes, es in raw_chains:
        # orienta la catena come la digitalizzazione d'origine (per lunghezza)
        fwd = 0.0
        tot = 0.0
        by_src = {}
        for k, e in enumerate(es):
            ln = elen[e]
            tot += ln
            if edges[e][0] == nodes[k]:
                fwd += ln
            s = edges[e][2]
            by_src[s] = by_src.get(s, 0.0) + ln
        if tot > 0 and fwd < tot / 2.0:
            nodes = nodes[::-1]
            es = es[::-1]
        main_src = max(by_src.items(), key=lambda kv: kv[1])[0] \
            if by_src else None
        topo.chains.append({
            "u": nodes[0], "v": nodes[-1], "nodes": nodes, "edges": es,
            "length_m": tot, "src": main_src, "srcs": set(by_src),
            "dir": rel_dir(es[0], nodes[0]) if es else 0,
        })
    if progress:
        progress(100)
    return topo
