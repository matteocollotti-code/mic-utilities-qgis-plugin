# -*- coding: utf-8 -*-
"""Isocrone: geometrie e layer.

Dai tratti di rete raggiunti (net_iso) costruisce le aree per fascia di tempo
in modalita' concava (buffer dei tratti), poligono (inviluppo convesso) o
lineare; inoltre bacini del trasporto pubblico (cerchi attorno alle fermate
raggiunte), scenario A/B e la vecchia isocrona "a volo d'uccello".
"""
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsPointXY,
    QgsRectangle,
    QgsSpatialIndex,
    QgsSymbol,
    QgsVectorLayer,
    QgsWkbTypes,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


def _utm_crs_for(lon, lat):
    zone = int((lon + 180) / 6) + 1
    epsg = (32600 if lat >= 0 else 32700) + zone
    return QgsCoordinateReferenceSystem.fromEpsgId(epsg)


def build_station_isochrones(stops_latlon, speed_kmh, times_min, mode_label,
                             transform_context, name="Isocrone fermate"):
    """Crea un memory layer poligonale con una fascia di copertura per tempo.

    :param stops_latlon: lista di (lat, lon) delle fermate/stazioni.
    :param speed_kmh: velocita' media del mezzo (km/h).
    :param times_min: lista di tempi (minuti).
    :param mode_label: etichetta del mezzo (per l'attributo).
    :return: QgsVectorLayer (Polygon, EPSG:4326).
    """
    pts = [(la, lo) for la, lo in stops_latlon
           if la is not None and lo is not None]
    times = sorted({float(t) for t in times_min if float(t) > 0})
    if not pts or not times:
        raise ValueError("Servono almeno una fermata e un tempo valido.")

    lon0 = sum(p[1] for p in pts) / len(pts)
    lat0 = sum(p[0] for p in pts) / len(pts)
    utm = _utm_crs_for(lon0, lat0)
    to_utm = QgsCoordinateTransform(WGS84, utm, transform_context)
    to_wgs = QgsCoordinateTransform(utm, WGS84, transform_context)
    pts_utm = [to_utm.transform(QgsPointXY(lo, la)) for la, lo in pts]

    layer = QgsVectorLayer("Polygon?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("time_min", QVariant.Double),
        QgsField("mezzo", QVariant.String),
        QgsField("speed_kmh", QVariant.Double),
        QgsField("radius_m", QVariant.Double),
    ])
    layer.updateFields()

    feats = []
    # fascia piu' grande per prima: resta sotto, le piu' piccole sopra
    for t in sorted(times, reverse=True):
        radius_m = speed_kmh * 1000.0 / 60.0 * t
        circles = [QgsGeometry.fromPointXY(p).buffer(radius_m, 24) for p in pts_utm]
        union = QgsGeometry.unaryUnion(circles)
        if union is None or union.isEmpty():
            continue
        union.transform(to_wgs)
        f = QgsFeature(layer.fields())
        f.setGeometry(union)
        f.setAttributes([t, mode_label, speed_kmh, round(radius_m, 1)])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    _style_by_time(layer)
    return layer


def _style_by_time(layer):
    """Legenda CATEGORIZZATA per tempo: una voce per fascia (es. 5, 10, 15 min).

    Verde scuro = vicino, chiaro = lontano. Le voci mostrano i minuti esatti.
    Vale per poligoni (riempimento semitrasparente) e linee (tratto pieno e
    più spesso, altrimenti le fasce non si distinguono sulla mappa).
    """
    from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory
    values = sorted({f["time_min"] for f in layer.getFeatures()
                     if f["time_min"] is not None})
    if not values:
        return
    n = len(values)
    is_line = layer.geometryType() == QgsWkbTypes.LineGeometry
    # verde scuro -> chiaro; per le linee il chiaro è meno tenue (leggibile
    # come tratto su una mappa di base chiara)
    far = (120, 198, 121) if is_line else (199, 233, 192)
    cats = []
    for i, t in enumerate(values):
        frac = i / (n - 1) if n > 1 else 0.0
        col = QColor(
            int(0 + frac * (far[0] - 0)),
            int(104 + frac * (far[1] - 104)),
            int(55 + frac * (far[2] - 55)),
        )
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(col)
        if is_line:
            sym.setWidth(0.9)  # mm
        else:
            sym.setOpacity(0.55)
        label = ("%g min" % t)
        cats.append(QgsRendererCategory(t, sym, label))
    layer.setRenderer(QgsCategorizedSymbolRenderer("time_min", cats))


def _empty_iso_layer(name, geom="Polygon"):
    layer = QgsVectorLayer("%s?crs=EPSG:4326" % geom, name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("source_id", QVariant.Int),
        QgsField("time_min", QVariant.Double),
        QgsField("mezzo", QVariant.String),
        QgsField("speed_kmh", QVariant.Double),
    ])
    layer.updateFields()
    return layer


_CHUNK = 2500      # tratti per blocco nell'unione dei buffer
_TILE_M = 800.0    # tessera per ordinare i tratti (blocchi compatti)


def _union_buffers(parts, access_m, progress=None, is_canceled=None):
    """Buffer di ogni tratto (metri) e unione, a blocchi spazialmente compatti.

    Stesso risultato e stessi tempi di un'unica unione, ma con avanzamento
    continuo e annullabile fra un blocco e l'altro: su una rete grande
    l'unione dura decine di secondi e una sola chiamata GEOS sembrerebbe un
    blocco. In ogni blocco le linee vengono prima unite (mergeLines), così i
    buffer da unire sono molti meno.
    """
    def key(g):
        c = g.boundingBox().center()
        return (int(c.y() // _TILE_M), int(c.x() // _TILE_M))

    parts = sorted(parts, key=key)
    n = len(parts)
    partial = []
    for k in range(0, n, _CHUNK):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        merged = QgsGeometry.unaryUnion(parts[k:k + _CHUNK]).mergeLines()
        lines = (merged.asGeometryCollection() if merged.isMultipart()
                 else [merged])
        partial.append(QgsGeometry.unaryUnion(
            [ln.buffer(access_m, 8) for ln in lines]))
        if progress:
            progress(min(95, int(95 * (k + _CHUNK) / n)))
    return partial[0] if len(partial) == 1 else QgsGeometry.unaryUnion(partial)


def _segments_to_geom(segs, output_mode, access_m, transform_context,
                      progress=None, is_canceled=None):
    """Unisce i segmenti (lon/lat) in una geometria WGS84.

    `linear` = linee unite; `polygon` = inviluppo convesso; altrimenti
    (concavo) = buffer dei segmenti in METRI (proiezione UTM → buffer → WGS84,
    così `access_m` è in metri e non in gradi).
    """
    parts = [QgsGeometry.fromPolylineXY([QgsPointXY(lo, la) for lo, la in s])
             for s in (segs or []) if len(s) >= 2]
    if not parts:
        return None
    if output_mode == "linear":
        union = QgsGeometry.unaryUnion(parts)
        return union if (union is not None and not union.isEmpty()) else None
    lon0 = sum(s[0][0] for s in segs) / len(segs)
    lat0 = sum(s[0][1] for s in segs) / len(segs)
    utm = _utm_crs_for(lon0, lat0)
    to_utm = QgsCoordinateTransform(WGS84, utm, transform_context)
    to_wgs = QgsCoordinateTransform(utm, WGS84, transform_context)
    for p in parts:
        if p.transform(to_utm) != 0:
            return None
    if output_mode == "polygon":
        # inviluppo del buffer = buffer dell'inviluppo (molto piu' veloce)
        geom = QgsGeometry.collectGeometry(parts).convexHull().buffer(
            access_m, 8)
    else:
        # buffer per tratto/linea + unione: decine di volte piu' veloce del
        # buffer di un'unica multilinea con migliaia di tratti
        geom = _union_buffers(parts, access_m, progress, is_canceled)
    if geom is None or geom.isEmpty() or geom.transform(to_wgs) != 0:
        return None
    return geom


def band_geometries(per_source, output_mode, access_m, dissolve,
                    transform_context, progress=None, is_canceled=None):
    """Parte pesante (thread-safe) del layer isocrone: una geometria WGS84 per
    fascia (e per sorgente se non dissolto). Non crea layer, quindi può
    girare in un QgsTask.

    :return: lista di (source_id, time_min, QgsGeometry); source_id = 0 se
        dissolto. Fasce dalla più ampia alla più stretta.
    """
    times = sorted({t for bands in per_source for t in bands}, reverse=True)
    jobs = []
    for t in times:
        if dissolve:
            merged = []
            for bands in per_source:
                merged.extend(bands.get(t, []))
            jobs.append((0, t, _dedup_segments(merged)))
        else:
            for sidx, bands in enumerate(per_source):
                jobs.append((sidx, t, bands.get(t, [])))
    # peso di ogni fascia/sorgente = numero di tratti (avanzamento realistico)
    total = float(sum(len(s) for _i, _t, s in jobs)) or 1.0
    out = []
    done = 0.0
    for sidx, t, segs in jobs:
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        base, share = done, len(segs)
        sub = ((lambda p, b=base, s=share:
                progress(int(100 * (b + s * p / 100.0) / total)))
               if progress else None)
        g = _segments_to_geom(segs, output_mode, access_m, transform_context,
                              sub, is_canceled)
        if g is not None:
            out.append((sidx, t, g))
        done += share
        if progress:
            progress(int(100 * done / total))
    return out


def layer_from_band_geoms(items, speed_kmh, mode_label, output_mode,
                          name="Isocrone (rete)"):
    """Layer isocrone (main thread) dalle geometrie di `band_geometries`.

    Gli elementi possono avere un quarto valore, l'etichetta della linea
    di TP ("Dividi per linea"): allora il layer ha il campo «linea» e la
    legenda è per linea.
    """
    geom_type = "MultiLineString" if output_mode == "linear" else "MultiPolygon"
    layer = _empty_iso_layer(name, geom_type)
    by_line = any(len(it) > 3 for it in items)
    if by_line:
        layer.dataProvider().addAttributes([QgsField("linea", QVariant.String)])
        layer.updateFields()
    feats = []
    for it in items:
        sidx, t, g = it[0], it[1], it[2]
        g = QgsGeometry(g)
        g.convertToMultiType()
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        attrs = [sidx, t, mode_label, speed_kmh]
        if by_line:
            attrs.append(it[3] if len(it) > 3 else "")
        f.setAttributes(attrs)
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    if by_line:
        _style_by_line(layer)
    else:
        # fasce dalla più ampia: le più vicine (più scure) disegnate sopra
        _style_by_time(layer)
    return layer


# colori qualitativi per le linee di TP (ColorBrewer Set1 + Dark2)
_LINE_COLORS = ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00",
                "#a65628", "#f781bf", "#1b9e77", "#d95f02", "#7570b3",
                "#e7298a", "#66a61e", "#e6ab02", "#666666"]


def _style_by_line(layer):
    """Legenda categorizzata per linea di TP: un colore per linea."""
    from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory
    lines = sorted({f["linea"] for f in layer.getFeatures()
                    if f["linea"] is not None})
    is_line = layer.geometryType() == QgsWkbTypes.LineGeometry
    cats = []
    for i, ln in enumerate(lines):
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(QColor(_LINE_COLORS[i % len(_LINE_COLORS)]))
        if is_line:
            sym.setWidth(0.9)
        else:
            sym.setOpacity(0.35)
        cats.append(QgsRendererCategory(ln, sym, "linea %s" % ln))
    layer.setRenderer(QgsCategorizedSymbolRenderer("linea", cats))


def build_layer_from_segments(per_source, speed_kmh, mode_label, output_mode,
                              access_m, dissolve, transform_context=None,
                              name="Isocrone (rete)"):
    """Costruisce il layer isocrone dai segmenti calcolati (lon/lat).

    Il buffer (concavo/poligono) è in METRI: la geometria viene proiettata in
    UTM, bufferata e riproiettata in WGS84 (altrimenti `access_m` sarebbe in
    gradi). Nella GUI le geometrie si calcolano nel task (band_geometries) e
    qui resta solo layer_from_band_geoms.
    """
    if transform_context is None:
        from qgis.core import QgsProject
        transform_context = QgsProject.instance().transformContext()
    items = band_geometries(per_source, output_mode, access_m, dissolve,
                            transform_context)
    return layer_from_band_geoms(items, speed_kmh, mode_label, output_mode,
                                 name)


def _dedup_segments(segs):
    """Rimuove i segmenti duplicati (molte sorgenti raggiungono gli stessi
    archi): unisce per chiave coordinate arrotondate, indipendente dal verso.

    Senza dedup, l'unione di N sorgenti produrrebbe N copie di ogni arco
    condiviso → unaryUnion patologico. Riduce drasticamente l'input.
    """
    seen = set()
    out = []
    for s in segs:
        if len(s) < 2:
            continue
        a = (round(s[0][0], 6), round(s[0][1], 6))
        b = (round(s[-1][0], 6), round(s[-1][1], 6))
        key = (a, b) if a <= b else (b, a)
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


def dissolved_reach_geom(per_source, time_min, access_m, transform_context):
    """Poligono unico (WGS84, modo concavo) dell'area raggiunta a `time_min`.

    Unisce i segmenti di tutte le sorgenti per la fascia indicata, deduplicati
    per non far esplodere l'unione quando le sorgenti sono molte.
    """
    merged = []
    for bands in per_source:
        merged.extend(bands.get(time_min, []))
    merged = _dedup_segments(merged)
    return _segments_to_geom(merged, "concave", access_m, transform_context)


def _geom_area_m2(geom, transform_context):
    """Area in metri quadri (proiezione UTM locale). 0 se geometria vuota."""
    if geom is None or geom.isEmpty():
        return 0.0
    c = geom.centroid().asPoint()
    utm = _utm_crs_for(c.x(), c.y())
    to_utm = QgsCoordinateTransform(WGS84, utm, transform_context)
    g = QgsGeometry(geom)
    if g.transform(to_utm) != 0:
        return 0.0
    return g.area()


def _polygonal(geom):
    """Mantiene solo le parti poligonali di una geometria.

    Le operazioni di differenza/intersezione fra poligoni bufferati possono
    restituire una GeometryCollection (poligoni + tratti di bordo); un layer
    Polygon scarterebbe quelle feature. Qui si filtrano le sole parti poligono.
    """
    if geom is None or geom.isEmpty():
        return QgsGeometry()
    parts = [g for g in geom.asGeometryCollection()
             if not g.isEmpty() and g.type() == QgsWkbTypes.PolygonGeometry]
    if not parts:
        return QgsGeometry()
    if len(parts) == 1:
        return parts[0]
    u = QgsGeometry.unaryUnion(parts)
    return u if (u is not None and not u.isEmpty()) else parts[0]


def build_isochrone_diff_layer(geom_a, geom_b, time_min, transform_context,
                               name="MIC - Scenario isocrone A/B"):
    """Differenza geometrica fra due isocrone su rete (A attuale, B progetto).

    Tre classi: «comune» (A∩B), «guadagno» (B−A, area raggiungibile solo nel
    progetto), «perdita» (A−B, area persa rispetto allo stato attuale).
    Ritorna (layer, summary) con aree in m² ed ettari per classe.
    """
    from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory
    layer = QgsVectorLayer("MultiPolygon?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("classe", QVariant.String),
        QgsField("time_min", QVariant.Double),
        QgsField("area_m2", QVariant.Double),
        QgsField("area_ha", QVariant.Double),
    ])
    layer.updateFields()

    ga = QgsGeometry(geom_a) if geom_a is not None else QgsGeometry()
    gb = QgsGeometry(geom_b) if geom_b is not None else QgsGeometry()
    a_ok = not ga.isEmpty()
    b_ok = not gb.isEmpty()
    common = ga.intersection(gb) if (a_ok and b_ok) else QgsGeometry()
    # guadagno = area solo in B (se A vuota, è tutta B); perdita = solo in A
    gain = (gb.difference(ga) if a_ok else QgsGeometry(gb)) if b_ok \
        else QgsGeometry()
    loss = (ga.difference(gb) if b_ok else QgsGeometry(ga)) if a_ok \
        else QgsGeometry()
    common, gain, loss = _polygonal(common), _polygonal(gain), _polygonal(loss)
    parts = [("comune", common, QColor(120, 120, 120)),
             ("guadagno", gain, QColor(27, 158, 55)),
             ("perdita", loss, QColor(202, 0, 32))]
    feats = []
    summary = {"time_min": time_min}
    cats = []
    for cls, geom, col in parts:
        area = _geom_area_m2(geom, transform_context)
        summary[cls] = area
        if geom is not None and not geom.isEmpty():
            f = QgsFeature(layer.fields())
            f.setGeometry(geom)
            f.setAttributes([cls, time_min, round(area, 1),
                             round(area / 1e4, 3)])
            feats.append(f)
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(col)
        sym.setOpacity(0.5)
        cats.append(QgsRendererCategory(cls, sym, cls))
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    layer.setRenderer(QgsCategorizedSymbolRenderer("classe", cats))
    return layer, summary


def isochrone_scenario_geoms(roads_a, roads_b, sources_latlon, speed_kmh,
                             time_min, access_m=30.0, dir_a=None, dir_b=None,
                             transform_context=None, progress=None,
                             is_canceled=None):
    """Parte pesante (thread-safe) dello scenario isocrone A/B.

    Calcola le due isocrone su rete (Dijkstra sub-arco) per le stesse sorgenti
    e ritorna (ga, gb, n_snap_a, n_snap_b) come geometrie WGS84 dissolte. Non
    crea layer, quindi è eseguibile in un QgsTask in background.
    """
    from . import net_iso
    if transform_context is None:
        from qgis.core import QgsProject
        transform_context = QgsProject.instance().transformContext()
    ps_a, na = net_iso.compute_reachable_segments(
        roads_a, sources_latlon, speed_kmh, [time_min], directions=dir_a,
        progress=(lambda p: progress(int(p * 0.40))) if progress else None,
        is_canceled=is_canceled, dissolve=True)
    ga = dissolved_reach_geom(ps_a, time_min, access_m, transform_context)
    if progress:
        progress(55)
    ps_b, nb = net_iso.compute_reachable_segments(
        roads_b, sources_latlon, speed_kmh, [time_min], directions=dir_b,
        progress=(lambda p: progress(55 + int(p * 0.40))) if progress else None,
        is_canceled=is_canceled, dissolve=True)
    gb = dissolved_reach_geom(ps_b, time_min, access_m, transform_context)
    if progress:
        progress(100)
    return ga, gb, na, nb


def isochrone_scenario(roads_a, roads_b, sources_latlon, speed_kmh, time_min,
                       access_m=30.0, dir_a=None, dir_b=None,
                       transform_context=None, name="MIC - Scenario isocrone A/B",
                       progress=None):
    """Scenario isocrone A/B completo (calcolo + layer). Per uso headless o
    Processing; nella GUI il calcolo gira in un task e il layer si costruisce
    sul main thread via build_isochrone_diff_layer.

    Ritorna (layer, summary) con summary[comune|guadagno|perdita] in m² e
    summary[snap_a|snap_b] = sorgenti agganciate per rete.
    """
    if transform_context is None:
        from qgis.core import QgsProject
        transform_context = QgsProject.instance().transformContext()
    ga, gb, na, nb = isochrone_scenario_geoms(
        roads_a, roads_b, sources_latlon, speed_kmh, time_min, access_m,
        dir_a, dir_b, transform_context, progress=progress)
    layer, summary = build_isochrone_diff_layer(ga, gb, time_min,
                                                transform_context, name)
    summary["snap_a"] = na
    summary["snap_b"] = nb
    return layer, summary


def catchment_geoms(per_band_circles, transform_context, progress=None,
                    is_canceled=None):
    """Parte pesante (thread-safe) dei bacini del trasporto pubblico: unione
    dei cerchi per fascia. Ritorna [(0, t_min, geometria WGS84)] come
    band_geometries, dalla fascia più ampia.

    :param per_band_circles: lista di (t_min, [(lat, lon, radius_m), ...]).
    """
    all_pts = [c for _, circles in per_band_circles for c in circles]
    if not all_pts:
        raise ValueError("Nessuna fermata raggiunta in TP.")
    lat0 = sum(c[0] for c in all_pts) / len(all_pts)
    lon0 = sum(c[1] for c in all_pts) / len(all_pts)
    utm = _utm_crs_for(lon0, lat0)
    to_utm = QgsCoordinateTransform(WGS84, utm, transform_context)
    to_wgs = QgsCoordinateTransform(utm, WGS84, transform_context)
    bands = sorted(per_band_circles, key=lambda x: -x[0])
    out = []
    for k, (t, circles) in enumerate(bands):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        buffs = []
        for la, lo, rad in circles:
            if rad <= 0:
                continue
            p = to_utm.transform(QgsPointXY(lo, la))
            buffs.append(QgsGeometry.fromPointXY(p).buffer(rad, 18))
        if buffs:
            union = QgsGeometry.unaryUnion(buffs)
            if union is not None and not union.isEmpty():
                union.transform(to_wgs)
                out.append((0, t, union))
        if progress:
            progress(int(100 * (k + 1) / len(bands)))
    return out


def build_catchment_layer(per_band_circles, mode_label, transform_context,
                          name="Isocrona TP"):
    """Layer poligonale dai bacini pedonali del trasporto pubblico.

    :param per_band_circles: lista di (t_min, [(lat, lon, radius_m), ...]).
    """
    return layer_from_band_geoms(
        catchment_geoms(per_band_circles, transform_context), 0.0,
        mode_label, "concave", name)


def build_network_isochrones(stops_latlon, road_layer, speed_kmh, times_min,
                             mode_label, transform_context, access_m=30.0,
                             output_mode="concave", dissolve=True,
                             progress=None, is_canceled=None,
                             name="Isocrone fermate (rete)"):
    """Isocrone basate sulla rete stradale (service area via Dijkstra).

    Per ogni fascia di tempo calcola le strade raggiungibili dalle sorgenti
    entro la distanza percorribile (velocita x tempo). Modalita' di output:
      - "linear": i segmenti stradali raggiunti (linee);
      - "polygon": inviluppo convesso dell'area raggiunta;
      - "concave": buffer dei segmenti raggiunti (segue le strade, include gli
        edifici vicini, esclude le aree senza accesso).
    """
    from qgis.analysis import (
        QgsVectorLayerDirector,
        QgsNetworkDistanceStrategy,
        QgsGraphBuilder,
        QgsGraphAnalyzer,
    )

    def _progress(p):
        if progress:
            progress(p)

    pts = [(la, lo) for la, lo in stops_latlon
           if la is not None and lo is not None]
    times = sorted({float(t) for t in times_min if float(t) > 0})
    if not pts or not times:
        raise ValueError("Servono almeno una fermata e un tempo valido.")
    if road_layer is None or not road_layer.isValid():
        raise ValueError("Rete stradale non valida.")

    lon0 = sum(p[1] for p in pts) / len(pts)
    lat0 = sum(p[0] for p in pts) / len(pts)
    utm = _utm_crs_for(lon0, lat0)
    to_utm = QgsCoordinateTransform(WGS84, utm, transform_context)
    to_wgs = QgsCoordinateTransform(utm, WGS84, transform_context)
    road_to_utm = QgsCoordinateTransform(road_layer.crs(), utm, transform_context)

    # solo le strade entro la massima distanza percorribile da una fermata
    start_pts = [to_utm.transform(QgsPointXY(lo, la)) for la, lo in pts]
    max_dist = speed_kmh * 1000.0 / 60.0 * max(times)
    # indice spaziale dei punti fermata per filtrare le strade vicine
    stop_index = QgsSpatialIndex()
    for i, sp in enumerate(start_pts):
        sf = QgsFeature(i)
        sf.setGeometry(QgsGeometry.fromPointXY(sp))
        stop_index.addFeature(sf)

    # rete riproiettata in UTM (distanze in metri), solo strade vicine a fermate
    net = QgsVectorLayer("LineString?crs=%s" % utm.authid(), "net", "memory")
    feats = []
    for f in road_layer.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        if g.transform(road_to_utm) != 0:
            continue
        bb = g.boundingBox()
        search = QgsRectangle(bb.xMinimum() - max_dist, bb.yMinimum() - max_dist,
                              bb.xMaximum() + max_dist, bb.yMaximum() + max_dist)
        if not stop_index.intersects(search):
            continue
        nf = QgsFeature()
        nf.setGeometry(g)
        feats.append(nf)
    net.dataProvider().addFeatures(feats)
    net.updateExtents()
    _progress(15)

    director = QgsVectorLayerDirector(
        net, -1, "", "", "", QgsVectorLayerDirector.DirectionBoth)
    director.addStrategy(QgsNetworkDistanceStrategy())
    builder = QgsGraphBuilder(utm)
    tied = director.makeGraph(builder, start_pts)
    graph = builder.graph()
    _progress(45)

    n_vert = graph.vertexCount()
    # costo a ogni vertice da ciascuna sorgente
    per_source = []
    for sp in tied:
        start = graph.findVertex(sp)
        if start < 0:
            per_source.append(None)
            continue
        _tree, cost = QgsGraphAnalyzer.dijkstra(graph, start, 0)
        per_source.append(cost)
    _progress(70)

    def _band_geom(cost_arr, thr):
        segs = []
        for i in range(n_vert):
            ci = cost_arr[i]
            if ci < 0 or ci > thr:
                continue
            vi = graph.vertex(i)
            pi = vi.point()
            for eid in vi.outgoingEdges():
                edge = graph.edge(eid)
                j = edge.toVertex()
                pj = graph.vertex(j).point()
                length = edge.cost(0)
                cj = cost_arr[j]
                if 0 <= cj <= thr:
                    segs.append(QgsGeometry.fromPolylineXY([pi, pj]))
                else:
                    rem = thr - ci
                    if rem > 0 and length > 0:
                        frac = min(1.0, rem / length)
                        mid = QgsPointXY(pi.x() + frac * (pj.x() - pi.x()),
                                         pi.y() + frac * (pj.y() - pi.y()))
                        segs.append(QgsGeometry.fromPolylineXY([pi, mid]))
        if not segs:
            return None
        union = QgsGeometry.unaryUnion(segs)
        if output_mode == "linear":
            geom = union
        elif output_mode == "polygon":
            geom = union.buffer(access_m, 8).convexHull()
        else:
            geom = union.buffer(access_m, 8)
        if geom is None or geom.isEmpty():
            return None
        geom.transform(to_wgs)
        return geom

    geom_type = "LineString" if output_mode == "linear" else "Polygon"
    layer = _empty_iso_layer(name, geom_type)
    out_feats = []
    for t in sorted(times, reverse=True):
        thr = speed_kmh * 1000.0 / 60.0 * t
        if dissolve:
            combined = [float("inf")] * n_vert
            for cost in per_source:
                if cost is None:
                    continue
                for v in range(n_vert):
                    c = cost[v]
                    if 0 <= c < combined[v]:
                        combined[v] = c
            combined = [c if c != float("inf") else -1 for c in combined]
            geom = _band_geom(combined, thr)
            if geom is not None:
                f = QgsFeature(layer.fields())
                f.setGeometry(geom)
                f.setAttributes([0, t, mode_label, speed_kmh])
                out_feats.append(f)
        else:
            for sidx, cost in enumerate(per_source):
                if cost is None:
                    continue
                geom = _band_geom(cost, thr)
                if geom is not None:
                    f = QgsFeature(layer.fields())
                    f.setGeometry(geom)
                    f.setAttributes([sidx, t, mode_label, speed_kmh])
                    out_feats.append(f)
    layer.dataProvider().addFeatures(out_feats)
    layer.updateExtents()
    if output_mode != "linear":
        _style_by_time(layer)
    _progress(100)
    return layer
