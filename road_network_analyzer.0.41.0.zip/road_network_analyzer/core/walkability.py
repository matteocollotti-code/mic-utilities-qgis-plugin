# -*- coding: utf-8 -*-
"""Indice di walkability (v3) per zona.

Combina fino a quattro dimensioni, ciascuna normalizzata 0-1 sulle zone e poi
mediata (solo le dimensioni presenti) in un indice 0-100:

1. DESIGN (sempre) — morfologia: densità di incroci, densità stradale, rapporto
   link/nodi, connettività media. Incroci, nodi e link vengono dal grafo
   degli incroci reali (topology): nodi = incroci (≥3 bracci) e vicoli
   ciechi, link = tratti tra due nodi. I vertici intermedi che disegnano la
   forma della strada non contano, quindi il risultato non dipende da quanti
   vertici o feature descrivono la rete.
2. DESTINAZIONI (se forniti POI) — accessibilità pedonale alle amenità con
   decadimento della distanza. Modalità `crowfly` (linea d'aria) o `network`
   (distanza di rete: Dijkstra multi-sorgente DAI POI, una volta per categoria).
   Con un campo categoria premia la *diversità* (somma, per categoria, della
   migliore vicinanza).
3. PENDENZA (se fornito un DEM via elev_sampler) — grado medio delle strade;
   più ripido → meno camminabile (componente invertita).
4. ATTRAVERSAMENTI (se forniti) — densità di attraversamenti pedonali per zona
   (n/km²), normalizzata.

Puro Python tranne `elev_sampler`, che il chiamante può legare a un raster QGIS.
"""
import math


def _ring_area_m2(ring_latlon):
    if len(ring_latlon) < 3:
        return 0.0
    lat0 = sum(la for la, lo in ring_latlon) / len(ring_latlon)
    mlon = 111320.0 * math.cos(math.radians(lat0))
    mlat = 111320.0
    pts = [(lo * mlon, la * mlat) for la, lo in ring_latlon]
    s = 0.0
    for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]):
        s += x1 * y2 - x2 * y1
    return abs(s) / 2.0


def _point_in_ring(lon, lat, ring_latlon):
    inside = False
    n = len(ring_latlon)
    j = n - 1
    for i in range(n):
        yi, xi = ring_latlon[i]
        yj, xj = ring_latlon[j]
        if (xi > lon) != (xj > lon):
            yint = yi + (lon - xi) / (xj - xi) * (yj - yi)
            if lat < yint:
                inside = not inside
        j = i
    return inside


def _ring_centroid(ring_latlon):
    n = len(ring_latlon)
    return (sum(la for la, lo in ring_latlon) / n,
            sum(lo for la, lo in ring_latlon) / n)


def _haversine(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = (math.sin(dphi / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2)
    return 2 * r * math.asin(math.sqrt(a))


def _normalize(values, invert=False):
    """Min-max 0-1 sulle zone; con invert=True più alto = peggio (pendenza).

    Differenze sotto una tolleranza relativa contano come zone uguali:
    con un confronto esatto il solo rumore di arrotondamento diventava una
    differenza piena 0 contro 1.
    """
    if not values:
        return []
    lo = min(values)
    hi = max(values)
    span = hi - lo
    if span <= 1e-9 * max(1.0, abs(hi), abs(lo)):
        # tutte le zone uguali: nessuna differenza da premiare o penalizzare
        # (1.0 se il valore è positivo o se è una dimensione invertita)
        return [1.0 if (lo > 0 or invert) else 0.0 for _ in values]
    norm = [(v - lo) / span for v in values]
    return [1.0 - x for x in norm] if invert else norm


def _dest_crowfly(zones_latlon, pois, max_dest_m):
    """Destinazioni in linea d'aria. Ritorna (dest_raw, n_poi)."""
    dest_raw = [0.0] * len(zones_latlon)
    npoi = [0] * len(zones_latlon)
    by_cat = {}
    for la, lo, cat in pois:
        by_cat.setdefault(cat, []).append((la, lo))
    has_cat = not (len(by_cat) == 1 and None in by_cat)
    for zi, ring in enumerate(zones_latlon):
        cla, clo = _ring_centroid(ring)
        if has_cat:
            score = 0.0
            cnt = 0
            for cat, plist in by_cat.items():
                best = 0.0
                for la, lo in plist:
                    dd = _haversine(cla, clo, la, lo)
                    if dd <= max_dest_m:
                        cnt += 1
                        best = max(best, 1.0 - dd / max_dest_m)
                score += best
            dest_raw[zi] = score
            npoi[zi] = cnt
        else:
            score = 0.0
            cnt = 0
            for la, lo in by_cat.get(None, []):
                dd = _haversine(cla, clo, la, lo)
                if dd <= max_dest_m:
                    score += 1.0 - dd / max_dest_m
                    cnt += 1
            dest_raw[zi] = score
            npoi[zi] = cnt
    return dest_raw, npoi


def _dest_network(graph, zones_latlon, pois, max_dest_m):
    """Destinazioni sulla rete: Dijkstra multi-sorgente per categoria DAI POI.

    Per ogni categoria si propaga dai POI fino a max_dest_m; ogni nodo registra
    la distanza al POI più vicino di quella categoria. Poi ogni zona legge la
    distanza dal proprio centroide agganciato. Ritorna (dest_raw, n_cat_reached).
    """
    by_cat = {}
    for la, lo, cat in pois:
        by_cat.setdefault(cat, []).append((la, lo))
    if len(by_cat) == 1 and None in by_cat:
        # senza categorie si sommano TUTTI i POI raggiunti, come in linea
        # d'aria: la modalità cambia la distanza, non il significato
        return _dest_network_sum(graph, zones_latlon, by_cat[None],
                                 max_dest_m)
    # costo per categoria
    cat_cost = {}
    for cat, plist in by_cat.items():
        seeds = []
        for la, lo in plist:
            info = graph.snap_edge_ll(la, lo, 500.0)
            if info:
                seeds.extend(info["seeds"])
        cat_cost[cat] = graph.dijkstra_multi(seeds, max_dest_m) if seeds else None

    dest_raw = [0.0] * len(zones_latlon)
    ncat = [0] * len(zones_latlon)
    for zi, ring in enumerate(zones_latlon):
        cla, clo = _ring_centroid(ring)
        cinfo = graph.snap_edge_ll(cla, clo, 500.0)
        if cinfo is None:
            continue
        score = 0.0
        reached = 0
        for cat, cost in cat_cost.items():
            if cost is None:
                continue
            d = min(cost[n] + off for n, off in cinfo["seeds"])
            if d <= max_dest_m:
                score += 1.0 - d / max_dest_m
                reached += 1
        dest_raw[zi] = score
        ncat[zi] = reached
    return dest_raw, ncat


def _dest_network_sum(graph, zones_latlon, plist, max_dest_m):
    """Somma, per zona, di (1 − d/max) su tutti i POI entro max_dest_m di rete.

    Un Dijkstra per zona dal centroide agganciato, limitato a max_dest_m
    (pochi nodi); i POI candidati sono quelli entro max_dest_m in linea d'aria
    (la distanza di rete non è mai minore). Ritorna (dest_raw, n_poi).
    """
    cell = max(1.0, float(max_dest_m))
    grid = {}
    for la, lo in plist:
        info = graph.snap_edge_ll(la, lo, 500.0)
        if info is None:
            continue
        x, y = graph.to_m(lo, la)
        grid.setdefault((int(x // cell), int(y // cell)), []).append(
            (x, y, info))
    dest_raw = [0.0] * len(zones_latlon)
    npoi = [0] * len(zones_latlon)
    for zi, ring in enumerate(zones_latlon):
        cla, clo = _ring_centroid(ring)
        cinfo = graph.snap_edge_ll(cla, clo, 500.0)
        if cinfo is None:
            continue
        cx, cy = graph.to_m(clo, cla)
        gx, gy = int(cx // cell), int(cy // cell)
        cand = []
        for ix in (gx - 1, gx, gx + 1):
            for iy in (gy - 1, gy, gy + 1):
                for x, y, info in grid.get((ix, iy), ()):
                    if math.hypot(x - cx, y - cy) <= max_dest_m:
                        cand.append(info)
        if not cand:
            continue
        cost = graph.dijkstra_multi(cinfo["seeds"], max_dest_m)
        score = 0.0
        cnt = 0
        for info in cand:
            d = graph.edge_distance(cost, cinfo, info)
            if d <= max_dest_m:
                score += 1.0 - d / max_dest_m
                cnt += 1
        dest_raw[zi] = score
        npoi[zi] = cnt
    return dest_raw, npoi


def compute_walkability(roads_lonlat, zones_latlon, pois=None, max_dest_m=800.0,
                        elev_sampler=None, crossings=None, dest_mode="crowfly",
                        progress=None):
    """Indice di walkability per zona.

    :param zones_latlon: lista di anelli [[(lat,lon),...], ...].
    :param pois: lista di (lat, lon, categoria|None) o None.
    :param dest_mode: 'crowfly' (linea d'aria) o 'network' (distanza di rete).
    :param elev_sampler: f(lon,lat)->quota (m) o None.
    :param crossings: lista di (lat, lon) di attraversamenti pedonali o None.
    :return: lista (per zona) di dict con indicatori, sotto-punteggi e
        'walkability' (0-100).
    """
    from . import net_iso, topology
    polys = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    n_zones = len(zones_latlon)
    if not polys or n_zones == 0:
        return [{"walkability": 0.0, "design": 0.0, "destinazioni": 0.0,
                 "pendenza": 0.0, "attraversamenti": 0.0, "n_incroci": 0,
                 "int_density": 0.0, "street_density": 0.0, "link_node": 0.0,
                 "mean_conn": 0.0, "grade_pct": 0.0, "n_poi": 0, "n_attrav": 0}
                for _ in range(n_zones)]

    lat0 = polys[0][0][1]
    graph = net_iso.build_metric_graph(polys, lat0)
    node_ll = [graph.to_ll(*graph.node_xy[i]) for i in range(graph.n)]
    topo = topology.build_topology(polys)
    zbb = []
    for ring in zones_latlon:
        las = [la for la, lo in ring]
        los = [lo for la, lo in ring]
        zbb.append((min(las), max(las), min(los), max(los)))

    def zone_of(lon, lat):
        for zi, (laM, laX, loM, loX) in enumerate(zbb):
            if laM <= lat <= laX and loM <= lon <= loX and \
                    _point_in_ring(lon, lat, zones_latlon[zi]):
                return zi
        return None

    # nodi del grafo degli incroci (grado ≠ 2) per zona; link contati a metà
    # per ogni estremo nella zona (un tratto a cavallo di due zone vale ½+½)
    deg = topo.degree
    znodes = [[] for _ in range(n_zones)]
    node_zone = {}
    for ni, d in enumerate(deg):
        if d == 2:
            continue
        zi = zone_of(*topo.node_ll[ni])
        node_zone[ni] = zi
        if zi is not None:
            znodes[zi].append(ni)
    zlinks = [0.0] * n_zones
    for ch in topo.chains:
        for end in (ch["u"], ch["v"]):
            zi = node_zone.get(end)
            if zi is not None:
                zlinks[zi] += 0.5
    if progress:
        progress(30)

    node_z = None
    if elev_sampler is not None:
        node_z = []
        for lon, lat in node_ll:
            try:
                node_z.append(elev_sampler(lon, lat))
            except Exception:
                node_z.append(None)

    zlen = [0.0] * n_zones
    zgrade_sum = [0.0] * n_zones
    zgrade_n = [0] * n_zones
    for a, b, d in graph.edges:
        ax, ay = graph.node_xy[a]
        bx, by = graph.node_xy[b]
        mlon, mlat = graph.to_ll((ax + bx) / 2.0, (ay + by) / 2.0)
        zi = zone_of(mlon, mlat)
        if zi is None:
            continue
        zlen[zi] += d
        if node_z is not None and d > 0:
            za, zb = node_z[a], node_z[b]
            if za is not None and zb is not None:
                zgrade_sum[zi] += abs(za - zb) / d
                zgrade_n[zi] += 1
    if progress:
        progress(55)

    # destinazioni
    dest_raw = [0.0] * n_zones
    npoi = [0] * n_zones
    if pois:
        if dest_mode == "network":
            dest_raw, npoi = _dest_network(graph, zones_latlon, pois, max_dest_m)
        else:
            dest_raw, npoi = _dest_crowfly(zones_latlon, pois, max_dest_m)
    if progress:
        progress(75)

    # attraversamenti pedonali per zona
    zcross = [0] * n_zones
    if crossings:
        for la, lo in crossings:
            zi = zone_of(lo, la)
            if zi is not None:
                zcross[zi] += 1

    rows = []
    int_d, str_d, ln_d, mc_d, grade_d, cross_d = [], [], [], [], [], []
    for zi in range(n_zones):
        area_km2 = _ring_area_m2(zones_latlon[zi]) / 1e6
        nodes = znodes[zi]
        nn = len(nodes)
        n_int = sum(1 for ni in nodes if deg[ni] >= 3)
        idn = n_int / area_km2 if area_km2 > 0 else 0.0
        sdn = (zlen[zi] / 1000.0) / area_km2 if area_km2 > 0 else 0.0
        lnr = zlinks[zi] / nn if nn > 0 else 0.0
        mcn = (sum(deg[ni] for ni in nodes) / nn) if nn > 0 else 0.0
        grade = (zgrade_sum[zi] / zgrade_n[zi]) if zgrade_n[zi] > 0 else 0.0
        cdn = zcross[zi] / area_km2 if area_km2 > 0 else 0.0
        int_d.append(idn)
        str_d.append(sdn)
        ln_d.append(lnr)
        mc_d.append(mcn)
        grade_d.append(grade)
        cross_d.append(cdn)
        rows.append({"n_incroci": n_int, "int_density": round(idn, 2),
                     "street_density": round(sdn, 2),
                     "link_node": round(lnr, 2), "mean_conn": round(mcn, 2),
                     "grade_pct": round(100.0 * grade, 2), "n_poi": npoi[zi],
                     "n_attrav": zcross[zi], "cross_density": round(cdn, 2)})

    nidn = _normalize(int_d)
    nsdn = _normalize(str_d)
    nlnr = _normalize(ln_d)
    nmcn = _normalize(mc_d)
    ndest = _normalize(dest_raw)
    ngrade = _normalize(grade_d, invert=True)   # ripido = peggio
    ncross = _normalize(cross_d)
    has_dest = bool(pois)
    has_slope = elev_sampler is not None
    has_cross = bool(crossings)

    for zi in range(n_zones):
        design = (nidn[zi] + nsdn[zi] + nlnr[zi] + nmcn[zi]) / 4.0
        comps = [design]
        rows[zi]["design"] = round(design, 3)
        rows[zi]["destinazioni"] = round(ndest[zi], 3) if has_dest else 0.0
        if has_dest:
            comps.append(ndest[zi])
        if has_slope:
            slope_score = ngrade[zi]
            rows[zi]["pendenza"] = round(slope_score, 3)
            comps.append(slope_score)
        else:
            rows[zi]["pendenza"] = 0.0
        rows[zi]["attraversamenti"] = round(ncross[zi], 3) if has_cross else 0.0
        if has_cross:
            comps.append(ncross[zi])
        rows[zi]["walkability"] = round(100.0 * sum(comps) / len(comps), 1)
    if progress:
        progress(100)
    return rows
