# -*- coding: utf-8 -*-
"""Lettura del GTFS statico e calcolo delle metriche programmate.

Costruisce:
  * geometrie delle linee dalle shapes;
  * segmenti stop-to-stop con lunghezza, tempo e velocita' programmati;
  * metriche di linea (velocita' commerciale e di esercizio, sosta media).

Usa pandas (disponibile nel Python di QGIS) per join e aggregazioni.
Le distanze sono misurate in modo ellissoidale su WGS84.
"""
import contextlib
import math
import os
import zipfile
from array import array
from collections import defaultdict

try:  # pandas è opzionale: serve solo alle funzioni GTFS
    import pandas as pd
except ImportError:  # pragma: no cover
    pd = None

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsDistanceArea,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsUnitTypes,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


class GtfsCancelled(Exception):
    """Sollevata quando l'utente annulla il caricamento in background."""


def _geod():
    da = QgsDistanceArea()
    da.setSourceCrs(WGS84, QgsProject.instance().transformContext())
    da.setEllipsoid("WGS84")
    return da


def interpolate_trip_times(trip_ids, seq, sec):
    """Orari mancanti delle fermate senza orario (non timepoint), interpolati.

    Nel GTFS le fermate intermedie possono avere arrival/departure vuoti: qui
    prendono un tempo interpolato fra la fermata con orario precedente e la
    successiva della stessa corsa (ordine stop_sequence). Senza, quelle
    fermate risultano senza passaggi.

    :param trip_ids, seq, sec: Series allineate (seq e sec numerici o NaN).
    :return: Series dei secondi allineata a sec.
    """
    if not sec.isna().any():
        return sec
    tmp = pd.DataFrame({"t": trip_ids.values,
                        "q": pd.to_numeric(seq, errors="coerce").values,
                        "s": sec.values}, index=sec.index)
    tmp = tmp.sort_values(["t", "q"])
    tmp["s"] = tmp.groupby("t", sort=False)["s"].transform(
        lambda x: x.interpolate(limit_area="inside"))
    return tmp["s"].reindex(sec.index)


def _require_pandas():
    if pd is None:
        raise RuntimeError(
            "Le funzioni GTFS richiedono il modulo 'pandas', non installato nel "
            "Python di QGIS. Installalo dalla OSGeo4W Shell: "
            "python -m pip install pandas.")


def _zip_member(zf, name):
    """Nome del membro dello zip che corrisponde alla tabella `name`.

    Accetta anche i feed con i file dentro una sottocartella (zip creati
    comprimendo la cartella): vince il percorso meno profondo.
    """
    names = zf.namelist()
    if name in names:
        return name
    cands = [n for n in names
             if not n.endswith("/") and n.replace("\\", "/").rsplit("/", 1)[-1] == name
             and "__MACOSX" not in n]
    if not cands:
        return None
    return min(cands, key=lambda n: n.count("/"))


def _dir_member(source, name):
    path = os.path.join(source, name)
    if os.path.exists(path):
        return path
    for root, dirs, files in os.walk(source):
        if root[len(source):].count(os.sep) >= 2:
            dirs[:] = []
        if name in files:
            return os.path.join(root, name)
    return None


def feed_files(source):
    """Nomi (senza cartella) delle tabelle presenti nel feed."""
    if os.path.isdir(source):
        out = set(os.listdir(source))
        for root, dirs, files in os.walk(source):
            if root[len(source):].count(os.sep) >= 2:
                dirs[:] = []
            out.update(files)
        return out
    with zipfile.ZipFile(source) as zf:
        return {n.replace("\\", "/").rsplit("/", 1)[-1] for n in zf.namelist()
                if not n.endswith("/") and "__MACOSX" not in n}


@contextlib.contextmanager
def open_table(source, name):
    """File binario della tabella GTFS (cartella o zip, anche in una
    sottocartella), o None se assente. Da usare con `with`."""
    if os.path.isdir(source):
        path = _dir_member(source, name)
        if path is None:
            yield None
            return
        with open(path, "rb") as fh:
            yield fh
        return
    with zipfile.ZipFile(source) as zf:
        member = _zip_member(zf, name)
        if member is None:
            yield None
            return
        with zf.open(member) as fh:
            yield fh


_ENC_CACHE = {}


def table_encoding(source, name):
    """Codifica della tabella: UTF-8 (con o senza BOM) o, se non è UTF-8
    valido, Windows-1252/Latin-1 (feed esportati da Excel o da sistemi
    vecchi). Si controllano i primi 64 MB; prima un nome accentato in
    latin-1 faceva fallire l'intero caricamento."""
    try:
        key = (os.path.abspath(source), os.path.getmtime(source), name)
    except OSError:
        key = None
    if key is not None and key in _ENC_CACHE:
        return _ENC_CACHE[key]
    enc = "utf-8-sig"
    with open_table(source, name) as fh:
        data = fh.read(64 * 1024 * 1024) if fh is not None else b""
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # un carattere multibyte tagliato alla fine del blocco non conta
        if exc.start < len(data) - 4:
            try:
                data.decode("cp1252")
                enc = "cp1252"
            except UnicodeDecodeError:
                enc = "latin-1"
    if key is not None:
        _ENC_CACHE[key] = enc
    return enc


def read_csv_table(source, name, **kwargs):
    """pandas.read_csv della tabella (None se assente), con la codifica
    giusta. Con `chunksize` usare read_csv_chunks."""
    _require_pandas()
    enc = table_encoding(source, name)
    with open_table(source, name) as fh:
        if fh is None:
            return None
        return pd.read_csv(fh, encoding=enc, **kwargs)


def read_csv_chunks(source, name, consume, **kwargs):
    """Legge la tabella a blocchi passando ogni blocco a consume(chunk).

    :return: False se la tabella non c'è.
    """
    _require_pandas()
    enc = table_encoding(source, name)
    with open_table(source, name) as fh:
        if fh is None:
            return False
        for chunk in pd.read_csv(fh, encoding=enc, **kwargs):
            consume(chunk)
    return True


def _read_table(source, name, usecols=None, dtype=str):
    """Legge una tabella GTFS da cartella o zip; None se assente."""
    _require_pandas()
    return read_csv_table(source, name, dtype=dtype, keep_default_na=False,
                          usecols=usecols)


def _table_columns(source, name):
    """Colonne presenti in una tabella GTFS senza caricarne i dati."""
    df = read_csv_table(source, name, nrows=0)
    return None if df is None else [str(c) for c in df.columns]


def _read_subset(source, name, needed):
    """Legge solo le colonne richieste (se presenti) per ridurre la memoria."""
    cols = _table_columns(source, name)
    if cols is None:
        return None
    use = [c for c in needed if c in cols]
    return _read_table(source, name, usecols=use or None)


def list_routes(source):
    """Elenco delle linee del feed (per il filtro pre-caricamento).

    Legge solo routes.txt (file piccolo): [{route_id, short_name, long_name}].
    """
    routes = _read_table(source, "routes.txt")
    if routes is None:
        return []
    out = []
    for r in routes.itertuples(index=False):
        out.append({
            "route_id": r.route_id,
            "short_name": getattr(r, "route_short_name", ""),
            "long_name": getattr(r, "route_long_name", ""),
        })
    out.sort(key=lambda d: (d["short_name"] or d["route_id"]))
    return out


_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday",
             "saturday", "sunday"]
REQUIRED_FILES = ["agency.txt", "stops.txt", "routes.txt", "trips.txt",
                  "stop_times.txt"]


def active_services(source, service_date):
    """Set di service_id attivi in una data (YYYYMMDD).

    Combina calendar.txt (giorno della settimana + intervallo di validità) e
    calendar_dates.txt (eccezioni: 1=aggiunto, 2=rimosso). Ritorna None se non
    c'è alcun calendario (il chiamante userà il giorno di servizio dominante).
    """
    import datetime
    s = str(service_date)
    if len(s) != 8 or not s.isdigit():
        return None
    try:
        d = datetime.date(int(s[0:4]), int(s[4:6]), int(s[6:8]))
    except ValueError:
        return None
    wcol = _WEEKDAYS[d.weekday()]
    cal = _read_table(source, "calendar.txt")
    cd = _read_table(source, "calendar_dates.txt")
    if (cal is None or cal.empty) and (cd is None or cd.empty):
        return None
    active = set()
    if cal is not None and not cal.empty and wcol in cal.columns:
        for r in cal.itertuples(index=False):
            if str(getattr(r, wcol, "0")) != "1":
                continue
            sd = str(getattr(r, "start_date", "") or "")
            ed = str(getattr(r, "end_date", "") or "")
            if (not sd or sd <= s) and (not ed or s <= ed):
                active.add(getattr(r, "service_id"))
    if cd is not None and not cd.empty and "date" in cd.columns:
        for r in cd.itertuples(index=False):
            if str(getattr(r, "date", "")) != s:
                continue
            sid = getattr(r, "service_id")
            et = str(getattr(r, "exception_type", ""))
            if et == "1":
                active.add(sid)
            elif et == "2":
                active.discard(sid)
    return active


_BUSIEST_CACHE = {}


def busiest_service_date(source, trips):
    """Giorno del calendario con più corse attive: (YYYYMMDD, n_corse) o None.

    Combina calendar.txt (giorni della settimana nell'intervallo di validità,
    al massimo 400 giorni) e calendar_dates.txt (aggiunte/rimozioni). È il
    giorno da usare quando l'utente non indica una data: tutti i servizi
    attivi quel giorno (bus, tram, metro…), non un solo service_id.
    """
    import datetime
    try:
        key = (os.path.abspath(source), os.path.getmtime(source))
    except OSError:
        key = None
    if key is not None and key in _BUSIEST_CACHE:
        return _BUSIEST_CACHE[key]
    per_service = trips["service_id"].value_counts().to_dict()
    date_services = defaultdict(set)
    cal = _read_table(source, "calendar.txt")
    if cal is not None and not cal.empty and "start_date" in cal.columns:
        for r in cal.itertuples(index=False):
            try:
                d0 = datetime.datetime.strptime(str(r.start_date), "%Y%m%d").date()
                d1 = datetime.datetime.strptime(str(r.end_date), "%Y%m%d").date()
            except (ValueError, AttributeError):
                continue
            d1 = min(d1, d0 + datetime.timedelta(days=400))
            d = d0
            while d <= d1:
                if str(getattr(r, _WEEKDAYS[d.weekday()], "0")) == "1":
                    date_services[d.strftime("%Y%m%d")].add(r.service_id)
                d += datetime.timedelta(days=1)
    cd = _read_table(source, "calendar_dates.txt")
    if cd is not None and not cd.empty and "date" in cd.columns:
        for date, sid, et in zip(cd["date"], cd["service_id"],
                                 cd["exception_type"].astype(str)):
            if et == "1":
                date_services[str(date)].add(sid)
            elif et == "2":
                date_services[str(date)].discard(sid)
    best = None
    for date, sids in date_services.items():
        n = sum(per_service.get(s, 0) for s in sids)
        # a parità di corse, la data più vicina all'inizio del feed
        if n and (best is None or n > best[1] or (n == best[1] and date < best[0])):
            best = (date, n)
    if key is not None:
        _BUSIEST_CACHE[key] = best
    return best


def select_trips(trips, source, service_date=None):
    """Filtra il DataFrame trips per data reale (calendario) o giorno più carico.

    Senza data (o con una data non coperta dal feed) usa il giorno del
    calendario con più corse: prima si usava il solo service_id più frequente,
    che in feed come quello di Roma esclude interi modi (metro, tram).

    :return: (trips_filtrato, descrizione testuale del criterio).
    """
    if "service_id" not in trips.columns or trips["service_id"].empty:
        return trips, "tutti i servizi"
    note = ""
    if service_date:
        active = active_services(source, service_date)
        if active is not None:
            sub = trips[trips["service_id"].isin(active)]
            if not sub.empty:
                return sub, "data %s (%d servizi attivi, %d corse)" % (
                    service_date, len(active), len(sub))
            note = "la data %s non è coperta dal feed: " % service_date
    best = busiest_service_date(source, trips)
    if best is not None:
        active = active_services(source, best[0]) or set()
        sub = trips[trips["service_id"].isin(active)]
        if not sub.empty:
            return sub, "%sgiorno più carico del feed %s (%d corse)" % (
                note, best[0], len(sub))
    dominant = trips["service_id"].value_counts().idxmax()
    return (trips[trips["service_id"] == dominant],
            "%sservizio più frequente (%s): il feed non ha calendario"
            % (note, dominant))


def validate_feed(source):
    """Controlli base sul feed GTFS. Ritorna (ok, messaggi, info)."""
    msgs = []
    info = {}
    try:
        present = feed_files(source)
    except Exception as exc:
        return False, ["Impossibile aprire il feed: %s" % exc], {}
    missing = [f for f in REQUIRED_FILES if f not in present]
    ok = not missing
    if missing:
        msgs.append("File richiesti mancanti: %s" % ", ".join(missing))
    has_cal = "calendar.txt" in present
    has_cd = "calendar_dates.txt" in present
    info["calendar"] = has_cal
    info["calendar_dates"] = has_cd
    if not has_cal and not has_cd:
        msgs.append("Né calendar.txt né calendar_dates.txt presenti: verrà "
                    "usato il giorno di servizio dominante.")
    cal = (_read_subset(source, "calendar.txt", ["start_date", "end_date"])
           if has_cal else None)
    if cal is not None and not cal.empty:
        try:
            info["date_min"] = min(cal["start_date"])
            info["date_max"] = max(cal["end_date"])
            msgs.append("Validità del servizio: %s – %s"
                        % (info["date_min"], info["date_max"]))
        except Exception:
            pass
    if ok and not missing:
        msgs.insert(0, "Feed valido (file richiesti presenti).")
    return ok, msgs, info


def _read_stop_times_filtered(source, use, allowed_trips, chunksize=400000):
    """Legge stop_times.txt a blocchi tenendo solo le righe dei trip ammessi.

    Tiene basso il picco di memoria: il file (anche centinaia di MB) viene
    letto a pezzi e di ciascuno si conserva solo il sottoinsieme filtrato.
    """
    frames = []

    def _consume(chunk):
        sub = chunk[chunk["trip_id"].isin(allowed_trips)]
        if not sub.empty:
            frames.append(sub)

    read_csv_chunks(source, "stop_times.txt", _consume, dtype=str,
                    keep_default_na=False, usecols=use, chunksize=chunksize)
    if frames:
        return pd.concat(frames, ignore_index=True)
    return pd.DataFrame(columns=use)


def _time_to_seconds(value):
    """HH:MM:SS -> secondi (ammette ore >= 24); None se non valido."""
    if not value or value.count(":") != 2:
        return None
    try:
        h, m, s = value.split(":")
        return int(h) * 3600 + int(m) * 60 + int(s)
    except ValueError:
        return None


# ----------------------------------------------------------------- geometrie
def build_shapes(source):
    """{shape_id: [(lat, lon, dist|None), ...]} ordinato per sequenza."""
    shapes = _read_table(source, "shapes.txt")
    out = {}
    if shapes is None or shapes.empty:
        return out
    has_dist = "shape_dist_traveled" in shapes.columns
    shapes = shapes.copy()
    shapes["seq"] = pd.to_numeric(shapes["shape_pt_sequence"], errors="coerce")
    shapes["lat"] = pd.to_numeric(shapes["shape_pt_lat"], errors="coerce")
    shapes["lon"] = pd.to_numeric(shapes["shape_pt_lon"], errors="coerce")
    if has_dist:
        shapes["dist"] = pd.to_numeric(shapes["shape_dist_traveled"], errors="coerce")
    for sid, grp in shapes.groupby("shape_id"):
        grp = grp.sort_values("seq")
        if has_dist:
            out[sid] = list(zip(grp["lat"], grp["lon"],
                                [d if pd.notna(d) else None for d in grp["dist"]]))
        else:
            out[sid] = [(la, lo, None) for la, lo in zip(grp["lat"], grp["lon"])]
    return out


def _cut_shape(points, d0, d1):
    """Sotto-polilinea della shape tra le distanze d0 e d1 (interpola i capi).

    :return: lista di (lat, lon) oppure None se le distanze non sono usabili.
    """
    dists = [p[2] for p in points]
    if any(d is None for d in dists) or d0 is None or d1 is None:
        return None
    if d1 < d0:
        d0, d1 = d1, d0

    def interp(d):
        if d <= dists[0]:
            return points[0][0], points[0][1]
        if d >= dists[-1]:
            return points[-1][0], points[-1][1]
        for i in range(len(points) - 1):
            a, b = points[i], points[i + 1]
            if a[2] <= d <= b[2]:
                if b[2] == a[2]:
                    return a[0], a[1]
                t = (d - a[2]) / (b[2] - a[2])
                return a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])
        return points[-1][0], points[-1][1]

    coords = [interp(d0)]
    coords.extend((p[0], p[1]) for p in points if d0 < p[2] < d1)
    coords.append(interp(d1))
    return coords


def _geodesic_length(coords_latlon, da):
    """Lunghezza ellissoidale (m) di una polilinea [(lat, lon), ...]."""
    pts = [QgsPointXY(lon, lat) for lat, lon in coords_latlon]
    if len(pts) < 2:
        return 0.0
    return da.convertLengthMeasurement(
        da.measureLength(QgsGeometry.fromPolylineXY(pts)),
        QgsUnitTypes.DistanceMeters,
    )


def _shape_metric(points):
    """Shape in metri locali: (xy, distanze cumulate, punti (lat, lon, m))."""
    lat0 = points[0][0]
    mlat = 111320.0
    mlon = 111320.0 * math.cos(math.radians(lat0))
    xy = [(lo * mlon, la * mlat) for la, lo, _d in points]
    cum = [0.0]
    for (ax, ay), (bx, by) in zip(xy, xy[1:]):
        cum.append(cum[-1] + math.hypot(bx - ax, by - ay))
    pts = [(la, lo, c) for (la, lo, _d), c in zip(points, cum)]
    return xy, cum, pts, (mlon, mlat)


def _project_stops(shape_m, stops_latlon):
    """Posizione (m lungo la shape) di ogni fermata, in ordine di corsa.

    Proiezione in avanti: ogni fermata si cerca dopo la precedente, così le
    linee che ripassano dallo stesso punto (anelli) restano in ordine. Fra
    segmenti di shape quasi equidistanti (entro 25 m) vince il primo.
    """
    xy, cum, _pts, (mlon, mlat) = shape_m
    n = len(xy)
    out = []
    k0 = 0
    for lat, lon in stops_latlon:
        if lat is None or lon is None or lat != lat or lon != lon:
            out.append(float("nan"))
            continue
        px, py = lon * mlon, lat * mlat
        cands = []
        best = None
        for k in range(k0, n - 1):
            ax, ay = xy[k]
            bx, by = xy[k + 1]
            dx, dy = bx - ax, by - ay
            l2 = dx * dx + dy * dy
            t = ((px - ax) * dx + (py - ay) * dy) / l2 if l2 > 0 else 0.0
            t = 0.0 if t < 0 else (1.0 if t > 1 else t)
            d = math.hypot(px - ax - t * dx, py - ay - t * dy)
            cands.append((k, d, cum[k] + t * math.sqrt(l2)))
            if best is None or d < best:
                best = d
            # trovata una buona proiezione: inutile scorrere tutta la shape
            if best < 30.0 and cum[k] - cands[0][2] > 3000.0:
                break
        if not cands:
            out.append(float("nan"))
            continue
        k, _d, pos = next(c for c in cands if c[1] <= best + 25.0)
        out.append(pos)
        k0 = k
    return out


def _fix_times(trip_codes, pos, arr, dep):
    """Orari mancanti e coppie a tempo zero, interpolati per distanza.

    Una fermata senza orario (non timepoint) o con arrivo non successivo alla
    partenza dalla precedente pur essendo più avanti (orari al minuto: due
    fermate alle 10:00) ha un orario ignoto: lo si ricava interpolando per
    distanza fra gli orari noti della corsa. Prima queste coppie venivano
    scartate: la loro lunghezza spariva dal totale della corsa ma il tempo
    restava, e le fermate senza orario facevano perdere interi segmenti.

    :return: (arr, dep, n_eventi_ricostruiti) come array numpy.
    """
    import numpy as np
    arr = np.asarray(arr, dtype="float64").copy()
    dep = np.asarray(dep, dtype="float64").copy()
    arr = np.where(np.isnan(arr), dep, arr)
    dep = np.where(np.isnan(dep), arr, dep)
    tc = np.asarray(trip_codes)
    same = np.r_[False, tc[1:] == tc[:-1]]
    prev_dep = np.r_[np.nan, dep[:-1]]
    prev_pos = np.r_[np.nan, pos[:-1]]
    with np.errstate(invalid="ignore"):
        zero = same & (arr <= prev_dep) & (pos > prev_pos + 1e-6)
        dep_zero = zero & (dep <= arr)
    arr[zero] = np.nan
    dep[dep_zero] = np.nan
    ev_t = np.column_stack((arr, dep)).ravel()
    ev_p = np.repeat(np.asarray(pos, dtype="float64"), 2)
    ev_c = np.repeat(tc, 2)
    known = ~np.isnan(ev_t)
    n_missing = int((~known).sum())
    if n_missing == 0:
        return arr, dep, 0
    st_ = pd.Series(np.where(known, ev_t, np.nan))
    sp_ = pd.Series(np.where(known, ev_p, np.nan))
    pt = st_.groupby(ev_c).ffill().values
    pp = sp_.groupby(ev_c).ffill().values
    nt = st_.groupby(ev_c).bfill().values
    npos = sp_.groupby(ev_c).bfill().values
    with np.errstate(invalid="ignore", divide="ignore"):
        span = npos - pp
        frac = np.where(span > 0, (ev_p - pp) / span, 0.0)
        fill = pt + (nt - pt) * frac
    ev_t = np.where(known, ev_t, fill)
    n_fixed = int((~known & ~np.isnan(ev_t)).sum())
    return ev_t[0::2], ev_t[1::2], n_fixed


def _agency_timezone(source):
    ag = _read_subset(source, "agency.txt", ["agency_timezone"])
    if ag is not None and "agency_timezone" in ag.columns:
        for tz in ag["agency_timezone"]:
            if str(tz).strip():
                return str(tz).strip()
    return None


def merge_static(acc, new):
    """Unisce un nuovo caricamento (stesso feed e stesso giorno) in `acc`.

    I dizionari di `acc` vengono aggiornati sul posto: chi li tiene (logger
    RT, layer) vede subito le linee aggiunte.
    """
    for k in ("routes", "stops", "shapes_geom", "segments", "trip_index",
              "shape_routes", "line_metrics", "line_hourly_sched",
              "trip_stops"):
        if k in new:
            acc.setdefault(k, {}).update(new[k])
    for k in ("selection", "timezone", "source", "service_date"):
        if k in new:
            acc[k] = new[k]
    acc["times_fixed"] = acc.get("times_fixed", 0) + new.get("times_fixed", 0)
    return acc


# ------------------------------------------------------------------ pipeline
def analyze_static(source, route_ids=None, progress=None, is_canceled=None,
                   service_date=None):
    """Analizza un feed GTFS (cartella o zip) e restituisce le strutture base.

    :param route_ids: se valorizzato, limita l'analisi a queste linee (route_id).
        Riduce drasticamente la memoria: stop_times viene letto a blocchi
        tenendo solo le corse delle linee scelte.
    :param service_date: YYYYMMDD; si analizzano solo le corse di quel giorno
        (senza data: il giorno più carico del feed). Prima si mescolavano
        tutti i giorni (feriali, festivi…) nei tempi e nel numero di corse.
    :param progress: callable(pct 0-100) opzionale per il progresso.
    :param is_canceled: callable() -> bool opzionale per l'annullamento.
    :return: dict con chiavi
        routes, stops, shapes_geom, segments, trip_index, shape_routes,
        line_metrics, line_hourly_sched
    """
    def _progress(pct):
        if progress:
            progress(pct)

    def _check():
        if is_canceled and is_canceled():
            raise GtfsCancelled()

    da = _geod()
    routes = _read_table(source, "routes.txt")
    trips = _read_subset(source, "trips.txt",
                         ["trip_id", "route_id", "direction_id", "shape_id",
                          "service_id"])
    stops = _read_table(source, "stops.txt")
    if trips is None or stops is None:
        raise ValueError("Feed GTFS incompleto: servono trips.txt, "
                         "stop_times.txt e stops.txt.")

    # un solo giorno di servizio (data scelta o giorno più carico)
    trips, selection = select_trips(trips, source, service_date)
    allowed_trips = set(trips["trip_id"])
    # filtro per linea (riduce drasticamente i dati da elaborare)
    if route_ids:
        wanted = set(route_ids)
        trips = trips[trips["route_id"].isin(wanted)].copy()
        allowed_trips = set(trips["trip_id"])
        if not allowed_trips:
            raise ValueError("Nessuna corsa per le linee selezionate nel "
                             "giorno di servizio (%s)." % selection)

    st_need = ["trip_id", "arrival_time", "departure_time",
               "stop_id", "stop_sequence", "shape_dist_traveled"]
    st_cols = _table_columns(source, "stop_times.txt")
    if st_cols is None:
        raise ValueError("Feed GTFS incompleto: manca stop_times.txt.")
    use = [c for c in st_need if c in st_cols]
    if allowed_trips is not None:
        # lettura a blocchi filtrata: poca memoria
        stop_times = _read_stop_times_filtered(source, use, allowed_trips)
    else:
        # dtype compatti: category sulle colonne ad alta ripetizione
        cat = {c: "category" for c in use
               if c in ("trip_id", "stop_id", "arrival_time",
                        "departure_time", "stop_sequence")}
        stop_times = _read_table(source, "stop_times.txt", usecols=use,
                                 dtype=cat or str)
    _check()
    _progress(15)

    shapes_geom = build_shapes(source)
    _check()
    _progress(25)

    # mappa fermate
    stops = stops.copy()
    stops["lat"] = pd.to_numeric(stops["stop_lat"], errors="coerce")
    stops["lon"] = pd.to_numeric(stops["stop_lon"], errors="coerce")
    name_col = "stop_name" if "stop_name" in stops.columns else "stop_id"
    stops_map = {r.stop_id: (r.lat, r.lon, getattr(r, name_col))
                 for r in stops.itertuples(index=False)}

    # mappe trip -> route/direction/shape (evita un merge pesante su milioni
    # di righe; le colonne risultanti restano compatte come category).
    # direction_id vuoto = "0", come nei TripUpdates (prima non combaciavano)
    if "direction_id" not in trips.columns:
        trips = trips.assign(direction_id="0")
    else:
        trips = trips.assign(direction_id=trips["direction_id"].astype(str)
                             .str.strip().replace("", "0"))
    if "shape_id" not in trips.columns:
        trips = trips.assign(shape_id="")
    route_map = dict(zip(trips["trip_id"], trips["route_id"]))
    dir_map = dict(zip(trips["trip_id"], trips["direction_id"].astype(str)))
    shape_map = dict(zip(trips["trip_id"], trips["shape_id"]))

    import numpy as np
    st = stop_times
    st["seq"] = pd.to_numeric(st["stop_sequence"], errors="coerce").astype("float32")
    st["arr_s"] = st["arrival_time"].map(_time_to_seconds).astype("float64") \
        if "arrival_time" in st.columns else np.nan
    st["dep_s"] = st["departure_time"].map(_time_to_seconds).astype("float64") \
        if "departure_time" in st.columns else np.nan
    if "shape_dist_traveled" in st.columns:
        st["sdt"] = pd.to_numeric(
            st["shape_dist_traveled"], errors="coerce").astype("float64")
    else:
        st["sdt"] = np.nan
    st["route_id"] = st["trip_id"].map(route_map).astype("category")
    st["direction_id"] = st["trip_id"].map(dir_map).astype("category")
    st["shape_id"] = st["trip_id"].map(shape_map).astype("category")
    st = st[["trip_id", "stop_id", "seq", "arr_s", "dep_s", "sdt",
             "route_id", "direction_id", "shape_id"]].copy()
    del stop_times
    st = st.sort_values(["trip_id", "seq"]).reset_index(drop=True)
    tc = pd.factorize(st["trip_id"])[0]
    same_prev = np.r_[False, tc[1:] == tc[:-1]]

    # ---- posizione delle fermate lungo la corsa ----
    # shape_dist_traveled; senza, proiezione delle fermate sulla shape (prima i
    # segmenti diventavano linee dritte fra le fermate: lunghezze e velocità
    # sottostimate); senza shape, distanza in linea retta.
    sid_str = st["stop_id"].astype(str)
    lat = sid_str.map({k: v[0] for k, v in stops_map.items()}).astype("float64").values
    lon = sid_str.map({k: v[1] for k, v in stops_map.items()}).astype("float64").values
    mlat_ = 111320.0
    mlon_ = 111320.0 * math.cos(math.radians(float(np.nanmean(lat)) if len(lat) and not np.isnan(lat).all() else 0.0))
    step = np.hypot(np.diff(lon, prepend=np.nan) * mlon_,
                    np.diff(lat, prepend=np.nan) * mlat_)
    step = np.where(same_prev, np.nan_to_num(step), 0.0)
    straight = pd.Series(step).groupby(tc).cumsum().values

    shape_str = st["shape_id"].astype(str).values
    shapes_ok = {sid for sid, pts in shapes_geom.items() if len(pts) >= 2}
    shapes_dist = {sid for sid in shapes_ok
                   if all(p[2] is not None for p in shapes_geom[sid])}
    sdt = st["sdt"].values
    trip_sdt_ok = pd.Series(~np.isnan(sdt)).groupby(tc).transform("all").values
    has_shape = pd.Series(shape_str).isin(shapes_ok).values
    has_sdist = pd.Series(shape_str).isin(shapes_dist).values
    need = has_shape & ~(trip_sdt_ok & has_sdist)
    pm = np.full(len(st), np.nan)
    shape_m = {}
    if need.any():
        rows = np.flatnonzero(need)
        rtc = tc[rows]
        brk = list(np.flatnonzero(np.r_[True, rtc[1:] != rtc[:-1]])) + [len(rows)]
        cache = {}
        stop_vals = sid_str.values
        for a, b in zip(brk, brk[1:]):
            idx = rows[a:b]
            sid = shape_str[idx[0]]
            pat = (sid, tuple(stop_vals[idx]))
            if pat not in cache:
                if sid not in shape_m:
                    shape_m[sid] = _shape_metric(shapes_geom[sid])
                cache[pat] = _project_stops(
                    shape_m[sid], list(zip(lat[idx], lon[idx])))
            pm[idx] = cache[pat]
        _check()
    pos = np.where(trip_sdt_ok & ~need, sdt, np.where(~np.isnan(pm), pm, straight))

    # ---- orari mancanti e coppie a tempo zero ----
    arr, dep, times_fixed = _fix_times(tc, pos, st["arr_s"].values,
                                       st["dep_s"].values)
    st["arr_s"] = arr
    st["dep_s"] = dep
    st["pm"] = pm
    _check()

    # ---- orari programmati per corsa (per il confronto RT corsa per corsa) ----
    trip_stops = {}
    starts = np.flatnonzero(np.r_[True, tc[1:] != tc[:-1]])
    ends = list(starts[1:]) + [len(st)]
    tid_vals = st["trip_id"].astype(str).values
    seq_vals = st["seq"].values
    stop_vals = sid_str.values
    for a, b in zip(starts, ends):
        trip_stops[tid_vals[a]] = (
            tuple(stop_vals[a:b]),
            array("i", [int(x) if x == x else -1 for x in seq_vals[a:b]]),
            array("d", arr[a:b]),
            array("d", dep[a:b]),
        )

    # coppie di fermate consecutive (shift dentro ogni trip)
    grp = st.groupby("trip_id", sort=False, observed=True)
    st["to_stop"] = grp["stop_id"].shift(-1)
    st["to_arr_s"] = grp["arr_s"].shift(-1)
    st["to_sdt"] = grp["sdt"].shift(-1)
    st["to_pm"] = grp["pm"].shift(-1)
    pairs = st.dropna(subset=["to_stop"]).copy()
    pairs["travel_s"] = pairs["to_arr_s"] - pairs["dep_s"]
    del st, grp
    _check()
    _progress(45)

    trip_index = {r.trip_id: (r.route_id, str(r.direction_id))
                  for r in trips.itertuples(index=False)}

    # mappa shape -> route (per costruire il layer delle linee)
    shape_routes = {}
    for r in trips.itertuples(index=False):
        if r.shape_id and r.shape_id not in shape_routes:
            shape_routes[r.shape_id] = (r.route_id, str(r.direction_id))

    # con il filtro per linea, tieni solo le shape delle linee scelte
    if route_ids:
        shapes_geom = {sid: pts for sid, pts in shapes_geom.items()
                       if sid in shape_routes}

    # linee senza shape: geometria dalla sequenza di fermate più lunga (prima
    # il layer delle linee restava vuoto con i feed senza shapes.txt)
    with_shape = {rd for sid, rd in shape_routes.items() if sid in shapes_geom}
    best_trip = {}
    for tid, (rid, d) in trip_index.items():
        if (rid, d) in with_shape or tid not in trip_stops:
            continue
        n = len(trip_stops[tid][0])
        if n > best_trip.get((rid, d), ("", 0))[1]:
            best_trip[(rid, d)] = (tid, n)
    for (rid, d), (tid, _n) in best_trip.items():
        pts = [(stops_map[sid][0], stops_map[sid][1], None)
               for sid in trip_stops[tid][0]
               if sid in stops_map and pd.notna(stops_map[sid][0])]
        if len(pts) >= 2:
            fid = "fermate:%s:%s" % (rid, d)
            shapes_geom[fid] = pts
            shape_routes[fid] = (rid, d)

    routes_map = {}
    if routes is not None:
        rcols = routes.set_index("route_id")
        for rid, row in rcols.iterrows():
            routes_map[rid] = {
                "short_name": row.get("route_short_name", ""),
                "long_name": row.get("route_long_name", ""),
                "route_type": row.get("route_type", ""),
            }

    # ---- segmenti unici (route, direction, from_stop, to_stop) ----
    keys = ["route_id", "direction_id", "stop_id", "to_stop"]
    geo = pairs.groupby(keys, observed=True, sort=False).agg(
        shape_id=("shape_id", "first"), sdt=("sdt", "first"),
        to_sdt=("to_sdt", "first"), pm=("pm", "first"),
        to_pm=("to_pm", "first"))
    ok = pairs["travel_s"] > 0
    tim = pairs[ok].groupby(keys, observed=True, sort=False)["travel_s"].agg(
        ["mean", "std", "count"])
    tim_d = {k: (m, sd, c) for k, m, sd, c in zip(
        tim.index, tim["mean"], tim["std"], tim["count"])}
    segments = {}
    seg_len = {}
    n_seg = len(geo)
    for idx, (key, row) in enumerate(zip(geo.index, geo.itertuples(index=False))):
        if idx % 2000 == 0:
            _check()
            _progress(45 + int(45 * idx / n_seg) if n_seg else 90)
        route_id, direction_id, from_stop, to_stop = key
        direction_id = str(direction_id)
        coords = None
        sid = str(row.shape_id)
        if sid in shapes_dist and pd.notna(row.sdt) and pd.notna(row.to_sdt):
            coords = _cut_shape(shapes_geom[sid], row.sdt, row.to_sdt)
        if coords is None and pd.notna(row.pm) and pd.notna(row.to_pm) \
                and sid in shapes_ok:
            if sid not in shape_m:
                shape_m[sid] = _shape_metric(shapes_geom[sid])
            coords = _cut_shape(shape_m[sid][2], row.pm, row.to_pm)
        if coords is None:
            a = stops_map.get(from_stop)
            b = stops_map.get(to_stop)
            if a and b and pd.notna(a[0]) and pd.notna(b[0]):
                coords = [(a[0], a[1]), (b[0], b[1])]
            else:
                continue
        length_m = _geodesic_length(coords, da)
        if length_m <= 0:
            continue
        nkey = (route_id, direction_id, from_stop, to_stop)
        seg_len[nkey] = length_m
        t = tim_d.get(key)
        if t is None or not t[2]:
            continue  # nessun tempo programmato utilizzabile
        sched_time = float(t[0])
        segments[nkey] = {
            "route_id": route_id,
            "direction_id": direction_id,
            "from_stop": from_stop,
            "to_stop": to_stop,
            "from_name": stops_map.get(from_stop, ("", "", from_stop))[2],
            "to_name": stops_map.get(to_stop, ("", "", to_stop))[2],
            "route_short_name": routes_map.get(route_id, {}).get("short_name", ""),
            "length_m": length_m,
            "sched_time_s": sched_time,
            "sched_speed_kmh": length_m / sched_time * 3.6 if sched_time > 0 else 0.0,
            "n_trips": int(t[2]),
            "coords": coords,
        }

    # ---- metriche di linea (commerciale / esercizio) ----
    # su TUTTE le coppie: lunghezza e tempo restano coerenti anche dove il
    # tempo di una coppia è nullo
    len_df = pd.DataFrame(list(seg_len.keys()), columns=keys)
    len_df["seg_len"] = list(seg_len.values())
    pk = pairs[keys + ["trip_id", "dep_s", "to_arr_s", "travel_s"]].copy()
    for c in keys:
        pk[c] = pk[c].astype(str)
    pk = pk.merge(len_df, on=keys, how="left")
    pk["run"] = pk["travel_s"].clip(lower=0).fillna(0)
    pk["no_len"] = pk["seg_len"].isna()
    trip_stats = pk.groupby(["route_id", "direction_id", "trip_id"]).agg(
        total_len=("seg_len", "sum"),
        running_time=("run", "sum"),
        first_dep=("dep_s", "min"),
        last_arr=("to_arr_s", "max"),
        no_len=("no_len", "sum"),
    ).reset_index()
    del pk, pairs
    trip_stats = trip_stats[trip_stats["no_len"] == 0]
    trip_stats["total_time"] = trip_stats["last_arr"] - trip_stats["first_dep"]
    trip_stats = trip_stats[(trip_stats["total_time"] > 0) &
                            (trip_stats["running_time"] > 0)]
    trip_stats["commercial_kmh"] = trip_stats["total_len"] / trip_stats["total_time"] * 3.6
    trip_stats["running_kmh"] = trip_stats["total_len"] / trip_stats["running_time"] * 3.6
    trip_stats["dwell_s"] = trip_stats["total_time"] - trip_stats["running_time"]

    line_metrics = {}
    for (rid, direction), grp2 in trip_stats.groupby(["route_id", "direction_id"]):
        line_metrics[(rid, str(direction))] = {
            "route_id": rid,
            "direction_id": str(direction),
            "route_short_name": routes_map.get(rid, {}).get("short_name", ""),
            "n_trips": int(len(grp2)),
            "mean_length_m": float(grp2["total_len"].mean()),
            "commercial_speed_kmh": float(grp2["commercial_kmh"].mean()),
            "running_speed_kmh": float(grp2["running_kmh"].mean()),
            "mean_dwell_s": float(grp2["dwell_s"].mean()),
        }

    # ---- velocita' programmata per linea e per ora di partenza ----
    # Definizione space-mean (sum lunghezze / sum tempi di percorrenza) per
    # confrontabilita' con l'osservato ricavato dai segmenti RT.
    ts = trip_stats.copy()
    ts["hour"] = (ts["first_dep"] // 3600 % 24).astype(int)
    line_hourly_sched = {}
    grp_h = ts.groupby(["route_id", "direction_id", "hour"]).agg(
        len_sum=("total_len", "sum"), time_sum=("running_time", "sum"))
    for (rid, direction, hour), row in grp_h.iterrows():
        if row["time_sum"] <= 0:
            continue
        speed = row["len_sum"] / row["time_sum"] * 3.6
        line_hourly_sched.setdefault((rid, str(direction)), {})[int(hour)] = speed
    _progress(100)

    return {
        "routes": routes_map,
        "stops": stops_map,
        "shapes_geom": shapes_geom,
        "segments": segments,
        "trip_index": trip_index,
        "trip_stops": trip_stops,
        "shape_routes": shape_routes,
        "line_metrics": line_metrics,
        "line_hourly_sched": line_hourly_sched,
        "selection": selection,
        "timezone": _agency_timezone(source),
        "times_fixed": times_fixed,
        "source": source,
        "service_date": service_date,
    }
