# -*- coding: utf-8 -*-
"""Map-matching delle velocita' GTFS sui segmenti della rete stradale.

Per ogni feature della rete stradale campiona punti lungo la geometria e cerca
i segmenti GTFS vicini entro una tolleranza e con direzione allineata (per non
agganciare strade perpendicolari). Alla strada vengono assegnate le velocita'
(programmata ed effettiva) dei segmenti di trasporto che la percorrono.

Tutto il calcolo avviene in un CRS metrico: si usa il CRS della rete stradale
se proiettato, altrimenti la zona UTM ricavata dall'estensione dei dati.
"""
import math

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsRectangle,
    QgsSpatialIndex,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


# tipi OSM (campo highway) dove il trasporto su gomma non passa: marciapiedi
# e ciclabili paralleli entro la tolleranza prendevano la velocità del bus
NOT_FOR_TRANSIT = {
    "footway", "path", "cycleway", "steps", "pedestrian", "corridor",
    "bridleway", "platform", "elevator", "sidewalk", "crossing", "track",
}


def transit_road(highway):
    """True se una strada con questo valore highway può portare autobus."""
    return str(highway or "").strip().lower() not in NOT_FOR_TRANSIT


def _utm_crs_for(lon, lat):
    zone = int((lon + 180) / 6) + 1
    epsg = (32600 if lat >= 0 else 32700) + zone
    return QgsCoordinateReferenceSystem.fromEpsgId(epsg)


def _bearing(p1, p2):
    return math.degrees(math.atan2(p2.x() - p1.x(), p2.y() - p1.y())) % 360.0


def _angle_diff_undirected(a, b):
    d = abs(a - b) % 180.0
    return min(d, 180.0 - d)


def _angle_diff_directed(a, b):
    d = abs(a - b) % 360.0
    return min(d, 360.0 - d)


def _work_crs(road_crs, road_geoms, transform_context):
    """CRS metrico di lavoro: quello della rete se è proiettato in metri
    VERI, altrimenti la zona UTM (anche per Web Mercator, dove un "metro"
    della mappa a Roma vale circa 0,74 m)."""
    from qgis.core import QgsUnitTypes
    proj = ""
    try:
        proj = road_crs.toProj() or ""
    except Exception:
        pass
    if (not road_crs.isGeographic()
            and road_crs.mapUnits() == QgsUnitTypes.DistanceMeters
            and "+proj=merc" not in proj):
        return road_crs
    if not road_geoms:
        return _utm_crs_for(0, 0)
    c = road_geoms[0][1].boundingBox().center()
    if not road_crs.isGeographic():
        g = QgsGeometry.fromPointXY(c)
        g.transform(QgsCoordinateTransform(road_crs, WGS84, transform_context))
        c = g.asPoint()
    return _utm_crs_for(c.x(), c.y())


def match_gtfs_to_roads(segments, seg_eff, road_geoms, road_crs, transform_context,
                        tolerance_m=20.0, angle_tol_deg=30.0, spacing_m=25.0,
                        min_cover=0.5, progress=None, is_canceled=None):
    """Associa i segmenti GTFS alle feature stradali.

    Una strada è abbinata solo se almeno `min_cover` dei suoi campioni (presi
    lontano dagli estremi, dove le strade che proseguono si toccano) ha un
    segmento GTFS entro la tolleranza e con direzione simile; ogni segmento
    GTFS deve toccare almeno due campioni (uno solo per le strade molto
    corte). Prima bastava un punto: una via di prosecuzione senza bus veniva
    abbinata tramite il nodo in comune e la velocità finiva su tutta la
    strada. Sulle strade a senso unico conta il verso: le due carreggiate di
    un viale non si scambiano le velocità.

    :param segments: dict {seg_key: {coords (lat,lon), sched_speed_kmh,
                     route_short_name, route_id, ...}} dal GTFS statico.
    :param seg_eff:  dict {seg_key: {eff_speed_kmh, ...}} dal logger RT (o {}).
    :param road_geoms: lista [(fid, QgsGeometry[, oneway])] nella CRS della
        rete stradale; oneway 1 = verso di digitalizzazione, −1 = opposto.
    :param road_crs: QgsCoordinateReferenceSystem della rete stradale.
    :param transform_context: QgsCoordinateTransformContext del progetto.
    :return: dict {fid: {v_sched, v_eff, dev, n_seg, n_routes, routes, cover}}
    """
    import math

    def _progress(pct):
        if progress:
            progress(pct)

    def _check():
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()

    # --- CRS di lavoro (metrico) ---
    work_crs = _work_crs(road_crs, road_geoms, transform_context)
    ct_gtfs = QgsCoordinateTransform(WGS84, work_crs, transform_context)
    ct_road = QgsCoordinateTransform(road_crs, work_crs, transform_context)

    # --- indice spaziale dei segmenti GTFS nel CRS di lavoro ---
    index = QgsSpatialIndex()
    gsegs = {}
    gid = 0
    for key, seg in segments.items():
        coords = seg.get("coords")
        if not coords or len(coords) < 2:
            continue
        g = QgsGeometry.fromPolylineXY([QgsPointXY(lon, lat) for lat, lon in coords])
        if g.transform(ct_gtfs) != 0:
            continue
        line = g.asPolyline()
        if len(line) < 2:
            continue
        f = QgsFeature(gid)
        f.setGeometry(g)
        index.addFeature(f)
        gsegs[gid] = {
            "geom": g,
            "line": line,
            "v_sched": seg.get("sched_speed_kmh", 0.0),
            "v_eff": seg_eff.get(key, {}).get("eff_speed_kmh"),
            "route": seg.get("route_short_name") or seg.get("route_id", ""),
        }
        gid += 1

    tol = float(tolerance_m)
    tol2 = tol * tol
    step = max(5.0, float(spacing_m))
    results = {}
    n_roads = len(road_geoms)

    for i, item in enumerate(road_geoms):
        fid, rgeom = item[0], item[1]
        oneway = item[2] if len(item) > 2 else 0
        if i % 200 == 0:
            _check()
            _progress(int(100 * i / n_roads) if n_roads else 100)
        g = QgsGeometry(rgeom)
        if g.transform(ct_road) != 0:
            continue
        length = g.length()
        if length <= 0:
            continue

        # campioni al centro di intervalli regolari, lontani dagli estremi
        margin = min(tol, length / 4.0)
        usable = length - 2.0 * margin
        n_s = max(1, int(usable // step) + 1) if usable > 0 else 1
        if usable > 0:
            positions = [margin + usable * (k + 0.5) / n_s for k in range(n_s)]
        else:
            positions = [length / 2.0]
        hits = {}
        n_hit = 0
        for d in positions:
            pt = g.interpolate(d)
            if not pt or pt.isEmpty():
                continue
            p = pt.asPoint()
            # direzione con differenze centrali: mai fra due punti uguali
            # (all'estremo veniva "nord" e una via est-ovest si abbinava a
            # una linea nord-sud)
            pa = g.interpolate(max(0.0, d - 2.5)).asPoint()
            pb = g.interpolate(min(length, d + 2.5)).asPoint()
            rb = _bearing(pa, pb) if (pa.x(), pa.y()) != (pb.x(), pb.y()) else None
            if rb is not None and oneway == -1:
                rb = (rb + 180.0) % 360.0
            rect = QgsRectangle(p.x() - tol, p.y() - tol, p.x() + tol, p.y() + tol)
            hit = False
            for cid in index.intersects(rect):
                cg = gsegs[cid]
                sqdist, _near, after, _l = cg["geom"].closestSegmentWithContext(p)
                if sqdist > tol2:
                    continue
                line = cg["line"]
                if not 1 <= after < len(line):
                    continue
                gb = _bearing(line[after - 1], line[after])
                if rb is None:
                    ok = True
                elif oneway in (1, -1):
                    ok = _angle_diff_directed(rb, gb) <= angle_tol_deg
                else:
                    ok = _angle_diff_undirected(rb, gb) <= angle_tol_deg
                if ok:
                    hits[cid] = hits.get(cid, 0) + 1
                    hit = True
            if hit:
                n_hit += 1

        cover = n_hit / float(len(positions))
        if cover < min_cover:
            continue
        need = 2 if len(positions) >= 3 else 1
        matched = {c: h for c, h in hits.items() if h >= need}
        if not matched:
            continue
        # medie pesate sulla parte di strada coperta da ciascun segmento
        wsum = float(sum(matched.values()))
        v_sched = sum(gsegs[c]["v_sched"] * h for c, h in matched.items()) / wsum
        ve = [(gsegs[c]["v_eff"], h) for c, h in matched.items()
              if gsegs[c]["v_eff"] is not None]
        v_eff = (sum(v * h for v, h in ve) / float(sum(h for _v, h in ve))
                 if ve else None)
        routes = sorted({gsegs[c]["route"] for c in matched})
        results[fid] = {
            "v_sched": v_sched,
            "v_eff": v_eff,
            "dev": (v_eff - v_sched) if v_eff is not None else None,
            "n_seg": len(matched),
            "n_routes": len(routes),
            "routes": ",".join(routes),
            "cover": round(cover, 2),
        }
    _progress(100)
    return results
