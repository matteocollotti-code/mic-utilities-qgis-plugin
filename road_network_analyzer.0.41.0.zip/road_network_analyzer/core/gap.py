# -*- coding: utf-8 -*-
"""Gap analysis: aree con accessibilita' bassa (PTAL) e popolazione alta."""
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsSpatialIndex,
    QgsSymbol,
    QgsVectorLayer,
)

from . import style_util


def compute_gap(ptal_layer, pop_layer, pop_field, transform_context,
                name="Gap accessibilita"):
    """Copia le celle PTAL aggiungendo popolazione e punteggio di gap.

    gap = popolazione x (8 - ptal_level) / 8  (alta pop + basso PTAL = gap alto).
    """
    ct = QgsCoordinateTransform(pop_layer.crs(), ptal_layer.crs(),
                                transform_context)
    # punti/centroidi popolazione nella CRS delle celle
    pts = []
    index = QgsSpatialIndex()
    for f in pop_layer.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        c = g.centroid()
        try:
            w = float(f[pop_field]) if pop_field else 1.0
        except (TypeError, ValueError):
            w = 0.0  # popolazione mancante (NULL): non conta, non vale 1
        feat = QgsFeature(len(pts))
        feat.setGeometry(c)
        pts.append((c.asPoint(), w))
        index.addFeature(feat)

    layer = QgsVectorLayer(
        "Polygon?crs=%s" % ptal_layer.crs().authid(), name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("ptal", QVariant.String),
        QgsField("ptal_level", QVariant.Int),
        QgsField("popolazione", QVariant.Double),
        QgsField("gap", QVariant.Double),
    ])
    layer.updateFields()
    feats = []
    for cell in ptal_layer.getFeatures():
        g = cell.geometry()
        if g is None or g.isEmpty():
            continue
        pop = 0.0
        for fid in index.intersects(g.boundingBox()):
            p, w = pts[fid]
            if g.contains(QgsGeometry.fromPointXY(p)):
                pop += w
        try:
            level = int(cell["ptal_level"])
        except (TypeError, ValueError):
            level = None  # livello mancante (NULL): gap non calcolabile
        gap = None if level is None else round(pop * (8 - level) / 8.0, 1)
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        f.setAttributes([cell["ptal"], level, round(pop, 1), gap])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    ramp = QgsGradientColorRamp(QColor(255, 255, 212), QColor(153, 0, 13))
    values = [f["gap"] for f in layer.getFeatures() if f["gap"] is not None]
    n = min(6, len(set(values))) if values else 0
    if n >= 1:
        r = style_util.graduated_from(layer, "gap", n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer
