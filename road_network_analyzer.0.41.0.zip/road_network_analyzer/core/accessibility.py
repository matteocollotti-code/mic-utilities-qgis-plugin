# -*- coding: utf-8 -*-
"""Accessibilita' cumulativa alle opportunita'.

Per ogni origine conta (o somma i pesi del)le destinazioni raggiungibili entro
soglie di tempo, a piedi/bici/auto sulla rete oppure in trasporto pubblico.
"""
import math
from collections import defaultdict


def _haversine(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def accessibility_network(origins_latlon, dests, roads_lonlat, speed_kmh,
                          times_min, progress=None, is_canceled=None,
                          directions=None):
    """Accessibilita' su rete.

    :param dests: lista di (lat, lon, weight).
    :param directions: sensi unici per polilinea (vedi net_iso.build_metric_graph).
    :return: lista (per origine) di dict {t_min: peso_raggiungibile}.
    """
    from . import net_iso
    times = sorted({float(t) for t in times_min if float(t) > 0})
    lat0 = (sum(la for la, lo in origins_latlon) / len(origins_latlon)
            if origins_latlon else 0.0)
    graph = net_iso.build_metric_graph(roads_lonlat, lat0,
                                       directions=directions)
    if progress:
        progress(20)
    max_dist = speed_kmh * 1000.0 / 60.0 * max(times)
    # aggancia destinazioni all'arco piu' vicino (info precisa: edge, t, seeds)
    dest_info = []
    for la, lo, w in dests:
        info = graph.snap_edge_ll(la, lo, 500.0)
        if info:
            dest_info.append((info, float(w)))

    out = []
    n = len(origins_latlon)
    for idx, (la, lo) in enumerate(origins_latlon):
        if is_canceled and idx % 25 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and idx % 50 == 0 and n:
            progress(20 + int(75 * idx / n))
        src_info = graph.snap_edge_ll(la, lo, 500.0)
        res = {t: 0.0 for t in times}
        if src_info:
            # seed e arrivi rispettano i sensi unici (source_seeds/edge_distance)
            cost = graph.dijkstra_multi(graph.source_seeds(src_info), max_dist)
            for dinfo, w in dest_info:
                d = graph.edge_distance(cost, src_info, dinfo)
                if d > max_dist:
                    continue
                for t in times:
                    if d <= speed_kmh * 1000.0 / 60.0 * t:
                        res[t] += w
        out.append(res)
    if progress:
        progress(100)
    return out, times


def accessibility_transit(origins_latlon, dests, gtfs_path, start_h, times_min,
                          walk_speed_kmh, access_m=800.0, egress_m=800.0,
                          access_speed_kmh=None, egress_speed_kmh=None,
                          transfer_penalty_s=0.0, service_date=None,
                          progress=None, is_canceled=None):
    """Accessibilita' via trasporto pubblico (CSA per origine), multimodale.

    Una destinazione conta se raggiunta in tempo con il TP (accesso, corse,
    egress dalla fermata entro egress_m) oppure direttamente, senza mezzi,
    con il modo di accesso.
    """
    from . import transit_iso
    times = sorted({float(t) for t in times_min if float(t) > 0})
    max_t = max(times)
    direct_mps = (access_speed_kmh or walk_speed_kmh) / 3.6
    weights = [float(w) for _la, _lo, w in dests]
    index = transit_iso.PointIndex([(la, lo) for la, lo, _w in dests], egress_m)

    # legge il GTFS UNA volta sola, poi CSA per ogni origine
    data = transit_iso.prepare_transit(
        gtfs_path, start_h, max_t, walk_speed_kmh, 200.0, service_date,
        progress=(lambda p: progress(int(p * 0.3))) if progress else None)

    out = []
    nbr_cache = {}
    n = len(origins_latlon)
    for idx, src in enumerate(origins_latlon):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and n:
            progress(30 + int(70 * idx / n))
        reach = transit_iso.reach_from(
            data, src, access_speed_kmh=access_speed_kmh,
            egress_speed_kmh=egress_speed_kmh, max_access_m=access_m,
            transfer_penalty_s=transfer_penalty_s, budget_s=max_t * 60.0)
        start_s = reach[2]
        best = transit_iso.arrivals_at_points(
            index, src, reach, direct_mps, egress_m, max_t * 60.0, nbr_cache)
        res = {t: 0.0 for t in times}
        for i, a in best.items():
            for t in times:
                if a <= start_s + t * 60.0:
                    res[t] += weights[i]
        out.append(res)
    if progress:
        progress(100)
    return out, times
