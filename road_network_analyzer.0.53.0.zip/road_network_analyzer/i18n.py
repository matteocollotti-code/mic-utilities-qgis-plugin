# -*- coding: utf-8 -*-
"""Lingua del plugin: italiano o inglese.

I testi sono scritti in italiano nel codice, avvolti in `tr("…")`; in
inglese `tr` li cerca in `data/i18n_en.json` ({italiano: inglese}) e, se
manca la traduzione, lascia l'italiano. I testi a livello di modulo sono
tradotti all'importazione: per cambiare lingua il plugin si ricarica
(`set_language`).

La lingua è quella scelta nel pannello (QgsSettings `MIC-Utilities/language`);
la prima volta quella di QGIS se è l'italiano, l'italiano anche per chi usava
già il plugin, altrimenti l'inglese. La variabile d'ambiente `MIC_LANG`
(it/en) ha la precedenza (prove).
"""
import json
import os

KEY = "MIC-Utilities/language"
LANGUAGES = [("it", "Italiano"), ("en", "English")]
TABLE = os.path.join(os.path.dirname(__file__), "data", "i18n_en.json")

_lang = None
_en = None


def _settings():
    from qgis.core import QgsSettings
    return QgsSettings()


def default_language():
    """Lingua senza una scelta salvata: italiano se QGIS è in italiano o se
    il plugin era già in uso (impostazioni salvate), altrimenti inglese."""
    try:
        from qgis.core import QgsApplication
        if (QgsApplication.locale() or "").lower().startswith("it"):
            return "it"
    except Exception:
        pass
    try:
        st = _settings()
        if st.value("MIC-Utilities/repo_added", None) is not None or \
                st.value("MIC-Utilities/last_seen_version", None) is not None:
            return "it"
    except Exception:
        pass
    return "en"


def language():
    """«it» o «en»."""
    global _lang
    if _lang is None:
        v = (os.environ.get("MIC_LANG") or "").strip().lower()
        if v not in ("it", "en"):
            try:
                v = str(_settings().value(KEY, "") or "").lower()
            except Exception:
                v = ""
        _lang = v if v in ("it", "en") else default_language()
    return _lang


def is_english():
    return language() == "en"


def save_language(code):
    """Salva la scelta (vale dal prossimo caricamento del plugin)."""
    global _lang
    if code not in ("it", "en"):
        return
    try:
        _settings().setValue(KEY, code)
    except Exception:
        pass
    _lang = code


def table():
    global _en
    if _en is None:
        try:
            with open(TABLE, encoding="utf-8") as fh:
                _en = json.load(fh)
        except (OSError, ValueError):
            _en = {}
    return _en


def tr(text):
    """Il testo nella lingua scelta (l'italiano se manca la traduzione)."""
    if not text or language() == "it" or not isinstance(text, str):
        return text
    return table().get(text, text)


def num(v, dec=0):
    """Numero con le cifre raggruppate: 1.234,5 in italiano, 1,234.5 in
    inglese; «–» se manca."""
    if v is None:
        return "–"
    try:
        s = ("{:,.%df}" % dec).format(float(v))
    except (TypeError, ValueError):
        return str(v)
    if language() == "en":
        return s
    return s.replace(",", "§").replace(".", ",").replace("§", ".")


def dec_sep(s):
    """Separatore decimale della lingua in un numero già scritto con il
    punto («3.5» → «3,5» in italiano)."""
    return s if language() == "en" else s.replace(".", ",")
