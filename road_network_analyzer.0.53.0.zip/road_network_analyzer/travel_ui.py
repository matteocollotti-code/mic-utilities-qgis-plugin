# -*- coding: utf-8 -*-
"""Controlli riusabili per il mezzo di trasporto delle analisi su rete.

Mezzo (piedi, bici, auto), velocità, sensi unici, velocità di ogni strada
per l'auto (limiti OSM, tipo di strada, campo) e pendenza dal DEM a piedi.
`TravelControls.cost()` produce la configurazione che i task usano per
calcolare il tempo di ogni tratto (gtfs_tasks.read_costed_network).
"""
from .i18n import tr
from qgis.PyQt.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox,
                                 QFormLayout, QGroupBox, QLabel, QSpinBox)
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox

from .core import travel_cost

MODES = {"walk": (tr("Piedi"), 4.5), "bike": (tr("Bici"), 15.0),
         "car": (tr("Auto (limite di ogni strada)"), 50.0)}
OSM_MODE = {"walk": "pedestrian", "bike": "bicycle", "car": "vehicular"}


def dem_combo():
    """Combo dei raster da usare come DEM: vuota all'avvio e senza le mappe
    di sfondo (WMS/XYZ), che sono raster ma non hanno quote. Un WCS resta:
    può essere un DEM (servizi altimetrici nazionali)."""
    c = QgsMapLayerComboBox()
    c.setFilters(QgsMapLayerProxyModel.RasterLayer)
    c.setExcludedProviders(["wms", "arcgismapserver", "arcgisfeatureserver",
                            "vectortile"])
    c.setAllowEmptyLayer(True)
    c.setLayer(None)
    return c


def dem_spec(dem, ctx):
    return travel_cost.dem_spec(dem, ctx)


def car_cost(road, speed_kmh, factor, speed_field=None):
    return travel_cost.car_cost(road.fields().names(), speed_kmh, factor,
                                speed_field)


class TravelControls(object):
    """Righe di un QFormLayout per scegliere il mezzo e le sue velocità."""

    def __init__(self, form, road_combo, modes=("walk", "bike", "car")):
        self.form = form
        self.mode = QComboBox()
        for k in modes:
            self.mode.addItem(MODES[k][0], k)
        form.addRow(tr("Mezzo:"), self.mode)
        self.speed = QDoubleSpinBox()
        self.speed.setDecimals(1)
        self.speed.setRange(0.5, 200.0)
        self.speed.setSingleStep(0.5)
        self.speed.setSuffix(" km/h")
        form.addRow(tr("Velocità:"), self.speed)
        self.oneway = QCheckBox(tr("Rispetta i sensi unici"))
        self.oneway.setToolTip(tr("Usa il campo «oneway» della rete (e i sensi "
                               "unici impliciti OSM)."))
        form.addRow("", self.oneway)
        self.car_box = None
        self.dem = None
        self.dem_box = None
        if "car" in modes:
            self.car_box = QGroupBox(tr("Auto · velocità per strada"))
            cf = QFormLayout(self.car_box)
            self.speed_field = QgsFieldComboBox()
            self.speed_field.setAllowEmptyFieldName(True)
            road_combo.layerChanged.connect(self.speed_field.setLayer)
            self.speed_field.setLayer(road_combo.currentLayer())
            cf.addRow(tr("Campo velocità km/h (opz.):"), self.speed_field)
            self.factor = QSpinBox()
            self.factor.setRange(10, 150)
            self.factor.setValue(100)
            self.factor.setSuffix(" %")
            self.factor.setToolTip(tr("Quota del limite a cui si viaggia davvero "
                                   "(es. 60–70 % in città)."))
            cf.addRow(tr("Velocità effettiva:"), self.factor)
            note = QLabel(tr("Ogni strada si percorre al suo limite (campo, "
                          "maxspeed OSM o tipo di strada); marciapiedi e "
                          "percorsi pedonali sono esclusi."))
            note.setWordWrap(True)
            cf.addRow(note)
            form.addRow(self.car_box)
        if "walk" in modes:
            self.dem_box = QGroupBox(tr("A piedi · pendenza (DEM)"))
            df = QFormLayout(self.dem_box)
            self.dem = dem_combo()
            df.addRow(tr("DEM (quote in m):"), self.dem)
            note = QLabel(tr("Con un DEM la velocità segue la pendenza (Tobler): "
                          "più piano in salita, un po' più veloce in leggera "
                          "discesa."))
            note.setWordWrap(True)
            df.addRow(note)
            form.addRow(self.dem_box)
        self.mode.currentIndexChanged.connect(self._changed)
        self._changed()

    def kind(self):
        return self.mode.currentData()

    def osm_mode(self):
        return OSM_MODE.get(self.kind(), "all")

    def _changed(self, *_a):
        k = self.kind()
        self.speed.setValue(MODES[k][1])
        lab = self.form.labelForField(self.speed)
        if lab is not None:
            lab.setText({"car": tr("Velocità se manca il limite:"),
                         "walk": tr("Velocità (in piano):")}.get(k, tr("Velocità:")))
        if self.car_box is not None:
            self.car_box.setVisible(k == "car")
        if self.dem_box is not None:
            self.dem_box.setVisible(k == "walk")
        self.oneway.setChecked(k == "car")

    def cost(self, road, ctx):
        """(cost per read_costed_network, velocità massima km/h, testo)."""
        k = self.kind()
        v = self.speed.value()
        if k == "car":
            fac = self.factor.value() / 100.0
            sf = self.speed_field.currentField() or None
            cost, vmax = car_cost(road, v, fac, sf)
            return cost, vmax, (tr("in auto, limite di ogni strada (%s) al %d %%")
                                % (tr("campo «%s»") % sf if sf else tr("maxspeed OSM "
                                   "o tipo di strada"), self.factor.value()))
        cost = {"default_mps": v / 3.6}
        desc = tr("%s a %.1f km/h") % ("a piedi" if k == "walk" else tr("in bici"), v)
        dem = self.dem.currentLayer() if (k == "walk" and self.dem) else None
        if dem is not None:
            cost["dem"] = dem_spec(dem, ctx)
            return (cost, v * travel_cost.TOBLER_MAX,
                    desc + tr(" in piano, pendenza dal DEM «%s»") % dem.name())
        return cost, v, desc
