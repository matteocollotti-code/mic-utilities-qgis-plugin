# -*- coding: utf-8 -*-
"""Aggiornamenti del plugin da QGIS.

- `ensure_repository`: aggiunge (una volta sola) il repository del plugin al
  gestore plugin di QGIS, così chi lo ha installato da uno zip riceve gli
  aggiornamenti in «Plugin → Gestisci e installa plugin → Aggiornabili».
- `UpdateChecker`: all'avvio legge il plugins.xml del repository e, se c'è
  una versione più recente di quella installata, mostra un avviso con il
  pulsante «Aggiorna» (apre il gestore plugin sulla scheda degli
  aggiornamenti). Senza rete non fa nulla.
- `prepare_whats_new` / `notify_whats_new`: al primo avvio dopo un
  aggiornamento, una volta sola, avviso «aggiornato alla X» con il pulsante
  «Novità» (le voci del changelog delle versioni nuove); `show_whats_new`
  apre la stessa finestra anche dal menu.
"""
from .i18n import tr
import configparser
import html
import os
import re
import xml.etree.ElementTree as ET

from qgis.PyQt.QtCore import QObject, QUrl
from qgis.PyQt.QtNetwork import QNetworkReply, QNetworkRequest
from qgis.PyQt.QtWidgets import (QDialog, QDialogButtonBox, QPushButton,
                                 QTextBrowser, QVBoxLayout)
from qgis.core import Qgis, QgsNetworkAccessManager, QgsSettings

PLUGIN_ID = "road_network_analyzer"
REPO_NAME = "MIC - Utilities"
REPO_URL = ("https://raw.githubusercontent.com/matteocollotti-code/"
            "mic-utilities-qgis-plugin/main/plugins.xml")
_FLAG = "MIC-Utilities/repo_added"
_REPOS = "app/plugin_repositories"
_SEEN = "MIC-Utilities/last_seen_version"
_ENTRY = re.compile(r"^\s*(\d+(?:\.\d+)+)\s*-\s*(.*)$")
_METADATA = os.path.join(os.path.dirname(__file__), "metadata.txt")


def installed_version():
    """Versione dal metadata.txt del plugin installato."""
    path = os.path.join(os.path.dirname(__file__), "metadata.txt")
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("version="):
                    return line.split("=", 1)[1].strip()
    except OSError:
        pass
    return ""


def changelog_entries(path=None):
    """[(versione, testo)] dal changelog di metadata.txt, dal più recente.

    Una voce comincia con «X.Y.Z -» (anche senza spazio dopo il trattino,
    come «0.38.5 -Isocrone»); le altre righe continuano la voce precedente.
    """
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    try:
        cp.read(path or _METADATA, encoding="utf-8")
        text = cp["general"].get("changelog", "")
    except (configparser.Error, KeyError, OSError):
        return []
    out = []
    for line in text.splitlines():
        m = _ENTRY.match(line)
        if m:
            out.append([m.group(1), m.group(2).strip()])
        elif out and line.strip():
            out[-1][1] = (out[-1][1] + " " + line.strip()).strip()
    return [(v, t) for v, t in out]


def _parts(v):
    out = []
    for p in str(v).replace("-", ".").split("."):
        num = "".join(ch for ch in p if ch.isdigit())
        out.append(int(num) if num else 0)
    return out


def is_newer(available, installed):
    """True se `available` è più recente di `installed` (stesso criterio del
    gestore plugin di QGIS quando disponibile)."""
    try:
        from pyplugin_installer.version_compare import compareVersions
        return compareVersions(available, installed) == 1
    except Exception:
        return _parts(available) > _parts(installed)


def ensure_repository():
    """Aggiunge il repository del plugin al gestore plugin di QGIS.

    Una volta sola: se l'utente poi lo toglie, non viene rimesso.
    :return: True se è stato aggiunto ora.
    """
    s = QgsSettings()
    if s.value(_FLAG, False, type=bool):
        return False
    s.beginGroup(_REPOS)
    present = any(s.value(k + "/url", "", type=str).strip() == REPO_URL
                  for k in s.childGroups())
    s.endGroup()
    if not present:
        base = "%s/%s/" % (_REPOS, REPO_NAME)
        s.setValue(base + "url", REPO_URL)
        s.setValue(base + "enabled", True)
        s.setValue(base + "valid", True)
        s.setValue(base + "authcfg", "")
    s.setValue(_FLAG, True)
    return not present


def prepare_whats_new(current=None, entries=None):
    """Novità da mostrare a questo avvio, una volta sola per versione.

    Va chiamata PRIMA di ensure_repository: il suo flag distingue un
    aggiornamento da una versione senza questo avviso (≤ 0.46.0, flag già
    presente) da una prima installazione (nessun avviso).
    Salva la versione corrente come «vista».
    :return: (versione corrente, [(versione, testo)]) — lista vuota se non
        c'è nulla da mostrare.
    """
    current = current or installed_version()
    if not current:
        return current, []
    s = QgsSettings()
    seen = s.value(_SEEN, "", type=str) or ""
    had_plugin = s.value(_FLAG, False, type=bool)
    s.setValue(_SEEN, current)
    if entries is None:
        entries = changelog_entries()
    if not seen:
        if not had_plugin:
            return current, []      # prima installazione
        return current, [e for e in entries if e[0] == current]
    if not is_newer(current, seen):
        return current, []          # stessa versione (o tornati indietro)
    return current, [e for e in entries
                     if is_newer(e[0], seen) and not is_newer(e[0], current)]


def whats_new_html(entries):
    """HTML della finestra Novità: un titolo per versione, una frase per
    paragrafo."""
    parts = []
    for ver, text in entries:
        parts.append("<h3>Versione %s</h3>" % html.escape(ver))
        sentences = re.split(r"(?<=\.)\s+(?=[A-Z])", text.strip())
        parts.extend("<p>%s</p>" % html.escape(x) for x in sentences if x)
    return "".join(parts) or "<p>Nessuna novità registrata.</p>"


def show_whats_new(parent=None, entries=None, title=None):
    """Finestra con le novità (di default tutte le versioni del changelog)."""
    entries = changelog_entries() if entries is None else entries
    dlg = QDialog(parent)
    dlg.setWindowTitle(title or tr("MIC - Utilities · novità"))
    dlg.resize(560, 460)
    lay = QVBoxLayout(dlg)
    tb = QTextBrowser()
    tb.setOpenExternalLinks(True)
    tb.setHtml(whats_new_html(entries))
    lay.addWidget(tb)
    box = QDialogButtonBox(QDialogButtonBox.Close)
    box.rejected.connect(dlg.reject)
    box.accepted.connect(dlg.accept)
    lay.addWidget(box)
    dlg.exec_()
    return dlg


def notify_whats_new(iface, current, entries):
    """Avviso nella barra dei messaggi con il pulsante «Novità»."""
    if not entries:
        return None
    bar = iface.messageBar()
    w = bar.createMessage("MIC - Utilities",
                          tr("Aggiornato alla versione %s.") % current)
    btn = QPushButton(tr("Novità"))

    def _open():
        show_whats_new(iface.mainWindow(), entries,
                       tr("MIC - Utilities %s · novità") % current)
    btn.clicked.connect(_open)
    w.layout().addWidget(btn)
    bar.pushWidget(w, Qgis.Info, 0)
    return w


def latest_in_xml(data):
    """Versione del plugin nel plugins.xml (bytes), o None."""
    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        return None
    best = None
    for p in root.findall("pyqgis_plugin"):
        pid = p.get("plugin_id") or ""
        fname = (p.findtext("file_name") or "").split(".")[0]
        if PLUGIN_ID not in (pid, fname):
            continue
        v = p.get("version") or p.findtext("version")
        if v and (best is None or is_newer(v, best)):
            best = v
    return best


class UpdateChecker(QObject):
    """Controllo asincrono degli aggiornamenti all'avvio di QGIS."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._reply = None
        self.latest = None

    def start(self):
        req = QNetworkRequest(QUrl(REPO_URL))
        self._reply = QgsNetworkAccessManager.instance().get(req)
        self._reply.finished.connect(self._done)

    def _done(self):
        reply = self._reply
        self._reply = None
        if reply is None:
            return
        try:
            if reply.error() != QNetworkReply.NoError:
                return  # offline o repository non raggiungibile: niente avviso
            latest = latest_in_xml(bytes(reply.readAll()))
        finally:
            reply.deleteLater()
        current = installed_version()
        if latest and current and is_newer(latest, current):
            self.latest = latest
            self._notify(latest, current)

    def _notify(self, latest, current):
        bar = self.iface.messageBar()
        w = bar.createMessage(
            "MIC - Utilities",
            tr("È disponibile la versione %s (installata %s).") % (latest, current))
        btn = QPushButton(tr("Aggiorna"))
        btn.clicked.connect(self.open_manager)
        w.layout().addWidget(btn)
        bar.pushWidget(w, Qgis.Info, 0)

    def open_manager(self):
        """Gestore plugin sulla scheda «Aggiornabili» (repository ricaricati,
        così compare anche se il repository è stato aggiunto ora)."""
        self.iface.messageBar().clearWidgets()
        try:
            import pyplugin_installer
            inst = pyplugin_installer.instance()
            inst.fetchAvailablePlugins(reloadMode=True)
            inst.showPluginManagerWhenReady(3)  # scheda Aggiornabili
        except Exception:
            self.iface.actionManagePlugins().trigger()
