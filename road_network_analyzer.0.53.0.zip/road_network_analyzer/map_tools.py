# -*- coding: utf-8 -*-
"""Strumenti di mappa del pannello."""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.core import QgsGeometry, QgsPointXY, QgsWkbTypes
from qgis.gui import QgsMapTool, QgsRubberBand


class PolygonDrawTool(QgsMapTool):
    """Disegno di un poligono sulla mappa: clic sinistro aggiunge un
    vertice, clic destro (o doppio clic) chiude il poligono, Backspace
    toglie l'ultimo vertice, Esc annulla.

    :param on_done: f(QgsGeometry nel CRS della mappa) a poligono chiuso.
    """

    def __init__(self, canvas, on_done, on_cancel=None):
        super().__init__(canvas)
        self.canvas = canvas
        self.on_done = on_done
        self.on_cancel = on_cancel
        self.points = []
        self.band = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        self.band.setColor(QColor(79, 70, 229, 200))
        self.band.setFillColor(QColor(79, 70, 229, 45))
        self.band.setWidth(2)
        self.setCursor(Qt.CrossCursor)

    def _redraw(self, hover=None):
        self.band.reset(QgsWkbTypes.PolygonGeometry)
        pts = self.points + ([hover] if hover is not None else [])
        for i, p in enumerate(pts):
            self.band.addPoint(p, i == len(pts) - 1)

    def canvasMoveEvent(self, e):  # noqa: N802 (API QGIS)
        if self.points:
            self._redraw(self.toMapCoordinates(e.pos()))

    def canvasReleaseEvent(self, e):  # noqa: N802 (API QGIS)
        pt = self.toMapCoordinates(e.pos())
        if e.button() == Qt.RightButton:
            self.finish()
            return
        if e.button() == Qt.LeftButton:
            self.points.append(QgsPointXY(pt))
            self._redraw()

    def canvasDoubleClickEvent(self, e):  # noqa: N802 (API QGIS)
        self.finish()

    def keyPressEvent(self, e):  # noqa: N802 (API QGIS)
        if e.key() == Qt.Key_Escape:
            self.clear()
            if self.on_cancel:
                self.on_cancel()
        elif e.key() in (Qt.Key_Backspace, Qt.Key_Delete) and self.points:
            self.points.pop()
            self._redraw()

    def finish(self):
        # il doppio clic aggiunge anche un ultimo vertice ripetuto
        pts = []
        for p in self.points:
            if not pts or p != pts[-1]:
                pts.append(p)
        if len(pts) < 3:
            return
        geom = QgsGeometry.fromPolygonXY([pts + [pts[0]]])
        if not geom.isGeosValid():
            geom = geom.makeValid()
        self.points = []
        self.on_done(geom)

    def clear(self):
        self.points = []
        self.band.reset(QgsWkbTypes.PolygonGeometry)

    def show_geometry(self, geom):
        """Mostra un poligono (CRS della mappa) già disegnato."""
        self.band.reset(QgsWkbTypes.PolygonGeometry)
        if geom is not None and not geom.isEmpty():
            self.band.setToGeometry(geom, None)

    def deactivate(self):  # noqa: N802 (API QGIS)
        super().deactivate()
