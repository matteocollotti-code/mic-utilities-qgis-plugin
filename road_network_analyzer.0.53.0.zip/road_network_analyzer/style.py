# -*- coding: utf-8 -*-
"""Tema "liquid glass" (ispirato a shadcn) per il pannello, via QSS.

Nota: shadcn e' una libreria React/Tailwind e non puo' girare in un dock Qt;
qui se ne riproduce l'estetica (palette neutra, angoli arrotondati, accento
indaco, superfici translucide) con un foglio di stile Qt.
"""

MIC_STYLE = """
QWidget {
    background: transparent;
    color: #0f172a;
    font-family: "Segoe UI", "Inter", sans-serif;
    font-size: 9pt;
}
QScrollArea, QAbstractScrollArea {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 #eef2f7, stop:1 #e7ecf3);
    border: none;
}
QTabWidget::pane {
    border: 1px solid rgba(148,163,184,0.35);
    border-radius: 12px;
    background: rgba(255,255,255,0.65);
    top: -1px;
}
QTabBar::tab {
    background: rgba(255,255,255,0.45);
    color: #475569;
    padding: 5px 6px;
    margin-right: 2px;
    border: 1px solid rgba(148,163,184,0.30);
    border-top-left-radius: 9px;
    border-top-right-radius: 9px;
}
QTabBar::tab:selected {
    background: rgba(255,255,255,0.92);
    color: #4f46e5;
    border-bottom: 2px solid #4f46e5;
}
QTabBar::tab:hover { background: rgba(255,255,255,0.75); }
QGroupBox {
    background: rgba(255,255,255,0.55);
    border: 1px solid rgba(148,163,184,0.35);
    border-radius: 12px;
    margin-top: 14px;
    padding: 10px 8px 8px 8px;
    font-weight: 600;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 1px 8px;
    color: #334155;
    background: rgba(255,255,255,0.85);
    border-radius: 7px;
}
QPushButton {
    background: #4f46e5;
    color: #ffffff;
    border: none;
    border-radius: 9px;
    padding: 6px 9px;
    font-weight: 600;
}
QPushButton:hover { background: #4338ca; }
QPushButton:pressed { background: #3730a3; }
QPushButton:checked { background: #0ea5e9; }
QPushButton:disabled { background: rgba(148,163,184,0.45); color: #f1f5f9; }
QPushButton[flat="true"] {
    background: transparent; color: #4f46e5; font-weight: 600; padding: 2px;
}
QPushButton[flat="true"]:hover { background: rgba(79,70,229,0.10); }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTimeEdit, QDateTimeEdit, QTextBrowser,
QPlainTextEdit {
    background: rgba(255,255,255,0.92);
    border: 1px solid rgba(148,163,184,0.45);
    border-radius: 8px;
    padding: 4px 6px;
    selection-background-color: #c7d2fe;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus,
QTimeEdit:focus {
    border: 1px solid #6366f1;
}
QComboBox::drop-down { border: none; width: 18px; }
QCheckBox { spacing: 6px; }
QLabel { background: transparent; }
QTableWidget, QTableView {
    background: rgba(255,255,255,0.85);
    border: 1px solid rgba(148,163,184,0.35);
    border-radius: 10px;
    gridline-color: rgba(148,163,184,0.30);
}
QHeaderView::section {
    background: rgba(241,245,249,0.95);
    color: #334155;
    border: none;
    border-right: 1px solid rgba(148,163,184,0.25);
    padding: 4px 6px;
    font-weight: 600;
}
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical {
    background: rgba(148,163,184,0.55); border-radius: 5px; min-height: 24px;
}
QScrollBar::add-line, QScrollBar::sub-line { height: 0; }
/* finestre aperte dal pannello (barre di avanzamento, domande, menu,
   elenchi a discesa): fondo bianco esplicito. Senza, ereditano
   «background: transparent» e su Windows escono nere. */
QDialog, QMessageBox, QProgressDialog {
    background: #ffffff;
}
QMenu {
    background: #ffffff;
    border: 1px solid rgba(148,163,184,0.45);
    border-radius: 8px;
    padding: 4px;
}
QMenu::item { padding: 5px 18px; border-radius: 6px; }
QMenu::item:selected { background: #eef2ff; color: #3730a3; }
QComboBox QAbstractItemView, QListView {
    background: #ffffff;
    selection-background-color: #e0e7ff;
    selection-color: #0f172a;
}
QToolTip {
    background: #ffffff;
    color: #0f172a;
    border: 1px solid rgba(148,163,184,0.6);
    padding: 3px 5px;
}
QProgressBar {
    background: #e2e8f0;
    border: none;
    border-radius: 6px;
    min-height: 16px;
    text-align: center;
    color: #0f172a;
    font-weight: 600;
}
QProgressBar::chunk { background: #a5b4fc; border-radius: 6px; }
QProgressDialog QLabel { color: #0f172a; padding: 2px 0px; }
QProgressDialog QProgressBar {
    min-height: 10px;
    max-height: 10px;
    color: transparent;
}
QProgressDialog QProgressBar::chunk { background: #4f46e5; border-radius: 5px; }
"""


def panel_style(icon_dir):
    """Foglio di stile del pannello: MIC_STYLE + frecce delle sezioni
    richiudibili (QGroupBox «checkable»: ▸ chiusa, ▾ aperta, invece della
    casella di spunta, che sembrava un'opzione da attivare)."""
    d = icon_dir.replace("\\", "/")
    return MIC_STYLE + """
QGroupBox::indicator { width: 14px; height: 14px; }
QGroupBox::indicator:unchecked { image: url(%s/chevron_right.svg); }
QGroupBox::indicator:checked { image: url(%s/chevron_down.svg); }
QGroupBox:checkable { font-weight: 600; }
QGroupBox[micCollapsed="true"] {
    background: transparent;
    border: none;
    padding: 0px;
}
""" % (d, d)
