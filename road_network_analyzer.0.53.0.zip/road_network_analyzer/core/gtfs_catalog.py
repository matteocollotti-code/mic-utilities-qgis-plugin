# -*- coding: utf-8 -*-
"""GTFS trovati in automatico per un'area: catalogo Mobility Database.

Il catalogo (MobilityData, https://mobilitydatabase.org) è un CSV aperto
con circa 3.600 feed nel mondo e, per ognuno, il riquadro delle fermate e
una copia dell'ultimo GTFS ospitata dal catalogo (`urls.latest`, senza
chiavi). Si scarica una volta alla settimana; i feed scelti restano in cache
una settimana.

Scelta dei feed per un'area: GTFS non dismessi (status diverso da
deprecated/inactive/development, senza redirect), con un riquadro valido che
tocca l'area, non più grande di `max_area` gradi² (i riquadri enormi sono
feed nazionali o hanno fermate sbagliate) e, se il paese è noto, dello stesso
paese; i più piccoli (locali) per primi. Nessun oggetto QGIS: si può usare
in un task.
"""
from ..i18n import tr
import csv
import io
import json
import os
import time
import zipfile

from . import istat

CATALOG_URL = ("https://storage.googleapis.com/storage/v1/b/mdb-csv/o/"
               "sources.csv?alt=media")
SITE = "Mobility Database"
SOURCE = tr("GTFS dal catalogo Mobility Database (MobilityData)")
MAX_AGE_S = 7 * 24 * 3600
SKIP_STATUS = {"deprecated", "inactive", "development"}

_CACHE_DIR = None


def set_cache_dir(path):
    global _CACHE_DIR
    _CACHE_DIR = path


def cache_dir():
    d = _CACHE_DIR or os.path.join(os.path.dirname(istat.cache_dir()), "gtfs")
    os.makedirs(d, exist_ok=True)
    return d


def _fresh(path, max_age=MAX_AGE_S):
    return os.path.exists(path) and time.time() - os.path.getmtime(path) < \
        max_age


def catalog(progress=None, is_canceled=None, url=CATALOG_URL):
    """Righe del catalogo (dict); lo riscarica se ha più di una settimana.
    Se il sito non risponde usa la copia in cache, anche vecchia."""
    path = os.path.join(cache_dir(), "mobilitydatabase_sources.csv")
    if not _fresh(path):
        try:
            istat._download(url, path, progress or (lambda _f: None),
                            is_canceled, site=SITE)
        except istat.Cancelled:
            raise
        except Exception:
            if not os.path.exists(path):
                raise
    with io.open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# nomi inglesi delle città nel catalogo → nomi locali (comuni ISTAT,
# municipi INEGI)
ALIASES = {"rome": "roma", "milan": "milano", "turin": "torino",
           "naples": "napoli", "florence": "firenze", "venice": "venezia",
           "genoa": "genova", "padua": "padova", "mantua": "mantova",
           "syracuse": "siracusa", "leghorn": "livorno", "bozen": "bolzano",
           "mexico city": "ciudad de mexico", "cdmx": "ciudad de mexico"}


def plain(text):
    """Minuscolo senza accenti, per confrontare i nomi."""
    import unicodedata
    t = unicodedata.normalize("NFKD", str(text or "")).encode(
        "ascii", "ignore").decode("ascii").lower().strip()
    return ALIASES.get(t, t)


def find_feeds(rows, bbox, country=None, max_feeds=3, max_area=2.0,
               names=None):
    """Feed GTFS per il riquadro WGS84 (ovest, sud, est, nord).

    I feed senza riquadro nel catalogo si prendono se il loro comune è fra
    `names` (comuni o Stati dell'area): sono segnati `check` e vanno
    verificati sulle fermate dopo il download (`stops_bbox`).

    :return: [{id, provider, name, url, license, bbox, area, check}] dal
        più locale."""
    w, s, e, n = bbox
    wanted = {plain(x) for x in (names or []) if x}
    out, seen = [], set()
    for r in rows:
        if (r.get("data_type") or "").strip() != "gtfs":
            continue
        if (r.get("status") or "").strip().lower() in SKIP_STATUS or \
                (r.get("redirect.id") or "").strip():
            continue
        if country and (r.get("location.country_code") or "").upper() not in \
                ("", country.upper()):
            continue
        b = [_f(r.get("location.bounding_box." + k)) for k in (
            "minimum_longitude", "minimum_latitude", "maximum_longitude",
            "maximum_latitude")]
        check = False
        if None in b or b[2] <= b[0] or b[3] <= b[1]:
            # senza riquadro: solo se il comune del feed è quello dell'area
            muni = plain(r.get("location.municipality"))
            if not wanted or muni not in wanted:
                continue
            b, area, check = None, 0.0, True
        else:
            if b[2] < w or b[0] > e or b[3] < s or b[1] > n:
                continue
            area = (b[2] - b[0]) * (b[3] - b[1])
            if area > max_area:
                continue
        url = (r.get("urls.latest") or "").strip()
        if not url and (r.get("urls.authentication_type") or "").strip() in \
                ("", "0"):
            url = (r.get("urls.direct_download") or "").strip()
        if not url:
            continue
        prov = (r.get("provider") or "").strip()
        key = (prov.lower(), (r.get("name") or "").strip().lower())
        if key in seen:
            continue
        seen.add(key)
        out.append({"id": (r.get("mdb_source_id") or r.get("id") or "").strip(),
                    "provider": prov, "name": (r.get("name") or "").strip(),
                    "url": url, "license": (r.get("urls.license") or "").strip(),
                    "bbox": b, "area": area, "check": check})
    out.sort(key=lambda x: x["area"])
    return out[:max_feeds]


def stops_bbox(path):
    """Riquadro (ovest, sud, est, nord) delle fermate di un GTFS, o None."""
    try:
        with zipfile.ZipFile(path) as z:
            name = [x for x in z.namelist()
                    if os.path.basename(x) == "stops.txt"][0]
            with z.open(name) as raw:
                rd = csv.DictReader(io.TextIOWrapper(raw, "utf-8-sig"))
                xs, ys = [], []
                for r in rd:
                    la, lo = _f(r.get("stop_lat")), _f(r.get("stop_lon"))
                    if la is not None and lo is not None and (la or lo):
                        ys.append(la)
                        xs.append(lo)
    except (OSError, IndexError, KeyError, zipfile.BadZipFile, ValueError):
        return None
    if not xs:
        return None
    xs.sort()
    ys.sort()
    # 1 % - 99 %: poche fermate sbagliate non allargano il riquadro
    k = int(len(xs) * 0.01)
    return (xs[k], ys[k], xs[-1 - k], ys[-1 - k])


def label(feed):
    """Nome leggibile del feed: «Fornitore (nome)»."""
    return feed["provider"] + (" (%s)" % feed["name"] if feed.get("name")
                               else "")


def download(feed, progress=None, is_canceled=None):
    """Il GTFS del feed in cache (scaricato se manca o ha più di una
    settimana). Controlla che sia un GTFS (stops e stop_times)."""
    safe = "".join(c if c.isalnum() else "_" for c in str(feed["id"]))
    path = os.path.join(cache_dir(), "mdb_%s.zip" % safe)
    if not _fresh(path):
        istat._download(feed["url"], path, progress or (lambda _f: None),
                        is_canceled, site=SITE)
        try:
            with zipfile.ZipFile(path) as z:
                names = {os.path.basename(x) for x in z.namelist()}
        except zipfile.BadZipFile:
            names = set()
        if not {"stops.txt", "stop_times.txt"} <= names:
            istat._remove(path)
            raise RuntimeError(tr("il GTFS di «%s» non è valido (mancano "
                                  "stops.txt o stop_times.txt)") % label(feed))
        with io.open(path + ".json", "w", encoding="utf-8") as fh:
            json.dump(feed, fh, ensure_ascii=False)
    return path


def feeds_for_area(bbox, country=None, max_feeds=3, progress=None,
                   is_canceled=None, status=None, url=CATALOG_URL, names=None):
    """Cerca e scarica i GTFS dell'area. :return: ([(percorso, feed)],
    [avvisi]). Un feed che non si scarica non ferma gli altri; uno senza
    riquadro nel catalogo resta solo se le sue fermate toccano l'area."""
    say = status or (lambda _t: None)
    prog = progress or (lambda _p: None)
    say(tr("catalogo dei GTFS (Mobility Database)"))
    rows = catalog(lambda f: prog(10 * f), is_canceled, url)
    feeds = find_feeds(rows, bbox, country, max_feeds, names=names)
    out, notes = [], []
    for i, feed in enumerate(feeds):
        say(tr("GTFS %d di %d: %s") % (i + 1, len(feeds), label(feed)))
        lo = 10 + 90.0 * i / max(1, len(feeds))
        hi = 10 + 90.0 * (i + 1) / max(1, len(feeds))
        try:
            path = download(feed, lambda f: prog(lo + (hi - lo) * f),
                            is_canceled)
            if feed.get("check"):
                sb = stops_bbox(path)
                w, s, e, n = bbox
                if sb is None or not (sb[2] >= w and sb[0] <= e and
                                      sb[3] >= s and sb[1] <= n):
                    continue
                feed["bbox"] = list(sb)
            out.append((path, feed))
        except istat.Cancelled:
            raise
        except Exception as exc:
            notes.append(tr("GTFS «%s» non scaricato: %s") % (label(feed), exc))
    prog(100)
    return out, notes


def cache_info():
    """[(feed, MB, data)] dei GTFS in cache."""
    out = []
    d = cache_dir()
    for fn in sorted(os.listdir(d)):
        if fn.startswith("mdb_") and fn.endswith(".zip"):
            p = os.path.join(d, fn)
            try:
                feed = json.load(io.open(p + ".json", encoding="utf-8"))
            except (OSError, ValueError):
                feed = {"provider": fn, "name": ""}
            out.append((feed, os.path.getsize(p) / 1e6,
                        time.strftime("%Y-%m-%d", time.localtime(
                            os.path.getmtime(p)))))
    return out
