# -*- coding: utf-8 -*-
"""Gap analysis: aree con accessibilita' bassa (PTAL) e popolazione alta."""
from ..i18n import tr
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsSpatialIndex,
    QgsSymbol,
    QgsVectorLayer,
)

from . import style_util


def compute_gap(ptal_layer, pop_layer, pop_field, transform_context,
                name=tr("Gap accessibilita")):
    """Copia le celle PTAL aggiungendo popolazione e punteggio di gap.

    gap = popolazione x (8 - ptal_level) / 8  (alta pop + basso PTAL = gap alto).
    """
    ct = QgsCoordinateTransform(pop_layer.crs(), ptal_layer.crs(),
                                transform_context)
    # punti/centroidi popolazione nella CRS delle celle
    pts = []
    for f in pop_layer.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        c = g.centroid()
        try:
            w = float(f[pop_field]) if pop_field else 1.0
        except (TypeError, ValueError):
            w = 0.0  # popolazione mancante (NULL): non conta, non vale 1
        pts.append((c.asPoint(), w))

    layer = style_util.memory_layer("Polygon", ptal_layer.crs(), name)
    layer.dataProvider().addAttributes([
        QgsField("ptal", QVariant.String),
        QgsField("ptal_level", QVariant.Int),
        QgsField("popolazione", QVariant.Double),
        QgsField("gap", QVariant.Double),
    ])
    layer.updateFields()
    feats = []
    cells = [c for c in ptal_layer.getFeatures()
             if c.geometry() is not None and not c.geometry().isEmpty()]
    _n, pops = assign_points_to_cells([c.geometry() for c in cells], pts)
    for cell, pop in zip(cells, pops):
        g = cell.geometry()
        try:
            level = int(cell["ptal_level"])
        except (TypeError, ValueError):
            level = None  # livello mancante (NULL): gap non calcolabile
        gap = None if level is None else round(pop * (8 - level) / 8.0, 1)
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        f.setAttributes([cell["ptal"], level, round(pop, 1), gap])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    ramp = QgsGradientColorRamp(QColor(255, 255, 212), QColor(153, 0, 13))
    values = [f["gap"] for f in layer.getFeatures() if f["gap"] is not None]
    n = min(6, len(set(values))) if values else 0
    if n >= 1:
        r = style_util.graduated_from(layer, "gap", n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer


def assign_points_to_cells(cell_geoms, pts):
    """Somma dei pesi e conteggio dei punti per cella. Ogni punto va in UNA
    sola cella, anche se cade sul bordo comune a due celle (con «contiene»
    un punto sul bordo non finiva in nessuna; con «interseca» in due): vince
    la prima cella nell'ordine dato.

    :param cell_geoms: lista di QgsGeometry poligonali.
    :param pts: lista di (QgsPointXY, peso).
    :return: (conteggi, pesi) per cella.
    """
    from qgis.core import QgsRectangle
    index = QgsSpatialIndex()
    for k, g in enumerate(cell_geoms):
        ft = QgsFeature(k)
        ft.setGeometry(g)
        index.addFeature(ft)
    engines = {}
    counts = [0] * len(cell_geoms)
    sums = [0.0] * len(cell_geoms)
    for p, w in pts:
        eps = 1e-9 * max(1.0, abs(p.x()), abs(p.y()))
        cand = index.intersects(QgsRectangle(p.x() - eps, p.y() - eps,
                                             p.x() + eps, p.y() + eps))
        if not cand:
            continue
        pg = QgsGeometry.fromPointXY(p)
        for k in sorted(cand):
            eng = engines.get(k)
            if eng is None:
                eng = QgsGeometry.createGeometryEngine(
                    cell_geoms[k].constGet())
                eng.prepareGeometry()
                engines[k] = eng
            if eng.intersects(pg.constGet()):
                counts[k] += 1
                sums[k] += w
                break
    return counts, sums
