# -*- coding: utf-8 -*-
"""Visualizzatore Origine-Destinazione: desire lines tra centroidi di zona."""
from ..i18n import tr
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsPointXY,
    QgsSymbol,
    QgsVectorLayer,
)

from . import style_util

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


def filter_rows(od_rows, min_flow=0.0, top_n=0, origin=None, dest=None):
    """Applica i filtri alle righe OD."""
    rows = [(o, d, v) for o, d, v in od_rows if v >= min_flow]
    if origin:
        rows = [r for r in rows if str(r[0]) == str(origin)]
    if dest:
        rows = [r for r in rows if str(r[1]) == str(dest)]
    if top_n and top_n > 0:
        rows.sort(key=lambda r: r[2], reverse=True)
        rows = rows[:top_n]
    return rows


def norm_id(value):
    """ID di zona come testo confrontabile: spazi tolti, numeri interi senza
    decimali (un campo ID di tipo double dà "1.0" mentre il CSV dice "1")."""
    s = str(value).strip()
    try:
        f = float(s.replace(",", "."))
        if f == int(f):
            return str(int(f))
    except (ValueError, OverflowError):
        pass
    return s


def parse_number(text, delimiter=","):
    """Numero da CSV, anche in formato italiano.

    Con entrambi i separatori ("1.234,5" o "1,234.5") l'ultimo è quello
    decimale. Con la sola virgola: decimale nei CSV a punto e virgola o
    tabulazione (Excel italiano), migliaia nei CSV a virgola ("1,234").
    """
    s = str(text).strip().replace(" ", "").replace(" ", "")
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(",", "") if delimiter == "," else s.replace(",", ".")
    return float(s)


def read_od_csv(path, col_o, col_d, col_v):
    """Legge una matrice OD da CSV: (righe, scartate).

    Accetta UTF-8 (anche con BOM), Windows-1252/Latin-1 (Excel), separatore
    virgola, punto e virgola, tabulazione o barra verticale, spazi attorno
    ai valori e numeri in formato italiano.
    """
    import csv
    import io
    raw = open(path, "rb").read()
    text = None
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    sample = text[:8192]
    try:
        delim = csv.Sniffer().sniff(sample, delimiters=";,\t|").delimiter
    except csv.Error:
        delim = max(";,\t|", key=sample.count)
    rows, bad = [], 0
    reader = csv.DictReader(io.StringIO(text), delimiter=delim,
                            skipinitialspace=True)
    for r in reader:
        r = {(k or "").strip(): (v or "") for k, v in r.items()}
        try:
            rows.append((norm_id(r[col_o]), norm_id(r[col_d]),
                         parse_number(r[col_v], delim)))
        except (KeyError, ValueError, TypeError):
            bad += 1
    return rows, bad


def _arc_points(p0, p1, curvature=0.2, n=18):
    """Punti di un arco (Bézier quadratico) da p0 a p1.

    Il punto di controllo è il punto medio spostato in perpendicolare alla
    direzione O→D di `curvature * lunghezza`; la curva piega sempre dallo stesso
    lato (sinistra), così A→B e B→A non si sovrappongono. Coordinate in gradi
    (le geometrie sono già in WGS84): l'offset è proporzionale alla lunghezza.
    """
    x0, y0 = p0.x(), p0.y()
    x1, y1 = p1.x(), p1.y()
    mx, my = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    dx, dy = x1 - x0, y1 - y0
    cx = mx - dy * curvature
    cy = my + dx * curvature
    pts = []
    for i in range(n + 1):
        t = i / float(n)
        u = 1.0 - t
        bx = u * u * x0 + 2 * u * t * cx + t * t * x1
        by = u * u * y0 + 2 * u * t * cy + t * t * y1
        pts.append(QgsPointXY(bx, by))
    return pts


def build_desire_lines(zones_layer, id_field, od_rows, transform_context,
                       name=tr("OD - desire lines"), arc=False, curvature=0.2):
    """Crea le desire lines tra i centroidi delle zone.

    :param od_rows: lista di (origine, destinazione, valore_float).
    :param arc: se True le linee sono arcuate (Bézier) anziché rette.
    :return: (QgsVectorLayer LineString EPSG:4326, n_create, n_scartate).
    """
    to_wgs = QgsCoordinateTransform(zones_layer.crs(), WGS84, transform_context)
    centroids = {}
    for f in zones_layer.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        c = g.centroid()
        c.transform(to_wgs)
        centroids[norm_id(f[id_field])] = c.asPoint()

    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("origine", QVariant.String),
        QgsField("destinazione", QVariant.String),
        QgsField("flusso", QVariant.Double),
    ])
    layer.updateFields()

    feats = []
    missing = 0
    for o, d, val in od_rows:
        po = centroids.get(norm_id(o))
        pd_ = centroids.get(norm_id(d))
        if po is None or pd_ is None or norm_id(o) == norm_id(d):
            missing += 1
            continue
        f = QgsFeature(layer.fields())
        if arc:
            f.setGeometry(QgsGeometry.fromPolylineXY(
                _arc_points(po, pd_, curvature)))
        else:
            f.setGeometry(QgsGeometry.fromPolylineXY([po, pd_]))
        f.setAttributes([str(o), str(d), float(val)])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    _style_by_flow(layer)
    return layer, len(feats), missing


def _haversine(lat1, lon1, lat2, lon2):
    import math
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def compute_transit_od(zones, gtfs_path, start_h, budget_min, walk_speed_kmh,
                       access_m=800.0, egress_m=800.0, service_date=None,
                       progress=None, is_canceled=None):
    """Matrice tempi zona->zona via TP (CSA per zona origine).

    Il tempo è il minimo fra il viaggio in TP (accesso, corse, egress) e il
    cammino diretto fra le zone.

    :param zones: lista di (zone_id, lat, lon).
    :param service_date: YYYYMMDD; None = giorno più carico del feed.
    :return: lista di (o_id, d_id, tempo_min).
    """
    from . import transit_iso
    walk_mps = walk_speed_kmh * 1000.0 / 3600.0
    index = transit_iso.PointIndex([(la, lo) for _z, la, lo in zones], egress_m)
    # legge il GTFS una volta sola, poi CSA per ogni zona origine
    data = transit_iso.prepare_transit(
        gtfs_path, start_h, budget_min, walk_speed_kmh, 200.0, service_date,
        progress=(lambda p: progress(int(p * 0.3))) if progress else None)
    out = []
    nbr_cache = {}
    n = len(zones)
    for i, (oid, ola, olo) in enumerate(zones):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and n:
            progress(30 + int(70 * i / n))
        reach = transit_iso.reach_from(data, (ola, olo), max_access_m=access_m,
                                       budget_s=budget_min * 60.0)
        start_s = reach[2]
        best = transit_iso.arrivals_at_points(
            index, (ola, olo), reach, walk_mps, egress_m, budget_min * 60.0,
            nbr_cache)
        for j, a in best.items():
            did = zones[j][0]
            if did != oid and a <= start_s + budget_min * 60.0:
                out.append((oid, did, (a - start_s) / 60.0))
    return out


def build_od_time_lines(zones_layer, id_field, rows, transform_context,
                        name=tr("OD tempi TP")):
    """Desire lines colorate per tempo di viaggio (verde=basso, rosso=alto)."""
    to_wgs = QgsCoordinateTransform(zones_layer.crs(), WGS84, transform_context)
    centroids = {}
    for f in zones_layer.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        c = g.centroid()
        c.transform(to_wgs)
        centroids[str(f[id_field])] = c.asPoint()
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("origine", QVariant.String),
        QgsField("destinazione", QVariant.String),
        QgsField("tempo_min", QVariant.Double),
    ])
    layer.updateFields()
    feats = []
    for o, d, v in rows:
        po = centroids.get(str(o))
        pd_ = centroids.get(str(d))
        if po is None or pd_ is None:
            continue
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY([po, pd_]))
        f.setAttributes([str(o), str(d), round(float(v), 1)])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    values = [f["tempo_min"] for f in layer.getFeatures()]
    if len(set(values)) >= 2:
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        ramp = QgsGradientColorRamp(QColor(26, 152, 80), QColor(215, 48, 39))
        n = min(5, len(set(values)))
        r = style_util.graduated_from(layer, "tempo_min", n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer, len(feats)


def _style_by_flow(layer, classes=5):
    values = [f["flusso"] for f in layer.getFeatures() if f["flusso"] is not None]
    if len(set(values)) < 2:
        return
    n = min(classes, len(set(values)))
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    ramp = QgsGradientColorRamp(QColor(255, 224, 178), QColor(183, 28, 28))
    renderer = style_util.graduated_from(layer, "flusso", n, symbol, ramp)
    if renderer and renderer.ranges():
        # spessore crescente col flusso
        for i, rng in enumerate(renderer.ranges()):
            sym = rng.symbol()
            sym.setWidth(0.3 + 1.2 * i / max(1, n - 1))
        layer.setRenderer(renderer)
