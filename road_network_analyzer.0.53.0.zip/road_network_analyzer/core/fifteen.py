# -*- coding: utf-8 -*-
"""Città dei 15 minuti: quali servizi si raggiungono a piedi (o in bici).

Per ogni zona (cella di una griglia, poligono o punto) si calcola il tempo
sulla rete fino al servizio più vicino di ogni categoria (alimentari,
scuole, salute, verde…). L'indice è la quota di categorie raggiunte entro
la soglia (15 minuti di default): 100 = tutte.

Calcolo: per ogni categoria un solo Dijkstra a ritroso dai servizi
(multi-sorgente sul grafo con gli archi invertiti), che dà a ogni nodo il
tempo fino al servizio più vicino; poi ogni zona legge il valore dei nodi
del suo arco. Costa come una manciata di isocrone, non una per zona.
I tempi per tratto vengono da travel_cost (pendenza dal DEM compresa: il
verso conta, si va DALLA zona AL servizio).
"""
from ..i18n import tr
import heapq
import math

# categorie dei servizi scaricati da OSM: (chiave, etichetta, [(tag, valori)])
SERVICES = [
    ("alimentari", tr("Alimentari"), [
        ("shop", "supermarket|convenience|greengrocer|bakery|butcher|deli|"
                 "grocery|general|food|seafood|dairy|cheese|pastry")]),
    ("scuola", tr("Scuole e nidi"), [
        ("amenity", "school|kindergarten|childcare")]),
    ("salute", tr("Salute"), [
        ("amenity", "pharmacy|doctors|clinic|hospital|dentist"),
        ("healthcare", "pharmacy|doctor|clinic|hospital|centre|dentist")]),
    ("verde", tr("Parchi e gioco"), [
        ("leisure", "park|playground|garden|recreation_ground|dog_park")]),
    ("sport", "Sport", [
        ("leisure", "sports_centre|fitness_centre|pitch|swimming_pool|"
                    "sports_hall|track")]),
    ("trasporto", tr("Trasporto pubblico"), [
        ("highway", "bus_stop"),
        ("railway", "station|halt|tram_stop|subway_entrance"),
        ("public_transport", "platform|station")]),
    ("cultura", tr("Cultura e socialità"), [
        ("amenity", "library|community_centre|theatre|cinema|arts_centre|"
                    "social_centre|social_facility")]),
    ("ristoro", tr("Bar e ristoranti"), [
        ("amenity", "cafe|restaurant|bar|pub|fast_food|ice_cream")]),
    ("servizi", tr("Uffici e servizi"), [
        ("amenity", "post_office|bank|townhall|police|marketplace|"
                    "community_centre")]),
]
LABELS = [lab for _k, lab, _t in SERVICES]


def overpass_query(south, west, north, east):
    """Query Overpass: tutti i servizi delle categorie, punti e aree
    (centro delle aree)."""
    bbox = "%.6f,%.6f,%.6f,%.6f" % (south, west, north, east)
    by_tag = {}
    for _k, _lab, tags in SERVICES:
        for tag, vals in tags:
            by_tag.setdefault(tag, set()).update(vals.split("|"))
    parts = []
    for tag in sorted(by_tag):
        vals = sorted(by_tag[tag])
        if len(vals) == 1:
            parts.append('nwr["%s"="%s"](%s);' % (tag, vals[0], bbox))
        else:
            parts.append('nwr["%s"~"^(%s)$"](%s);' % (tag, "|".join(vals),
                                                      bbox))
    return "[out:json][timeout:120];(%s);out center tags;" % "".join(parts)


def classify(tags):
    """(chiave, etichetta, "tag=valore") della prima categoria che il
    servizio soddisfa, o None."""
    for key, lab, tlist in SERVICES:
        for tag, vals in tlist:
            v = tags.get(tag)
            if v and v in vals.split("|"):
                return key, lab, "%s=%s" % (tag, v)
    return None


def fetch_services(south, west, north, east, progress=None,
                   is_canceled=None):
    """Servizi OSM nel riquadro: [(osm_tipo, osm_id, chiave, etichetta,
    tag, nome, lon, lat)]. Solo I/O e parsing: sicuro in background."""
    import requests
    from .osm_download import OVERPASS_URLS, OVERPASS_HEADERS, _check_remark
    query = overpass_query(south, west, north, east)
    if progress:
        progress(10)
    data = None
    last = None
    for url in OVERPASS_URLS:
        if is_canceled and is_canceled():
            return []
        try:
            resp = requests.post(url, data={"data": query},
                                 headers=OVERPASS_HEADERS, timeout=150)
            resp.raise_for_status()
            data = resp.json()
            _check_remark(data)
            break
        except Exception as exc:
            last = exc
            data = None
    if data is None:
        raise RuntimeError(tr("Overpass non raggiungibile: %s") % last)
    if progress:
        progress(80)
    out = []
    for el in data.get("elements", []):
        tags = el.get("tags") or {}
        c = classify(tags)
        if c is None:
            continue
        if el.get("type") == "node":
            lon, lat = el.get("lon"), el.get("lat")
        else:
            ctr = el.get("center") or {}
            lon, lat = ctr.get("lon"), ctr.get("lat")
        if lon is None or lat is None:
            continue
        out.append((el.get("type"), el.get("id"), c[0], c[1], c[2],
                    tags.get("name", ""), lon, lat))
    if progress:
        progress(100)
    return out


def build_services_layer(rows, name=tr("OSM - Servizi")):
    """Layer di punti (EPSG:4326) dei servizi, categorizzato per categoria."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.PyQt.QtGui import QColor
    from qgis.core import (QgsCategorizedSymbolRenderer, QgsFeature,
                           QgsField, QgsGeometry, QgsPointXY,
                           QgsRendererCategory, QgsSymbol, QgsVectorLayer)
    layer = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("osm_tipo", QVariant.String),
        QgsField("osm_id", QVariant.LongLong),
        QgsField("categoria", QVariant.String),
        QgsField("tag", QVariant.String),
        QgsField("nome", QVariant.String),
    ])
    layer.updateFields()
    feats = []
    for typ, oid, _key, lab, tag, nome, lon, lat in rows:
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        f.setAttributes([typ, oid, lab, tag, nome])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    colors = ["#e41a1c", "#377eb8", "#4daf4a", "#1b9e77", "#ff7f00",
              "#984ea3", "#a65628", "#f781bf", "#666666"]
    cats = []
    for i, lab in enumerate(LABELS):
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(QColor(colors[i % len(colors)]))
        sym.setSize(1.8)
        cats.append(QgsRendererCategory(lab, sym, lab))
    layer.setRenderer(QgsCategorizedSymbolRenderer("categoria", cats))
    return layer


def order_categories(values):
    """Categorie in ordine: prima quelle OSM nell'ordine di SERVICES, poi le
    altre in ordine alfabetico."""
    vals = set(values)
    first = [lab for lab in LABELS if lab in vals]
    return first + sorted(vals - set(first))


def _reverse_dijkstra(radj, n, seeds, max_s, is_canceled=None):
    inf = float("inf")
    cost = [inf] * n
    heap = []
    for node, c in seeds:
        if c < cost[node]:
            cost[node] = c
            heapq.heappush(heap, (c, node))
    k = 0
    while heap:
        c, v = heapq.heappop(heap)
        if c > cost[v]:
            continue
        k += 1
        if is_canceled and k % 20000 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        for w, d in radj[v]:
            nc = c + d
            if nc < cost[w] and nc <= max_s:
                cost[w] = nc
                heapq.heappush(heap, (nc, w))
    return cost


def nearest_times(roads, directions, edge_costs, origins, pois, categories,
                  max_s, snap_m=500.0, progress=None, is_canceled=None):
    """Tempo (s) dal punto di ogni zona al servizio più vicino di ogni
    categoria, lungo la rete.

    :param origins: [(lat, lon)] (centro delle zone).
    :param pois: [(lat, lon, categoria)].
    :param max_s: tempo massimo cercato: oltre, None.
    :return: (tempi[i][c] o None, n_origini_fuori_rete, n_servizi_fuori_rete).
    """
    from . import net_iso
    pts = list(origins) + [(la, lo) for la, lo, _c in pois]
    lat0 = sum(p[0] for p in pts) / len(pts) if pts else 0.0
    graph = net_iso.build_metric_graph(roads, lat0, directions=directions,
                                       edge_costs=edge_costs)
    if progress:
        progress(5)
    radj = [[] for _ in range(graph.n)]
    for v, lst in graph.adj.items():
        for w, c in lst:
            radj[w].append((v, c))
    cat_index = {c: k for k, c in enumerate(categories)}
    # servizi: arrivo al piede dagli estremi del suo arco
    seeds = [[] for _ in categories]
    by_edge = [{} for _ in categories]
    n_poi_out = 0
    for la, lo, cat in pois:
        k = cat_index.get(cat)
        if k is None:
            continue
        info = graph.snap_edge_ll(la, lo, snap_m)
        if info is None:
            n_poi_out += 1
            continue
        seeds[k].extend(graph.dest_seeds(info))
        by_edge[k].setdefault(info["edge"], []).append(info)
    oinfo = []
    n_out = 0
    for la, lo in origins:
        info = graph.snap_edge_ll(la, lo, snap_m)
        if info is None:
            n_out += 1
            oinfo.append(None)
        else:
            oinfo.append((info, graph.source_seeds(info)))
    res = [[None] * len(categories) for _ in origins]
    for k in range(len(categories)):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if seeds[k]:
            cost = _reverse_dijkstra(radj, graph.n, seeds[k], max_s,
                                     is_canceled)
            for i, oi in enumerate(oinfo):
                if oi is None:
                    continue
                info, sseeds = oi
                best = min((off + cost[n] for n, off in sseeds),
                           default=float("inf"))
                # servizio sullo stesso arco: diretto lungo l'arco
                for pinfo in by_edge[k].get(info["edge"], ()):
                    best = min(best, graph.edge_distance(_NO_COST, info,
                                                         pinfo))
                if best <= max_s:
                    res[i][k] = best
        if progress:
            progress(5 + int(95 * (k + 1) / len(categories)))
    return res, n_out, n_poi_out


class _NoCost(object):
    """Vettore di costi «infinito» per edge_distance (solo il caso diretto
    lungo lo stesso arco)."""

    def __getitem__(self, _k):
        return float("inf")


_NO_COST = _NoCost()


def summarize(times, categories, threshold_s):
    """Per zona: {n, indice, t_tutti, mancanti, tempi_min}."""
    out = []
    K = len(categories)
    for row in times:
        got = [t is not None and t <= threshold_s for t in row]
        n = sum(got)
        t_all = (max(row) / 60.0 if all(t is not None for t in row) and row
                 else None)
        out.append({
            "n": n,
            "indice": 100.0 * n / K if K else 0.0,
            "t_tutti": t_all,
            "mancanti": ", ".join(c for c, g in zip(categories, got) if not g),
            "tempi_min": [None if t is None else t / 60.0 for t in row],
        })
    return out


def field_names(categories):
    """Nomi di campo brevi e unici (max 10 caratteri, per lo Shapefile)
    per i tempi di ogni categoria: t_<categoria>."""
    import re
    used = set()
    out = []
    for c in categories:
        base = re.sub(r"[^a-z0-9]+", "_", c.lower()).strip("_") or "cat"
        name = ("t_" + base)[:10]
        k = 1
        while name in used:
            k += 1
            name = ("t_" + base)[:10 - len(str(k))] + str(k)
        used.add(name)
        out.append(name)
    return out


def apply_style(layer, field="indice"):
    """Classi fisse sull'indice (0–100): rosso = pochi servizi, verde =
    tutti."""
    from qgis.PyQt.QtGui import QColor
    from qgis.core import (QgsGraduatedSymbolRenderer, QgsRendererRange,
                           QgsSymbol)
    classes = [(0, 20, "#d73027", "0–20"), (20, 40, "#fc8d59", "20–40"),
               (40, 60, "#fee08b", "40–60"), (60, 80, "#d9ef8b", "60–80"),
               (80, 99.99, "#91cf60", "80–99"),
               (99.99, 100.0, "#1a9850", tr("100 (tutti i servizi)"))]
    ranges = []
    for lo, hi, col, lab in classes:
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(QColor(col))
        try:
            sym.setOpacity(0.8)
        except Exception:
            pass
        ranges.append(QgsRendererRange(lo, hi, sym, lab))
    layer.setRenderer(QgsGraduatedSymbolRenderer(field, ranges))


def build_layer(categories, summary, threshold_min, cells=None,
                source_layer=None, name=tr("Città 15 minuti")):
    """Layer dei risultati: celle della griglia (anelli lat/lon) oppure
    copia delle zone/punti d'origine con i campi aggiunti."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsFeature, QgsField, QgsGeometry, QgsPointXY,
                           QgsWkbTypes)
    from . import style_util
    from .isochrones import WGS84
    tf = field_names(categories)
    new_fields = ([QgsField(f, QVariant.Double) for f in tf]
                  + [QgsField("n_servizi", QVariant.Int),
                     QgsField("indice", QVariant.Double),
                     QgsField("t_tutti", QVariant.Double),
                     QgsField("mancanti", QVariant.String)])
    if source_layer is None:
        layer = style_util.memory_layer("Polygon", WGS84, name)
        layer.dataProvider().addAttributes(new_fields)
    else:
        wkb = QgsWkbTypes.displayString(source_layer.wkbType()) or "Point"
        layer = style_util.memory_layer(wkb, source_layer.crs(), name)
        # campi d'origine con lo stesso nome dei nuovi (es. rilanciando sul
        # risultato precedente) non vengono copiati: valgono i nuovi
        taken = {f.name().lower() for f in new_fields}
        keep = [i for i, f in enumerate(source_layer.fields())
                if f.name().lower() not in taken]
        layer.dataProvider().addAttributes(
            [source_layer.fields().at(i) for i in keep] + new_fields)
    layer.updateFields()

    def extra(s):
        return ([None if t is None else round(t, 1) for t in s["tempi_min"]]
                + [s["n"], round(s["indice"], 1),
                   None if s["t_tutti"] is None else round(s["t_tutti"], 1),
                   s["mancanti"]])

    feats = []
    if source_layer is None:
        for ring, s in zip(cells, summary):
            f = QgsFeature(layer.fields())
            f.setGeometry(QgsGeometry.fromPolygonXY(
                [[QgsPointXY(lo, la) for la, lo in ring]]))
            f.setAttributes(extra(s))
            feats.append(f)
    else:
        it = iter(summary)
        for src in source_layer.getFeatures():
            g = src.geometry()
            if g is None or g.isEmpty():
                continue
            s = next(it, None)
            if s is None:
                break
            f = QgsFeature(layer.fields())
            f.setGeometry(g)
            attrs = src.attributes()
            f.setAttributes([attrs[i] for i in keep] + extra(s))
            feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    apply_style(layer)
    return layer


def haversine_m(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2)
         * math.sin(math.radians(lon2 - lon1) / 2) ** 2)
    return 2 * r * math.asin(math.sqrt(a))
