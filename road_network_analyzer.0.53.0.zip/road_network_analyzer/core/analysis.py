# -*- coding: utf-8 -*-
"""Funzioni di analisi della rete stradale.

Tutte pure rispetto alla GUI: operano su QgsVectorLayer e restituiscono
strutture Python semplici, cosi da poter essere riusate (es. in un
algoritmo Processing) e testate in isolamento dalla console QGIS.
"""
from ..i18n import tr
from collections import defaultdict

from qgis.core import (
    QgsDistanceArea,
    QgsProject,
    QgsSpatialIndex,
    QgsUnitTypes,
    QgsWkbTypes,
)

UNCLASSIFIED = tr("(non classificato)")


def distance_area(layer):
    """QgsDistanceArea configurato per misure ellissoidali in metri."""
    da = QgsDistanceArea()
    da.setSourceCrs(layer.crs(), QgsProject.instance().transformContext())
    ellipsoid = QgsProject.instance().ellipsoid()
    if not ellipsoid or ellipsoid == "NONE":
        ellipsoid = layer.crs().ellipsoidAcronym() or "WGS84"
    da.setEllipsoid(ellipsoid)
    return da


def type_value(feature, type_field):
    """Valore di tipologia normalizzato (gestisce NULL e stringhe vuote)."""
    if not type_field:
        return UNCLASSIFIED
    val = feature[type_field]
    if val is None:
        return UNCLASSIFIED
    if isinstance(val, str) and val.strip() == "":
        return UNCLASSIFIED
    return str(val)


def compute_lengths_by_type(layer, type_field, da=None):
    """Somma la lunghezza ellissoidale (metri) raggruppata per tipologia.

    :return: dict {tipologia: lunghezza_metri}
    """
    da = da or distance_area(layer)
    lengths = defaultdict(float)
    for feat in layer.getFeatures():
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        length_m = da.convertLengthMeasurement(
            da.measureLength(geom), QgsUnitTypes.DistanceMeters
        )
        lengths[type_value(feat, type_field)] += length_m
    return dict(lengths)


def junction_matrix(topo, arm_type, nodes=None):
    """Matrice delle tipologie agli incroci reali (nodi con ≥3 bracci).

    Per ogni incrocio si guardano i bracci (archi incidenti) e la tipologia
    della strada a cui appartengono: la cella (t1, t2) conta gli incroci in
    cui sono presenti entrambe le tipologie; la diagonale (t, t) quelli con
    almeno tre bracci di tipo t (si incontrano almeno due strade di quel
    tipo). Un incrocio con più tipologie conta in più celle.

    :param arm_type: funzione src → tipologia.
    :param nodes: incroci da considerare (default: tutti).
    :return: (matrix {(t1, t2): n}, tipologie presenti).
    """
    matrix = defaultdict(int)
    types = set()
    if nodes is None:
        nodes = topo.junctions()
    for n in nodes:
        arms = defaultdict(int)
        for e in topo.inc[n]:
            arms[arm_type(topo.edges[e][2])] += 1
        ts = sorted(arms)
        types.update(ts)
        for i, t1 in enumerate(ts):
            if arms[t1] >= 3:
                matrix[(t1, t1)] += 1
            for t2 in ts[i + 1:]:
                matrix[(t1, t2)] += 1
    return dict(matrix), types


def analyze_roads(features, layer_crs, transform_context, type_field=None,
                  area_geom=None, ellipsoid="WGS84", level_of=None,
                  snap_tol_m=1.0, progress=None, is_canceled=None, total=0):
    """Lunghezze per tipologia, incroci reali e attraversamenti da verificare.

    Thread-safe (features da un QgsVectorLayerFeatureSource): gira in un
    QgsTask. Gli incroci sono i vertici CONDIVISI da almeno tre bracci
    (topology): un ponte che passa sopra una strada senza vertice comune non
    è un incrocio; i punti in cui due strade allo stesso livello si
    attraversano senza vertice comune sono contati a parte (da nodare).

    :param area_geom: QgsGeometry dell'area di progetto nel CRS della rete,
        o None. Con l'area, lunghezze, incroci e vicoli ciechi sono
        RITAGLIATI sull'area (le densità si riferiscono alla stessa area).
    :return: dict con lengths, types, matrix, junctions, dead_ends,
        unnoded, junction_points (lon/lat).
    """
    from qgis.core import (QgsCoordinateReferenceSystem,
                           QgsCoordinateTransform, QgsGeometry, QgsPointXY)
    from . import topology, network_prepare
    da = QgsDistanceArea()
    da.setSourceCrs(layer_crs, transform_context)
    da.setEllipsoid(ellipsoid or "WGS84")
    ct = QgsCoordinateTransform(
        layer_crs, QgsCoordinateReferenceSystem("EPSG:4326"),
        transform_context)
    area_eng = None
    area_ll_eng = None
    if area_geom is not None and not area_geom.isEmpty():
        area_eng = QgsGeometry.createGeometryEngine(area_geom.constGet())
        area_eng.prepareGeometry()
        g_ll = QgsGeometry(area_geom)
        g_ll.transform(ct)
        area_ll_eng = QgsGeometry.createGeometryEngine(g_ll.constGet())
        area_ll_eng.prepareGeometry()

    lengths = defaultdict(float)
    roads, types, levels = [], [], []
    for i, feat in enumerate(features):
        if i % 500 == 0:
            if is_canceled and is_canceled():
                from .gtfs_static import GtfsCancelled
                raise GtfsCancelled()
            if progress and total:
                progress(40.0 * min(1.0, i / float(total)))
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        typ = type_value(feat, type_field)
        part = geom
        if area_eng is not None:
            if not area_eng.intersects(geom.constGet()):
                part = None
            elif not area_eng.contains(geom.constGet()):
                part = geom.intersection(area_geom)
        if part is not None and not part.isEmpty():
            lengths[typ] += da.convertLengthMeasurement(
                da.measureLength(part), QgsUnitTypes.DistanceMeters)
        g = QgsGeometry(geom)
        g.transform(ct)
        lev = level_of(feat) if level_of else 0
        for pl in (g.asMultiPolyline() if g.isMultipart()
                   else [g.asPolyline()]):
            if len(pl) >= 2:
                roads.append([(p.x(), p.y()) for p in pl])
                types.append(typ)
                levels.append(lev)
    if progress:
        progress(45)

    def inside(lon, lat):
        if area_ll_eng is None:
            return True
        return area_ll_eng.intersects(
            QgsGeometry.fromPointXY(QgsPointXY(lon, lat)).constGet())

    topo = topology.build_topology(
        roads, snap_tol_m=snap_tol_m, is_canceled=is_canceled,
        progress=(lambda p: progress(45 + 0.25 * p)) if progress else None)
    present = set(lengths)
    junctions = []
    for n in topo.junctions():
        if inside(*topo.node_ll[n]):
            junctions.append(n)
    matrix, jtypes = junction_matrix(topo, lambda src: types[src], junctions)
    present |= jtypes
    dead = [n for n in topo.dead_ends() if inside(*topo.node_ll[n])]
    if progress:
        progress(75)
    cross = network_prepare.find_unresolved_crossings(
        roads, max_report=10 ** 9, levels=levels if level_of else None)
    unnoded = [(la, lo) for la, lo in cross if inside(lo, la)]
    if progress:
        progress(100)
    return {
        "lengths": dict(lengths),
        "types": sorted(present),
        "matrix": matrix,
        "junctions": len(junctions),
        "dead_ends": len(dead),
        "unnoded": unnoded,
        "junction_points": [topo.node_ll[n] for n in junctions],
        "has_levels": bool(level_of) and any(levels),
    }


def geometry_area_m2(geom, crs, transform_context, ellipsoid="WGS84"):
    """Area ellissoidale (m2) di una geometria nel CRS indicato."""
    da = QgsDistanceArea()
    da.setSourceCrs(crs, transform_context)
    da.setEllipsoid(ellipsoid or "WGS84")
    return da.convertAreaMeasurement(da.measureArea(geom),
                                     QgsUnitTypes.AreaSquareMeters)


def compute_area(layer, da=None):
    """Area ellissoidale totale (m2) di un layer poligonale."""
    if layer is None:
        return 0.0
    da = da or distance_area(layer)
    total = 0.0
    for feat in layer.getFeatures():
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        total += da.convertAreaMeasurement(
            da.measureArea(geom), QgsUnitTypes.AreaSquareMeters
        )
    return total


def compute_ratios(lengths_by_type, total_intersections, area_m2,
                   dead_ends=None, unnoded=None):
    """Rapporti sintetici a partire dai risultati precedenti.

    :param total_intersections: incroci reali (nodi con ≥3 bracci).
    """
    total_length_m = sum(lengths_by_type.values())
    ratios = {
        "total_length_m": total_length_m,
        "total_length_km": total_length_m / 1000.0,
        "junctions": total_intersections,
        "area_m2": area_m2,
        "area_km2": area_m2 / 1_000_000.0 if area_m2 else 0.0,
    }
    if dead_ends is not None:
        ratios["dead_ends"] = dead_ends
        tot = total_intersections + dead_ends
        if tot:
            # quota di nodi che sono incroci (connected node ratio)
            ratios["connected_node_ratio"] = total_intersections / float(tot)
    if unnoded is not None:
        ratios["unnoded_crossings"] = unnoded
    if area_m2 and area_m2 > 0:
        area_km2 = area_m2 / 1_000_000.0
        ratios["density_km_per_km2"] = (total_length_m / 1000.0) / area_km2
        ratios["intersection_density_per_km2"] = total_intersections / area_km2
    return ratios
