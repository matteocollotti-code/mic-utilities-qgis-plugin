# -*- coding: utf-8 -*-
"""Metriche di sintesi ed equità su un campo di accessibilità/PTAL.

Dato un valore per feature (es. acc_15min, ptal_level) e un peso opzionale (es.
popolazione), calcola statistiche pesate, la quota "servita" oltre una soglia,
il coefficiente di Gini e la curva di Lorenz dell'accessibilità.

Funzioni pure (nessun oggetto QGIS): facili da testare e riusare.
"""


from ..i18n import tr
def compute_equity(values, weights=None, threshold=None):
    """Statistiche pesate ed equità.

    :param values: lista di valori (float) per feature.
    :param weights: lista di pesi (es. popolazione); None = peso 1 per feature.
    :param threshold: soglia per la quota "servita" (valore >= soglia).
    :return: dict con n, peso_totale, media, mediana, gini, pct_servita,
             lorenz (lista di (quota_pop, quota_valore)).
    """
    pairs = []
    for i, v in enumerate(values):
        if v is None:
            continue
        w = 1.0 if weights is None else weights[i]
        try:
            v = float(v)
            w = float(w)
        except (TypeError, ValueError):
            continue
        # NaN/infiniti (es. accessibilità non calcolata) non sono valori:
        # prima un solo NaN portava il Gini a 1
        if v != v or w != w or v in (float("inf"), float("-inf"))                 or w in (float("inf"), float("-inf")) or w < 0:
            continue
        pairs.append((v, w))

    n = len(pairs)
    W = sum(w for _v, w in pairs)
    out = {"n": n, "peso_totale": W, "media": 0.0, "mediana": 0.0,
           "gini": 0.0, "pct_servita": None, "lorenz": []}
    if n == 0 or W <= 0:
        return out
    if any(v < 0 for v, _w in pairs):
        # Gini e Lorenz non hanno senso con valori negativi (es. un delta)
        raise ValueError(tr("Il campo contiene valori negativi (es. una "
                         "differenza fra scenari): Gini e curva di Lorenz "
                         "richiedono valori ≥ 0."))

    # media pesata
    sv = sum(v * w for v, w in pairs)
    out["media"] = sv / W

    # ordina per valore crescente
    pairs.sort(key=lambda p: p[0])

    # mediana pesata: valore a metà del peso cumulato; se il peso cumulato
    # cade esattamente a metà, media con il valore successivo
    cum = 0.0
    half = W / 2.0
    out["mediana"] = pairs[-1][0]
    for k, (v, w) in enumerate(pairs):
        cum += w
        if cum > half + 1e-12:
            out["mediana"] = v
            break
        if abs(cum - half) <= 1e-12 and k + 1 < n:
            out["mediana"] = (v + pairs[k + 1][0]) / 2.0
            break

    # quota servita (>= soglia)
    if threshold is not None:
        served = sum(w for v, w in pairs if v >= threshold)
        out["pct_servita"] = 100.0 * served / W

    if sv == 0:
        # tutti i valori nulli: distribuzione perfettamente uguale (Gini 0)
        out["lorenz"] = [(0.0, 0.0), (1.0, 1.0)]
        return out

    # curva di Lorenz e Gini (area trapezoidale)
    total_vw = sv
    lorenz = [(0.0, 0.0)]
    cum_w = 0.0
    cum_vw = 0.0
    gini = 0.0
    prev_x, prev_l = 0.0, 0.0
    for v, w in pairs:
        cum_w += w
        cum_vw += v * w
        x = cum_w / W
        l = cum_vw / total_vw
        lorenz.append((x, l))
        gini += (x - prev_x) * (l + prev_l)
        prev_x, prev_l = x, l
    out["lorenz"] = lorenz
    out["gini"] = max(0.0, min(1.0, 1.0 - gini))
    return out
