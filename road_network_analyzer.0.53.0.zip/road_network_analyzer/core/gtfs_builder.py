# -*- coding: utf-8 -*-
"""Costruzione di un feed GTFS da un layer lineare con fermate.

Dato un layer di linee (le rotte) e un layer di punti (le fermate), genera un
feed GTFS minimale (agency, stops, routes, trips, stop_times, calendar,
shapes) chiedendo i parametri di servizio (velocita, frequenza, orari, sosta).
I tempi di percorrenza derivano dalla distanza lungo la linea / velocita.

Per ogni linea si generano l'andata (verso di disegno, direction_id 0) e, se
richiesto, il ritorno (verso opposto, direction_id 1). Le fermate disegnate ai
due lati della strada vanno ciascuna alla sua direzione (lato di marcia
destro o sinistro); quelle sulla linea servono entrambe.

`collect_inputs` legge i layer (thread principale, veloce); `build_gtfs`
fa il resto ed è thread-safe (QgsTask).
"""
from ..i18n import tr
import csv
import datetime
import io
import zipfile

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGeometry,
    QgsPointXY,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")
CENTER_M = 2.0  # fermate entro questa distanza dalla linea: entrambe le direzioni
DAYS = {
    "all": "1111111",
    "weekdays": "1111100",
    "monsat": "1111110",
}


def _utm_crs_for(lon, lat):
    zone = int((lon + 180) / 6) + 1
    epsg = (32600 if lat >= 0 else 32700) + zone
    return QgsCoordinateReferenceSystem.fromEpsgId(epsg)


def _text(value):
    """Valore di attributo come testo; NULL e None diventano stringa vuota
    (str() darebbe la parola "NULL" nel GTFS)."""
    if value is None or str(value) == "NULL":
        return ""
    return str(value).strip()


def _hhmmss(seconds):
    seconds = int(round(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return "%02d:%02d:%02d" % (h, m, s)


def valid_timezone(name):
    """True se il fuso è un nome IANA noto (pytz); senza pytz si accetta."""
    try:
        import pytz
    except Exception:
        return bool(name and "/" in name)
    return name in pytz.all_timezones_set


def collect_inputs(line_layer, stops_layer, params):
    """Copia geometrie e attributi utili dei due layer (thread principale)."""
    route_field = params.get("route_field") or None
    stop_name_field = params.get("stop_name_field") or None
    line_names = line_layer.fields().names()
    stop_names = stops_layer.fields().names()
    lines = []
    for lf in line_layer.getFeatures():
        g = lf.geometry()
        if g is None or g.isEmpty():
            continue
        name = _text(lf[route_field]) if route_field in line_names else ""
        lines.append((lf.id(), QgsGeometry(g), name))
    stops = []
    for sf in stops_layer.getFeatures():
        g = sf.geometry()
        if g is None or g.isEmpty():
            continue
        name = _text(sf[stop_name_field]) if stop_name_field in stop_names \
            else ""
        stops.append((sf.id(), QgsGeometry(g), name))
    return {"lines": lines, "stops": stops, "line_crs": line_layer.crs(),
            "stop_crs": stops_layer.crs(),
            "center": line_layer.extent().center()}


def _side(line_pts, point):
    """+1 se il punto è a sinistra del verso di disegno, −1 a destra, 0 se
    praticamente sulla linea (entro CENTER_M)."""
    best = None
    px, py = point.x(), point.y()
    for a, b in zip(line_pts, line_pts[1:]):
        dx, dy = b.x() - a.x(), b.y() - a.y()
        l2 = dx * dx + dy * dy
        if l2 <= 0:
            continue
        t = max(0.0, min(1.0, ((px - a.x()) * dx + (py - a.y()) * dy) / l2))
        qx, qy = a.x() + t * dx, a.y() + t * dy
        d2 = (px - qx) ** 2 + (py - qy) ** 2
        if best is None or d2 < best[0]:
            cross = dx * (py - a.y()) - dy * (px - a.x())
            best = (d2, cross)
    if best is None or best[0] <= CENTER_M ** 2:
        return 0
    return 1 if best[1] > 0 else -1


PAIR_M = 80.0  # fermate opposte entro questa distanza lungo la linea


def _two_sided(near):
    """Fermate disegnate davvero sui due lati della strada?

    Serve che ciascun lato abbia almeno due fermate e che almeno metà delle
    fermate del lato meno numeroso abbia una fermata di fronte (entro PAIR_M
    lungo la linea). Una fermata isolata sull'altro lato o fermate messe a
    mano qualche metro fuori asse non dividono le direzioni: prima bastava
    una sola fermata fuori dai 2 m.
    """
    left = [d for d, sd, _s in near if sd == 1]
    right = [d for d, sd, _s in near if sd == -1]
    if len(left) < 2 or len(right) < 2:
        return False
    small, other = (left, right) if len(left) <= len(right) else (right, left)
    paired = sum(1 for d in small if any(abs(d - e) <= PAIR_M for e in other))
    return paired >= 0.5 * len(small)


def build_gtfs(inputs, params, out_path, transform_context, progress=None,
               is_canceled=None):
    """Genera il feed GTFS (zip) dagli input di collect_inputs.

    params: agency_name, route_type, speed_kmh, headway_min, start_h, end_h,
        dwell_s, snap_m; opzionali: directions ("both" | "one"),
        drive_side ("right" | "left": lato delle fermate rispetto al verso di
        marcia), timezone (IANA, es. Europe/Rome), start_date / end_date
        (YYYYMMDD; default oggi → +1 anno), days ("all" | "weekdays" |
        "monsat").
    :return: (out_path, stats)
    """
    speed_mps = float(params["speed_kmh"]) * 1000.0 / 3600.0
    headway_s = float(params["headway_min"]) * 60.0
    start_s = float(params["start_h"]) * 3600.0
    end_s = float(params["end_h"]) * 3600.0
    dwell_s = float(params.get("dwell_s", 0))
    snap_m = float(params.get("snap_m", 50))
    route_type = str(params.get("route_type", "3"))
    both = params.get("directions", "both") != "one"
    right = params.get("drive_side", "right") != "left"
    tz = params.get("timezone") or "Europe/Rome"
    if speed_mps <= 0 or headway_s <= 0 or end_s <= start_s:
        raise ValueError(tr("Parametri non validi (velocita/frequenza/orari)."))
    if not valid_timezone(tz):
        raise ValueError(tr("Fuso orario non riconosciuto: %s (es. Europe/Rome).")
                         % tz)
    today = datetime.date.today()
    d0 = params.get("start_date") or today.strftime("%Y%m%d")
    d1 = params.get("end_date") or (today.replace(year=today.year + 1)
                                    if not (today.month == 2 and today.day == 29)
                                    else today + datetime.timedelta(days=365)
                                    ).strftime("%Y%m%d")
    if str(d1) < str(d0):
        raise ValueError(tr("La data di fine servizio precede quella di inizio."))
    days = DAYS.get(params.get("days", "all"), DAYS["all"])

    line_crs = inputs["line_crs"]
    line_to_wgs = QgsCoordinateTransform(line_crs, WGS84, transform_context)
    cc = line_to_wgs.transform(inputs["center"])
    utm = _utm_crs_for(cc.x(), cc.y())
    line_to_utm = QgsCoordinateTransform(line_crs, utm, transform_context)
    stop_to_utm = QgsCoordinateTransform(inputs["stop_crs"], utm,
                                         transform_context)
    stop_to_wgs = QgsCoordinateTransform(inputs["stop_crs"], WGS84,
                                         transform_context)
    utm_to_wgs = QgsCoordinateTransform(utm, WGS84, transform_context)

    # fermate: id, nome, geom (utm + wgs); multipunti -> centroide
    stops = []
    for fid, g, name in inputs["stops"]:
        gu = QgsGeometry(g)
        gu.transform(stop_to_utm)
        gw = QgsGeometry(g)
        gw.transform(stop_to_wgs)
        p = gw.centroid().asPoint()
        sid = "S%d" % fid
        stops.append({"id": sid, "name": name or sid,
                      "lat": p.y(), "lon": p.x(),
                      "utm": gu.centroid().asPoint()})

    stop_times_rows = []
    trips_rows = []
    routes_rows = []
    shapes_rows = []
    used_stop_ids = set()
    stats = {"linee": 0, "direzioni": 0, "corse": 0, "fermate_lato": 0}

    def _part_len(pp):
        return sum(((pp[i + 1].x() - pp[i].x()) ** 2
                    + (pp[i + 1].y() - pp[i].y()) ** 2) ** 0.5
                   for i in range(len(pp) - 1)) if len(pp) >= 2 else 0.0

    def _emit_direction(route_id, direction, shape_id, line_pts, along):
        # shape (vertici in WGS84 con distanza cumulata)
        cum = 0.0
        prev = None
        for si, p in enumerate(line_pts):
            if prev is not None:
                cum += ((p.x() - prev.x()) ** 2 + (p.y() - prev.y()) ** 2) ** 0.5
            wp = utm_to_wgs.transform(p)
            shapes_rows.append([shape_id, "%.6f" % wp.y(), "%.6f" % wp.x(),
                                si + 1, "%.1f" % cum])
            prev = p
        # trips a frequenza costante
        t0 = start_s
        while t0 <= end_s:
            trip_id = "%s_%d_%05d" % (route_id, direction, int(t0))
            trips_rows.append([route_id, "SRV", trip_id, str(direction),
                               shape_id])
            prev_d = along[0][0]
            dep = t0
            for seq, (d, st) in enumerate(along):
                arr = t0 if seq == 0 else dep + (d - prev_d) / speed_mps
                departure = arr if seq == len(along) - 1 else arr + dwell_s
                # distanza assoluta lungo la linea, come in shapes.txt
                stop_times_rows.append([
                    trip_id, _hhmmss(arr), _hhmmss(departure), st["id"],
                    seq + 1, "%.1f" % d])
                used_stop_ids.add(st["id"])
                prev_d = d
                dep = departure
            stats["corse"] += 1
            t0 += headway_s
        stats["direzioni"] += 1

    n_lines = len(inputs["lines"])
    for idx, (fid, lg, lname) in enumerate(inputs["lines"]):
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress:
            progress(int(80 * idx / max(1, n_lines)))
        lg_utm = QgsGeometry(lg)
        lg_utm.transform(line_to_utm)
        # multipart: usa la parte più lunga (evita shape vuote)
        if lg_utm.isMultipart():
            parts = lg_utm.asMultiPolyline()
            if not parts:
                continue
            longest = max(parts, key=_part_len)
            if len(longest) < 2:
                continue
            lg_utm = QgsGeometry.fromPolylineXY(longest)
        line_pts = lg_utm.asPolyline()
        if len(line_pts) < 2:
            continue
        total = lg_utm.length()

        # ID univoci PER FEATURE (evita route/shape/trip duplicati)
        route_id = "R%d" % (idx + 1)
        short_name = lname or route_id

        # fermate vicine alla linea, con posizione lungo la linea e lato
        near = []
        for st in stops:
            ptg = QgsGeometry.fromPointXY(st["utm"])
            if lg_utm.distance(ptg) > snap_m:
                continue
            near.append((lg_utm.lineLocatePoint(ptg), _side(line_pts, st["utm"]),
                         st))
        if len(near) < 2:
            continue
        # andata (verso di disegno): fermate sul lato di marcia; ritorno:
        # sull'altro lato. Lato destro con circolazione a destra.
        out_side = -1 if right else 1
        fw = [(d, st) for d, sd, st in near if sd in (0, out_side)]
        bw = [(total - d, st) for d, sd, st in near if sd in (0, -out_side)]
        two_sided = _two_sided(near)
        if not two_sided:
            # fermate disegnate su un solo lato (o sulla linea): servono
            # entrambe le direzioni
            fw = [(d, st) for d, _sd, st in near]
            bw = [(total - d, st) for d, _sd, st in near]
        else:
            stats["fermate_lato"] += 1
        fw.sort(key=lambda x: x[0])
        bw.sort(key=lambda x: x[0])
        if len(fw) < 2 and not (both and len(bw) >= 2):
            continue
        routes_rows.append([route_id, "AG", short_name, "", route_type])
        stats["linee"] += 1
        if len(fw) >= 2:
            _emit_direction(route_id, 0, "shp_%d" % (idx + 1), line_pts, fw)
        if both and len(bw) >= 2:
            _emit_direction(route_id, 1, "shp_%d_r" % (idx + 1),
                            list(reversed(line_pts)), bw)

    if not trips_rows:
        raise ValueError(tr("Nessuna corsa generata: controlla che le fermate "
                         "siano vicine alle linee (tolleranza snap)."))

    # scrittura zip
    def _csv(header, rows):
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(header)
        w.writerows(rows)
        return buf.getvalue()

    stops_rows = [[s["id"], s["name"], "%.6f" % s["lat"], "%.6f" % s["lon"]]
                  for s in stops if s["id"] in used_stop_ids]

    files = {
        "agency.txt": _csv(
            ["agency_id", "agency_name", "agency_url", "agency_timezone"],
            [["AG", params.get("agency_name", tr("Agenzia")),
              "https://example.com", tz]]),
        "stops.txt": _csv(
            ["stop_id", "stop_name", "stop_lat", "stop_lon"], stops_rows),
        "routes.txt": _csv(
            ["route_id", "agency_id", "route_short_name", "route_long_name",
             "route_type"], routes_rows),
        "calendar.txt": _csv(
            ["service_id", "monday", "tuesday", "wednesday", "thursday",
             "friday", "saturday", "sunday", "start_date", "end_date"],
            [["SRV"] + list(days) + [str(d0), str(d1)]]),
        "trips.txt": _csv(
            ["route_id", "service_id", "trip_id", "direction_id", "shape_id"],
            trips_rows),
        "stop_times.txt": _csv(
            ["trip_id", "arrival_time", "departure_time", "stop_id",
             "stop_sequence", "shape_dist_traveled"], stop_times_rows),
        "shapes.txt": _csv(
            ["shape_id", "shape_pt_lat", "shape_pt_lon", "shape_pt_sequence",
             "shape_dist_traveled"], shapes_rows),
    }
    if not out_path.lower().endswith(".zip"):
        out_path += ".zip"
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname, content in files.items():
            zf.writestr(fname, content)
    if progress:
        progress(100)
    stats["date"] = "%s–%s" % (d0, d1)
    return out_path, stats


def build_gtfs_from_lines(line_layer, stops_layer, params, out_path,
                          transform_context):
    """Genera un feed GTFS (zip) da linee + fermate (uso diretto, headless).

    :return: out_path
    """
    inputs = collect_inputs(line_layer, stops_layer, params)
    return build_gtfs(inputs, params, out_path, transform_context)[0]
