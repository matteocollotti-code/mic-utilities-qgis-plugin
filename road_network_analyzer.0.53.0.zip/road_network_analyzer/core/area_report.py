# -*- coding: utf-8 -*-
"""Report automatico di un'area: calcolo degli indicatori.

Mette in fila sulla stessa area gli strumenti del plugin: rete stradale
(lunghezze, incroci reali, vicoli ciechi), camminabilità per cella, PTAL
(se c'è un GTFS), isocrone a piedi dal centro dell'area, città dei 15
minuti, servizi; con un layer di popolazione anche le quote di abitanti
(popolazione ripartita per area di sovrapposizione).

`compute(cfg, task)` è thread-safe e gira in un QgsTask: legge la rete da
una sorgente di feature, usa solo geometrie e liste Python e restituisce un
dict con i numeri e le geometrie (lon/lat) da cui il thread principale
costruisce layer, PDF ed Excel (report_layout, report_excel).
"""
from ..i18n import tr, num
import math
import statistics
from collections import defaultdict

SECTIONS = [
    ("demo", tr("Popolazione")),
    ("rete", tr("Rete stradale")),
    ("walk", tr("Camminabilità")),
    ("tp", tr("Trasporto pubblico")),
    ("iso", tr("Accessibilità a piedi")),
    ("tpiso", tr("Accessibilità con il trasporto pubblico")),
    ("f15", tr("Città dei 15 minuti")),
    ("servizi", tr("Servizi")),
]
SECTION_LABEL = dict(SECTIONS)

# strade dove non si cammina (escluse dalla rete pedonale)
WALK_EXCLUDE = {"motorway", "motorway_link", "trunk", "trunk_link"}

# soglie del semaforo nella sintesi: (verde da, giallo da, più alto = meglio)
# Indicative, da adattare al contesto: sono riportate nelle note del report.
THRESHOLDS = {
    "int_density": (100.0, 60.0, True),
    "dead_end_share": (10.0, 20.0, False),
    "ptal4_share": (50.0, 20.0, True),
    "f15_index": (80.0, 60.0, True),
    "f15_full_share": (50.0, 25.0, True),
    "grade_mean": (5.0, 8.0, False),
}


# etichetta e unità delle soglie (pagina Note del report)
THRESHOLD_LABEL = {
    "int_density": (tr("Incroci reali per km²"), ""),
    "dead_end_share": (tr("Vicoli ciechi sul totale dei nodi"), " %"),
    "ptal4_share": (tr("Quota con PTAL 4 o più"), " %"),
    "f15_index": (tr("Indice 15 minuti medio"), ""),
    "f15_full_share": (tr("Quota con tutti i servizi entro la soglia"), " %"),
    "grade_mean": (tr("Pendenza media delle strade"), " %"),
}

# frasi della sintesi per indicatore e giudizio ({v} = valore)
INSIGHT = {
    "int": {"verde": tr("rete fitta e ben connessa ({v})"),
            "giallo": tr("rete di media densità ({v})"),
            "rosso": tr("rete rada, con pochi incroci ({v})")},
    "dead": {"verde": tr("pochi vicoli ciechi ({v} dei nodi)"),
             "giallo": tr("vicoli ciechi non trascurabili ({v} dei nodi)"),
             "rosso": tr("molti vicoli ciechi ({v} dei nodi)")},
    "grade": {"verde": tr("strade poco pendenti ({v} in media)"),
              "giallo": tr("pendenze moderate ({v} in media)"),
              "rosso": tr("strade ripide ({v} in media)")},
    "ptal": {"verde": tr("buona accessibilità al trasporto pubblico ({v} con "
                      "PTAL 4 o più)"),
             "giallo": tr("accessibilità al trasporto pubblico media ({v} con "
                       "PTAL 4 o più)"),
             "rosso": tr("accessibilità al trasporto pubblico bassa (solo {v} "
                      "con PTAL 4 o più)")},
    "f15": {"verde": tr("servizi di ogni giorno vicini (indice {v})"),
            "giallo": tr("alcuni servizi lontani (indice {v})"),
            "rosso": tr("molti servizi lontani (indice {v})")},
    "f15full": {"verde": tr("{v} ha tutti i servizi entro la soglia"),
                "giallo": tr("solo {v} ha tutti i servizi entro la soglia"),
                "rosso": tr("appena {v} ha tutti i servizi entro la soglia")},
}


def insights(res):
    """Sintesi a parole: {"verde": [...], "giallo": [...], "rosso": [...]}
    dalle voci della sintesi che hanno un giudizio."""
    out = {"verde": [], "giallo": [], "rosso": []}
    for cd in res.get("summary", []):
        lv = cd.get("light")
        tpl = INSIGHT.get(cd["key"], {}).get(lv)
        if tpl:
            out[lv].append(tpl.format(v=cd["value"]))
    f = res.get("f15")
    if f and f.get("worst"):
        out["giallo" if not out["rosso"] else "rosso"].append(
            tr("la categoria che manca più spesso è «%s»") % f["worst"])
    return out


# parametri avanzati del report (scheda Report → Avanzate): valori
# predefiniti; `thresholds` = soglie del semaforo {chiave: (verde, giallo)}
ADVANCED = {
    "bus_m": 400.0,         # fermata a portata: bus e tram (m a piedi)
    "rail_m": 800.0,        # fermata a portata: metro, treno, traghetto
    "freq_h": 6.0,          # servizio frequente: corse l'ora
    "ptal_walk_kmh": 4.8,   # PTAL (TfL): velocità a piedi
    "ptal_bus_m": 640.0,    # PTAL: distanza massima bus e tram
    "ptal_rail_m": 960.0,   # PTAL: distanza massima metro e treno
    "snap_m": 500.0,        # aggancio massimo alla rete
    "iso_buffer_m": 30.0,   # contorno delle isocrone attorno alle strade
    "walk_dest_m": 800.0,   # camminabilità: servizi entro (linea d'aria)
    "tp_access_m": 800.0,   # isocrone TP: a piedi da e verso le fermate
    "thresholds": {k: (g, m) for k, (g, m, _h) in THRESHOLDS.items()},
}


def advanced(adv=None):
    """Parametri avanzati completi: quelli dati sopra i predefiniti."""
    out = dict(ADVANCED)
    out["thresholds"] = dict(ADVANCED["thresholds"])
    for k, v in (adv or {}).items():
        if k == "thresholds":
            for tk, tv in (v or {}).items():
                if tk in THRESHOLDS and tv is not None:
                    out["thresholds"][tk] = (float(tv[0]), float(tv[1]))
        elif k in ADVANCED and v is not None:
            out[k] = float(v)
    return out


def thresholds_of(adv=None):
    """Soglie del semaforo {chiave: (verde, giallo, più alto = meglio)}."""
    thr = advanced(adv)["thresholds"]
    return {k: (thr[k][0], thr[k][1], THRESHOLDS[k][2]) for k in THRESHOLDS}


def threshold_texts(thresholds=None):
    """Le soglie a parole (foglio Parametri dell'Excel): {chiave: testo}."""
    thresholds = thresholds or THRESHOLDS
    out = {}
    for k, (good, mid, higher) in thresholds.items():
        lab, unit = THRESHOLD_LABEL[k]
        sgn = tr("da %s") if higher else tr("fino a %s")
        out[k] = tr("%s: verde %s, giallo %s") % (
            lab, sgn % (num(good, 1).rstrip("0").rstrip(",.") + unit),
            sgn % (num(mid, 1).rstrip("0").rstrip(",.") + unit))
    return out


def light(key, value, thresholds=None):
    """"verde", "giallo", "rosso" secondo le soglie (quelle del report o
    THRESHOLDS), o None."""
    thresholds = thresholds or THRESHOLDS
    if value is None or key not in thresholds:
        return None
    good, mid, higher = thresholds[key]
    if higher:
        return "verde" if value >= good else ("giallo" if value >= mid
                                               else "rosso")
    return "verde" if value <= good else ("giallo" if value <= mid
                                           else "rosso")


def gtfs_sources(g):
    """I GTFS del report: `g["source"]` è un percorso o una lista."""
    src = (g or {}).get("source")
    return [x for x in (src if isinstance(src, (list, tuple)) else [src])
            if x]


TP_SKIP = tr("nessun feed GTFS (scheda Trasporti → GTFS, il campo GTFS del "
             "report o la ricerca automatica)")


def margin_m(walk_kmh, times, f15_min, has_dem=False, snap_m=500.0):
    """Margine attorno all'area per la rete e i servizi: il percorso a piedi
    più lungo che serve (isocrone, soglia dei 15 minuti) più l'aggancio.
    Senza margine isocrone e 15 minuti si fermerebbero al confine."""
    from .travel_cost import TOBLER_MAX
    v = walk_kmh / 3.6 * (TOBLER_MAX if has_dem else 1.0)
    return v * 60.0 * max(list(times or []) + [f15_min or 0, 1]) + \
        float(snap_m or 500.0)


class _Progress(object):
    def __init__(self, task):
        self.task = task
        self.phase = ""

    def stage(self, phase, lo, hi):
        self.phase = phase
        if self.task is not None:
            self.task.setProgress(lo)
            try:
                self.task.phase = phase
            except Exception:
                pass
        return lambda p: (self.task.setProgress(lo + (hi - lo) * p / 100.0)
                          if self.task is not None else None)

    def check(self):
        if self.task is not None and self.task.isCanceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()


class PopIndex(object):
    """Popolazione ripartita per area di sovrapposizione (areal weighting):
    un poligono con P abitanti che cade per metà in una zona ne dà P/2.
    Geometrie in metri (CRS proiettato)."""

    def __init__(self, polys):
        from qgis.core import QgsFeature, QgsSpatialIndex
        self.items = []
        self.index = QgsSpatialIndex()
        for k, (g, pop) in enumerate(polys):
            a = g.area()
            if a <= 0 or not pop or pop <= 0:
                continue
            f = QgsFeature(len(self.items))
            f.setGeometry(g)
            self.index.addFeature(f)
            self.items.append((g, float(pop), a))

    def pop_in(self, geom):
        if geom is None or geom.isEmpty():
            return 0.0
        tot = 0.0
        for fid in self.index.intersects(geom.boundingBox()):
            g, pop, a = self.items[fid]
            inter = g.intersection(geom)
            if inter is not None and not inter.isEmpty():
                tot += pop * min(1.0, inter.area() / a)
        return tot


def _ring_geom(ring_latlon):
    from qgis.core import QgsGeometry, QgsPointXY
    return QgsGeometry.fromPolygonXY(
        [[QgsPointXY(lo, la) for la, lo in ring_latlon]])


def _median(values):
    vals = sorted(values)
    if not vals:
        return None
    return statistics.median(vals)


def compute(cfg, task=None):
    """Indicatori del report. Vedi il modulo per il contenuto di `cfg`:

    name, area_wkt (WGS84), ctx (transform context), road (spec con
    source, crs, rect, level_of), type_field, pop [(wkt WGS84, abitanti)] o
    None, services [(lat, lon, categoria)] o None, gtfs {source,
    service_date, start_h, end_h} o None, dem (travel_cost.dem_spec) o None,
    walk_kmh, iso_times, f15_min, cell_m, sections (insieme di chiavi),
    demo (profilo demografico da `istat.report_data`) o None, demo_skip
    (perché manca: allora la sezione Popolazione risulta saltata; senza né
    l'uno né l'altro la sezione semplicemente non c'è), jobs (addetti 2011
    dell'area da `addetti.report_totals`) o None.
    """
    from qgis.core import (QgsCoordinateReferenceSystem,
                           QgsCoordinateTransform, QgsFeatureRequest,
                           QgsGeometry, QgsPointXY)
    from . import (analysis, fifteen, grid_gen, isochrones, net_clean,
                   net_iso, travel_cost)
    pr = _Progress(task)
    ctx = cfg["ctx"]
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    sections = set(cfg.get("sections") or [k for k, _l in SECTIONS])
    walk_kmh = float(cfg.get("walk_kmh") or 4.5)
    times = sorted({float(t) for t in (cfg.get("iso_times") or [5, 10, 15])
                    if float(t) > 0})
    thr = float(cfg.get("f15_min") or 15)
    cell_m = float(cfg.get("cell_m") or 100)
    adv = advanced(cfg.get("advanced"))
    thresholds = thresholds_of(adv)
    skipped = {}
    notes = []

    area_ll = QgsGeometry.fromWkt(cfg["area_wkt"])
    if area_ll is None or area_ll.isEmpty():
        raise ValueError(tr("Area vuota."))
    area_ll = area_ll.makeValid() if not area_ll.isGeosValid() else area_ll
    c = area_ll.centroid().asPoint()
    utm = isochrones._utm_crs_for(c.x(), c.y())
    to_utm = QgsCoordinateTransform(wgs, utm, ctx)
    area_m = QgsGeometry(area_ll)
    area_m.transform(to_utm)
    area_m2 = analysis.geometry_area_m2(area_ll, wgs, ctx)
    area_km2 = area_m2 / 1e6
    eng_ll = QgsGeometry.createGeometryEngine(area_ll.constGet())
    eng_ll.prepareGeometry()

    def inside(lat, lon):
        pg = QgsGeometry.fromPointXY(QgsPointXY(lon, lat))
        return eng_ll.intersects(pg.constGet())

    res = {"name": cfg.get("name") or "Area", "area_km2": area_km2,
           "area_wkt": area_ll.asWkt(7), "utm": utm.authid(),
           "skipped": skipped, "notes": notes,
           "params": {"walk_kmh": walk_kmh, "iso_times": times,
                      "f15_min": thr, "cell_m": cell_m,
                      "type_field": cfg.get("type_field"),
                      "dem": (cfg.get("dem") or {}).get("name"),
                      "gtfs": cfg.get("gtfs"), "adv": adv,
                      "thresholds": thresholds}}

    # ------------------------------------------------------------ popolazione
    pop_index = None
    if cfg.get("pop"):
        polys = []
        for wkt, p in cfg["pop"]:
            g = QgsGeometry.fromWkt(wkt)
            if g is None or g.isEmpty():
                continue
            g.transform(to_utm)
            polys.append((g, p))
        pop_index = PopIndex(polys)
        res["pop"] = pop_index.pop_in(area_m)
    else:
        res["pop"] = None

    # ------------------------------------------------------------ demografia
    if "demo" in sections:
        if cfg.get("demo"):
            res["demo"] = _demo(cfg["demo"], area_ll, res.get("pop"),
                                area_km2)
        elif cfg.get("demo_skip"):
            skipped["demo"] = cfg["demo_skip"]
    res["jobs"] = cfg.get("jobs") or None

    # ------------------------------------------------------------ rete
    prog = pr.stage(tr("lettura della rete"), 2, 15)
    spec = cfg["road"]
    request = QgsFeatureRequest()
    if spec.get("rect") is not None:
        request.setFilterRect(spec["rect"])
    feats = []
    total = max(1, spec.get("count") or 1)
    for i, f in enumerate(spec["source"].getFeatures(request)):
        if i % 500 == 0:
            pr.check()
            prog(min(100.0, 100.0 * i / total))
        feats.append(f)
    if not feats:
        raise ValueError(tr("Nessuna strada della rete nell'area (rete e area "
                         "non si sovrappongono: controlla i CRS)."))
    names = feats[0].fields().names()
    hw = {n.lower(): n for n in names}.get("highway")
    tf = cfg.get("type_field") or hw
    level_of = spec.get("level_of")
    to_road = QgsCoordinateTransform(wgs, spec["crs"], ctx)
    area_road = QgsGeometry(area_ll)
    area_road.transform(to_road)
    road_to_ll = QgsCoordinateTransform(spec["crs"], wgs, ctx)

    if "rete" in sections:
        prog = pr.stage(tr("rete stradale: lunghezze e incroci"), 15, 30)
        rr = analysis.analyze_roads(
            feats, spec["crs"], ctx, tf, area_geom=area_road,
            level_of=level_of, progress=prog, is_canceled=(
                task.isCanceled if task is not None else None))
        ratios = analysis.compute_ratios(rr["lengths"], rr["junctions"],
                                         area_m2, rr["dead_ends"],
                                         len(rr["unnoded"]))
        nodes = rr["junctions"] + rr["dead_ends"]
        res["rete"] = {
            "lengths": dict(sorted(rr["lengths"].items(),
                                   key=lambda kv: -kv[1])),
            "ratios": ratios, "type_field": tf,
            "dead_end_share": (100.0 * rr["dead_ends"] / nodes
                               if nodes else None),
            "junction_points": rr["junction_points"],
        }
        # strade nell'area per la mappa (ritagliate, con il tipo)
        eng_r = QgsGeometry.createGeometryEngine(area_road.constGet())
        eng_r.prepareGeometry()
        clip = []
        for f in feats:
            g = f.geometry()
            if g is None or g.isEmpty() or not eng_r.intersects(g.constGet()):
                continue
            part = g if eng_r.contains(g.constGet()) else \
                g.intersection(area_road)
            if part is None or part.isEmpty():
                continue
            part = QgsGeometry(part)
            part.transform(road_to_ll)
            clip.append((part.asWkt(7), analysis.type_value(f, tf)))
        res["rete"]["clip"] = clip

    # strade di contesto per le mappe: tutte quelle lette (area + margine);
    # se sono moltissime si tengono solo le strade vere e proprie
    minor = {"footway", "path", "steps", "corridor", "platform", "service",
             "cycleway", "track", "bridleway", "pedestrian"}
    many = len(feats) > 40000
    name_f = {nm.lower(): nm for nm in names}.get("name")
    context = []
    for f in feats:
        kind = str(f[hw] or "").strip().lower() if hw else ""
        if many and kind in minor:
            continue
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(road_to_ll)
        nm = f[name_f] if name_f else None
        nm = str(nm).strip() if nm not in (None, "") and str(nm) != "NULL" \
            else ""
        # (geometria, tipo OSM della strada, nome, livello: < 0 in galleria)
        context.append((g.asWkt(6), kind, nm,
                        level_of(f) if level_of else 0))
    res["context"] = context

    # ------------------------------------------------------------ rete pedonale
    pr.stage(tr("rete pedonale e tempi a piedi"), 30, 36)
    raw, levels = [], []
    for f in feats:
        if hw and str(f[hw] or "").strip().lower() in WALK_EXCLUDE:
            continue
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(road_to_ll)
        lev = level_of(f) if level_of else 0
        for part in (g.asMultiPolyline() if g.isMultipart()
                     else [g.asPolyline()]):
            if len(part) >= 2:
                raw.append([(p.x(), p.y()) for p in part])
                levels.append(lev)
    if not raw:
        raise ValueError(tr("La rete non ha strade percorribili a piedi."))
    dem = None
    if cfg.get("dem"):
        d = cfg["dem"]
        lons = [x for r in raw for x, _y in r]
        lats = [y for r in raw for _x, y in r]
        dem = travel_cost.DemGrid(d["provider"], d["crs"], ctx,
                                  (min(lons), min(lats), max(lons),
                                   max(lats)), band=d.get("band", 1))
        if not dem.ok:
            notes.append(tr("Il DEM non copre l'area: pendenza ignorata."))
            dem = None
    raw_times, tstats = travel_cost.edge_times(
        raw, None, walk_kmh / 3.6, dem,
        [lv != 0 for lv in levels] if dem is not None else None,
        is_canceled=task.isCanceled if task is not None else None)
    pairs = []
    roads_w, _d, _cs = net_clean.clean_network(raw, 1.0, None,
                                               pairs_out=pairs)
    ec_w = travel_cost.costs_for_segments(raw_times, pairs)
    vmax_kmh = 3.6 * (tstats.get("vmax_mps") or walk_kmh / 3.6)
    res["dem_used"] = dem is not None
    if dem is not None and tstats.get("campioni"):
        miss = tstats.get("senza_quota", 0) / float(tstats["campioni"])
        if miss > 0.05:
            notes.append(tr("%.0f %% dei punti delle strade è fuori dal DEM o "
                         "senza quota: lì la pendenza vale zero.")
                         % (100 * miss))

    # ------------------------------------------------------------ griglia
    bb = area_ll.boundingBox()
    cents, cells = grid_gen.build_grid(bb.yMinimum(), bb.yMaximum(),
                                       bb.xMinimum(), bb.xMaximum(),
                                       cell_m, "hex")
    # celle che toccano l'area, ritagliate sul suo bordo: insieme coprono
    # esattamente l'area (popolazione e quote senza perdite ai margini);
    # il punto di analisi di una cella ritagliata è un suo punto interno
    hex_area = None
    kc, kr = [], []
    for k, ring in enumerate(cells):
        g = _ring_geom(ring)
        if hex_area is None:
            hex_area = g.area()
        if not eng_ll.intersects(g.constGet()):
            continue
        if eng_ll.contains(g.constGet()):
            kc.append(cents[k])
            kr.append(ring)
            continue
        gi = g.intersection(area_ll)
        if gi is None or gi.isEmpty() or gi.area() < 0.01 * hex_area:
            continue
        parts = (gi.asMultiPolygon() if gi.isMultipart()
                 else [gi.asPolygon()])
        parts = [p for p in parts if p and p[0]]
        if not parts:
            continue
        big = max(parts, key=lambda p: QgsGeometry.fromPolygonXY(p).area())
        pt = QgsGeometry.fromPolygonXY(big).pointOnSurface().asPoint()
        kc.append((pt.y(), pt.x()))
        kr.append([(p.y(), p.x()) for p in big[0]])
    if not kc:
        pt = area_ll.pointOnSurface().asPoint()
        kc = [(pt.y(), pt.x())]
        poly = (area_ll.asMultiPolygon()[0] if area_ll.isMultipart()
                else area_ll.asPolygon())
        kr = [[(p.y(), p.x()) for p in poly[0]]]
    cents, cells = kc, kr
    if len(cells) > 20000:
        raise ValueError(tr("Troppe celle (%d): aumenta la cella o riduci "
                         "l'area.") % len(cells))
    cell_pop = None
    if pop_index is not None:
        cell_pop = []
        for ring in cells:
            g = _ring_geom(ring)
            g.transform(to_utm)
            cell_pop.append(pop_index.pop_in(g.intersection(area_m)))
    res["cells"] = cells
    res["centroids"] = cents
    res["cell_pop"] = cell_pop

    def share(flags):
        """Quota (%) di celle e di popolazione che soddisfano flags."""
        n = len(flags)
        sc = 100.0 * sum(1 for x in flags if x) / n if n else 0.0
        sp = None
        if cell_pop is not None and sum(cell_pop) > 0:
            sp = 100.0 * sum(p for p, x in zip(cell_pop, flags) if x) / \
                sum(cell_pop)
        return sc, sp

    services = list(cfg.get("services") or [])
    cats = fifteen.order_categories({cc for _a, _b, cc in services})

    # ------------------------------------------------------------ walkability
    if "walk" in sections:
        prog = pr.stage(tr("camminabilità per cella"), 36, 50)
        sampler = _dem_sampler(dem) if dem is not None else None
        wres = _walkability(roads_w, cells, services, sampler, prog,
                            adv["walk_dest_m"])
        grades = [r.get("grade_pct", 0.0) for r in wres]
        res["walk"] = {
            "cells": wres,
            "mean_index": (sum(r["walkability"] for r in wres) / len(wres)
                           if wres else None),
            "grade_mean": (sum(grades) / len(grades)
                           if (grades and dem is not None) else None),
            "link_node": _median([r["link_node"] for r in wres
                                  if r["link_node"]]),
        }

    # ------------------------------------------------------------ PTAL
    if "tp" in sections:
        g = cfg.get("gtfs")
        if not gtfs_sources(g):
            skipped["tp"] = TP_SKIP
        else:
            pr.stage(tr("trasporto pubblico: frequenze dal GTFS"), 50, 60)
            pr.check()
            from . import ptal
            srcs = gtfs_sources(g)
            stop_routes, stops_xy, sels = {}, {}, []
            for i, src in enumerate(srcs):
                pr.check()
                inf = {}
                sr, sx = ptal.compute_stop_frequencies(
                    src, g.get("start_h", 8.25), g.get("end_h", 9.25),
                    service_date=g.get("service_date"), info=inf)
                if len(srcs) == 1:
                    stop_routes, stops_xy = sr, sx
                else:
                    # più feed: codici distinti per feed (fermate e linee)
                    pre = "%d:" % i
                    for sid, rts in sr.items():
                        stop_routes[pre + str(sid)] = [
                            (pre + str(rr[0]),) + tuple(rr[1:]) for rr in rts]
                    for sid, xy in sx.items():
                        stops_xy[pre + str(sid)] = xy
                if inf.get("selection"):
                    sels.append(inf["selection"])
            info = {"selection": "; ".join(dict.fromkeys(sels))}
            prog = pr.stage(tr("trasporto pubblico: PTAL per cella"), 60, 68)
            pb, prl = adv["ptal_bus_m"], adv["ptal_rail_m"]
            pres = ptal.compute_ptal_network(
                cents, stop_routes, stops_xy, roads_w, params={
                    "walk_speed_kmh": adv["ptal_walk_kmh"],
                    "thresholds": {"0": pb, "1": prl, "2": prl, "3": pb,
                                   "4": prl},
                    "default_threshold": pb}, progress=prog,
                is_canceled=task.isCanceled if task is not None else None)
            bands = [lab for _hi, lab, _lv in ptal.PTAL_BANDS]
            by_band = []
            for lab in ["0"] + [b for b in bands if b != "0"]:
                sc, sp = share([r["band"] == lab for r in pres])
                by_band.append((lab, sc, sp))
            ge4 = share([r["level"] >= 5 for r in pres])
            # residenti serviti: una fermata a portata di piedi dalla cella
            # (400 m bus e tram, 800 m metro e treno, o i valori avanzati),
            # lungo la stessa rete
            from . import tp_coverage
            cov = tp_coverage.compute(
                [(la, lo, 1.0) for la, lo in cents], stop_routes, stops_xy,
                roads_w, dist=tp_coverage.thresholds(adv["bus_m"],
                                                     adv["rail_m"]),
                snap_m=adv["snap_m"],
                is_canceled=task.isCanceled if task is not None else None)
            served = share([c["freq"] > 0 for c in cov["points"]])
            served6 = share([c["freq"] >= adv["freq_h"]
                             for c in cov["points"]])
            in_stops = [sid for sid, (la, lo) in stops_xy.items()
                        if sid in stop_routes and inside(la, lo)]
            lines = set()
            deps = 0.0
            stop_rows = []
            for sid in in_stops:
                rts = stop_routes[sid]
                lines.update(r[0] for r in rts)
                f_h = sum(r[2] for r in rts)
                deps += f_h
                la, lo = stops_xy[sid]
                stop_rows.append((sid, la, lo, len(rts), f_h))
            res["tp"] = {
                "cells": pres, "by_band": by_band,
                "ptal4_cells": ge4[0], "ptal4_pop": ge4[1],
                "served_cells": served[0], "served_pop": served[1],
                "served6_cells": served6[0], "served6_pop": served6[1],
                "coverage": [(c["dist"], c["freq"], c["lines"], c["cls"])
                             for c in cov["points"]],
                "mean_ai": (sum(r["ai"] for r in pres) / len(pres)
                            if pres else 0.0),
                "n_stops": len(in_stops), "n_lines": len(lines),
                "deps_h": deps, "stops": stop_rows,
                "selection": info.get("selection", ""),
                "feeds": list(g.get("names") or []),
                "band_label": "%02d:%02d–%02d:%02d" % (
                    int(g.get("start_h", 8.25)),
                    round(g.get("start_h", 8.25) % 1 * 60),
                    int(g.get("end_h", 9.25)),
                    round(g.get("end_h", 9.25) % 1 * 60)),
            }

    # ------------------------------------------------------------ isocrone
    if "iso" in sections:
        prog = pr.stage(tr("isocrone a piedi dal centro"), 68, 80)
        pos = area_ll.pointOnSurface().asPoint()
        centre = (pos.y(), pos.x())
        per_source, n_snap = net_iso.compute_reachable_segments(
            roads_w, [centre], vmax_kmh, times, dissolve=True,
            edge_costs=ec_w, snap_m=adv["snap_m"],
            is_canceled=task.isCanceled if task is not None else None)
        if not n_snap:
            skipped["iso"] = tr("il centro dell'area è a più di %s m dalla "
                                "rete") % _fmt(adv["snap_m"], 0)
        else:
            items = isochrones.band_geometries(
                per_source, "polygon", adv["iso_buffer_m"], True, ctx,
                is_canceled=task.isCanceled if task is not None else None)
            bands = []
            for _s, t, geom in sorted(items, key=lambda x: x[1]):
                gm = QgsGeometry(geom)
                gm.transform(to_utm)
                eng = QgsGeometry.createGeometryEngine(geom.constGet())
                eng.prepareGeometry()
                cnt = defaultdict(int)
                for la, lo, cc in services:
                    pg = QgsGeometry.fromPointXY(QgsPointXY(lo, la))
                    if eng.intersects(pg.constGet()):
                        cnt[cc] += 1
                bands.append({"t": t, "wkt": geom.asWkt(7),
                              "area_ha": gm.area() / 1e4,
                              "pop": (pop_index.pop_in(gm)
                                      if pop_index is not None else None),
                              "services": dict(cnt)})
            res["iso"] = {"centre": centre, "bands": bands}
            prog(100)

    # ------------------------------------------------------------ isocrone TP
    if "tpiso" in sections:
        g = cfg.get("gtfs")
        if not gtfs_sources(g):
            skipped["tpiso"] = TP_SKIP
        else:
            res["tpiso"] = _transit_iso(cfg, g, area_ll, to_utm, walk_kmh,
                                        adv, pr, task)

    # ------------------------------------------------------------ 15 minuti
    if "f15" in sections:
        if not services:
            skipped["f15"] = tr("nessun servizio (layer o download OSM)")
        else:
            prog = pr.stage(tr("città dei 15 minuti"), 80, 94)
            tms, n_out, n_po = fifteen.nearest_times(
                roads_w, None, ec_w, cents, services, cats, thr * 60.0,
                snap_m=adv["snap_m"], progress=prog,
                is_canceled=task.isCanceled if task is not None else None)
            summ = fifteen.summarize(tms, cats, thr * 60.0)
            K = len(cats)
            full = share([s["n"] == K for s in summ])
            per_cat = []
            for k, cname in enumerate(cats):
                tk = [s["tempi_min"][k] for s in summ]
                got = share([t is not None and t <= thr for t in tk])
                med = _median([t if t is not None else float("inf")
                               for t in tk])
                per_cat.append({"categoria": cname,
                                "mediana_min": (None if med is None
                                                or math.isinf(med) else med),
                                "celle_pct": got[0], "pop_pct": got[1]})
            idx = [s["indice"] for s in summ]
            if cell_pop is not None and sum(cell_pop) > 0:
                mean_idx = sum(i * p for i, p in zip(idx, cell_pop)) / \
                    sum(cell_pop)
            else:
                mean_idx = sum(idx) / len(idx) if idx else 0.0
            mean_idx = max(0.0, min(100.0, mean_idx))
            worst = min(per_cat, key=lambda r: r["celle_pct"]) \
                if per_cat else None
            res["f15"] = {"categories": cats, "summary": summ,
                          "mean_index": mean_idx, "full_cells": full[0],
                          "full_pop": full[1], "per_cat": per_cat,
                          "worst": worst["categoria"] if worst and
                          worst["celle_pct"] < 100 else None,
                          "cells_off_network": n_out}

    # ------------------------------------------------------------ servizi
    if "servizi" in sections:
        if not services:
            skipped["servizi"] = tr("nessun servizio (layer o download OSM)")
        else:
            cnt = defaultdict(int)
            pts = []
            for la, lo, cc in services:
                if inside(la, lo):
                    cnt[cc] += 1
                    pts.append((la, lo, cc))
            pop = res.get("pop")
            rows = [(cc, cnt.get(cc, 0),
                     (1000.0 * cnt.get(cc, 0) / pop) if pop else None)
                    for cc in cats]
            res["servizi"] = {"rows": rows, "total": sum(cnt.values()),
                              "points": pts,
                              "source": cfg.get("services_source", "")}

    res["summary"] = summary_cards(res)
    res["insights"] = insights(res)
    pr.stage("fine", 100, 100)
    return res


def _transit_iso(cfg, g, area_ll, to_utm, walk_kmh, adv, pr, task):
    """Isocrone in trasporto pubblico dal centro dell'area: a piedi fino a
    una fermata (entro `tp_access_m`), il GTFS con i cambi (a piedi fino a
    200 m) e a piedi dalla fermata d'arrivo con il tempo che resta. Il tempo
    per fermata è la mediana delle partenze ogni 15 minuti nella fascia del
    PTAL. Con più feed ognuno si calcola da solo (niente cambi fra feed) e
    le aree si uniscono."""
    from qgis.core import QgsGeometry, QgsPointXY
    from . import transit_iso
    times = sorted({float(t) for t in (cfg.get("tp_iso_times")
                                       or [15, 30, 45]) if float(t) > 0})
    start_h = float(g.get("start_h", 8.25))
    end_h = float(g.get("end_h", 9.25))
    window_s = max(0.0, (end_h - start_h) * 3600.0)
    step_s = 900.0 if window_s >= 900.0 else 0.0
    tmax = max(times)
    pos = area_ll.pointOnSurface().asPoint()
    centre = (pos.y(), pos.x())
    walk_mps = walk_kmh / 3.6
    circles = {t: [] for t in times}
    stops = {t: 0 for t in times}
    srcs = gtfs_sources(g)
    is_canceled = task.isCanceled if task is not None else None
    for i, src in enumerate(srcs):
        lo = 70.0 + 10.0 * i / len(srcs)
        hi = 70.0 + 10.0 * (i + 1) / len(srcs)
        prog = pr.stage(tr("trasporto pubblico: isocrone dal centro") + (
            " (%d/%d)" % (i + 1, len(srcs)) if len(srcs) > 1 else ""), lo, hi)
        data = transit_iso.prepare_transit(
            src, start_h, window_s / 60.0 + tmax, walk_kmh, 200.0,
            g.get("service_date"), progress=lambda x: prog(0.8 * x),
            is_canceled=is_canceled)
        pr.check()
        if step_s:
            earliest, stops_xy, s0, _e = transit_iso.reach_window(
                data, centre, start_h * 3600.0, window_s, step_s, tmax * 60.0,
                max_access_m=adv["tp_access_m"])
        else:
            earliest, stops_xy, s0, _e = transit_iso.reach_from(
                data, centre, max_access_m=adv["tp_access_m"],
                start_s=start_h * 3600.0, budget_s=tmax * 60.0)
        for t in times:
            circles[t] += transit_iso.transit_circles_for_band(
                earliest, stops_xy, s0, walk_mps, centre, t,
                max_access_m=adv["tp_access_m"])
            stops[t] += sum(1 for v in earliest.values()
                            if v <= s0 + t * 60.0)
        prog(100)
    bands = []
    from qgis.core import QgsCoordinateTransform
    back = QgsCoordinateTransform(to_utm.destinationCrs(),
                                  to_utm.sourceCrs(), to_utm.context())
    for t in times:
        pr.check()
        parts = []
        for la, lo_, r in circles[t]:
            if r <= 0:
                continue
            pt = QgsGeometry.fromPointXY(QgsPointXY(lo_, la))
            pt.transform(to_utm)
            parts.append(pt.buffer(r, 8))
        if not parts:
            continue
        gm = QgsGeometry.unaryUnion(parts)
        area_ha = gm.area() / 1e4
        gl = QgsGeometry(gm)
        gl.transform(back)
        bands.append({"t": t, "wkt": gl.asWkt(6), "area_ha": area_ha,
                      "stops": stops[t]})
    return {"centre": centre, "bands": bands, "start_h": start_h,
            "window_min": window_s / 60.0, "access_m": adv["tp_access_m"],
            "feeds": list(g.get("names") or []), "n_feeds": len(srcs)}


def _demo(dm, area_ll, pop, area_km2):
    """Sezione «Popolazione» dai dati ISTAT (`istat.report_data`): profilo
    dell'area e del comune di confronto, e le sezioni di censimento
    ritagliate sul bordo dell'area per la mappa.

    La densità dell'area nel confronto è quella del report (abitanti /
    superficie dell'area), così coincide con la sintesi.
    """
    from qgis.core import QgsGeometry, QgsWkbTypes
    from . import istat
    fields = dm["fields"]
    secs = []
    for wkt, q, v in dm["rows"]:
        g = QgsGeometry.fromWkt(wkt)
        if g is None or g.isEmpty():
            continue
        if q < 0.999:
            g = g.intersection(area_ll)
            if g is None or g.isEmpty():
                continue
            if QgsWkbTypes.flatType(g.wkbType()) == \
                    QgsWkbTypes.GeometryCollection:
                g.convertGeometryCollectionToSubclass(
                    QgsWkbTypes.PolygonGeometry)
            if g.type() != QgsWkbTypes.PolygonGeometry:
                continue
        row = dict(zip(fields, v))
        d = istat.derive(row)
        secs.append({
            "wkt": g.asWkt(7), "id": row["SEZ21_ID"], "quota": q,
            "pop": row["POP21"] or 0, "fam": row["FAM21"] or 0,
            "abi": row["ABI21"] or 0, "edi": row["EDI21"] or 0,
            "dens_ha": d.get("DENS_HA") if row["POP21"] else None,
            "pct_0_14": d.get("PCT_0_14"), "pct_65": d.get("PCT_65P"),
            "pct_stran": d.get("PCT_STRAN"),
            "pct_laurea": d.get("PCT_LAUREA"), "occ": d.get("TASSO_OCC")})
    pa = dict(dm["profile"])
    if pop and area_km2:
        pa["density"] = pop / area_km2
    com = dm["comune"]
    pc = com["profile"]
    compare = [(lab, pa.get(k), pc.get(k), unit, dec)
               for k, lab, unit, dec in istat.COMPARE]
    return {"profile": pa, "sections": secs, "compare": compare,
            "comune": {"nome": com["nome"], "share": com["share"],
                       "others": com.get("others", 0), "profile": pc},
            "source": dm.get("source", "")}


def _dem_sampler(dem):
    """f(lon, lat) → quota (m) o None, per la walkability."""
    def sampler(lon, lat):
        z = dem.heights([lon], [lat])[0]
        return None if z != z else float(z)
    return sampler


def _walkability(roads, cells, services, sampler, prog, max_dest_m=800.0):
    from .walkability import compute_walkability
    return compute_walkability(roads, cells, pois=services or None,
                               max_dest_m=max_dest_m, elev_sampler=sampler,
                               progress=prog)


def summary_cards(res):
    """Riquadri della sintesi: [(chiave, titolo, valore testo, nota,
    semaforo)] nell'ordine della pagina."""
    out = []

    thresholds = res.get("params", {}).get("thresholds")

    def add(key, title, text, note="", lkey=None, lval=None):
        out.append({"key": key, "title": title, "value": text, "note": note,
                    "light": light(lkey, lval, thresholds) if lkey else None,
                    "lkey": lkey, "raw": lval})

    add("area", tr("Superficie"), tr("%s km²") % _fmt(res["area_km2"], 2),
        tr("area analizzata"))
    pop = res.get("pop")
    if pop is not None:
        add("pop", tr("Popolazione"), tr("%s ab.") % _fmt(pop, 0),
            tr("%s ab./km²") % _fmt(pop / res["area_km2"], 0)
            if res["area_km2"] else "")
    jobs = res.get("jobs")
    if jobs:
        add("jobs", "Addetti (2011)", _fmt(jobs["total"], 0),
            tr("%s ogni 100 residenti") % _fmt(100.0 * jobs["total"] / pop, 0)
            if pop else tr("posti di lavoro nell'area"))
    r = res.get("rete")
    if r:
        rt = r["ratios"]
        idn = rt.get("intersection_density_per_km2")
        add("int", tr("Densità degli incroci"), tr("%s /km²") % _fmt(idn, 0),
            tr("%d incroci reali") % rt.get("junctions", 0), "int_density", idn)
        add("net", tr("Densità della rete"),
            tr("%s km/km²") % _fmt(rt.get("density_km_per_km2"), 1),
            tr("%s km di strade") % _fmt(rt.get("total_length_km"), 1))
        if r.get("dead_end_share") is not None:
            add("dead", tr("Vicoli ciechi"), "%s %%" % _fmt(r["dead_end_share"], 0),
                tr("%d sui nodi della rete") % rt.get("dead_ends", 0),
                "dead_end_share", r["dead_end_share"])
    w = res.get("walk")
    if w and w.get("grade_mean") is not None:
        add("grade", tr("Pendenza media"), "%s %%" % _fmt(w["grade_mean"], 1),
            tr("delle strade, dal DEM"), "grade_mean", w["grade_mean"])
    tp = res.get("tp")
    if tp:
        v = tp["ptal4_pop"] if tp.get("ptal4_pop") is not None \
            else tp["ptal4_cells"]
        add("ptal", tr("PTAL 4 o più"), "%s %%" % _fmt(v, 0),
            tr("%s, %d fermate, %d linee") % (
                tr("della popolazione") if tp.get("ptal4_pop") is not None
                else "dell'area", tp["n_stops"], tp["n_lines"]),
            "ptal4_share", v)
    f = res.get("f15")
    if f:
        add("f15", tr("Indice %g minuti") % res["params"]["f15_min"],
            "%s / 100" % _fmt(f["mean_index"], 0),
            tr("media %s") % (tr("pesata sulla popolazione")
                          if f.get("full_pop") is not None else tr("delle celle")),
            "f15_index", f["mean_index"])
        v = f["full_pop"] if f.get("full_pop") is not None else f["full_cells"]
        add("f15full", tr("Tutti i servizi in %g min") % res["params"]["f15_min"],
            "%s %%" % _fmt(v, 0),
            (tr("della popolazione") if f.get("full_pop") is not None
             else tr("delle celle")) + (tr("; manca più spesso: %s") % f["worst"]
                                    if f.get("worst") else ""),
            "f15_full_share", v)
    iso = res.get("iso")
    if iso and iso["bands"]:
        b = iso["bands"][-1]
        val = (tr("%s ab.") % _fmt(b["pop"], 0) if b.get("pop") is not None
               else tr("%s ha") % _fmt(b["area_ha"], 0))
        add("iso", tr("A piedi in %g min dal centro") % b["t"], val,
            tr("%s ha raggiunti") % _fmt(b["area_ha"], 0)
            if b.get("pop") is not None else tr("area raggiunta"))
    s = res.get("servizi")
    if s:
        pop = res.get("pop")
        add("serv", tr("Servizi nell'area"), "%d" % s["total"],
            tr("%s ogni 1 000 abitanti") % _fmt(1000.0 * s["total"] / pop, 1)
            if pop else tr("%d categorie") % len(s["rows"]))
    return out


def _fmt(v, dec=0):
    """Numero nella lingua scelta: 1.234,5 (italiano) o 1,234.5."""
    return num(v, dec)


fmt = _fmt
