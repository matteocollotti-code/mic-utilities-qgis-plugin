# -*- coding: utf-8 -*-
"""Preparazione della rete: noding alle intersezioni + snap + dedup.

Trasforma una rete grezza (anche non "noded") in una rete pronta per il grafo:
spezza le linee dove si incrociano geometricamente senza un vertice condiviso,
così che le analisi su rete (isocrone, accessibilità, PTAL, space syntax) possano
attraversare quegli incroci.

`node_network` lavora su segmenti lon/lat (puro Python, thread-safe). La
proiezione è equirettangolare locale in metri (coerente con net_iso/net_clean).
Con i livelli (ponte, tunnel, layer OSM) si spezzano solo gli incroci tra
strade allo stesso livello. Limiti: ignora le sovrapposizioni collineari; per
reti molto grandi può essere costoso (mitigato da indice a griglia + progress).
"""
from ..i18n import tr
import math


def _projector(lat0):
    mlat = 111320.0
    mlon = 111320.0 * math.cos(math.radians(lat0))

    def to_m(lon, lat):
        return (lon * mlon, lat * mlat)

    def to_ll(x, y):
        return (x / mlon, y / mlat)

    return to_m, to_ll


def _seg_intersection(ax, ay, bx, by, cx, cy, dx, dy):
    """Intersezione dei segmenti AB e CD. Ritorna (t, u) lungo AB/CD o None.

    Include i contatti a T (estremo di un segmento sull'interno dell'altro).
    Ignora i casi paralleli/collineari.
    """
    rx, ry = bx - ax, by - ay
    sx, sy = dx - cx, dy - cy
    denom = rx * sy - ry * sx
    if denom == 0:
        return None
    qpx, qpy = cx - ax, cy - ay
    t = (qpx * sy - qpy * sx) / denom
    u = (qpx * ry - qpy * rx) / denom
    if -1e-9 <= t <= 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9:
        return t, u
    return None


def _seg_grid(segs, cell):
    grid = {}
    for i, sg in enumerate(segs):
        ax, ay, bx, by = sg[0], sg[1], sg[2], sg[3]
        x0, x1 = sorted((ax, bx))
        y0, y1 = sorted((ay, by))
        for gx in range(int(x0 // cell), int(x1 // cell) + 1):
            for gy in range(int(y0 // cell), int(y1 // cell) + 1):
                grid.setdefault((gx, gy), []).append(i)
    return grid


def _candidates(grid, cell, ax, ay, bx, by):
    x0, x1 = sorted((ax, bx))
    y0, y1 = sorted((ay, by))
    cand = set()
    for gx in range(int(x0 // cell), int(x1 // cell) + 1):
        for gy in range(int(y0 // cell), int(y1 // cell) + 1):
            cand.update(grid.get((gx, gy), ()))
    return cand


def node_network(roads_lonlat, snap_tol_m=1.0, min_seg_m=0.2, directions=None,
                 split=True, progress=None, is_canceled=None, levels=None,
                 sources=None, src_out=None):
    """Spezza i segmenti alle intersezioni e pulisce.

    :param split: se False salta il noding (solo snap + dedup, come net_clean).
    :param min_seg_m: niente schegge più corte: un punto di taglio più vicino
        di così a un estremo del segmento si aggancia all'estremo, e due tagli
        più vicini tra loro diventano uno solo.
    :param levels: livello per polilinea (topology.level_reader: ponte,
        tunnel, layer e piano OSM): si spezzano solo gli incroci tra strade
        allo STESSO livello, così un cavalcavia non si collega alla strada
        sotto.
    :param sources: id d'origine per polilinea; con `src_out` (lista) vi si
        aggiunge l'origine di ogni segmento restituito.
    :return: (segmenti lon/lat, directions allineate o None, stats).
    """
    from . import net_clean, net_iso

    polys = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    stats = {"segmenti_in": 0, "segmenti_out": 0, "split": 0,
             "intersezioni": 0, "nulli": 0, "duplicati": 0, "nodi": 0,
             "livelli_diversi": 0}
    if not polys:
        return [], (None if directions is None else []), stats
    # CRS sbagliato (metri letti come gradi): l'indice a griglia avrebbe
    # miliardi di celle e bloccherebbe QGIS
    ok, vmsg, _info = net_iso.validate_network(polys)
    if not ok:
        raise ValueError(vmsg)
    if not split:
        cleaned, cdirs, cstats = net_clean.clean_network(
            roads_lonlat, snap_tol_m, directions, sources=sources,
            src_out=src_out)
        stats.update(cstats)
        return cleaned, cdirs, stats

    lat0 = polys[0][0][1]
    to_m, to_ll = _projector(lat0)
    min_seg = max(0.0, float(min_seg_m or 0.0))

    # 1) segmenti elementari in metri, con direzione, livello e origine
    segs = []          # (ax, ay, bx, by, livello)
    seg_dir = []
    seg_src = []
    for ri, road in enumerate(roads_lonlat or []):
        if not road or len(road) < 2:
            continue
        rd = directions[ri] if directions and ri < len(directions) else 0
        lv = levels[ri] if levels and ri < len(levels) else 0
        src = sources[ri] if sources is not None else ri
        m = [to_m(lon, lat) for lon, lat in road]
        for (ax, ay), (bx, by) in zip(m, m[1:]):
            if ax == bx and ay == by:
                continue
            segs.append((ax, ay, bx, by, lv))
            seg_dir.append(rd)
            seg_src.append(src)
    stats["segmenti_in"] = len(segs)
    if not segs:
        return [], (None if directions is None else []), stats

    # 2) indice a griglia delle bbox dei segmenti
    cell = 25.0
    grid = _seg_grid(segs, cell)

    # 3) punti di taglio: ogni incrocio diventa un punto condiviso dai due
    # segmenti (union-find per fondere i tagli troppo vicini)
    pts = []           # coordinate dei punti di taglio
    parent = []

    def new_pt(x, y):
        pts.append((x, y))
        parent.append(len(parent))
        return len(pts) - 1

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    splits = [[] for _ in segs]     # (t, id punto)
    lv_pts = set()
    # vertici da far coincidere: incrocio vicino (entro min_seg) agli estremi
    # di ENTRAMBI i segmenti, risolto unendo i due estremi
    alias = {}
    n = len(segs)
    for i, (ax, ay, bx, by, li) in enumerate(segs):
        if is_canceled and i % 256 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and i % 512 == 0:
            progress(int(60 * i / n))
        len_i = math.hypot(bx - ax, by - ay)
        for j in _candidates(grid, cell, ax, ay, bx, by):
            if j <= i:
                continue
            cx, cy, ddx, ddy, lj = segs[j]
            r = _seg_intersection(ax, ay, bx, by, cx, cy, ddx, ddy)
            if r is None:
                continue
            t, u = r
            in_i = 1e-6 < t < 1 - 1e-6
            in_j = 1e-6 < u < 1 - 1e-6
            if not (in_i or in_j):
                continue
            if lj != li and in_i and in_j:
                # cavalcavia/sottopasso: nessun incrocio (contato per punto).
                # Un contatto a T (estremo di uno sull'altro) resta un
                # collegamento anche fra livelli diversi: è una rampa
                lv_pts.add((round(ax + (bx - ax) * t, 1),
                            round(ay + (by - ay) * t, 1)))
                continue
            len_j = math.hypot(ddx - cx, ddy - cy)
            # estremo vicino (entro min_seg): il taglio si aggancia a lui
            end_i = None
            if not in_i or t * len_i < min_seg or (1 - t) * len_i < min_seg:
                end_i = (ax, ay) if t <= 0.5 else (bx, by)
            end_j = None
            if not in_j or u * len_j < min_seg or (1 - u) * len_j < min_seg:
                end_j = (cx, cy) if u <= 0.5 else (ddx, ddy)
            if end_i is not None and end_j is not None:
                # entrambi vicini a un proprio estremo: prima si lasciava
                # fare allo snap a griglia, che spesso non li univa e
                # l'incrocio restava scollegato
                if end_i != end_j and end_j not in alias:
                    alias[end_j] = end_i
                    stats["intersezioni"] += 1
                continue
            if end_i is not None:
                splits[j].append((u, new_pt(*end_i)))
            elif end_j is not None:
                splits[i].append((t, new_pt(*end_j)))
            else:
                pid = new_pt(ax + (bx - ax) * t, ay + (by - ay) * t)
                splits[i].append((t, pid))
                splits[j].append((u, pid))
            stats["intersezioni"] += 1

    stats["livelli_diversi"] = len(lv_pts)

    # tagli più vicini di min_seg sullo stesso segmento: un solo punto
    for i, sp in enumerate(splits):
        if len(sp) < 2:
            continue
        ax, ay, bx, by, _l = segs[i]
        len_i = math.hypot(bx - ax, by - ay)
        sp.sort()
        kept = [sp[0]]
        for t, pid in sp[1:]:
            if (t - kept[-1][0]) * len_i < min_seg:
                ra, rb = find(pid), find(kept[-1][1])
                if ra != rb:
                    parent[ra] = rb
            else:
                kept.append((t, pid))
        splits[i] = kept

    def _al(pt):
        k = 0
        while pt in alias and k < 20:
            pt = alias[pt]
            k += 1
        return pt

    # 4) spezza i segmenti ai punti di taglio (lon/lat) e conta gli split
    out_roads = []
    out_dirs = []
    out_src = []
    n_split = 0
    for i, (ax, ay, bx, by, _l) in enumerate(segs):
        sp = splits[i]
        n_split += len(sp)
        chain = [_al((ax, ay))] + [_al(pts[find(pid)]) for _t, pid in sp] + \
            [_al((bx, by))]
        for (pax, pay), (pbx, pby) in zip(chain, chain[1:]):
            out_roads.append([to_ll(pax, pay), to_ll(pbx, pby)])
            out_dirs.append(seg_dir[i])
            out_src.append(seg_src[i])
    stats["split"] = n_split
    if progress:
        progress(75)

    # 5) snap finale + rimozione nulli/duplicati (riusa net_clean)
    cleaned, cdirs, cstats = net_clean.clean_network(
        out_roads, snap_tol_m, out_dirs if directions is not None else None,
        sources=out_src, src_out=src_out)
    stats["segmenti_out"] = cstats["segmenti_out"]
    stats["nulli"] = cstats["nulli"]
    stats["duplicati"] = cstats["duplicati"]
    stats["nodi"] = cstats["nodi"]
    if progress:
        progress(100)
    return cleaned, cdirs, stats


def find_unresolved_crossings(roads_lonlat, max_report=500, levels=None):
    """Punti dove due segmenti si toccano senza un vertice condiviso: incroci
    a X (interno di entrambi) e contatti a T (l'estremo di uno sull'interno
    dell'altro). Sono gli incroci da nodare.

    :param levels: livello per polilinea (ponte/tunnel/layer): gli incroci tra
        livelli diversi sono cavalcavia o sottopassi e non vengono segnalati.
    :return: lista di (lat, lon).
    """
    valid = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    if not valid:
        return []
    lat0 = valid[0][0][1]
    to_m, to_ll = _projector(lat0)
    segs = []
    for ri, road in enumerate(roads_lonlat):
        if not road or len(road) < 2:
            continue
        lv = levels[ri] if levels and ri < len(levels) else 0
        m = [to_m(lon, lat) for lon, lat in road]
        for (ax, ay), (bx, by) in zip(m, m[1:]):
            if (ax, ay) != (bx, by):
                segs.append((ax, ay, bx, by, lv))
    cell = 25.0
    grid = _seg_grid(segs, cell)
    seen = set()
    out = []
    for i, (ax, ay, bx, by, li) in enumerate(segs):
        for j in _candidates(grid, cell, ax, ay, bx, by):
            if j <= i:
                continue
            cx, cy, dx, dy, lj = segs[j]
            r = _seg_intersection(ax, ay, bx, by, cx, cy, dx, dy)
            if r is None:
                continue
            t, u = r
            in_i = 1e-6 < t < 1 - 1e-6
            in_j = 1e-6 < u < 1 - 1e-6
            if lj != li and in_i and in_j:
                continue  # cavalcavia/sottopasso
            if in_i or in_j:
                px, py = ax + (bx - ax) * t, ay + (by - ay) * t
                k = (round(px, 1), round(py, 1))
                if k in seen:
                    continue
                seen.add(k)
                lon, lat = to_ll(px, py)
                out.append((lat, lon))
                if len(out) >= max_report:
                    return out
    return out


def prepare_summary(stats):
    txt = (tr("rete preparata: %d segmenti (noding: %d split su %d intersezioni; "
           "−%d nulli, −%d duplicati), %d nodi")
           % (stats.get("segmenti_out", 0), stats.get("split", 0),
              stats.get("intersezioni", 0), stats.get("nulli", 0),
              stats.get("duplicati", 0), stats.get("nodi", 0)))
    if stats.get("tratti"):
        txt += tr(", %d tratti con gli attributi d'origine") % stats["tratti"]
    if stats.get("livelli_diversi"):
        txt += (tr("; %d attraversamenti tra livelli diversi (ponti, tunnel, "
                "piani) lasciati senza collegamento") % stats["livelli_diversi"])
    return txt
