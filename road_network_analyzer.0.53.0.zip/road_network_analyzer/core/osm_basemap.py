# -*- coding: utf-8 -*-
"""Base cartografica da OpenStreetMap per le mappe del report.

Scarica con Overpass, per un riquadro, gli elementi che danno il senso del
luogo sotto i temi: edifici, verde (parchi, giardini, boschi, prati), acqua
(specchi e corsi) e ferrovie in superficie. Le strade non servono: arrivano
dalla rete già letta per il report.

`fetch_base` fa solo rete e parsing più l'assemblaggio dei multipoligoni
con le geometrie QGIS (thread-safe: si può chiamare in un QgsTask); il
risultato è un dict di liste di WKT in lon/lat, serializzabile nella cache
locale dei download OSM (osm_cache, tipo "base").
"""
from ..i18n import tr
import math
import time

from .osm_download import OVERPASS_HEADERS, OVERPASS_URLS, _check_remark

# oltre questa superficie del riquadro gli edifici non si scaricano: sono
# troppi (decine di migliaia) e a quella scala in mappa non si distinguono
MAX_BUILDINGS_KM2 = 14.0
KINDS = ("build", "green", "water", "waterl", "rail")


def bbox_km2(south, west, north, east):
    lat = math.radians((south + north) / 2.0)
    return ((north - south) * 111.32) * ((east - west) * 111.32
                                         * max(0.05, math.cos(lat)))


def build_query(south, west, north, east, buildings=True):
    b = "%.6f,%.6f,%.6f,%.6f" % (south, west, north, east)
    parts = []
    if buildings:
        parts += ['way["building"](%s);' % b,
                  'relation["building"]["type"="multipolygon"](%s);' % b]
    parts += [
        'way["leisure"~"^(park|garden|playground|pitch|recreation_ground|'
        'dog_park)$"](%s);' % b,
        'relation["leisure"~"^(park|garden)$"](%s);' % b,
        'way["landuse"~"^(grass|forest|meadow|recreation_ground|cemetery|'
        'village_green|allotments)$"](%s);' % b,
        'way["natural"~"^(wood|scrub|grassland|water)$"](%s);' % b,
        'relation["natural"="water"](%s);' % b,
        'way["waterway"~"^(river|canal|stream)$"](%s);' % b,
        'way["railway"~"^(rail|tram|light_rail)$"](%s);' % b,
    ]
    return "[out:json][timeout:180];(%s);out geom;" % "".join(parts)


def kind_of(tags):
    """Tipo di elemento della base dai tag OSM, o None se da scartare."""
    if "building" in tags:
        return "build"
    if tags.get("railway"):
        # in galleria non si vede: fuori dalla mappa
        return None if tags.get("tunnel") in ("yes", "true") else "rail"
    if tags.get("waterway"):
        return None if tags.get("tunnel") in ("yes", "true", "culvert") \
            else "waterl"
    if tags.get("natural") == "water":
        return "water"
    return "green"


def _ring_wkt(coords):
    return "POLYGON((%s))" % ", ".join("%.7f %.7f" % p for p in coords)


def _line_wkt(coords):
    return "LINESTRING(%s)" % ", ".join("%.7f %.7f" % p for p in coords)


def parse(data):
    """Elementi Overpass (`out geom`) → {tipo: [WKT lon/lat]}."""
    out = dict((k, []) for k in KINDS)
    for el in data.get("elements", []):
        tags = el.get("tags") or {}
        k = kind_of(tags)
        if k is None:
            continue
        if el.get("type") == "way":
            co = [(p["lon"], p["lat"]) for p in el.get("geometry") or []
                  if p and p.get("lon") is not None]
            if len(co) < 2:
                continue
            if k in ("rail", "waterl"):
                out[k].append(_line_wkt(co))
            elif len(co) >= 4 and co[0] == co[-1]:
                out[k].append(_ring_wkt(co))
        elif el.get("type") == "relation" and k in ("build", "green",
                                                    "water"):
            wkt = _multipolygon_wkt(el)
            if wkt:
                out[k].append(wkt)
    return out


def _multipolygon_wkt(el):
    """Multipoligono di una relazione: anelli esterni ricomposti dai
    tratti dei membri, meno quelli interni."""
    from qgis.core import QgsGeometry, QgsPointXY
    outer, inner = [], []
    for m in el.get("members", []):
        co = [(p["lon"], p["lat"]) for p in m.get("geometry") or []
              if p and p.get("lon") is not None]
        if len(co) >= 2:
            (inner if m.get("role") == "inner" else outer).append(
                QgsGeometry.fromPolylineXY([QgsPointXY(x, y)
                                            for x, y in co]))
    if not outer:
        return None
    g = QgsGeometry.polygonize(outer)
    if g is None or g.isEmpty():
        return None
    g = QgsGeometry.unaryUnion(g.asGeometryCollection())
    if inner:
        gi = QgsGeometry.polygonize(inner)
        if gi is not None and not gi.isEmpty():
            g = g.difference(QgsGeometry.unaryUnion(
                gi.asGeometryCollection()))
    if g is None or g.isEmpty():
        return None
    return g.asWkt(7)


def fetch_base(south, west, north, east, progress=None, is_canceled=None,
               rounds=2):
    """Base cartografica del riquadro: {build, green, water, waterl, rail}
    (liste di WKT lon/lat) più "buildings": se gli edifici sono stati
    chiesti. Prova i server Overpass a turno, `rounds` volte."""
    import requests
    buildings = bbox_km2(south, west, north, east) <= MAX_BUILDINGS_KM2
    query = build_query(south, west, north, east, buildings)
    if progress:
        progress(8)
    data, last = None, None
    for attempt in range(max(1, rounds)):
        for url in OVERPASS_URLS:
            if is_canceled and is_canceled():
                return None
            try:
                resp = requests.post(url, data={"data": query},
                                     headers=OVERPASS_HEADERS, timeout=150)
                resp.raise_for_status()
                data = resp.json()
                _check_remark(data)
                break
            except Exception as exc:
                last, data = exc, None
        if data is not None:
            break
        if attempt + 1 < rounds:
            for _k in range(8):  # pausa annullabile fra i giri
                if is_canceled and is_canceled():
                    return None
                time.sleep(1.0)
    if data is None:
        raise RuntimeError(tr("Overpass non raggiungibile: %s") % last)
    if progress:
        progress(70)
    out = parse(data)
    out["buildings"] = buildings
    if progress:
        progress(100)
    return out


def cached_base(bbox, progress=None, is_canceled=None):
    """`fetch_base` con la cache locale dei download OSM.

    :param bbox: (south, west, north, east).
    :return: (base, dalla_cache) o (None, False) se annullato.
    """
    from . import osm_cache
    c = osm_cache.get_cached("base", bbox, "all")
    if c and isinstance(c.get("features"), dict):
        if progress:
            progress(100)
        return c["features"], True
    base = fetch_base(*bbox, progress=progress, is_canceled=is_canceled)
    if base is None:
        return None, False
    if any(base.get(k) for k in KINDS):
        osm_cache.put_cached("base", bbox, "all", base)
    return base, False


TILE_TEST = {
    "osm": "https://tile.openstreetmap.org/1/0/0.png",
    "satellite": "https://server.arcgisonline.com/ArcGIS/rest/services/"
                 "World_Imagery/MapServer/tile/1/0/0",
}


def tiles_reachable(style, timeout=7):
    """True se il server delle piastrelle dello stile risponde (serve
    internet a ogni report con le basi a piastrelle)."""
    import requests
    url = TILE_TEST.get(style)
    if not url:
        return True
    try:
        r = requests.get(url, headers=OVERPASS_HEADERS, timeout=timeout)
        return r.status_code == 200 and len(r.content) > 100
    except Exception:
        return False
