# -*- coding: utf-8 -*-
"""Sezioni di censimento ISTAT (Censimento permanente 2021).

Scarica dal sito ISTAT, una regione alla volta e una volta sola, le basi
territoriali (poligoni delle sezioni con popolazione, famiglie, abitazioni,
edifici) e gli indicatori per sezione (età, istruzione, lavoro,
cittadinanza, famiglie, abitazioni), li tiene in un GeoPackage per regione
nel profilo di QGIS e li legge per comune o per area.

Tutto ciò che scarica, costruisce e legge (`ensure_region`, `fetch`,
`population`) usa solo GDAL e la libreria standard: è sicuro in un task di
background. `build_layer` e `apply_theme` creano oggetti QGIS e vanno
chiamati sul thread principale.
"""
from ..i18n import tr, num
import csv
import io
import json
import os
import re
import shutil
import sqlite3
import struct
import time
import zipfile
import zlib
import xml.etree.ElementTree as ET

EDITION = 2021
SOURCE = (tr("ISTAT – Basi territoriali e variabili censuarie, Censimento "
          "permanente 2021 (CC BY 4.0)"))
BASE_URL = ("https://www.istat.it/storage/cartografia/basi_territoriali/"
            "2021/R%02d_21.zip")
IND_URL = ("https://esploradati.istat.it/databrowser/DWL/PERMPOP/SUBCOM/"
           "Dati_regionali_2021.zip")
IND_MEMBER = "R%02d_indicatori_2021_sezioni.xlsx"
HEADERS = {"User-Agent": "MIC-Utilities-QGIS/1.0 (QGIS plugin)"}
# versione dello schema dei GeoPackage in cache (nel nome del file)
SCHEMA = 1
EPSG = 32632

REGIONS = {
    1: "Piemonte", 2: tr("Valle d'Aosta"), 3: "Lombardia",
    4: tr("Trentino-Alto Adige"), 5: "Veneto", 6: tr("Friuli-Venezia Giulia"),
    7: "Liguria", 8: "Emilia-Romagna", 9: "Toscana", 10: "Umbria",
    11: "Marche", 12: "Lazio", 13: "Abruzzo", 14: "Molise", 15: "Campania",
    16: "Puglia", 17: "Basilicata", 18: "Calabria", 19: "Sicilia",
    20: "Sardegna",
}

# campi di base di ogni sezione (dalle basi territoriali)
BASE_FIELDS = ["SEZ21_ID", "PRO_COM", "SEZ21", "TIPO_LOC", "POP21", "FAM21",
               "ABI21", "EDI21", "AREA_M2"]
BASE_LABELS = {
    "SEZ21_ID": tr("Codice della sezione di censimento 2021"),
    "PRO_COM": tr("Codice ISTAT del comune"),
    "COMUNE": tr("Comune"),
    "SEZ21": tr("Numero della sezione nel comune"),
    "TIPO_LOC": tr("Tipo di località (1 centro abitato, 2 nucleo abitato, "
                "3 località produttiva, 4 case sparse)"),
    "POP21": tr("Popolazione residente"),
    "FAM21": tr("Famiglie residenti"),
    "ABI21": tr("Abitazioni"),
    "EDI21": tr("Edifici residenziali"),
    "AREA_HA": tr("Superficie (ettari)"),
    "QUOTA": tr("Quota della sezione dentro l'area (0-1)"),
}

_AGES = [tr("meno di 5 anni"), "5-9 anni", "10-14 anni", "15-19 anni",
         "20-24 anni", "25-29 anni", "30-34 anni", "35-39 anni",
         "40-44 anni", "45-49 anni", "50-54 anni", "55-59 anni",
         "60-64 anni", "65-69 anni", "70-74 anni", tr("75 anni e più")]
_TITOLI = [tr("senza titolo di studio"), tr("licenza elementare"), tr("licenza media"),
           tr("diploma di scuola superiore o qualifica professionale"),
           tr("titolo terziario (laurea, dottorato)")]
_AGE3 = ["0-14 anni", "15-64 anni", tr("65 anni e più")]


def _variables():
    """[(codice, descrizione, gruppo)] degli indicatori per sezione, nello
    stesso ordine del tracciato ISTAT."""
    out = [("P1", tr("Popolazione residente"), tr("Popolazione")),
           ("P2", tr("Maschi"), tr("Popolazione")),
           ("P3", tr("Femmine"), tr("Popolazione"))]
    for k, a in enumerate(_AGES):
        out.append(("P%d" % (14 + k), tr("Età: ") + a, tr("Età")))
    for k, a in enumerate(_AGES):
        out.append(("P%d" % (30 + k), tr("Maschi: ") + a, tr("Età, maschi")))
    for k, a in enumerate(_AGES):
        out.append(("P%d" % (67 + k), tr("Femmine: ") + a, tr("Età, femmine")))
    out += [("P83", tr("Popolazione di 9 anni e più"), tr("Istruzione")),
            ("P84", tr("Maschi di 9 anni e più"), tr("Istruzione")),
            ("P85", tr("Femmine di 9 anni e più"), tr("Istruzione"))]
    for base, who in ((86, tr("9 anni e più")), (91, tr("maschi di 9 anni e più")),
                      (96, tr("femmine di 9 anni e più"))):
        for k, t in enumerate(_TITOLI):
            out.append(("P%d" % (base + k), "%s (%s)" % (
                t[0].upper() + t[1:], who), tr("Istruzione")))
    out += [("P101", tr("Occupati di 15-64 anni"), tr("Lavoro")),
            ("P102", tr("Occupati maschi di 15-64 anni"), tr("Lavoro")),
            ("P103", tr("Occupate femmine di 15-64 anni"), tr("Lavoro"))]
    for base, who in ((1, tr("Italiani")), (4, tr("Italiani maschi")),
                      (7, tr("Italiane femmine"))):
        for k, a in enumerate(_AGE3):
            out.append(("IT%d" % (base + k), "%s: %s" % (who, a), tr("Italiani")))
    out += [("IT10", tr("Italiani occupati di 15-64 anni"), tr("Italiani")),
            ("IT11", tr("Italiani maschi occupati di 15-64 anni"), tr("Italiani")),
            ("IT12", tr("Italiane femmine occupate di 15-64 anni"), tr("Italiani")),
            ("ST1", tr("Stranieri e apolidi"), tr("Stranieri")),
            ("ST2", tr("Stranieri maschi"), tr("Stranieri")),
            ("ST2_B", tr("Straniere femmine"), tr("Stranieri")),
            ("ST3", tr("Stranieri: 0-29 anni"), tr("Stranieri")),
            ("ST4", tr("Stranieri: 30-54 anni"), tr("Stranieri")),
            ("ST5", tr("Stranieri: 55 anni e più"), tr("Stranieri")),
            ("ST16", tr("Stranieri di paesi UE"), tr("Stranieri")),
            ("ST17", tr("Stranieri maschi di paesi UE"), tr("Stranieri")),
            ("ST18", tr("Straniere femmine di paesi UE"), tr("Stranieri")),
            ("ST19", tr("Stranieri di paesi extra UE"), tr("Stranieri")),
            ("ST20", tr("Stranieri maschi di paesi extra UE"), tr("Stranieri")),
            ("ST21", tr("Straniere femmine di paesi extra UE"), tr("Stranieri"))]
    for base, who in ((22, tr("Stranieri")), (25, tr("Stranieri maschi")),
                      (28, tr("Straniere femmine"))):
        for k, a in enumerate(_AGE3):
            out.append(("ST%d" % (base + k), "%s: %s" % (who, a),
                        tr("Stranieri")))
    out += [("ST31", tr("Stranieri occupati di 15-64 anni"), tr("Stranieri")),
            ("ST32", tr("Stranieri maschi occupati di 15-64 anni"), tr("Stranieri")),
            ("ST33", tr("Straniere femmine occupate di 15-64 anni"),
             tr("Stranieri")),
            ("PF1", tr("Famiglie residenti"), tr("Famiglie")),
            ("PF3", tr("Famiglie di 1 componente"), tr("Famiglie")),
            ("PF4", tr("Famiglie di 2 componenti"), tr("Famiglie")),
            ("PF5", tr("Famiglie di 3 componenti"), tr("Famiglie")),
            ("PF6", tr("Famiglie di 4 componenti"), tr("Famiglie")),
            ("PF7", tr("Famiglie di 5 componenti"), tr("Famiglie")),
            ("PF8", tr("Famiglie di 6 o più componenti"), tr("Famiglie")),
            ("A2", tr("Abitazioni occupate da almeno un residente"),
             tr("Abitazioni ed edifici")),
            ("A3", tr("Abitazioni vuote o occupate solo da non residenti"),
             tr("Abitazioni ed edifici")),
            ("A8", tr("Abitazioni totali"), tr("Abitazioni ed edifici")),
            ("E3", tr("Edifici a uso residenziale"), tr("Abitazioni ed edifici"))]
    return out


VARIABLES = _variables()
VAR_LABEL = {c: d for c, d, _g in VARIABLES}

_YOUNG = ("P14", "P15", "P16")
_ADULT = tuple("P%d" % k for k in range(17, 27))
_OLD = ("P27", "P28", "P29")


def _ratio(num, den, k=1.0):
    return k * num / den if den and den > 0 else None


def _sum(v, codes):
    return sum(v[c] for c in codes)


# indicatori derivati: (campo, descrizione, codici che servono, formula su
# un dizionario codice → valore). Valgono per una sezione e per un totale.
DERIVED = [
    ("DENS_HA", tr("Densità (abitanti per ettaro)"), ("POP21", "AREA_M2"),
     lambda v: _ratio(v["POP21"], v["AREA_M2"], 1e4)),
    ("COMP_FAM", tr("Componenti per famiglia"), ("POP21", "FAM21"),
     lambda v: _ratio(v["POP21"], v["FAM21"])),
    ("PCT_0_14", "0-14 anni (%)", ("P1",) + _YOUNG,
     lambda v: _ratio(_sum(v, _YOUNG), v["P1"], 100.0)),
    ("PCT_65P", tr("65 anni e più (%)"), ("P1",) + _OLD,
     lambda v: _ratio(_sum(v, _OLD), v["P1"], 100.0)),
    ("IND_VECCH", tr("Indice di vecchiaia (65 e più ogni 100 di 0-14 anni)"),
     _YOUNG + _OLD,
     lambda v: _ratio(_sum(v, _OLD), _sum(v, _YOUNG), 100.0)),
    ("PCT_STRAN", "Stranieri (%)", ("P1", "ST1"),
     lambda v: _ratio(v["ST1"], v["P1"], 100.0)),
    ("PCT_LAUREA", tr("Con titolo terziario (% di 9 anni e più)"),
     ("P83", "P90"), lambda v: _ratio(v["P90"], v["P83"], 100.0)),
    ("TASSO_OCC", tr("Tasso di occupazione 15-64 anni (%)"),
     ("P101",) + _ADULT,
     lambda v: _ratio(v["P101"], _sum(v, _ADULT), 100.0)),
    ("PCT_ABI_NR", tr("Abitazioni non occupate da residenti (%)"),
     ("A3", "A8"), lambda v: _ratio(v["A3"], v["A8"], 100.0)),
]
DERIVED_LABEL = {k: d for k, d, _n, _f in DERIVED}

# temi della mappa: (chiave, voce, campo, decimali, colore chiaro, scuro)
THEMES = [
    ("dens", tr("Densità (abitanti per ettaro)"), "DENS_HA", 0,
     "#eef2ff", "#3730a3"),
    ("pop", tr("Abitanti per sezione"), "POP21", 0, "#eef2ff", "#3730a3"),
    ("fam", tr("Componenti per famiglia"), "COMP_FAM", 2, "#ecfeff", "#155e75"),
    ("p014", "0-14 anni (%)", "PCT_0_14", 1, "#f0fdf4", "#166534"),
    ("p65", tr("65 anni e più (%)"), "PCT_65P", 1, "#fff7ed", "#9a3412"),
    ("vecchiaia", tr("Indice di vecchiaia"), "IND_VECCH", 0,
     "#fff7ed", "#9a3412"),
    ("stran", "Stranieri (%)", "PCT_STRAN", 1, "#fdf4ff", "#86198f"),
    ("laurea", tr("Con titolo terziario (%)"), "PCT_LAUREA", 1,
     "#eff6ff", "#1e40af"),
    ("occ", tr("Tasso di occupazione 15-64 (%)"), "TASSO_OCC", 1,
     "#f0fdfa", "#115e59"),
    ("abi", tr("Abitazioni non occupate da residenti (%)"), "PCT_ABI_NR", 1,
     "#fefce8", "#854d0e"),
]


class Cancelled(Exception):
    """L'utente ha annullato."""


class _NoRange(Exception):
    """Il server non accetta richieste a intervalli."""


# ---------------------------------------------------------------- cache
_CACHE_DIR = None


def set_cache_dir(path):
    """Cartella della cache diversa da quella del profilo (strumenti,
    prove)."""
    global _CACHE_DIR
    _CACHE_DIR = path


def cache_dir():
    d = _CACHE_DIR
    if not d:
        try:
            from qgis.core import QgsApplication
            base = QgsApplication.qgisSettingsDirPath()
        except Exception:
            import tempfile
            base = tempfile.gettempdir()
        d = os.path.join(base, "MIC-Utilities", "istat")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def gpkg_path(code):
    return os.path.join(cache_dir(), "istat%d_R%02d_v%d.gpkg" % (
        EDITION, code, SCHEMA))


def _meta_path(code):
    return gpkg_path(code)[:-5] + ".json"


def region_state(code):
    """Metadati della regione in cache (dict) o None se non c'è."""
    p, m = gpkg_path(code), _meta_path(code)
    if not (os.path.exists(p) and os.path.exists(m)):
        return None
    try:
        with open(m, encoding="utf-8") as fh:
            meta = json.load(fh)
    except Exception:
        return None
    meta["size"] = os.path.getsize(p)
    return meta


def _write_meta(code, meta):
    with open(_meta_path(code), "w", encoding="utf-8") as fh:
        json.dump({k: v for k, v in meta.items() if k != "size"}, fh)


def cache_info():
    """[(codice, regione, metadati)] delle regioni in cache."""
    out = []
    for code in sorted(REGIONS):
        st = region_state(code)
        if st:
            out.append((code, REGIONS[code], st))
    return out


def clear_cache():
    """Cancella i dati ISTAT scaricati; ritorna i byte liberati."""
    d = cache_dir()
    freed = 0
    for fn in os.listdir(d):
        p = os.path.join(d, fn)
        try:
            if os.path.isdir(p):
                if fn.startswith("tmp_R"):
                    shutil.rmtree(p, ignore_errors=True)
                continue
            if re.match(r"^(istat\d{4}_R\d\d_v\d+(_build)?\.(gpkg|json)"
                        r"|R\d\d_21\.zip|R\d\d_indicatori\.xlsx"
                        r"|pendolarismo\d{4}_(lavoro|studio)\.zip"
                        r"|addetti\d{4}_R\d\d_v\d+(_build)?\.(gpkg|json)"
                        r"|sce2011\.zip|R\d\d_11_WGS84\.zip"
                        r"|asia_ul_\d{4}\.csv|ip_ul_\d{4}\.csv"
                        r"|R_indicatori_tutti\.zip)(\.part)?$", fn):
                size = os.path.getsize(p)
                os.remove(p)
                freed += size
        except Exception:
            pass
    return freed


# -------------------------------------------------------------- comuni
_COMUNI = None
_COMUNI_IDX = None


def _comuni_path():
    return os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "data", "istat_comuni_2021.csv")


def comuni():
    """Comuni del censimento 2021: lista di dict con pro_com, nome,
    provincia, reg (codice regione), bbox (W, S, E, N in WGS84), pop, lon e
    lat (baricentro dei residenti; centro del riquadro se manca)."""
    global _COMUNI
    if _COMUNI is None:
        out = []
        try:
            with open(_comuni_path(), encoding="utf-8", newline="") as fh:
                for r in csv.DictReader(fh, delimiter=";"):
                    box = (float(r["W"]), float(r["S"]), float(r["E"]),
                           float(r["N"]))
                    try:
                        lon, lat = float(r["LON"]), float(r["LAT"])
                    except (KeyError, TypeError, ValueError):
                        lon = (box[0] + box[2]) / 2.0
                        lat = (box[1] + box[3]) / 2.0
                    out.append({
                        "pro_com": int(r["PRO_COM"]), "nome": r["COMUNE"],
                        "provincia": r["PROVINCIA"], "reg": int(r["COD_REG"]),
                        "bbox": box, "pop": int(r["POP21"] or 0),
                        "lon": lon, "lat": lat})
        except Exception:
            out = []
        _COMUNI = out
    return _COMUNI


def _comuni_index():
    global _COMUNI_IDX
    if _COMUNI_IDX is None:
        _COMUNI_IDX = {c["pro_com"]: c for c in comuni()}
    return _COMUNI_IDX


def comune_label(c):
    return "%s (%s)" % (c["nome"], c["provincia"])


def find_comune(text):
    """Il comune scritto come «Nome (Provincia)» o col solo nome, se non è
    ambiguo. Ritorna (comune o None, messaggio di errore)."""
    t = " ".join((text or "").split()).lower()
    if not t:
        return None, tr("Scrivi il nome del comune.")
    rows = comuni()
    if not rows:
        return None, tr("Elenco dei comuni non disponibile.")
    for c in rows:
        if comune_label(c).lower() == t:
            return c, ""
    same = [c for c in rows if c["nome"].lower() == t]
    if not same:
        # bilingui: «Bolzano/Bozen» si trova anche scrivendo «Bolzano»
        same = [c for c in rows
                if t in [p.strip() for p in c["nome"].lower().split("/")]]
    if len(same) == 1:
        return same[0], ""
    if len(same) > 1:
        return None, tr("Ci sono più comuni «%s»: scegli dall'elenco (%s).") % (
            text.strip(), ", ".join(comune_label(c) for c in same[:4]))
    return None, tr("Comune «%s» non trovato: scegli dall'elenco.") % text.strip()


def comune_bbox(pro_com):
    """Riquadro (W, S, E, N) in WGS84 del comune, o None."""
    c = _comuni_index().get(int(pro_com))
    return c["bbox"] if c else None


def regions_for_bbox(w, s, e, n):
    """Codici delle regioni i cui comuni toccano il riquadro WGS84 (vuoto
    se il riquadro è fuori dall'Italia)."""
    out = set()
    for c in comuni():
        cw, cs, ce, cn = c["bbox"]
        if cw <= e and ce >= w and cs <= n and cn >= s:
            out.add(c["reg"])
    return sorted(out)


# ------------------------------------------------------------- download
def _check(is_canceled):
    if is_canceled and is_canceled():
        raise Cancelled()


def _span(progress, p0, p1):
    """Funzione frazione (0-1) → avanzamento fra p0 e p1."""
    def step(frac):
        if progress:
            progress(p0 + (p1 - p0) * max(0.0, min(1.0, frac)))
    return step


def _remove(path):
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            pass


def _open(url, byte_range=None, site="ISTAT"):
    """Risposta HTTP aperta (da chiudere). Si usa urllib e non requests:
    con la libreria urllib3 distribuita in alcune versioni di QGIS la
    connessione sicura a www.istat.it fallisce, con urllib no. `site` è il
    nome dell'ente nei messaggi d'errore (ISTAT, INEGI…)."""
    import urllib.error
    import urllib.request
    h = dict(HEADERS)
    if byte_range:
        h["Range"] = byte_range
    try:
        return urllib.request.urlopen(
            urllib.request.Request(url, headers=h), timeout=60)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(tr("il sito dell'%s ha risposto con l'errore %s")
                           % (site, exc.code))
    except (urllib.error.URLError, OSError) as exc:
        raise RuntimeError(tr("il sito dell'%s non risponde (%s): controlla "
                           "la connessione e riprova")
                           % (site, getattr(exc, "reason", exc)))


def _chunks(resp, is_canceled, size=1 << 18, site="ISTAT"):
    while True:
        _check(is_canceled)
        try:
            chunk = resp.read(size)
        except OSError as exc:
            raise RuntimeError(tr("download dall'%s interrotto (%s): "
                               "riprova") % (site, exc))
        if not chunk:
            return
        yield chunk


def _download(url, path, step, is_canceled, site="ISTAT"):
    """Scarica url in path (a pezzi, con avanzamento e annullamento)."""
    part = path + ".part"
    resp = _open(url, site=site)
    try:
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        with open(part, "wb") as fh:
            for chunk in _chunks(resp, is_canceled, site=site):
                fh.write(chunk)
                done += len(chunk)
                if total:
                    step(done / float(total))
        if total and done != total:
            raise RuntimeError(tr("download dall'%s incompleto: riprova") % site)
        os.replace(part, path)
    finally:
        resp.close()
        _remove(part)


def _range(url, first=None, last=None, tail=None, site="ISTAT"):
    resp = _open(url, ("bytes=-%d" % tail) if tail else (
        "bytes=%d-%d" % (first, last)), site=site)
    if getattr(resp, "status", resp.getcode()) != 206:
        resp.close()
        raise _NoRange()
    return resp


def _zip_directory(url, site="ISTAT"):
    """Indice di uno zip remoto letto dagli ultimi byte:
    {nome: (offset, compresso, espanso, metodo, crc)}."""
    resp = _range(url, tail=1 << 16, site=site)
    try:
        data = resp.read()
        total = int(resp.headers["Content-Range"].split("/")[1])
    except (KeyError, ValueError, IndexError):
        raise _NoRange()
    finally:
        resp.close()
    base = total - len(data)
    i = data.rfind(b"PK\x05\x06")
    if i < 0:
        raise _NoRange()
    n_tot, _size, cd_off = struct.unpack("<HII", data[i + 10:i + 20])
    p = cd_off - base
    if p < 0 or cd_off == 0xFFFFFFFF:
        raise _NoRange()
    out = {}
    for _k in range(n_tot):
        (sig, _vm, _vn, flag, comp, _mt, _md, crc, csz, usz, nl, el, cl,
         _dn, _ia, _ea, off) = struct.unpack("<IHHHHHHIIIHHHHHII",
                                             data[p:p + 46])
        if sig != 0x02014b50:
            break
        name = data[p + 46:p + 46 + nl].decode(
            "utf-8" if flag & 0x800 else "cp437", "replace")
        out[name] = (off, csz, usz, comp, crc)
        p += 46 + nl + el + cl
    return out


def _fetch_member(url, entry, path, step, is_canceled, site="ISTAT"):
    """Scarica ed espande un solo file di uno zip remoto."""
    off, csz, usz, comp, crc = entry
    if comp not in (0, 8) or 0xFFFFFFFF in (off, csz, usz):
        raise _NoRange()
    resp = _range(url, off, off + 29, site=site)
    try:
        head = resp.read()
    finally:
        resp.close()
    nl, el = struct.unpack("<HH", head[26:30])
    start = off + 30 + nl + el
    resp = _range(url, start, start + csz - 1, site=site)
    part = path + ".part"
    try:
        dec = zlib.decompressobj(-15)
        check = size = got = 0
        with open(part, "wb") as fh:
            for chunk in _chunks(resp, is_canceled, site=site):
                got += len(chunk)
                raw = dec.decompress(chunk) if comp == 8 else chunk
                check = zlib.crc32(raw, check)
                size += len(raw)
                fh.write(raw)
                step(got / float(csz or 1))
            raw = dec.flush() if comp == 8 else b""
            check = zlib.crc32(raw, check)
            size += len(raw)
            fh.write(raw)
        if size != usz or (check & 0xFFFFFFFF) != crc:
            raise RuntimeError(tr("download incompleto o danneggiato: riprova"))
        os.replace(part, path)
    except zlib.error:
        raise RuntimeError(tr("download incompleto o danneggiato: riprova"))
    finally:
        resp.close()
        _remove(part)


def _fetch_indicators_file(code, path, step, is_canceled):
    """Il file degli indicatori della regione: dall'archivio nazionale
    (254 MB) si scarica solo quel file; se il server non lo permette si
    scarica tutto l'archivio e si estrae."""
    member = IND_MEMBER % code
    try:
        entry = _zip_directory(IND_URL).get(member)
        if entry is None:
            raise RuntimeError(tr("indicatori della regione non trovati "
                               "nell'archivio ISTAT"))
        _fetch_member(IND_URL, entry, path, step, is_canceled)
        return
    except _NoRange:
        pass
    whole = os.path.join(cache_dir(), "R_indicatori_tutti.zip")
    try:
        _download(IND_URL, whole, step, is_canceled)
        with zipfile.ZipFile(whole) as z:
            with z.open(member) as src, open(path, "wb") as dst:
                shutil.copyfileobj(src, dst)
    finally:
        _remove(whole)


# ------------------------------------------------ basi territoriali → gpkg
def _extract_base(zpath, tmp):
    """Estrae lo shapefile delle sezioni e la tabella SEZ; ritorna
    (percorso .shp, percorso .csv)."""
    shp = tab = None
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            name = os.path.basename(info.filename)
            low = name.lower()
            if not (re.match(r"^r\d\d_21\w*\.(shp|shx|dbf|prj|cpg)$", low)
                    or re.match(r"^sez_r\d\d_21\.csv$", low)):
                continue
            out = os.path.join(tmp, name)
            with z.open(info) as src, open(out, "wb") as dst:
                shutil.copyfileobj(src, dst)
            if low.endswith(".shp"):
                shp = out
            elif low.endswith(".csv"):
                tab = out
    if not shp or not tab:
        raise RuntimeError(tr("archivio ISTAT con una struttura inattesa "
                           "(mancano le sezioni o la tabella SEZ)"))
    return shp, tab


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def _read_sez_table(path):
    """{SEZ21_ID: (POP21, FAM21, ABI21, EDI21)} dalla tabella SEZ (testo
    UTF-16 separato da tabulazioni)."""
    with open(path, "rb") as fh:
        raw = fh.read()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        txt = raw.decode("utf-16")
    elif raw[:3] == b"\xef\xbb\xbf":
        txt = raw.decode("utf-8-sig")
    else:
        try:
            txt = raw.decode("utf-8")
        except UnicodeDecodeError:
            txt = raw.decode("cp1252", "replace")
    first = txt.split("\n", 1)[0]
    delim = "\t" if "\t" in first else (";" if ";" in first else ",")
    rd = csv.reader(io.StringIO(txt), delimiter=delim)
    head = [h.strip().upper() for h in next(rd)]
    try:
        cols = [head.index(k) for k in ("SEZ21_ID", "POP21", "FAM21",
                                        "ABI21", "EDI21")]
    except ValueError:
        raise RuntimeError(tr("tabella SEZ dell'ISTAT con colonne inattese"))
    top = max(cols)
    out = {}
    for r in rd:
        if len(r) <= top or not r[cols[0]].strip():
            continue
        out[_int(r[cols[0]])] = tuple(_int(r[c]) for c in cols[1:])
    return out


def _multipolygon(g):
    """Le sole parti poligonali di g come MultiPolygon (None se non ce ne
    sono)."""
    from osgeo import ogr
    out = ogr.Geometry(ogr.wkbMultiPolygon)

    def add(x):
        t = ogr.GT_Flatten(x.GetGeometryType())
        if t == ogr.wkbPolygon:
            out.AddGeometry(x)
        elif t in (ogr.wkbMultiPolygon, ogr.wkbGeometryCollection):
            for k in range(x.GetGeometryCount()):
                add(x.GetGeometryRef(k))
    add(g)
    return out if out.GetGeometryCount() else None


def _build_gpkg(shp, table, out, step, is_canceled):
    """Sezioni + popolazione in un GeoPackage (layer «sezioni», con indice
    spaziale). Ritorna i metadati."""
    from osgeo import gdal, ogr
    src = ogr.Open(shp)
    if src is None:
        raise RuntimeError(tr("le sezioni scaricate non si aprono"))
    sl = src.GetLayer(0)
    sd = sl.GetLayerDefn()
    names = {sd.GetFieldDefn(i).GetName().upper(): i
             for i in range(sd.GetFieldCount())}
    if "SEZ21_ID" not in names:
        raise RuntimeError(tr("sezioni ISTAT senza il campo SEZ21_ID"))
    _remove(out)
    dst = ogr.GetDriverByName("GPKG").CreateDataSource(out)
    if dst is None:
        raise RuntimeError(tr("impossibile scrivere nella cache: %s") % out)
    dl = dst.CreateLayer("sezioni", sl.GetSpatialRef(), ogr.wkbMultiPolygon)
    for name in BASE_FIELDS:
        kind = (ogr.OFTReal if name == "AREA_M2" else
                ogr.OFTInteger64 if name in ("SEZ21_ID", "SEZ21") else
                ogr.OFTInteger)
        dl.CreateField(ogr.FieldDefn(name, kind))
    dd = dl.GetLayerDefn()
    copy = [(k, names[k]) for k in ("PRO_COM", "SEZ21", "TIPO_LOC")
            if k in names]
    i_id = names["SEZ21_ID"]
    total = max(1, sl.GetFeatureCount())
    n = fixed = pop = 0
    dl.StartTransaction()
    # il controllo di validità scrive un avviso per ogni anello che si
    # interseca: qui si corregge e basta (il gestore vale per questo thread)
    gdal.PushErrorHandler("CPLQuietErrorHandler")
    try:
        for k, f in enumerate(sl):
            if k % 500 == 0:
                _check(is_canceled)
                step(k / float(total))
            g = f.GetGeometryRef()
            if g is None or g.IsEmpty():
                continue
            if not g.IsValid():
                g = g.MakeValid()
                fixed += 1
                if g is None:
                    continue
            g = _multipolygon(g)
            if g is None:
                continue
            sid = f.GetField(i_id)
            vals = table.get(sid, (0, 0, 0, 0))
            o = ogr.Feature(dd)
            o.SetGeometry(g)
            o.SetField("SEZ21_ID", sid)
            for name, i in copy:
                v = f.GetField(i)
                if v is not None:
                    o.SetField(name, v)
            for name, v in zip(("POP21", "FAM21", "ABI21", "EDI21"), vals):
                o.SetField(name, v)
            o.SetField("AREA_M2", g.GetArea())
            dl.CreateFeature(o)
            n += 1
            pop += vals[0]
        dl.CommitTransaction()
    except BaseException:
        dl.RollbackTransaction()
        dl = None
        dst = None
        src = None
        raise
    finally:
        gdal.PopErrorHandler()
    dst.ExecuteSQL("CREATE INDEX idx_sezioni_pro_com ON sezioni (PRO_COM)")
    dl = None
    dst = None
    src = None
    return {"sections": n, "pop": pop, "fixed": fixed}


# ----------------------------------------------------------- indicatori
_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _col_index(ref):
    n = 0
    for ch in ref:
        if "A" <= ch <= "Z":
            n = n * 26 + (ord(ch) - 64)
        else:
            break
    return n - 1


def _shared_strings(z):
    out = []
    if "xl/sharedStrings.xml" not in z.namelist():
        return out
    with z.open("xl/sharedStrings.xml") as fh:
        for _ev, el in ET.iterparse(fh):
            if el.tag == _NS + "si":
                out.append("".join(t.text or "" for t in el.iter(_NS + "t")))
                el.clear()
    return out


def _xlsx_rows(fh, strings):
    """Righe del primo foglio di un xlsx (lista di valori, None = vuoto),
    lette a flusso: il foglio del Lazio espanso pesa 170 MB."""
    tag_row, tag_v, tag_t = _NS + "row", _NS + "v", _NS + "t"
    for _ev, el in ET.iterparse(fh):
        if el.tag != tag_row:
            continue
        row = []
        for c in el:
            ref = c.get("r")
            if ref:
                i = _col_index(ref)
                while len(row) < i:
                    row.append(None)
            kind = c.get("t")
            v = c.find(tag_v)
            if kind == "s" and v is not None:
                val = strings[int(v.text)]
            elif kind == "inlineStr":
                val = "".join(x.text or "" for x in c.iter(tag_t))
            else:
                val = v.text if v is not None else None
            row.append(val)
        yield row
        el.clear()


_ID_COLUMNS = {"CODREG", "REGIONE", "CODPRO", "PROVINCIA", "CODCOM", "COMUNE",
               "PROCOM", "SEZ21_ID", "COM_ASC1", "COM_ASC2", "COM_ASC3"}


def _load_indicators(xlsx, gpkg, step, is_canceled):
    """Tabella «indicatori» (una riga per sezione) e «comuni» (nomi) nel
    GeoPackage della regione. Ritorna il numero di sezioni caricate."""
    with zipfile.ZipFile(xlsx) as z:
        strings = _shared_strings(z)
        sheets = sorted(n for n in z.namelist()
                        if re.match(r"^xl/worksheets/sheet\d+\.xml$", n))
        if not sheets:
            raise RuntimeError(tr("file degli indicatori ISTAT senza fogli"))
        size = float(z.getinfo(sheets[0]).file_size or 1)
        with z.open(sheets[0]) as fh:
            it = _xlsx_rows(fh, strings)
            head = [str(h or "").strip().upper() for h in next(it)]
            if "SEZ21_ID" not in head:
                raise RuntimeError(tr("file degli indicatori ISTAT con colonne "
                                   "inattese"))
            i_id = head.index("SEZ21_ID")
            cols = [(i, h) for i, h in enumerate(head)
                    if h not in _ID_COLUMNS and re.match(r"^[A-Z]\w*$", h)]
            i_com = [head.index(k) if k in head else None
                     for k in ("PROCOM", "COMUNE", "PROVINCIA")]
            names = {}
            count = [0]

            def rows():
                for k, r in enumerate(it):
                    if k % 400 == 0:
                        _check(is_canceled)
                        step(fh.tell() / size)
                    if len(r) <= i_id or r[i_id] in (None, ""):
                        continue
                    if i_com[0] is not None and len(r) > i_com[0]:
                        pc = _int(r[i_com[0]])
                        if pc not in names:
                            names[pc] = tuple(
                                (r[i] if i is not None and len(r) > i
                                 else "") or "" for i in i_com[1:])
                    count[0] += 1
                    yield [_int(r[i_id])] + [
                        _int(r[i]) if len(r) > i and r[i] not in (None, "")
                        else None for i, _h in cols]

            con = sqlite3.connect(gpkg, isolation_level=None)
            try:
                con.execute("BEGIN")
                con.execute("DROP TABLE IF EXISTS indicatori")
                con.execute("DROP TABLE IF EXISTS comuni")
                con.execute("CREATE TABLE indicatori (SEZ21_ID INTEGER "
                            "PRIMARY KEY, %s)" % ", ".join(
                                '"%s" INTEGER' % h for _i, h in cols))
                con.execute("CREATE TABLE comuni (PRO_COM INTEGER PRIMARY "
                            "KEY, COMUNE TEXT, PROVINCIA TEXT)")
                con.executemany(
                    "INSERT OR REPLACE INTO indicatori VALUES (%s)"
                    % ",".join("?" * (len(cols) + 1)), rows())
                con.executemany("INSERT OR REPLACE INTO comuni VALUES "
                                "(?,?,?)", [(k, v[0], v[1])
                                            for k, v in names.items()])
                for t, d in (("indicatori", tr("Indicatori per sezione")),
                             ("comuni", tr("Nomi dei comuni"))):
                    con.execute("DELETE FROM gpkg_contents WHERE "
                                "table_name = ?", (t,))
                    con.execute("INSERT INTO gpkg_contents (table_name, "
                                "data_type, identifier, description) VALUES "
                                "(?, 'attributes', ?, ?)", (t, t, d))
                con.execute("COMMIT")
            except BaseException:
                try:
                    con.execute("ROLLBACK")
                except Exception:
                    pass
                raise
            finally:
                con.close()
    return count[0]


def ensure_region(code, indicators=True, progress=None, is_canceled=None,
                  status=None):
    """Mette in cache la regione (se manca) e ritorna (percorso del
    GeoPackage, nota). La nota non è vuota se gli indicatori sono stati
    chiesti ma non si sono potuti scaricare: restano i dati di base.

    :raises Cancelled: annullato.
    """
    if code not in REGIONS:
        raise ValueError(tr("codice di regione non valido: %s") % code)
    path = gpkg_path(code)
    meta = region_state(code)
    need_ind = indicators and not (meta or {}).get("indicators")
    base_end = 100.0 if not need_ind else (55.0 if meta is None else 0.0)
    say = status or (lambda _t: None)
    if meta is None:
        say(tr("download delle sezioni di censimento di %s (solo la prima "
            "volta)") % REGIONS[code])
        d = cache_dir()
        zpath = os.path.join(d, "R%02d_21.zip" % code)
        tmp = os.path.join(d, "tmp_R%02d" % code)
        build = path[:-5] + "_build.gpkg"
        try:
            _download(BASE_URL % code, zpath,
                      _span(progress, 0, 0.45 * base_end), is_canceled)
            shutil.rmtree(tmp, ignore_errors=True)
            os.makedirs(tmp)
            say(tr("archivio delle sezioni di %s") % REGIONS[code])
            shp, tab = _extract_base(zpath, tmp)
            table = _read_sez_table(tab)
            meta = _build_gpkg(shp, table, build,
                               _span(progress, 0.5 * base_end, base_end),
                               is_canceled)
            _remove(path)
            os.replace(build, path)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
            for p in (zpath, build, build + "-journal"):
                _remove(p)
        meta.update({"code": code, "edition": EDITION, "indicators": False,
                     "ts": time.time()})
        _write_meta(code, meta)
    note = ""
    if need_ind:
        xlsx = os.path.join(cache_dir(), "R%02d_indicatori.xlsx" % code)
        mid = base_end + 0.4 * (100.0 - base_end)
        say(tr("download degli indicatori di %s (solo la prima volta)")
            % REGIONS[code])
        try:
            _fetch_indicators_file(code, xlsx,
                                   _span(progress, base_end, mid),
                                   is_canceled)
            say(tr("indicatori di %s nell'archivio") % REGIONS[code])
            n = _load_indicators(xlsx, path, _span(progress, mid, 100.0),
                                 is_canceled)
            meta.update({"indicators": True, "ind_sections": n})
            _write_meta(code, meta)
        except Cancelled:
            raise
        except Exception as exc:
            note = (tr("indicatori di %s non scaricati (%s): restano "
                    "popolazione, famiglie, abitazioni, edifici")
                    % (REGIONS[code], exc))
        finally:
            _remove(xlsx)
    if progress:
        progress(100)
    return path, note


# --------------------------------------------------------------- lettura
def _traditional(srs):
    try:
        from osgeo import osr
        srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    except Exception:
        pass
    return srs


def _transforms(layer_srs):
    from osgeo import osr
    wgs = osr.SpatialReference()
    wgs.ImportFromEPSG(4326)
    _traditional(wgs)
    loc = _traditional(layer_srs.Clone())
    return (osr.CoordinateTransformation(wgs, loc),
            osr.CoordinateTransformation(loc, wgs))


def read_sections(code, rect=None, wkt=None, pro_com=None, indicators=True,
                  wgs84=False, is_canceled=None):
    """Sezioni della regione in cache: tutte quelle del comune `pro_com`,
    o quelle che toccano il poligono `wkt` o il riquadro `rect` (W, S, E, N)
    in WGS84.

    :return: (campi, righe) con righe = [(geometria, quota, valori)]:
        geometria WKB in EPSG:32632 (o WKT in WGS84 con wgs84=True), quota
        = parte della sezione dentro l'area (1 per i comuni), valori
        nell'ordine dei campi (BASE_FIELDS + indicatori).
    """
    from osgeo import ogr
    ds = ogr.Open(gpkg_path(code))
    lay = ds.GetLayerByName("sezioni") if ds is not None else None
    if lay is None:
        raise RuntimeError(tr("dati ISTAT di %s non leggibili: svuota i dati "
                           "scaricati e riprova") % REGIONS.get(code, code))
    to_l, to_w = _transforms(lay.GetSpatialRef())
    area = None
    if pro_com is not None:
        codes = pro_com if isinstance(pro_com, (list, tuple, set)) \
            else [pro_com]
        lay.SetAttributeFilter("PRO_COM IN (%s)" % ",".join(
            str(int(c)) for c in codes))
    elif wkt:
        area = ogr.CreateGeometryFromWkt(wkt)
    elif rect:
        w, s, e, n = rect
        area = ogr.CreateGeometryFromWkt(
            "POLYGON((%r %r,%r %r,%r %r,%r %r,%r %r))" % (
                w, s, e, s, e, n, w, n, w, s))
    if area is not None:
        area.Segmentize(0.02)
        area.Transform(to_l)
        if not area.IsValid():
            area = area.MakeValid()
        lay.SetSpatialFilter(area)
    dd = lay.GetLayerDefn()
    idx = [dd.GetFieldIndex(k) for k in BASE_FIELDS]
    rows = []
    for k, f in enumerate(lay):
        if k % 500 == 0:
            _check(is_canceled)
        g = f.GetGeometryRef()
        if g is None:
            continue
        share = 1.0
        if area is not None:
            if not g.Intersects(area):
                continue
            a = g.GetArea()
            inter = g.Intersection(area)
            share = min(1.0, inter.GetArea() / a) if a > 0 and \
                inter is not None else 0.0
            if share <= 0:
                continue
        vals = [f.GetField(i) if i >= 0 else None for i in idx]
        if wgs84:
            g = g.Clone()
            g.Transform(to_w)
            geom = g.ExportToWkt()
        else:
            geom = bytes(g.ExportToWkb())
        rows.append((geom, share, vals))
    lay = None
    ds = None
    fields = list(BASE_FIELDS)
    if indicators and rows:
        ind_fields, table = _read_indicators(code, [r[2][0] for r in rows])
        if ind_fields:
            fields += ind_fields
            zero = [0] * len(ind_fields)
            rows = [(g, q, v + list(table.get(v[0], zero)))
                    for g, q, v in rows]
    return fields, rows


def _read_indicators(code, ids):
    """(campi, {SEZ21_ID: valori}) dalla tabella degli indicatori; ([], {})
    se la regione non li ha."""
    con = sqlite3.connect(gpkg_path(code))
    try:
        cols = [r[1] for r in con.execute("PRAGMA table_info(indicatori)")]
        if len(cols) < 2:
            return [], {}
        out = {}
        for k in range(0, len(ids), 500):
            chunk = ids[k:k + 500]
            for r in con.execute(
                    "SELECT * FROM indicatori WHERE SEZ21_ID IN (%s)"
                    % ",".join("?" * len(chunk)), chunk):
                out[r[0]] = [0 if v is None else v for v in r[1:]]
        return cols[1:], out
    finally:
        con.close()


def points_of(data):
    """Un punto dentro ogni sezione letta: [(lat, lon)] nell'ordine delle
    righe di `data` (geometrie WKB in EPSG:32632, cioè senza wgs84=True)."""
    from osgeo import ogr, osr
    loc = osr.SpatialReference()
    loc.ImportFromEPSG(EPSG)
    _to_l, to_w = _transforms(loc)
    out = []
    for wkb, _q, _v in data["rows"]:
        g = ogr.CreateGeometryFromWkb(wkb)
        pt = g.PointOnSurface() if g is not None else None
        if pt is None or pt.IsEmpty():
            pt = g.Centroid()
        x, y, _z = to_w.TransformPoint(pt.GetX(), pt.GetY())
        out.append((y, x))
    return out


def _bbox_of_wkt(wkt):
    from osgeo import ogr
    g = ogr.CreateGeometryFromWkt(wkt)
    if g is None or g.IsEmpty():
        raise ValueError(tr("area non valida"))
    w, e, s, n = g.GetEnvelope()
    return w, s, e, n


def fetch(rect=None, wkt=None, pro_com=None, indicators=True, wgs84=False,
          progress=None, is_canceled=None, status=None):
    """Scarica le regioni che servono (se non sono in cache) e legge le
    sezioni del comune o dell'area.

    :return: dict con fields, rows (vedi `read_sections`), regions (codici
        usati; vuoto se l'area è fuori dall'Italia), notes (avvisi), cached
        (True se non si è scaricato nulla); None se annullato.
    """
    if pro_com is not None:
        c = _comuni_index().get(int(pro_com))
        if c is None:
            raise ValueError(tr("comune %s sconosciuto") % pro_com)
        regions = [c["reg"]]
    else:
        box = _bbox_of_wkt(wkt) if wkt else rect
        if box is None:
            raise ValueError(tr("indica un comune o un'area"))
        regions = regions_for_bbox(*box)
    out = {"fields": list(BASE_FIELDS), "rows": [], "regions": regions,
           "notes": [], "cached": True}
    try:
        for k, code in enumerate(regions):
            st = region_state(code)
            if st is None or (indicators and not st.get("indicators")):
                out["cached"] = False
            sub = _span(progress, 100.0 * k / len(regions),
                        100.0 * (k + 0.95) / len(regions))
            _path, note = ensure_region(
                code, indicators, lambda p, f=sub: f(p / 100.0), is_canceled,
                status)
            if note:
                out["notes"].append(note)
            if status:
                status(tr("lettura delle sezioni di %s") % REGIONS[code])
            fields, rows = read_sections(code, rect, wkt, pro_com,
                                         indicators, wgs84, is_canceled)
            if len(fields) > len(out["fields"]):
                # una regione senza indicatori non deve togliere le colonne
                # alle altre: le sue righe si completano con zeri
                pad = len(fields) - len(out["fields"])
                out["rows"] = [(g, q, v + [0] * pad)
                               for g, q, v in out["rows"]]
                out["fields"] = fields
            elif len(fields) < len(out["fields"]):
                pad = len(out["fields"]) - len(fields)
                rows = [(g, q, v + [0] * pad) for g, q, v in rows]
            out["rows"] += rows
    except Cancelled:
        return None
    if progress:
        progress(100)
    return out


def population(rect, progress=None, is_canceled=None):
    """Popolazione per sezione nel riquadro (W, S, E, N in WGS84), per il
    report d'area: ([(wkt WGS84, abitanti)], dati) dove dati è il risultato
    di `fetch`; None se annullato. Lista vuota se l'area è fuori
    dall'Italia."""
    data = fetch(rect=rect, indicators=False, wgs84=True, progress=progress,
                 is_canceled=is_canceled)
    if data is None:
        return None
    i = data["fields"].index("POP21")
    return ([(g, float(v[i])) for g, _q, v in data["rows"]
             if v[i] and v[i] > 0], data)


# -------------------------------------------------------------- riepilogo
def totals(data):
    """Somme dei campi sulle sezioni lette, pesate con la quota di ogni
    sezione dentro l'area (ripartizione per superficie): dict campo →
    totale, più «_sections» e «_inhabited»."""
    fields = data["fields"]
    skip = {fields.index(k) for k in ("SEZ21_ID", "PRO_COM", "SEZ21",
                                      "TIPO_LOC") if k in fields}
    tot = [0.0] * len(fields)
    i_pop = fields.index("POP21")
    inhabited = 0
    for _g, q, v in data["rows"]:
        for i, x in enumerate(v):
            if x and i not in skip:
                tot[i] += q * x
        if v[i_pop]:
            inhabited += 1
    out = {f: t for i, (f, t) in enumerate(zip(fields, tot))
           if i not in skip}
    out["_sections"] = len(data["rows"])
    out["_inhabited"] = inhabited
    return out


def derive(values):
    """Indicatori derivati da un dizionario campo → valore (di una sezione
    o di un totale): {campo: valore o None}. Quelli che richiedono
    indicatori non scaricati sono assenti."""
    out = {}
    for key, _d, needs, fn in DERIVED:
        if all(k in values for k in needs):
            try:
                out[key] = fn(values)
            except (TypeError, ZeroDivisionError):
                out[key] = None
    return out


def fmt(v, dec=0):
    """Numero come nel report, nella lingua scelta: 1.234,5 in italiano,
    1,234.5 in inglese; «–» se manca."""
    return num(v, dec)


def summary(data):
    """Riepilogo leggibile delle sezioni lette: [(voce, valore)]."""
    t = totals(data)
    d = derive(t)
    rows = [(tr("Sezioni di censimento"), tr("%s (%s con residenti)") % (
        fmt(t["_sections"]), fmt(t["_inhabited"]))),
        (tr("Popolazione residente"), fmt(t["POP21"])),
        (tr("Famiglie"), fmt(t["FAM21"])),
        (tr("Abitazioni"), fmt(t["ABI21"])),
        (tr("Edifici residenziali"), fmt(t["EDI21"])),
        (tr("Superficie"), tr("%s km²") % fmt(t["AREA_M2"] / 1e6, 2)),
        (tr("Densità"), tr("%s ab./km²") % fmt(
            _ratio(t["POP21"], t["AREA_M2"], 1e6), 0)),
        (tr("Componenti per famiglia"), fmt(d.get("COMP_FAM"), 2))]
    if "P1" in t:
        rows += [
            ("0-14 anni", "%s %%" % fmt(d.get("PCT_0_14"), 1)),
            ("15-64 anni", "%s %%" % fmt(
                _ratio(_sum(t, _ADULT), t["P1"], 100.0), 1)),
            (tr("65 anni e più"), "%s %%" % fmt(d.get("PCT_65P"), 1)),
            (tr("Indice di vecchiaia"), fmt(d.get("IND_VECCH"), 0)),
            (tr("Stranieri"), "%s %% (%s)" % (fmt(d.get("PCT_STRAN"), 1),
                                         fmt(t["ST1"]))),
            (tr("Con titolo terziario"), tr("%s %% di 9 anni e più")
             % fmt(d.get("PCT_LAUREA"), 1)),
            (tr("Tasso di occupazione 15-64"), "%s %%"
             % fmt(d.get("TASSO_OCC"), 1)),
            (tr("Abitazioni non occupate da residenti"), "%s %%"
             % fmt(d.get("PCT_ABI_NR"), 1))]
    return rows


# ------------------------------------------------- profilo per il report
_MALES_1564 = tuple("P%d" % k for k in range(33, 43))
_FEMALES_1564 = tuple("P%d" % k for k in range(70, 80))
EDUCATION = [("P86", tr("Nessun titolo")), ("P87", tr("Elementare")),
             ("P88", tr("Media")), ("P89", tr("Diploma")), ("P90", tr("Terziario"))]
FAMILIES = [("PF3", "1 componente"), ("PF4", "2 componenti"),
            ("PF5", "3 componenti"), ("PF6", "4 componenti"),
            ("PF7", "5 componenti"), ("PF8", tr("6 o più"))]
# indicatori del confronto area / comune: (chiave, voce, unità, decimali)
COMPARE = [("density", tr("Densità"), "ab./km²", 0),
           ("COMP_FAM", tr("Componenti per famiglia"), "", 2),
           ("PCT_0_14", "0-14 anni", "%", 1),
           ("PCT_65P", tr("65 anni e più"), "%", 1),
           ("IND_VECCH", tr("Indice di vecchiaia"), "", 0),
           ("PCT_STRAN", tr("Stranieri"), "%", 1),
           ("PCT_LAUREA", tr("Titolo terziario"), "%", 1),
           ("TASSO_OCC", tr("Occupati 15-64 anni"), "%", 1),
           ("PCT_ABI_NR", tr("Abitazioni senza residenti"), "%", 1)]


def comune_totals(pro_com):
    """Totali di tutto il comune dalla regione in cache: dizionario come
    quello di `totals` (i campi degli indicatori solo se scaricati)."""
    c = _comuni_index().get(int(pro_com))
    if c is None:
        raise ValueError(tr("comune %s sconosciuto") % pro_com)
    con = sqlite3.connect(gpkg_path(c["reg"]))
    try:
        n, inh, pop, fam, abi, edi, area = con.execute(
            "SELECT COUNT(*), SUM(POP21 > 0), SUM(POP21), SUM(FAM21), "
            "SUM(ABI21), SUM(EDI21), SUM(AREA_M2) FROM sezioni WHERE "
            "PRO_COM = ?", (int(pro_com),)).fetchone()
        out = {"POP21": float(pop or 0), "FAM21": float(fam or 0),
               "ABI21": float(abi or 0), "EDI21": float(edi or 0),
               "AREA_M2": float(area or 0), "_sections": n or 0,
               "_inhabited": inh or 0}
        cols = [r[1] for r in con.execute("PRAGMA table_info(indicatori)")]
        if len(cols) > 1:
            row = con.execute(
                "SELECT %s FROM indicatori WHERE SEZ21_ID IN (SELECT "
                "SEZ21_ID FROM sezioni WHERE PRO_COM = ?)" % ", ".join(
                    'SUM("%s")' % k for k in cols[1:]),
                (int(pro_com),)).fetchone()
            out.update({k: float(v or 0) for k, v in zip(cols[1:], row)})
        return out
    finally:
        con.close()


def profile(t):
    """Profilo demografico da un dizionario di totali (un'area o un
    comune): numeri pronti per il report. Le parti che richiedono gli
    indicatori ci sono solo se «P1» è fra i totali."""
    d = derive(t)
    out = {"pop": t["POP21"], "fam": t["FAM21"], "abi": t["ABI21"],
           "edi": t["EDI21"], "area_km2": t["AREA_M2"] / 1e6,
           "sections": t.get("_sections"), "inhabited": t.get("_inhabited"),
           "density": _ratio(t["POP21"], t["AREA_M2"], 1e6)}
    out.update(d)
    if "P1" not in t:
        return out
    p1 = t["P1"]

    def share(v, den=None):
        return _ratio(v, p1 if den is None else den, 100.0)

    out["males"], out["females"] = t["P2"], t["P3"]
    out["age"] = [(a.replace(" anni", "").replace(" e più", "+")
                   .replace("meno di 5", "0-4"),
                   t["P%d" % (30 + k)], t["P%d" % (67 + k)])
                  for k, a in enumerate(_AGES)]
    out["age3"] = [(lab, _sum(t, codes), share(_sum(t, codes)))
                   for lab, codes in (("0-14 anni", _YOUNG),
                                      ("15-64 anni", _ADULT),
                                      (tr("65 anni e più"), _OLD))]
    fam = sum(t[c] for c, _l in FAMILIES)
    out["families"] = [(lab, t[c], share(t[c], fam)) for c, lab in FAMILIES]
    out["education"] = [(lab, t[c], share(t[c], t["P83"]))
                        for c, lab in EDUCATION]
    ue = t["ST16"]
    out["citizenship"] = [
        (tr("Italiani"), p1 - t["ST1"], share(p1 - t["ST1"])),
        (tr("Stranieri UE"), ue, share(ue)),
        (tr("Stranieri extra UE"), t["ST1"] - ue, share(t["ST1"] - ue))]
    out["occ_m"] = _ratio(t["P102"], _sum(t, _MALES_1564), 100.0)
    out["occ_f"] = _ratio(t["P103"], _sum(t, _FEMALES_1564), 100.0)
    out["dwellings"] = [(tr("Occupate da residenti"), t["A2"],
                         share(t["A2"], t["A8"])),
                        (tr("Vuote o di non residenti"), t["A3"],
                         share(t["A3"], t["A8"]))]
    return out


def report_data(rect, area_wkt=None, demo=True, progress=None,
                is_canceled=None, status=None):
    """Dati ISTAT per il report d'area.

    :param rect: riquadro (W, S, E, N) dell'area più il margine: la
        popolazione per sezione serve anche attorno all'area (isocrone).
    :param area_wkt: l'area (WGS84); con demo=True se ne ricava il profilo
        demografico (servono gli indicatori della regione).
    :return: dict con pop [(wkt WGS84, abitanti)], regions, notes, demo
        (dati per `area_report`, o None) e demo_skip (perché manca); None
        se annullato.
    """
    want = bool(demo and area_wkt)
    first = _span(progress, 0.0, 35.0 if want else 100.0)
    second = _span(progress, 35.0, 97.0)
    say = status or (lambda _t: None)
    say(tr("residenti delle sezioni di censimento attorno all'area"))
    base = fetch(rect=rect, indicators=False, wgs84=True,
                 progress=lambda p: first(p / 100.0),
                 is_canceled=is_canceled, status=status)
    if base is None:
        return None
    i = base["fields"].index("POP21")
    out = {"pop": [(g, float(v[i])) for g, _q, v in base["rows"]
                   if v[i] and v[i] > 0],
           "regions": base["regions"], "notes": list(base["notes"]),
           "demo": None, "demo_skip": ""}
    if not base["regions"]:
        out["demo_skip"] = tr("l'area non è in Italia")
        return out
    if not want:
        return out
    # gli indicatori servono solo alla pagina «Popolazione»: se non
    # arrivano restano i residenti già letti
    say(tr("indicatori demografici dell'area"))
    try:
        d = fetch(wkt=area_wkt, indicators=True, wgs84=True,
                  progress=lambda p: second(p / 100.0),
                  is_canceled=is_canceled, status=status)
    except Exception as exc:
        out["demo_skip"] = tr("indicatori ISTAT non disponibili (%s)") % exc
        return out
    if d is None:   # saltato: restano i residenti
        out["demo_skip"] = tr("indicatori ISTAT saltati")
        return out
    say(tr("profilo dell'area e del comune"))
    out["notes"] += d["notes"]
    f = d["fields"]
    ip, ic = f.index("POP21"), f.index("PRO_COM")
    by = {}
    for _g, q, v in d["rows"]:
        if v[ip]:
            by[v[ic]] = by.get(v[ic], 0.0) + q * v[ip]
    if "P1" not in f:
        out["demo_skip"] = tr("indicatori ISTAT non scaricati")
    elif not by:
        out["demo_skip"] = tr("nessuna sezione ISTAT con residenti nell'area")
    else:
        t = totals(d)
        pc = max(by, key=by.get)
        c = _comuni_index().get(pc)
        out["demo"] = {
            "fields": f, "rows": d["rows"], "profile": profile(t),
            "comune": {"pro_com": pc, "nome": c["nome"] if c else str(pc),
                       "share": by[pc] / sum(by.values()),
                       "others": len(by) - 1,
                       "profile": profile(comune_totals(pc))},
            "source": SOURCE}
    if progress:
        progress(100)
    return out


# ------------------------------------------------------------ layer QGIS
def build_layer(data, name, theme="dens"):
    """Layer in memoria delle sezioni lette (EPSG:32632), con gli indicatori
    derivati, gli alias dei campi e il tema scelto. Thread principale."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import QgsFeature, QgsField, QgsGeometry, QgsVectorLayer
    lay = QgsVectorLayer("MultiPolygon?crs=EPSG:%d" % EPSG, name, "memory")
    fields = data["fields"]
    partial = any(q < 0.999 for _g, q, _v in data["rows"])
    ind = fields[len(BASE_FIELDS):]
    derived = [k for k, _d, needs, _f in DERIVED
               if all(n in fields for n in needs)]
    head = ["SEZ21_ID", "COMUNE", "PRO_COM", "SEZ21", "TIPO_LOC", "POP21",
            "FAM21", "ABI21", "EDI21", "AREA_HA"]
    if partial:
        head.append("QUOTA")
    defs = []
    for k in head:
        kind = (QVariant.String if k == "COMUNE" else
                QVariant.Double if k in ("AREA_HA", "QUOTA") else
                QVariant.LongLong if k in ("SEZ21_ID", "SEZ21") else
                QVariant.Int)
        defs.append(QgsField(k, kind))
    defs += [QgsField(k, QVariant.Double) for k in derived]
    defs += [QgsField(k, QVariant.Int) for k in ind]
    pr = lay.dataProvider()
    pr.addAttributes(defs)
    lay.updateFields()
    pos = [fields.index(k) for k in ind]
    names = _comuni_index()
    feats = []
    for wkb, q, v in data["rows"]:
        row = dict(zip(fields, v))
        g = QgsGeometry()
        g.fromWkb(wkb)
        f = QgsFeature(lay.fields())
        f.setGeometry(g)
        c = names.get(row.get("PRO_COM"))
        d = derive(row)
        attrs = []
        for k in head:
            if k == "COMUNE":
                attrs.append(c["nome"] if c else None)
            elif k == "AREA_HA":
                attrs.append(round((row.get("AREA_M2") or 0) / 1e4, 3))
            elif k == "QUOTA":
                attrs.append(round(q, 4))
            else:
                attrs.append(row.get(k))
        attrs += [None if d.get(k) is None else round(d[k], 2)
                  for k in derived]
        attrs += [v[i] for i in pos]
        f.setAttributes(attrs)
        feats.append(f)
    pr.addFeatures(feats)
    lay.updateExtents()
    for i, fld in enumerate(lay.fields()):
        k = fld.name()
        label = BASE_LABELS.get(k) or DERIVED_LABEL.get(k) or \
            VAR_LABEL.get(k)
        if label:
            lay.setFieldAlias(i, "%s · %s" % (k, label))
    apply_theme(lay, theme)
    return lay


def build_points_layer(data, name):
    """Un punto per sezione di censimento con residenti (dentro la
    sezione), con i dati di base: per le analisi che vogliono punti con un
    peso (isocrone, accessibilità, gap del PTAL). Thread principale."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsFeature, QgsField, QgsGeometry, QgsMarkerSymbol,
                           QgsPointXY, QgsProperty, QgsSingleSymbolRenderer,
                           QgsSymbolLayer, QgsVectorLayer)
    lay = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    pr = lay.dataProvider()
    pr.addAttributes([QgsField("SEZ21_ID", QVariant.LongLong),
                      QgsField("COMUNE", QVariant.String),
                      QgsField("PRO_COM", QVariant.Int),
                      QgsField("POP21", QVariant.Int),
                      QgsField("FAM21", QVariant.Int),
                      QgsField("ABI21", QVariant.Int),
                      QgsField("EDI21", QVariant.Int)])
    lay.updateFields()
    fields = data["fields"]
    ix = [fields.index(k) for k in ("SEZ21_ID", "PRO_COM", "POP21", "FAM21",
                                    "ABI21", "EDI21")]
    names = _comuni_index()
    feats = []
    top = 1
    for (la, lo), (_g, _q, v) in zip(points_of(data), data["rows"]):
        sid, pc, pop, fam, abi, edi = (v[i] for i in ix)
        if not pop:
            continue
        c = names.get(pc)
        f = QgsFeature(lay.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lo, la)))
        f.setAttributes([sid, c["nome"] if c else None, pc, pop, fam, abi,
                         edi])
        feats.append(f)
        top = max(top, pop)
    pr.addFeatures(feats)
    lay.updateExtents()
    sym = QgsMarkerSymbol.createSimple({
        "name": "circle", "color": "79,70,229,170",
        "outline_color": "#ffffff", "outline_width": "0.15", "size": "1.4"})
    sym.symbolLayer(0).setDataDefinedProperty(
        QgsSymbolLayer.PropertySize, QgsProperty.fromExpression(
            'scale_linear(sqrt("POP21"), 0, %r, 0.7, 3.6)' % (top ** 0.5)))
    lay.setRenderer(QgsSingleSymbolRenderer(sym))
    for i, fld in enumerate(lay.fields()):
        label = BASE_LABELS.get(fld.name())
        if label:
            lay.setFieldAlias(i, "%s · %s" % (fld.name(), label))
    return lay


def theme_available(layer, key, themes=None):
    t = next((x for x in (themes or THEMES) if x[0] == key), None)
    return t is not None and layer.fields().indexOf(t[2]) >= 0


def apply_theme(layer, key, classes=5, themes=None, pop_field="POP21"):
    """Colora le sezioni per il tema scelto: 5 classi a quantili sulle
    sezioni con un valore; le altre (senza residenti) in grigio chiaro.
    `themes` e `pop_field` servono agli altri censimenti (INEGI).
    Ritorna True se il tema è stato applicato."""
    from qgis.PyQt.QtGui import QColor
    from qgis.core import (QgsFillSymbol, QgsGradientColorRamp,
                           QgsGraduatedSymbolRenderer,
                           QgsRendererRangeLabelFormat, QgsRuleBasedRenderer,
                           QgsSingleSymbolRenderer)
    t = next((x for x in (themes or THEMES) if x[0] == key), None)
    empty = QgsFillSymbol.createSimple({
        "color": "244,244,245,120", "outline_color": "#d4d4d8",
        "outline_width": "0.1"})
    layer.setOpacity(0.85)
    if t is None or layer.fields().indexOf(t[2]) < 0:
        layer.setRenderer(QgsSingleSymbolRenderer(empty))
        return False
    _k, _label, field, dec, lo, hi = t
    sym = QgsFillSymbol.createSimple({
        "color": lo, "outline_color": "#ffffff", "outline_width": "0.1"})
    # nelle classi entrano solo le sezioni con residenti e con un valore.
    # Serve un'espressione che dia un vero NULL: il valore mancante di un
    # campo numerico verrebbe contato come zero e, con un terzo delle
    # sezioni senza residenti, i quantili si schiaccerebbero sullo zero
    expr = ('CASE WHEN "%s" > 0 AND "%s" IS NOT NULL THEN "%s" END'
            % (pop_field, field, field))
    r = QgsGraduatedSymbolRenderer(expr)
    r.setSourceSymbol(sym)
    r.setSourceColorRamp(QgsGradientColorRamp(QColor(lo), QColor(hi)))
    try:
        from qgis.core import QgsClassificationQuantile
        method = QgsClassificationQuantile()
        method.setLabelFormat("%1 – %2")
        method.setLabelPrecision(dec)
        method.setLabelTrimTrailingZeroes(False)
        r.setClassificationMethod(method)
        r.updateClasses(layer, classes)
    except Exception:
        r.setLabelFormat(QgsRendererRangeLabelFormat("%1 – %2", dec))
        r.updateClasses(layer, QgsGraduatedSymbolRenderer.Quantile, classes)
    if not r.ranges():
        layer.setRenderer(QgsSingleSymbolRenderer(empty))
        return False
    rb = QgsRuleBasedRenderer.convertFromRenderer(r)
    rb.rootRule().appendChild(QgsRuleBasedRenderer.Rule(
        empty, 0, 0, "ELSE", tr("senza residenti o dato assente")))
    layer.setRenderer(rb)
    layer.setCustomProperty("mic/istat_theme", key)
    return True
