# -*- coding: utf-8 -*-
"""Confronto di scenari: differenza tra due layer di risultati (B − A).

Tipico: PTAL/accessibilità calcolati su due feed GTFS (prima/dopo una modifica
al servizio). Allinea le feature per centroide più vicino e produce un layer con
val_a, val_b e delta, con stile divergente.
"""
from ..i18n import tr
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsSpatialIndex,
    QgsSymbol,
    QgsVectorLayer,
    QgsWkbTypes,
)

from . import style_util


def compute_difference(layer_a, field_a, layer_b, field_b, transform_context,
                       name=tr("Confronto scenari (B − A)"), max_dist_m=None):
    """Layer con la geometria di A e delta = B − A per feature corrispondente.

    L'abbinamento usa il centroide più vicino di B (assume griglie/punti
    sovrapponibili). Con `max_dist_m` le coppie più lontane di tale distanza non
    vengono abbinate (evita match errati tra layer non allineati).
    Ritorna (layer, n_abbinate, n_totali).
    """
    # abbinamento in un CRS metrico: in gradi il "più vicino" verso est/ovest
    # sarebbe sbagliato (a Roma 1° di longitudine = 0,75° di latitudine)
    metric = layer_a.crs()
    if metric.isGeographic():
        from .isochrones import _utm_crs_for
        from qgis.core import QgsCoordinateReferenceSystem
        c0 = QgsCoordinateTransform(
            layer_a.crs(), QgsCoordinateReferenceSystem("EPSG:4326"),
            transform_context).transform(layer_a.extent().center())
        metric = _utm_crs_for(c0.x(), c0.y())
    ct_a = QgsCoordinateTransform(layer_a.crs(), metric, transform_context)
    ct_b = QgsCoordinateTransform(layer_b.crs(), metric, transform_context)

    def _dist_m(p, q):
        return ((p.x() - q.x()) ** 2 + (p.y() - q.y()) ** 2) ** 0.5

    index = QgsSpatialIndex()
    b_vals = {}
    b_pts = {}
    for i, f in enumerate(layer_b.getFeatures()):
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        c = QgsGeometry(g).centroid()
        c.transform(ct_b)
        try:
            b_vals[i] = float(f[field_b])
        except (TypeError, ValueError):
            # NULL: la feature resta nell'indice, così A non viene abbinata
            # a una feature lontana; risulta semplicemente non abbinata
            b_vals[i] = None
        feat = QgsFeature(i)
        feat.setGeometry(c)
        b_pts[i] = c.asPoint()
        index.addFeature(feat)

    wkb = QgsWkbTypes.displayString(layer_a.wkbType()) or "Polygon"
    out = style_util.memory_layer(wkb, layer_a.crs(), name)
    out.dataProvider().addAttributes([
        QgsField("val_a", QVariant.Double),
        QgsField("val_b", QVariant.Double),
        QgsField("delta", QVariant.Double),
    ])
    out.updateFields()
    feats = []
    matched = 0
    total = 0
    for f in layer_a.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        total += 1
        try:
            va = float(f[field_a])
        except (TypeError, ValueError):
            continue
        cg = QgsGeometry(g).centroid()
        cg.transform(ct_a)
        c = cg.asPoint()
        near = index.nearestNeighbor(c, 1)
        if not near or b_vals.get(near[0]) is None:
            continue
        if max_dist_m and _dist_m(c, b_pts[near[0]]) > max_dist_m:
            continue
        vb = b_vals[near[0]]
        matched += 1
        nf = QgsFeature(out.fields())
        nf.setGeometry(g)
        nf.setAttributes([round(va, 3), round(vb, 3), round(vb - va, 3)])
        feats.append(nf)
    out.dataProvider().addFeatures(feats)
    out.updateExtents()
    _style_diverging(out, "delta")
    return out, matched, total


def _style_diverging(layer, field):
    values = [f[field] for f in layer.getFeatures() if f[field] is not None]
    if not values:
        return
    n = min(7, len(set(values)))
    if n < 1:
        return
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    # rosso (peggioramento) -> bianco -> blu (miglioramento)
    ramp = QgsGradientColorRamp(QColor(202, 0, 32), QColor(5, 113, 176))
    r = style_util.graduated_from(layer, field, n, symbol, ramp)
    if r and r.ranges():
        layer.setRenderer(r)
