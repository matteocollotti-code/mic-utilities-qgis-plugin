# -*- coding: utf-8 -*-
"""Residenti serviti dal trasporto pubblico (copertura).

Per ogni punto di popolazione (una sezione di censimento, un edificio, una
cella) si cercano le fermate raggiungibili a piedi entro la soglia del loro
mezzo: di default 400 m per bus e tram, 800 m per metro e treno. La distanza
è misurata lungo la rete (come nel PTAL: tratto dal punto alla strada,
percorso, tratto dalla strada alla fermata) o in linea d'aria.

Una linea è raggiungibile se lo è almeno una sua fermata, e conta una volta
sola, con la frequenza più alta fra le sue fermate raggiungibili. Il livello
di servizio di un punto è la somma delle corse all'ora delle linee
raggiungibili nella fascia oraria analizzata.

Nessun oggetto QGIS: sicuro in un task di background.
"""
from ..i18n import tr
import math
from collections import defaultdict

from .ptal import basic_route_type

# soglia di cammino (m) per tipo di rotta GTFS di base
DEFAULT_DIST = {"0": 400.0, "1": 800.0, "2": 800.0, "3": 400.0, "4": 800.0}
DEFAULT_OTHER = 400.0
MODE_LABEL = {"0": "Tram", "1": "Metro", "2": tr("Treno"), "3": "Bus",
              "4": tr("Traghetto"), "6": tr("Funivia"), "7": tr("Funicolare")}
# classi di servizio: (chiave, corse all'ora minime, etichetta, colore)
CLASSES = [("A", 12.0, tr("12 o più corse l'ora"), "#15803d"),
           ("B", 6.0, tr("da 6 a 12 corse l'ora"), "#84cc16"),
           ("C", 2.0, tr("da 2 a 6 corse l'ora"), "#facc15"),
           ("D", 0.0, tr("meno di 2 corse l'ora"), "#f97316"),
           ("N", None, tr("nessuna fermata a portata"), "#dc2626")]
CLASS_LABEL = {k: lab for k, _lo, lab, _c in CLASSES}
CLASS_COLOR = {k: c for k, _lo, _lab, c in CLASSES}


def service_class(freq):
    """Classe di servizio dalle corse all'ora raggiungibili."""
    if not freq or freq <= 0:
        return "N"
    for key, lo, _lab, _c in CLASSES:
        if lo is not None and freq >= lo:
            return key
    return "D"


def thresholds(bus_m=400.0, rail_m=800.0):
    """Soglie per tipo di rotta da due distanze: bus e tram, metro e treno
    (e traghetti)."""
    return {"0": float(bus_m), "3": float(bus_m), "1": float(rail_m),
            "2": float(rail_m), "4": float(rail_m), "other": float(bus_m)}


def compute(points, stop_routes, stops_xy, roads_lonlat=None, dist=None,
            progress=None, is_canceled=None, snap_m=500.0):
    """Fermate e linee raggiungibili da ogni punto di popolazione.

    :param points: [(lat, lon, residenti)]; residenti 0 o None = il punto
        si calcola ma non pesa nei totali.
    :param stop_routes: {fermata: [(linea, tipo di rotta, corse/ora)]}
        (da ptal.compute_stop_frequencies o ptal.stops_from_records).
    :param stops_xy: {fermata: (lat, lon)}.
    :param roads_lonlat: rete pedonale pulita; None = linea d'aria.
    :param dist: soglie in metri per tipo di rotta (vedi `thresholds`).
    :return: dict con
        points: per ogni punto {dist (m alla fermata più vicina che lo
            serve, o None), stop, freq (corse/ora raggiungibili), lines,
            cls (classe di servizio), modes};
        stops: {fermata: {lat, lon, pop (residenti entro la soglia),
            pop_nearest (residenti per cui è la più vicina), lines, freq,
            modes}} per le fermate a portata di almeno un punto;
        routes: {linea: {pop, freq, mode, stops}};
        summary: {pop, served, by_class, by_mode, mean_dist, points,
            off_network, network}.
    """
    thr = dict(DEFAULT_DIST)
    thr.update(dist or {})
    other = float(thr.get("other", DEFAULT_OTHER))

    def limit(rtype):
        return float(thr.get(basic_route_type(rtype), other))

    stops = {}
    for sid, routes in stop_routes.items():
        if sid not in stops_xy:
            continue
        rts = [(rid, basic_route_type(rt), float(f), limit(rt))
               for rid, rt, f in routes if f and f > 0]
        if rts:
            stops[sid] = (rts, max(r[3] for r in rts))
    max_thr = max([s[1] for s in stops.values()] + [0.0])
    pts = [(float(la), float(lo), float(p or 0.0)) for la, lo, p in points]
    lat0 = sum(la for la, _lo, _p in pts) / len(pts) if pts else 0.0

    graph = None
    if roads_lonlat:
        from . import net_iso
        graph = net_iso.build_metric_graph(roads_lonlat, lat0)
        to_m = graph.to_m
    else:
        kx = 111320.0 * math.cos(math.radians(lat0))

        def to_m(lon, lat):
            return lon * kx, lat * 110540.0
    if progress:
        progress(8)

    # fermate in una griglia (cella = soglia massima): candidati vicini
    cell = max(max_thr, 50.0)
    grid = defaultdict(list)
    stop_m = {}
    stop_info = {}
    for sid, (rts, _top) in stops.items():
        la, lo = stops_xy[sid]
        x, y = to_m(lo, la)
        stop_m[sid] = (x, y)
        grid[(int(x // cell), int(y // cell))].append(sid)
        if graph is not None:
            info = graph.snap_edge(x, y, snap_m)
            if info:
                stop_info[sid] = (info, math.hypot(x - info["foot"][0],
                                                   y - info["foot"][1]))
    if progress:
        progress(15)

    out = []
    total = served = dist_w = 0.0
    by_class = defaultdict(float)
    by_mode = defaultdict(float)
    stop_pop = defaultdict(float)
    stop_near = defaultdict(float)
    route_pop = defaultdict(float)
    route_stops = defaultdict(set)
    touched = set()
    off_network = 0
    n = len(pts)
    for idx, (la, lo, pop) in enumerate(pts):
        if is_canceled and idx % 50 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and idx % 100 == 0 and n:
            progress(15 + 83.0 * idx / n)
        x, y = to_m(lo, la)
        cx, cy = int(x // cell), int(y // cell)
        cand = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for sid in grid.get((cx + dx, cy + dy), ()):
                    sx, sy = stop_m[sid]
                    d0 = math.hypot(sx - x, sy - y)
                    if d0 <= stops[sid][1]:
                        cand.append((sid, d0))
        reach = []
        if cand and graph is None:
            reach = cand
        elif graph is not None:
            src = graph.snap_edge(x, y, snap_m)
            if src is None:
                off_network += 1
            elif cand:
                off = math.hypot(x - src["foot"][0], y - src["foot"][1])
                if off < max_thr:
                    cost = graph.dijkstra_multi(src["seeds"], max_thr - off)
                    for sid, _d0 in cand:
                        got = stop_info.get(sid)
                        if got is None:
                            continue
                        d = graph.edge_distance(cost, src, got[0]) + off \
                            + got[1]
                        if d <= stops[sid][1]:
                            reach.append((sid, d))
        lines = {}
        near = None
        serving = []
        for sid, d in reach:
            ok = False
            for rid, mode, f, lim in stops[sid][0]:
                if d <= lim:
                    ok = True
                    route_stops[rid].add(sid)
                    if f > lines.get(rid, (0.0, None))[0]:
                        lines[rid] = (f, mode)
            if ok:
                serving.append(sid)
                touched.add(sid)
                if near is None or d < near[0]:
                    near = (d, sid)
        freq = sum(f for f, _m in lines.values())
        cls = service_class(freq)
        modes = sorted({m for _f, m in lines.values()})
        out.append({"dist": near[0] if near else None,
                    "stop": near[1] if near else None, "freq": freq,
                    "lines": len(lines), "cls": cls, "modes": modes})
        if pop > 0:
            total += pop
            by_class[cls] += pop
            if near:
                served += pop
                dist_w += pop * near[0]
                stop_near[near[1]] += pop
            for sid in serving:
                stop_pop[sid] += pop
            for rid in lines:
                route_pop[rid] += pop
            for m in modes:
                by_mode[m] += pop

    stops_out = {}
    for sid in touched:
        rts = stops[sid][0]
        la, lo = stops_xy[sid]
        stops_out[sid] = {
            "lat": la, "lon": lo, "pop": stop_pop.get(sid, 0.0),
            "pop_nearest": stop_near.get(sid, 0.0), "lines": len(rts),
            "freq": sum(r[2] for r in rts),
            "modes": sorted({r[1] for r in rts})}
    routes_out = {}
    for rid, sids in route_stops.items():
        best = (0.0, "3")
        for sid in sids:
            for r, mode, f, _lim in stops[sid][0]:
                if r == rid and f > best[0]:
                    best = (f, mode)
        routes_out[rid] = {"pop": route_pop.get(rid, 0.0), "freq": best[0],
                           "mode": best[1], "stops": len(sids)}
    if progress:
        progress(100)
    return {"points": out, "stops": stops_out, "routes": routes_out,
            "summary": {
                "pop": total, "served": served,
                "by_class": {k: by_class.get(k, 0.0)
                             for k, _lo, _l, _c in CLASSES},
                "by_mode": dict(by_mode),
                "mean_dist": dist_w / served if served else None,
                "points": n, "off_network": off_network,
                "network": graph is not None,
                "thresholds": {k: v for k, v in thr.items()}}}


def summary_rows(s, fmt):
    """Riepilogo leggibile: [(voce, valore)]. `fmt(valore, decimali)`
    formatta i numeri."""
    pop = s["pop"]

    def share(v):
        return "%s (%s %%)" % (fmt(v, 0), fmt(100.0 * v / pop, 1)) \
            if pop else fmt(v, 0)

    rows = [(tr("Residenti analizzati"), fmt(pop, 0)),
            (tr("Con una fermata a portata"), share(s["served"]))]
    for key, _lo, lab, _c in CLASSES:
        rows.append((lab[0].upper() + lab[1:], share(s["by_class"][key])))
    for m, v in sorted(s["by_mode"].items(), key=lambda kv: -kv[1]):
        rows.append((tr("Con %s a portata") % MODE_LABEL.get(m, tr("mezzo %s") % m)
                     .lower(), share(v)))
    if s.get("mean_dist") is not None:
        rows.append((tr("Distanza media dalla fermata"), "%s m"
                     % fmt(s["mean_dist"], 0)))
    return rows


def gtfs_names(source):
    """Nomi dal feed: ({fermata: nome}, {linea: (sigla, nome)})."""
    from . import gtfs_static as gs
    stops, routes = {}, {}
    try:
        t = gs._read_subset(source, "stops.txt", ["stop_id", "stop_name"])
        if t is not None and "stop_name" in t.columns:
            stops = dict(zip(t["stop_id"], t["stop_name"]))
    except Exception:
        pass
    try:
        for r in gs.list_routes(source):
            routes[r["route_id"]] = (str(r["short_name"] or ""),
                                     str(r["long_name"] or ""))
    except Exception:
        pass
    return stops, routes


def mode_text(modes):
    return ", ".join(MODE_LABEL.get(m, tr("mezzo %s") % m) for m in modes)


# ------------------------------------------------------------ layer QGIS
def build_units_layer(units, result, name, geom, crs_authid):
    """Layer delle unità di popolazione (sezioni, edifici…) colorate per
    classe di servizio. Thread principale.

    :param units: [(geometria: QgsGeometry o WKB, codice, residenti)]
        allineate a result["points"].
    :param geom: "MultiPolygon" o "Point".
    """
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsCategorizedSymbolRenderer, QgsFeature,
                           QgsField, QgsFillSymbol, QgsGeometry,
                           QgsMarkerSymbol, QgsRendererCategory,
                           QgsVectorLayer)
    lay = QgsVectorLayer("%s?crs=%s" % (geom, crs_authid), name, "memory")
    pr = lay.dataProvider()
    pr.addAttributes([QgsField("codice", QVariant.String),
                      QgsField("residenti", QVariant.Double),
                      QgsField("dist_m", QVariant.Double),
                      QgsField("fermata", QVariant.String),
                      QgsField("corse_h", QVariant.Double),
                      QgsField("linee", QVariant.Int),
                      QgsField("mezzi", QVariant.String),
                      QgsField("classe", QVariant.String),
                      QgsField("servizio", QVariant.String)])
    lay.updateFields()
    feats = []
    for (g, code, pop), r in zip(units, result["points"]):
        if not isinstance(g, QgsGeometry):
            wkb = g
            g = QgsGeometry()
            g.fromWkb(wkb)
        if geom == "MultiPolygon":
            g = QgsGeometry(g)
            g.convertToMultiType()
        f = QgsFeature(lay.fields())
        f.setGeometry(g)
        f.setAttributes([
            str(code), round(pop, 1),
            None if r["dist"] is None else round(r["dist"], 0),
            None if r["stop"] is None else str(r["stop"]),
            round(r["freq"], 1), r["lines"], mode_text(r["modes"]),
            r["cls"], CLASS_LABEL[r["cls"]]])
        feats.append(f)
    pr.addFeatures(feats)
    lay.updateExtents()
    present = {r["cls"] for r in result["points"]}
    cats = []
    for key, _lo, lab, col in CLASSES:
        if key not in present:
            continue
        if geom == "Point":
            sym = QgsMarkerSymbol.createSimple({
                "name": "circle", "color": col, "outline_color": "#ffffff",
                "outline_width": "0.2", "size": "2.2"})
        else:
            sym = QgsFillSymbol.createSimple({
                "color": col, "outline_color": "#ffffff",
                "outline_width": "0.1"})
        cats.append(QgsRendererCategory(key, sym, lab[0].upper() + lab[1:]))
    lay.setRenderer(QgsCategorizedSymbolRenderer("classe", cats))
    lay.setOpacity(0.8)
    for i, alias in enumerate((
            tr("Codice"), tr("Residenti"), tr("Distanza dalla fermata più vicina (m)"),
            tr("Fermata più vicina"), tr("Corse all'ora raggiungibili"),
            tr("Linee raggiungibili"), tr("Mezzi raggiungibili"),
            tr("Classe di servizio (A-D, N = nessuna fermata)"), tr("Servizio"))):
        lay.setFieldAlias(i, alias)
    return lay


def build_stops_layer(result, stop_names, name):
    """Fermate a portata dei residenti: cerchi proporzionali ai residenti
    entro la soglia. Thread principale."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsFeature, QgsField, QgsGeometry, QgsMarkerSymbol,
                           QgsPointXY, QgsProperty, QgsSingleSymbolRenderer,
                           QgsSymbolLayer, QgsVectorLayer)
    lay = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    pr = lay.dataProvider()
    pr.addAttributes([QgsField("fermata", QVariant.String),
                      QgsField("nome", QVariant.String),
                      QgsField("mezzi", QVariant.String),
                      QgsField("linee", QVariant.Int),
                      QgsField("corse_h", QVariant.Double),
                      QgsField("residenti", QVariant.Double),
                      QgsField("res_vicina", QVariant.Double)])
    lay.updateFields()
    feats = []
    top = 0.0
    for sid, st in result["stops"].items():
        f = QgsFeature(lay.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(st["lon"],
                                                         st["lat"])))
        f.setAttributes([str(sid), str(stop_names.get(sid, "") or ""),
                         mode_text(st["modes"]), st["lines"],
                         round(st["freq"], 1), round(st["pop"], 0),
                         round(st["pop_nearest"], 0)])
        feats.append(f)
        top = max(top, st["pop"])
    pr.addFeatures(feats)
    lay.updateExtents()
    sym = QgsMarkerSymbol.createSimple({
        "name": "circle", "color": "79,70,229,150",
        "outline_color": "#ffffff", "outline_width": "0.3", "size": "2"})
    # area del cerchio proporzionale ai residenti entro la soglia
    sym.symbolLayer(0).setDataDefinedProperty(
        QgsSymbolLayer.PropertySize, QgsProperty.fromExpression(
            'coalesce(scale_linear(sqrt("residenti"), 0, %r, 1.0, 5), 1.0)'
            % (max(top, 1.0) ** 0.5)))
    lay.setRenderer(QgsSingleSymbolRenderer(sym))
    # a scala di città le fermate coprirebbero la mappa: si vedono
    # ingrandendo oltre 1:40.000
    lay.setScaleBasedVisibility(True)
    lay.setMinimumScale(40000)
    for i, alias in enumerate((
            tr("Codice della fermata"), tr("Nome"), tr("Mezzi"), tr("Linee"),
            tr("Corse all'ora nella fascia"), tr("Residenti entro la soglia"),
            tr("Residenti per cui è la fermata più vicina"))):
        lay.setFieldAlias(i, alias)
    return lay


def build_routes_table(result, route_names, name):
    """Tabella (senza geometria) delle linee con i residenti serviti."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import QgsFeature, QgsField, QgsVectorLayer
    lay = QgsVectorLayer("None", name, "memory")
    pr = lay.dataProvider()
    pr.addAttributes([QgsField("linea", QVariant.String),
                      QgsField("nome", QVariant.String),
                      QgsField("mezzo", QVariant.String),
                      QgsField("corse_h", QVariant.Double),
                      QgsField("fermate", QVariant.Int),
                      QgsField("residenti", QVariant.Double),
                      QgsField("quota_pct", QVariant.Double)])
    lay.updateFields()
    pop = result["summary"]["pop"] or 0.0
    feats = []
    for rid, r in sorted(result["routes"].items(),
                         key=lambda kv: -kv[1]["pop"]):
        short, long_ = route_names.get(rid, ("", ""))
        f = QgsFeature(lay.fields())
        f.setAttributes([short or str(rid), long_,
                         MODE_LABEL.get(r["mode"], r["mode"]),
                         round(r["freq"], 1), r["stops"], round(r["pop"], 0),
                         round(100.0 * r["pop"] / pop, 1) if pop else None])
        feats.append(f)
    pr.addFeatures(feats)
    for i, alias in enumerate((
            tr("Linea"), tr("Nome"), tr("Mezzo"), tr("Corse all'ora nella fascia"),
            tr("Fermate a portata dei residenti"), tr("Residenti serviti"),
            tr("Quota dei residenti (%)"))):
        lay.setFieldAlias(i, alias)
    return lay
