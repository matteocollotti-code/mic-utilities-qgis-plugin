# -*- coding: utf-8 -*-
"""Pendolarismo fra comuni: matrici ISTAT 2021 (Censimento permanente).

Due file, uno per motivo (lavoro, studio), ciascuno con una riga per coppia
comune di residenza → comune di lavoro o di studio e il numero di persone
che si spostano almeno tre giorni a settimana. Sono testi separati da
tabulazioni con intestazione; i codici dei comuni (6 cifre con gli zeri
iniziali) sono quelli al 31/12/2021, gli stessi dell'elenco dei comuni del
plugin. La riga con residenza = destinazione sono i pendolari interni.

Limiti del dato: è una stima da modello, non un conteggio; non dice il
mezzo di trasporto né l'orario; non comprende chi va all'estero; lo studio
riguarda i non occupati (gli studenti-lavoratori stanno nel lavoro).

`ensure`, `flows`, `rows`, `totals` non usano oggetti QGIS: sicuri in un
task di background. `build_lines` e `build_points` vanno chiamati sul
thread principale.
"""
from ..i18n import tr
import io
import math
import os
import zipfile

from . import istat

EDITION = 2021
_BASE = "https://esploradati.istat.it/databrowser/DWL/PERMPOP/MATPEN/"
URLS = {"lavoro": _BASE + "matrix_pendoLAVORO_2021.zip",
        "studio": _BASE + "matrix_pendoSTUDIO_2021.zip"}
SOURCE = (tr("ISTAT – Matrici del pendolarismo per lavoro e per studio, "
          "Censimento permanente 2021 (CC BY 4.0)"))
KINDS = [("tutti", tr("Lavoro e studio")), ("lavoro", tr("Lavoro")),
         ("studio", tr("Studio"))]
DIRECTIONS = [("both", tr("In uscita e in entrata")),
              ("out", tr("In uscita: dove vanno i residenti")),
              ("in", tr("In entrata: da dove arrivano"))]
DIR_LABEL = {"out": tr("in uscita"), "in": tr("in entrata")}
DIR_COLOR = {"out": "#ea580c", "in": "#2563eb"}


def kinds_of(key):
    """Motivi da leggere per la scelta dell'utente."""
    return ("lavoro", "studio") if key == "tutti" else (key,)


def cache_path(kind):
    return os.path.join(istat.cache_dir(),
                        "pendolarismo%d_%s.zip" % (EDITION, kind))


def _member(z):
    for n in z.namelist():
        if n.lower().endswith(".txt"):
            return n
    return None


def _valid(path):
    try:
        with zipfile.ZipFile(path) as z:
            return _member(z) is not None
    except Exception:
        return False


def cached_size():
    """Byte occupati dalle matrici scaricate."""
    return sum(os.path.getsize(cache_path(k)) for k in URLS
               if os.path.exists(cache_path(k)))


def ensure(kinds=("lavoro", "studio"), progress=None, is_canceled=None):
    """Scarica le matrici che mancano (2 MB in tutto) e ritorna
    {motivo: percorso dello zip}.

    :raises istat.Cancelled: annullato.
    """
    out = {}
    n = len(kinds)
    for k, kind in enumerate(kinds):
        path = cache_path(kind)
        if not (os.path.exists(path) and _valid(path)):
            istat._download(URLS[kind], path, istat._span(
                progress, 100.0 * k / n, 100.0 * (k + 1) / n), is_canceled)
            if not _valid(path):
                istat._remove(path)
                raise RuntimeError(tr("il file ISTAT del pendolarismo (%s) non "
                                   "si legge: riprova") % kind)
        out[kind] = path
    if progress:
        progress(100)
    return out


def read_flows(path, pro_com):
    """Flussi di un comune da una matrice: (interni, uscite {comune: n},
    entrate {comune: n}), con codici interi."""
    cod = "%06d" % int(pro_com)
    interni, uscite, entrate = 0, {}, {}
    with zipfile.ZipFile(path) as z:
        name = _member(z)
        if name is None:
            raise RuntimeError(tr("matrice del pendolarismo senza dati"))
        with z.open(name) as raw:
            f = io.TextIOWrapper(raw, encoding="ascii", errors="replace",
                                 newline="")
            next(f, None)   # intestazione
            for line in f:
                if cod not in line:
                    continue
                p = line.rstrip("\r\n").split("\t")
                if len(p) != 5:
                    continue
                res, dest = p[1].strip(), p[3].strip()
                if res != cod and dest != cod:
                    continue
                try:
                    v = int(p[4])
                except ValueError:
                    continue
                if res == dest:
                    interni += v
                elif res == cod:
                    uscite[int(dest)] = uscite.get(int(dest), 0) + v
                else:
                    entrate[int(res)] = entrate.get(int(res), 0) + v
    return interni, uscite, entrate


def flows(pro_com, kinds=("lavoro", "studio"), progress=None,
          is_canceled=None):
    """Flussi di pendolarismo di un comune, scaricando le matrici se
    mancano.

    :return: dict con pro_com, kinds, internal {motivo: n}, out e in
        {comune: {motivo: n}}; None se annullato.
    """
    try:
        paths = ensure(kinds, lambda p: progress(0.8 * p) if progress
                       else None, is_canceled)
    except istat.Cancelled:
        return None
    out = {"pro_com": int(pro_com), "kinds": list(kinds), "internal": {},
           "out": {}, "in": {}}
    for kind in kinds:
        interni, uscite, entrate = read_flows(paths[kind], pro_com)
        out["internal"][kind] = interni
        for key, part in (("out", uscite), ("in", entrate)):
            for code, v in part.items():
                out[key].setdefault(code, {})[kind] = v
    if progress:
        progress(100)
    return out


def totals(fl):
    """Totali del comune: per verso, persone e numero di comuni."""
    def tot(part):
        return sum(sum(d.values()) for d in part.values())
    return {"internal": sum(fl["internal"].values()),
            "internal_by": dict(fl["internal"]),
            "out": tot(fl["out"]), "n_out": len(fl["out"]),
            "in": tot(fl["in"]), "n_in": len(fl["in"])}


def rows(fl, direction="both", min_flow=0, top_n=0):
    """Flussi da disegnare: [(verso, altro comune, lavoro, studio, totale)]
    dal più grande, con i filtri (persone minime, primi N per verso)."""
    out = []
    for key in ("out", "in"):
        if direction not in ("both", key):
            continue
        part = []
        for code, d in fl[key].items():
            lav, stu = d.get("lavoro", 0), d.get("studio", 0)
            if lav + stu >= max(1, min_flow):
                part.append((key, code, lav, stu, lav + stu))
        part.sort(key=lambda r: -r[4])
        if top_n and top_n > 0:
            part = part[:top_n]
        out += part
    out.sort(key=lambda r: -r[4])
    return out


def _haversine_km(a, b):
    la1, lo1, la2, lo2 = (math.radians(x) for x in (a[1], a[0], b[1], b[0]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * \
        math.sin((lo2 - lo1) / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(h))


def summary_rows(fl, fmt, top=5):
    """Riepilogo leggibile: [(voce, valore)], con le prime destinazioni e
    origini."""
    t = totals(fl)
    idx = istat._comuni_index()

    def name(code):
        c = idx.get(code)
        return c["nome"] if c else str(code)

    by = " (%s)" % ", ".join("%s %s" % (k, fmt(v, 0))
                             for k, v in t["internal_by"].items()) \
        if len(t["internal_by"]) > 1 else ""
    out = [(tr("Restano nel comune"), fmt(t["internal"], 0) + by),
           (tr("Escono verso altri comuni"), tr("%s (%s comuni)") % (
               fmt(t["out"], 0), fmt(t["n_out"], 0))),
           (tr("Entrano da altri comuni"), tr("%s (%s comuni)") % (
               fmt(t["in"], 0), fmt(t["n_in"], 0))),
           (tr("Saldo (entrano meno escono)"), ("+" if t["in"] >= t["out"]
                                            else "") + fmt(t["in"]
                                                           - t["out"], 0))]
    for key, label in (("out", "Vanno a"), ("in", tr("Arrivano da"))):
        part = sorted(((sum(d.values()), code)
                       for code, d in fl[key].items()), reverse=True)[:top]
        for v, code in part:
            out.append(("%s %s" % (label, name(code)), fmt(v, 0)))
    return out


# ------------------------------------------------------------ layer QGIS
def build_lines(fl, flow_rows, name, arc=True):
    """Linee di desiderio fra il comune e gli altri: arancio in uscita, blu
    in entrata, spessore secondo le persone. Ritorna (layer, comuni senza
    posizione)."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsCategorizedSymbolRenderer, QgsFeature,
                           QgsFeatureRequest, QgsField, QgsGeometry,
                           QgsLineSymbol, QgsPointXY, QgsProperty,
                           QgsRendererCategory, QgsSymbolLayer,
                           QgsVectorLayer)
    from .od_viz import _arc_points
    idx = istat._comuni_index()
    home = idx.get(fl["pro_com"])
    lay = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    pr = lay.dataProvider()
    pr.addAttributes([QgsField("verso", QVariant.String),
                      QgsField("da", QVariant.String),
                      QgsField("a", QVariant.String),
                      QgsField("cod_da", QVariant.Int),
                      QgsField("cod_a", QVariant.Int),
                      QgsField("lavoro", QVariant.Int),
                      QgsField("studio", QVariant.Int),
                      QgsField("flusso", QVariant.Int),
                      QgsField("km", QVariant.Double)])
    lay.updateFields()
    feats = []
    missing = 0
    vals = []
    for key, code, lav, stu, tot in flow_rows:
        other = idx.get(code)
        if home is None or other is None:
            missing += 1
            continue
        o, d = (home, other) if key == "out" else (other, home)
        po = QgsPointXY(o["lon"], o["lat"])
        pd_ = QgsPointXY(d["lon"], d["lat"])
        f = QgsFeature(lay.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY(
            _arc_points(po, pd_, 0.18) if arc else [po, pd_]))
        f.setAttributes([DIR_LABEL[key], o["nome"], d["nome"], o["pro_com"],
                         d["pro_com"], lav, stu, tot,
                         round(_haversine_km((o["lon"], o["lat"]),
                                             (d["lon"], d["lat"])), 1)])
        feats.append(f)
        vals.append(tot)
    pr.addFeatures(feats)
    lay.updateExtents()
    lo, hi = (min(vals), max(vals)) if vals else (0, 1)
    width = QgsProperty.fromExpression(
        'scale_linear(sqrt("flusso"), %r, %r, 0.15, 3.2)'
        % (lo ** 0.5, max(hi ** 0.5, lo ** 0.5 + 1e-9)))
    cats = []
    present = {r[0] for r in flow_rows}
    for key in ("out", "in"):
        if key not in present:
            continue
        sym = QgsLineSymbol.createSimple({
            "line_color": DIR_COLOR[key], "line_width": "0.6",
            "capstyle": "round", "joinstyle": "round"})
        sym.symbolLayer(0).setDataDefinedProperty(
            QgsSymbolLayer.PropertyStrokeWidth, width)
        sym.setOpacity(0.7)
        lab = DIR_LABEL[key]
        cats.append(QgsRendererCategory(lab, sym, lab[0].upper() + lab[1:]))
    rend = QgsCategorizedSymbolRenderer("verso", cats)
    try:   # i flussi grandi sopra i piccoli
        rend.setOrderBy(QgsFeatureRequest.OrderBy(
            [QgsFeatureRequest.OrderByClause("flusso", True)]))
        rend.setOrderByEnabled(True)
    except Exception:
        pass
    lay.setRenderer(rend)
    for i, alias in enumerate((
            tr("Verso"), tr("Comune di residenza"), tr("Comune di lavoro o studio"),
            tr("Codice ISTAT di residenza"), tr("Codice ISTAT di destinazione"),
            tr("Per lavoro"), tr("Per studio"), tr("Persone"), tr("Distanza in linea "
            "d'aria (km)"))):
        lay.setFieldAlias(i, alias)
    return lay, missing


def build_points(fl, flow_rows, name, labels=12):
    """Comuni collegati: cerchi secondo le persone scambiate con il comune
    scelto (segnato a parte), con il nome dei principali."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.PyQt.QtGui import QColor, QFont
    from qgis.core import (QgsCategorizedSymbolRenderer, QgsFeature,
                           QgsField, QgsGeometry, QgsMarkerSymbol,
                           QgsPalLayerSettings, QgsPointXY, QgsProperty,
                           QgsRendererCategory, QgsSymbolLayer,
                           QgsTextBufferSettings, QgsTextFormat,
                           QgsVectorLayer, QgsVectorLayerSimpleLabeling)
    idx = istat._comuni_index()
    lay = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    pr = lay.dataProvider()
    pr.addAttributes([QgsField("comune", QVariant.String),
                      QgsField("provincia", QVariant.String),
                      QgsField("cod", QVariant.Int),
                      QgsField("tipo", QVariant.String),
                      QgsField("vanno", QVariant.Int),
                      QgsField("arrivano", QVariant.Int),
                      QgsField("saldo", QVariant.Int),
                      QgsField("totale", QVariant.Int),
                      QgsField("nome_mappa", QVariant.String)])
    lay.updateFields()
    part = {}
    for key, code, _lav, _stu, tot in flow_rows:
        d = part.setdefault(code, {"out": 0, "in": 0})
        d[key] += tot
    ranked = sorted(part, key=lambda c: -(part[c]["out"] + part[c]["in"]))
    named = set(ranked[:labels])
    feats = []
    top = 1
    for code in ranked:
        c = idx.get(code)
        if c is None:
            continue
        v = part[code]
        tot = v["out"] + v["in"]
        top = max(top, tot)
        f = QgsFeature(lay.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(c["lon"],
                                                         c["lat"])))
        f.setAttributes([c["nome"], c["provincia"], code, "collegato",
                         v["out"], v["in"], v["in"] - v["out"], tot,
                         c["nome"] if code in named else None])
        feats.append(f)
    home = idx.get(fl["pro_com"])
    if home is not None:
        t = totals(fl)
        f = QgsFeature(lay.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(home["lon"],
                                                         home["lat"])))
        f.setAttributes([home["nome"], home["provincia"], home["pro_com"],
                         "scelto", t["out"], t["in"], t["in"] - t["out"],
                         t["out"] + t["in"], home["nome"]])
        feats.append(f)
    pr.addFeatures(feats)
    lay.updateExtents()
    sym = QgsMarkerSymbol.createSimple({
        "name": "circle", "color": "255,255,255,220",
        "outline_color": "#3f3f46", "outline_width": "0.3", "size": "2"})
    sym.symbolLayer(0).setDataDefinedProperty(
        QgsSymbolLayer.PropertySize, QgsProperty.fromExpression(
            'scale_linear(sqrt("totale"), 0, %r, 1.2, 6)' % (top ** 0.5)))
    star = QgsMarkerSymbol.createSimple({
        "name": "star", "color": "#09090b", "outline_color": "#ffffff",
        "outline_width": "0.4", "size": "5"})
    lay.setRenderer(QgsCategorizedSymbolRenderer("tipo", [
        QgsRendererCategory("scelto", star, tr("Comune scelto")),
        QgsRendererCategory("collegato", sym, tr("Comuni collegati"))]))
    try:
        st = QgsPalLayerSettings()
        st.fieldName = "nome_mappa"
        tf = QgsTextFormat()
        font = QFont()
        font.setPointSizeF(8.0)
        tf.setFont(font)
        tf.setSize(8.0)
        tf.setColor(QColor("#18181b"))
        buf = QgsTextBufferSettings()
        buf.setEnabled(True)
        buf.setSize(0.8)
        buf.setColor(QColor("#ffffff"))
        tf.setBuffer(buf)
        st.setFormat(tf)
        lay.setLabeling(QgsVectorLayerSimpleLabeling(st))
        lay.setLabelsEnabled(True)
    except Exception:
        pass
    for i, alias in enumerate((
            tr("Comune"), tr("Provincia"), tr("Codice ISTAT"), tr("Tipo"),
            tr("Vanno qui dal comune scelto"), tr("Arrivano da qui al comune scelto"),
            tr("Saldo per il comune scelto (arrivano meno vanno)"),
            tr("Persone scambiate"), tr("Nome sulla mappa"))):
        lay.setFieldAlias(i, alias)
    return lay
