# -*- coding: utf-8 -*-
"""Tempi di percorrenza per tratto di strada, uno per verso.

Servono quando la velocità non è la stessa ovunque:
- in auto ogni strada ha la sua velocità (limite OSM, tipo di strada,
  campo scelto dall'utente: routing.speed_reader);
- a piedi con un DEM la velocità dipende dalla pendenza (funzione di
  Tobler): in salita si cammina più piano che in discesa, quindi lo stesso
  tratto ha due tempi diversi nei due versi.

`edge_times` restituisce per ogni polilinea la lista dei tempi (s) per
coppia di vertici consecutivi, (avanti, indietro), da passare a
net_iso.build_metric_graph(edge_costs=...). Puro Python + numpy, tranne
DemGrid che legge il raster con le API QGIS: si costruisce nel worker con
una copia del provider (dataProvider().clone() fatto sul thread principale).
"""
from ..i18n import tr
import math

# Tobler (1993): v = 6 · e^(−3.5·|S + 0.05|) km/h. Qui normalizzata alla
# velocità in piano scelta dall'utente: fattore 1 con pendenza 0, massimo
# (1.19) in leggera discesa (−5 %), 0.70 al +10 %, 0.50 al +20 %.
TOBLER_K = 3.5
TOBLER_S0 = 0.05
TOBLER_MAX = math.exp(TOBLER_K * TOBLER_S0)
# pendenze oltre il 100 % sono rumore del DEM (o pareti), non strade
SLOPE_CAP = 1.0
# passo minimo di campionamento lungo i tratti (m): sotto questa distanza la
# differenza di quota è dominata dal rumore del DEM
MIN_STEP_M = 10.0


def tobler_factor(slope):
    """Velocità relativa a quella in piano per una pendenza (dz/dx)."""
    s = max(-SLOPE_CAP, min(SLOPE_CAP, float(slope)))
    return math.exp(-TOBLER_K * (abs(s + TOBLER_S0) - TOBLER_S0))


def _np_dtype(qgis_type):
    import numpy as np
    from qgis.core import Qgis
    table = {}
    for name, dt in (("Byte", np.uint8), ("UInt16", np.uint16),
                     ("Int16", np.int16), ("UInt32", np.uint32),
                     ("Int32", np.int32), ("Float32", np.float32),
                     ("Float64", np.float64), ("Int8", np.int8)):
        v = getattr(Qgis, name, None)
        if v is None:
            v = getattr(getattr(Qgis, "DataType", object), name, None)
        if v is not None:
            table[int(v)] = dt
    return table.get(int(qgis_type))


class DemGrid(object):
    """Quote da un DEM, lette una volta sola per il riquadro che serve.

    Il blocco del raster che copre `bbox_wgs` (ovest, sud, est, nord) è
    letto in un array numpy; le quote si interpolano in modo bilineare.
    Un raster enorme rispetto all'area si legge sottocampionato (al più
    `max_cells` celle), così la memoria resta limitata.
    """

    def __init__(self, provider, dem_crs, ctx, bbox_wgs, band=1,
                 max_cells=8000000):
        import numpy as np
        from qgis.core import (QgsCoordinateReferenceSystem,
                               QgsCoordinateTransform, QgsRectangle)
        self.ok = False
        self.arr = None
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        self._identity = dem_crs.authid() == "EPSG:4326"
        self._ct = None if self._identity else QgsCoordinateTransform(
            wgs, dem_crs, ctx)
        self.geographic = dem_crs.isGeographic()
        w, s, e, n = bbox_wgs
        rect = QgsRectangle(w, s, e, n)
        if self._ct is not None:
            rect = self._ct.transformBoundingBox(rect)
        ext = provider.extent()
        nx, ny = provider.xSize(), provider.ySize()
        if nx <= 0 or ny <= 0 or ext.width() <= 0 or ext.height() <= 0:
            return
        px = ext.width() / nx
        py = ext.height() / ny
        c0 = max(0, int(math.floor((rect.xMinimum() - ext.xMinimum()) / px)) - 1)
        c1 = min(nx, int(math.ceil((rect.xMaximum() - ext.xMinimum()) / px)) + 1)
        r0 = max(0, int(math.floor((ext.yMaximum() - rect.yMaximum()) / py)) - 1)
        r1 = min(ny, int(math.ceil((ext.yMaximum() - rect.yMinimum()) / py)) + 1)
        if c1 <= c0 or r1 <= r0:
            return  # il DEM non copre l'area
        cols, rows = c1 - c0, r1 - r0
        f = max(1, int(math.ceil(math.sqrt(cols * rows / float(max_cells)))))
        bw = max(1, int(math.ceil(cols / float(f))))
        bh = max(1, int(math.ceil(rows / float(f))))
        aligned = QgsRectangle(ext.xMinimum() + c0 * px,
                               ext.yMaximum() - r1 * py,
                               ext.xMinimum() + c1 * px,
                               ext.yMaximum() - r0 * py)
        block = provider.block(band, aligned, bw, bh)
        if block is None or not block.isValid():
            return
        dt = _np_dtype(block.dataType())
        arr = None
        if dt is not None:
            try:
                raw = bytes(block.data())
                if len(raw) == bw * bh * np.dtype(dt).itemsize:
                    arr = np.frombuffer(raw, dtype=dt).reshape(bh, bw)
                    arr = arr.astype(np.float32)
            except Exception:
                arr = None
        if arr is None:
            # tipo non gestito: lettura cella per cella (lenta ma rara)
            arr = np.empty((bh, bw), np.float32)
            for r in range(bh):
                for c in range(bw):
                    arr[r, c] = block.value(r, c)
        if block.hasNoDataValue():
            arr[arr == np.float32(block.noDataValue())] = np.nan
        else:
            try:
                if provider.sourceHasNoDataValue(band):
                    nd = np.float32(provider.sourceNoDataValue(band))
                    arr[arr == nd] = np.nan
            except Exception:
                pass
        arr[~np.isfinite(arr)] = np.nan
        self.arr = arr
        self.x0 = aligned.xMinimum()
        self.y1 = aligned.yMaximum()
        self.dx = aligned.width() / bw
        self.dy = aligned.height() / bh
        lat_mid = 0.5 * (s + n)
        self.cell_m = (self.dx * 111320.0 * max(0.05, math.cos(
            math.radians(lat_mid))) if self.geographic else self.dx)
        self.ok = bool(np.isfinite(arr).any())

    def heights(self, lons, lats):
        """Quote (array numpy, NaN fuori DEM o senza dato) dei punti lon/lat."""
        import numpy as np
        lons = np.asarray(lons, float)
        lats = np.asarray(lats, float)
        out = np.full(lons.shape, np.nan)
        if not self.ok or lons.size == 0:
            return out
        if self._identity:
            xs, ys = lons, lats
        else:
            from qgis.core import QgsPointXY
            xs = np.empty(lons.shape)
            ys = np.empty(lats.shape)
            xform = self._ct.transform
            for k in range(lons.size):
                try:
                    p = xform(QgsPointXY(lons[k], lats[k]))
                    xs[k], ys[k] = p.x(), p.y()
                except Exception:
                    xs[k] = ys[k] = np.nan
        a = self.arr
        h, w = a.shape
        col = (xs - self.x0) / self.dx - 0.5
        row = (self.y1 - ys) / self.dy - 0.5
        inside = ((col >= -0.5) & (col <= w - 0.5) & (row >= -0.5)
                  & (row <= h - 0.5) & np.isfinite(col) & np.isfinite(row))
        if not inside.any():
            return out
        c = np.clip(col[inside], 0, w - 1)
        r = np.clip(row[inside], 0, h - 1)
        c0 = np.minimum(np.floor(c).astype(int), max(0, w - 2))
        r0 = np.minimum(np.floor(r).astype(int), max(0, h - 2))
        c1 = np.minimum(c0 + 1, w - 1)
        r1 = np.minimum(r0 + 1, h - 1)
        fc = np.clip(c - c0, 0.0, 1.0)
        fr = np.clip(r - r0, 0.0, 1.0)
        z = (a[r0, c0] * (1 - fc) * (1 - fr) + a[r0, c1] * fc * (1 - fr)
             + a[r1, c0] * (1 - fc) * fr + a[r1, c1] * fc * fr)
        # un vicino senza dato: si usa la cella più vicina
        bad = ~np.isfinite(z)
        if bad.any():
            rn = np.clip(np.rint(r[bad]).astype(int), 0, h - 1)
            cn = np.clip(np.rint(c[bad]).astype(int), 0, w - 1)
            z[bad] = a[rn, cn]
        out[inside] = z
        return out


def edge_times(roads_lonlat, speeds_mps=None, default_mps=1.25, dem=None,
               off_terrain=None, is_canceled=None):
    """Tempi (s) per coppia di vertici, nei due versi, per ogni polilinea.

    :param speeds_mps: velocità per polilinea (m/s, None = default_mps).
    :param dem: DemGrid: a piedi il tempo segue la pendenza (Tobler) con
        default_mps come velocità in piano. Ogni tratto è campionato a passi
        di circa una cella del DEM (almeno MIN_STEP_M), così un tratto
        lungo che scavalca un dosso costa di più in entrambi i versi.
    :param off_terrain: per polilinea, True per ponti e gallerie: lì il DEM
        dà la quota del terreno sotto/sopra, non della strada, quindi si
        usa una pendenza costante fra quota d'inizio e di fine.
    :return: (tempi, stats) con tempi[i] = [(t_avanti, t_indietro), ...] e
        stats = {vmax_mps, salita_m, campioni, senza_quota}.
    """
    import numpy as np
    from .net_iso import _projector
    polys = roads_lonlat or []
    first = next((r for r in polys if r), None)
    lat0 = first[0][1] if first else 0.0
    to_m, _ll = _projector(lat0)
    stats = {"vmax_mps": 0.0, "salita_m": 0.0, "campioni": 0,
             "senza_quota": 0}
    lengths = []
    for r in polys:
        pts = [to_m(lo, la) for lo, la in r]
        lengths.append([math.hypot(q[0] - p[0], q[1] - p[1])
                        for p, q in zip(pts, pts[1:])])

    def speed(i):
        v = speeds_mps[i] if speeds_mps is not None and i < len(speeds_mps) \
            else None
        return v if v and v > 0 else default_mps

    if dem is None or not getattr(dem, "ok", False):
        out = []
        for i, ls in enumerate(lengths):
            v = speed(i)
            stats["vmax_mps"] = max(stats["vmax_mps"], v)
            out.append([(L / v, L / v) for L in ls])
        return out, stats

    step = max(MIN_STEP_M, float(getattr(dem, "cell_m", MIN_STEP_M)))
    # campioni lungo tutti i tratti: una sola lettura vettoriale delle quote
    seg_n = []
    lon_s, lat_s = [], []
    for i, r in enumerate(polys):
        if is_canceled and i % 2000 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        flat = bool(off_terrain and i < len(off_terrain) and off_terrain[i])
        ns = []
        for k, L in enumerate(lengths[i]):
            m = 1 if flat else max(1, int(math.ceil(L / step)))
            (ax, ay), (bx, by) = r[k], r[k + 1]
            for j in range(m + 1):
                f = j / float(m)
                lon_s.append(ax + f * (bx - ax))
                lat_s.append(ay + f * (by - ay))
            ns.append(m)
        seg_n.append(ns)
    z = dem.heights(lon_s, lat_s)
    stats["campioni"] = int(z.size)
    stats["senza_quota"] = int(np.count_nonzero(~np.isfinite(z)))
    out = []
    pos = 0
    vmax = 0.0
    climb = 0.0
    for i, r in enumerate(polys):
        v0 = speed(i)
        vmax = max(vmax, v0 * TOBLER_MAX)
        flat = bool(off_terrain and i < len(off_terrain) and off_terrain[i])
        times = []
        if flat and lengths[i]:
            # ponte/galleria: pendenza media fra gli estremi della polilinea
            total = sum(lengths[i])
            za = z[pos]
            zb = z[pos + 2 * len(lengths[i]) - 1]
            slope = ((zb - za) / total if total > 0 and np.isfinite(za)
                     and np.isfinite(zb) else 0.0)
            ff, fb = tobler_factor(slope), tobler_factor(-slope)
            for L in lengths[i]:
                times.append((L / (v0 * ff), L / (v0 * fb)))
            if slope > 0:
                climb += slope * total
            pos += 2 * len(lengths[i])
            out.append(times)
            continue
        for k, L in enumerate(lengths[i]):
            m = seg_n[i][k]
            zz = z[pos:pos + m + 1]
            pos += m + 1
            if L <= 0:
                times.append((0.0, 0.0))
                continue
            dl = L / m
            tf = tb = 0.0
            for j in range(m):
                dz = zz[j + 1] - zz[j]
                if not np.isfinite(dz):
                    dz = 0.0
                s = dz / dl
                tf += dl / (v0 * tobler_factor(s))
                tb += dl / (v0 * tobler_factor(-s))
                if dz > 0:
                    climb += dz
            times.append((tf, tb))
        out.append(times)
    stats["vmax_mps"] = vmax
    stats["salita_m"] = climb
    return out, stats


def costs_for_segments(raw_times, pairs):
    """Tempi dei segmenti puliti (net_clean.clean_network con pairs_out):
    ogni segmento eredita il tempo della coppia di vertici d'origine."""
    out = []
    for ri, k in pairs:
        rt = raw_times[ri] if ri < len(raw_times) else None
        out.append([rt[k]] if rt is not None and k < len(rt) else None)
    return out


def dem_spec(dem, ctx):
    """Raster DEM per un task: copia del provider (thread-safe), CRS, banda
    1. ValueError se il layer non è un raster di quote."""
    if dem is None:
        return None
    from qgis.core import Qgis
    if not dem.isValid() or dem.bandCount() < 1:
        raise ValueError(tr("Il DEM «%s» non è un raster valido.") % dem.name())
    dp = dem.dataProvider()
    if dem.bandCount() >= 3 and dp.dataType(1) == Qgis.Byte:
        raise ValueError(tr("«%s» sembra un'immagine a colori, non un DEM "
                         "(servono quote in metri).") % dem.name())
    return {"provider": dp.clone(), "crs": dem.crs(), "ctx": ctx, "band": 1,
            "name": dem.name()}


def car_cost(field_names, speed_kmh, factor, speed_field=None):
    """Tempi in auto: velocità di ogni strada (campo, limite OSM, tipo di
    strada, default) × factor; strade non carrabili escluse.

    :return: (cost per read_costed_network, velocità massima km/h).
    """
    from . import routing
    names = list(field_names)
    hw = {n.lower(): n for n in names}.get("highway")
    cost = {"speed_of": routing.speed_reader(names, speed_field, speed_kmh,
                                             factor),
            "keep": ((lambda f, _h=hw: routing.car_allowed(f[_h]))
                     if hw else None),
            "default_mps": speed_kmh / 3.6}
    return cost, max(max(routing.DEFAULT_KMH.values()), speed_kmh) * factor
