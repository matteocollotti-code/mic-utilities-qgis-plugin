# -*- coding: utf-8 -*-
"""Decoder GTFS-Realtime puro Python (nessuna dipendenza protobuf).

Il Python di QGIS non include la libreria protobuf, quindi qui viene
implementato un decoder minimale del wire-format protobuf limitato ai
messaggi GTFS-RT che ci servono (FeedMessage -> FeedEntity -> TripUpdate /
VehiclePosition). I numeri di campo seguono la specifica ufficiale
gtfs-realtime.proto e sono stabili.

Riferimento campi (gtfs-realtime.proto):
  FeedMessage:      header=1, entity=2(repeated)
  FeedHeader:       gtfs_realtime_version=1, incrementality=2, timestamp=3
  FeedEntity:       id=1, is_deleted=2, trip_update=3, vehicle=4, alert=5
  TripUpdate:       trip=1, stop_time_update=2(repeated), vehicle=3,
                    timestamp=4, delay=5
  StopTimeUpdate:   stop_sequence=1, stop_id=4, arrival=2, departure=3,
                    schedule_relationship=5
  StopTimeEvent:    delay=1, time=2, uncertainty=3
  TripDescriptor:   trip_id=1, start_time=2, start_date=3,
                    schedule_relationship=4, route_id=5, direction_id=6
  VehiclePosition:  trip=1, position=2, current_stop_sequence=3,
                    current_status=4, timestamp=5, stop_id=7, vehicle=8
  Position:         latitude=1, longitude=2, bearing=3, odometer=4, speed=5
"""
try:
    from ..i18n import tr
except ImportError:   # modulo usato da solo (puro Python, senza QGIS)
    def tr(text):
        return text
import struct

WIRE_VARINT = 0
WIRE_64BIT = 1
WIRE_LEN = 2
WIRE_32BIT = 5


# --------------------------------------------------------------- low level
class FeedTruncated(ValueError):
    """Messaggio protobuf incompleto (download interrotto)."""


def _read_varint(buf, pos):
    result = 0
    shift = 0
    n = len(buf)
    while True:
        if pos >= n:
            raise FeedTruncated(tr("feed GTFS-RT troncato (varint incompleto)"))
        b = buf[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not b & 0x80:
            return result, pos
        shift += 7


def _iter_fields(buf):
    """Itera i campi di un messaggio protobuf: yield (field, wire_type, raw)."""
    pos = 0
    n = len(buf)
    while pos < n:
        key, pos = _read_varint(buf, pos)
        field = key >> 3
        wt = key & 0x07
        if wt == WIRE_VARINT:
            val, pos = _read_varint(buf, pos)
            yield field, wt, val
            continue
        if wt == WIRE_64BIT:
            ln = 8
        elif wt == WIRE_LEN:
            ln, pos = _read_varint(buf, pos)
        elif wt == WIRE_32BIT:
            ln = 4
        else:
            raise ValueError(tr("Wire type protobuf non supportato: %d") % wt)
        if pos + ln > n:
            # prima si leggeva in silenzio un pezzo del messaggio
            raise FeedTruncated(tr("feed GTFS-RT troncato: servono %d byte, "
                                "ne restano %d") % (ln, n - pos))
        val = buf[pos:pos + ln]
        pos += ln
        yield field, wt, val


def _signed(value):
    """Interpreta un varint come intero con segno (int32/int64 a complemento)."""
    if value >= (1 << 63):
        return value - (1 << 64)
    return value


def _as_float(raw):
    return struct.unpack("<f", raw)[0]


def _as_double(raw):
    return struct.unpack("<d", raw)[0]


def _as_str(raw):
    return raw.decode("utf-8", "replace")


# ------------------------------------------------------------ messaggi GTFS
def _parse_trip_descriptor(buf):
    out = {}
    for field, wt, val in _iter_fields(buf):
        if field == 1 and wt == WIRE_LEN:
            out["trip_id"] = _as_str(val)
        elif field == 2 and wt == WIRE_LEN:
            out["start_time"] = _as_str(val)
        elif field == 3 and wt == WIRE_LEN:
            out["start_date"] = _as_str(val)
        elif field == 4 and wt == WIRE_VARINT:
            out["schedule_relationship"] = val  # 3 = CANCELED
        elif field == 5 and wt == WIRE_LEN:
            out["route_id"] = _as_str(val)
        elif field == 6 and wt == WIRE_VARINT:
            out["direction_id"] = val
    return out


def _parse_stop_time_event(buf):
    out = {}
    for field, wt, val in _iter_fields(buf):
        if field == 1 and wt == WIRE_VARINT:
            out["delay"] = _signed(val)
        elif field == 2 and wt == WIRE_VARINT:
            out["time"] = _signed(val)
        elif field == 3 and wt == WIRE_VARINT:
            out["uncertainty"] = _signed(val)
    return out


def _parse_stop_time_update(buf):
    out = {"arrival": None, "departure": None}
    for field, wt, val in _iter_fields(buf):
        if field == 1 and wt == WIRE_VARINT:
            out["stop_sequence"] = val
        elif field == 4 and wt == WIRE_LEN:
            out["stop_id"] = _as_str(val)
        elif field == 2 and wt == WIRE_LEN:
            out["arrival"] = _parse_stop_time_event(val)
        elif field == 3 and wt == WIRE_LEN:
            out["departure"] = _parse_stop_time_event(val)
        elif field == 5 and wt == WIRE_VARINT:
            out["schedule_relationship"] = val
    return out


def _parse_trip_update(buf):
    out = {"trip": {}, "stop_time_updates": []}
    for field, wt, val in _iter_fields(buf):
        if field == 1 and wt == WIRE_LEN:
            out["trip"] = _parse_trip_descriptor(val)
        elif field == 2 and wt == WIRE_LEN:
            out["stop_time_updates"].append(_parse_stop_time_update(val))
        elif field == 4 and wt == WIRE_VARINT:
            out["timestamp"] = val
        elif field == 5 and wt == WIRE_VARINT:
            out["delay"] = _signed(val)
    return out


def _parse_position(buf):
    out = {}
    for field, wt, val in _iter_fields(buf):
        if field == 1 and wt == WIRE_32BIT:
            out["latitude"] = _as_float(val)
        elif field == 2 and wt == WIRE_32BIT:
            out["longitude"] = _as_float(val)
        elif field == 3 and wt == WIRE_32BIT:
            out["bearing"] = _as_float(val)
        elif field == 4 and wt == WIRE_64BIT:
            out["odometer"] = _as_double(val)
        elif field == 5 and wt == WIRE_32BIT:
            out["speed"] = _as_float(val)
    return out


def _parse_vehicle_position(buf):
    out = {"trip": {}, "position": {}}
    for field, wt, val in _iter_fields(buf):
        if field == 1 and wt == WIRE_LEN:
            out["trip"] = _parse_trip_descriptor(val)
        elif field == 2 and wt == WIRE_LEN:
            out["position"] = _parse_position(val)
        elif field == 3 and wt == WIRE_VARINT:
            out["current_stop_sequence"] = val
        elif field == 5 and wt == WIRE_VARINT:
            out["timestamp"] = val
        elif field == 7 and wt == WIRE_LEN:
            out["stop_id"] = _as_str(val)
    return out


def parse_feed(data):
    """Decodifica un FeedMessage GTFS-RT (bytes).

    :return: dict {'trip_updates': [...], 'vehicle_positions': [...],
        'timestamp': istante del feed (epoch s) o None}
    :raises FeedTruncated: se il messaggio è incompleto.
    """
    trip_updates = []
    vehicle_positions = []
    timestamp = None
    for field, wt, val in _iter_fields(data):
        if field == 1 and wt == WIRE_LEN:
            for hfield, hwt, hval in _iter_fields(val):
                if hfield == 3 and hwt == WIRE_VARINT:
                    timestamp = hval
            continue
        if field != 2 or wt != WIRE_LEN:
            continue  # 2 = entity
        for efield, ewt, eval_ in _iter_fields(val):
            if efield == 3 and ewt == WIRE_LEN:
                trip_updates.append(_parse_trip_update(eval_))
            elif efield == 4 and ewt == WIRE_LEN:
                vehicle_positions.append(_parse_vehicle_position(eval_))
    return {"trip_updates": trip_updates, "vehicle_positions": vehicle_positions,
            "timestamp": timestamp}
