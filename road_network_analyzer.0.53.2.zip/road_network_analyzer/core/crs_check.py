# -*- coding: utf-8 -*-
"""Controlli dei CRS prima dei calcoli su rete (isocrone e simili).

Tutti i calcoli riportano rete, sorgenti, punti di interesse e DEM in
WGS84 (lon/lat): i CRS diversi vanno bene. Gli errori veri sono i layer
senza CRS e quelli con il CRS dichiarato male (per esempio coordinate in
metri in un layer dichiarato in gradi): qui li si riconosce e si dice quale
layer controllare, invece di «nessuna sorgente aggancia la rete».
"""
from ..i18n import tr
import math


def _wgs():
    from qgis.core import QgsCoordinateReferenceSystem
    return QgsCoordinateReferenceSystem("EPSG:4326")


def crs_problem(layer):
    """Testo dell'errore se il layer non ha un CRS valido, altrimenti None."""
    if layer is None:
        return None
    if not layer.crs().isValid():
        return tr("Il layer «%s» è senza CRS: impostalo (Proprietà del layer "
                  "→ Sorgente → Sistema di riferimento) e riprova.") % \
            layer.name()
    return None


def valid_lonlat(lat, lon):
    return (isinstance(lat, (int, float)) and isinstance(lon, (int, float))
            and math.isfinite(lat) and math.isfinite(lon)
            and -90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0)


def extent_wgs(layer, ctx):
    """Riquadro (ovest, sud, est, nord) del layer in WGS84, None se vuoto o
    non trasformabile, False se le coordinate escono dai limiti WGS84 (CRS
    dichiarato male)."""
    from qgis.core import QgsCoordinateTransform
    ext = layer.extent()
    count = layer.featureCount() if hasattr(layer, "featureCount") else 1
    if ext is None or ext.isEmpty() or not count:
        return None
    if layer.crs().isGeographic() and (abs(ext.xMaximum()) > 180.5 or
                                       abs(ext.xMinimum()) > 180.5 or
                                       abs(ext.yMaximum()) > 90.5 or
                                       abs(ext.yMinimum()) > 90.5):
        return False
    try:
        r = QgsCoordinateTransform(layer.crs(), _wgs(), ctx) \
            .transformBoundingBox(ext)
    except Exception:
        return None
    vals = (r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum())
    if not all(math.isfinite(v) for v in vals):
        return False
    if not (valid_lonlat(vals[1], vals[0]) and valid_lonlat(vals[3], vals[2])):
        return False
    return vals


def km_to_box(lat, lon, box):
    """Distanza (km) da un punto al riquadro (0 dentro)."""
    w, s, e, n = box
    cla = min(max(lat, s), n)
    clo = min(max(lon, w), e)
    if cla == lat and clo == lon:
        return 0.0
    p1, p2 = math.radians(lat), math.radians(cla)
    a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * \
        math.sin(math.radians(clo - lon) / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(min(1.0, a)))


def check_network_inputs(road, ctx, coords, src_label, src_layer=None,
                         others=(), radius_m=0.0):
    """Controlli prima di un calcolo su rete.

    :param road: layer della rete (o None, es. TP senza rete).
    :param coords: sorgenti già in WGS84 [(lat, lon)].
    :param src_label: chi sono le sorgenti nei messaggi («il layer «X»», «i
        punti scelti sulla mappa»).
    :param others: altri layer usati (punti di interesse, DEM…).
    :return: (errore o None, nota per il messaggio, sorgenti da usare).
    """
    for lay in [road, src_layer] + list(others):
        err = crs_problem(lay)
        if err:
            return err, "", coords
    bad = [c for c in coords if not valid_lonlat(*c)]
    if bad and src_layer is None:
        return (tr("Le sorgenti (%s) non sono coordinate valide: il progetto "
                   "ha un CRS? (Progetto → Proprietà → SR; con la rete "
                   "scelta si usa il suo CRS)") % src_label), "", coords
    if bad:
        crs = src_layer.crs().authid()
        return (tr("Le sorgenti (%s) non sono coordinate valide nel loro "
                   "CRS (%s): il CRS del layer è dichiarato male? (per "
                   "esempio coordinate in metri in un layer in gradi)")
                % (src_label, crs)), "", coords
    note = ""
    if road is None:
        return None, note, coords
    box = extent_wgs(road, ctx)
    if box is False:
        return (tr("Le coordinate della rete «%s» escono dai limiti del suo "
                   "CRS (%s): il CRS del layer è dichiarato male?")
                % (road.name(), road.crs().authid())), "", coords
    crss = {road.crs().authid()}
    if src_layer is not None:
        crss.add(src_layer.crs().authid())
    crss.update(l.crs().authid() for l in others if l is not None)
    if len(crss) > 1:
        note = tr("CRS diversi (%s) riportati tutti in WGS84 per il "
                  "calcolo. ") % ", ".join(sorted(crss))
    if not box or not coords:
        return None, note, coords
    margin = max(1.0, radius_m / 1000.0)
    dist = [km_to_box(la, lo, box) for la, lo in coords]
    near = [c for c, d in zip(coords, dist) if d <= margin]
    if not near:
        return (tr("Le sorgenti (%s) sono lontane dalla rete «%s»: la più "
                   "vicina a %s km. Controlla che i layer siano nella stessa "
                   "zona e con il CRS giusto (rete in %s%s).")
                % (src_label, road.name(), "%.0f" % min(dist) if min(dist) >= 10
                   else "%.1f" % min(dist), road.crs().authid(),
                   (tr(", sorgenti in %s") % src_layer.crs().authid())
                   if src_layer is not None else "")), "", coords
    if len(near) < len(coords):
        note += tr("%d sorgenti lontane dalla rete (oltre %.0f km) "
                   "escluse. ") % (len(coords) - len(near), margin)
    return None, note, near


def _gap_km(a, b):
    """Distanza (km, circa) fra due riquadri WGS84; 0 se si toccano."""
    dx = max(0.0, a[0] - b[2], b[0] - a[2])
    dy = max(0.0, a[1] - b[3], b[1] - a[3])
    lat = (a[1] + a[3] + b[1] + b[3]) / 4.0
    return math.hypot(dx * 111.32 * math.cos(math.radians(lat)), dy * 110.57)


def check_layers(layers, ctx, max_gap_km=50.0):
    """Controllo dei layer di un'analisi, prima di usarli. Errore (testo)
    o None: layer senza CRS; coordinate fuori dai limiti del suo CRS (CRS
    dichiarato male, per esempio metri in un layer in gradi); un layer
    lontano più di `max_gap_km` dagli altri (CRS sbagliato, per esempio
    gradi in un layer proiettato, che finiscono vicino a lat 0, lon 0)."""
    lays = [l for l in layers if l is not None]
    for lay in lays:
        err = crs_problem(lay)
        if err:
            return err
    boxes = []
    for lay in lays:
        b = extent_wgs(lay, ctx)
        if b is False:
            return tr("Le coordinate del layer «%s» escono dai limiti del suo "
                      "CRS (%s): il CRS del layer è dichiarato male? (per "
                      "esempio coordinate in metri in un layer in gradi)") % (
                lay.name(), lay.crs().authid())
        if b:
            if max(abs(b[0]), abs(b[2])) < 1.0 and max(abs(b[1]), abs(b[3])) < 1.0:
                # tutto vicino a lat 0, lon 0: gradi in un layer dichiarato
                # proiettato (o metri piccoli dichiarati in gradi)
                return tr("Il layer «%s» cade vicino a latitudine 0, "
                          "longitudine 0: il CRS del layer (%s) è dichiarato "
                          "male?") % (lay.name(), lay.crs().authid())
            boxes.append((lay, b))
    if len(boxes) < 2:
        return None
    worst = None
    for i, (lay, b) in enumerate(boxes):
        # per posizione: lo stesso layer può comparire due volte (es. un
        # confronto di un layer con sé stesso)
        others = [o for j, (_l2, o) in enumerate(boxes) if j != i]
        u = (min(o[0] for o in others), min(o[1] for o in others),
             max(o[2] for o in others), max(o[3] for o in others))
        d = _gap_km(b, u)
        if worst is None or d > worst[0]:
            worst = (d, lay)
    if worst[0] > max_gap_km:
        d, lay = worst
        return tr("Il layer «%s» (%s) è a %s km dagli altri layer dell'analisi "
                  "(%s): controlla che sia nella stessa zona e con il CRS "
                  "giusto.") % (lay.name(), lay.crs().authid(), "%.0f" % d,
                                ", ".join("«%s» %s" % (l.name(), l.crs().authid())
                                          for l, _b in boxes if l is not lay)
                                or lay.name())
    return None
