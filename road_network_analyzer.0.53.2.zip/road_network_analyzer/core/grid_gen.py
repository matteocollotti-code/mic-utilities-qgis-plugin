# -*- coding: utf-8 -*-
"""Generazione di griglie regolari (esagonali o quadrate) per l'analisi."""
from ..i18n import tr
import math

# oltre questo numero di celle la griglia non si costruisce nemmeno (prima
# il limite delle analisi si controllava a celle già generate)
MAX_CELLS = 2000000


def build_grid(lat0, lat1, lon0, lon1, cell_m, shape="hex"):
    """Genera una griglia che copre il riquadro [lat0,lat1] x [lon0,lon1].

    :param cell_m: dimensione cella in metri (circumraggio per gli esagoni,
        lato per i quadrati).
    :param shape: "hex" o "square".
    :return: (centroids, cells) con
        centroids = [(lat, lon), ...] (per l'analisi)
        cells     = [[(lat, lon), ...], ...] (anelli poligonali)
    """
    if lat1 < lat0:
        lat0, lat1 = lat1, lat0
    if lon1 < lon0:
        lon0, lon1 = lon1, lon0
    if not (-90.0 <= lat0 <= 90.0 and -90.0 <= lat1 <= 90.0
            and -180.0 <= lon0 <= 180.0 and -180.0 <= lon1 <= 180.0):
        # coordinate non in gradi (layer senza CRS o con il CRS sbagliato):
        # senza questo controllo si generavano milioni di milioni di celle
        raise ValueError(tr("Il riquadro della griglia non è in gradi "
                            "(%.0f, %.0f – %.0f, %.0f): il layer o la mappa "
                            "hanno il CRS giusto?") % (lon0, lat0, lon1,
                                                        lat1))
    mlat = 111000.0
    mlon = 111000.0 * math.cos(math.radians((lat0 + lat1) / 2.0))
    centroids = []
    cells = []
    s = float(cell_m)
    n_est = (lat1 - lat0) * mlat * (lon1 - lon0) * mlon / max(1.0, s * s)
    if n_est > MAX_CELLS:
        raise ValueError(tr("Griglia troppo grande (circa %d celle): aumenta "
                            "la cella o riduci l'area.") % n_est)

    if shape == "square":
        ny = int((lat1 - lat0) * mlat / s) + 1
        nx = int((lon1 - lon0) * mlon / s) + 1
        for iy in range(ny):
            for ix in range(nx):
                cx = lon0 * mlon + (ix + 0.5) * s
                cy = lat0 * mlat + (iy + 0.5) * s
                clon, clat = cx / mlon, cy / mlat
                ring = [
                    ((cx - s / 2) / mlon, (cy - s / 2) / mlat),
                    ((cx + s / 2) / mlon, (cy - s / 2) / mlat),
                    ((cx + s / 2) / mlon, (cy + s / 2) / mlat),
                    ((cx - s / 2) / mlon, (cy + s / 2) / mlat),
                ]
                centroids.append((clat, clon))
                cells.append([(la, lo) for lo, la in ring])
        return centroids, cells

    # esagoni pointy-top. Ogni punto del riquadro sta in un esagono il cui
    # centro dista al massimo s (circumraggio): si tengono tutti gli esagoni
    # con il centro entro s dal riquadro, così i bordi sono coperti per intero
    dx = math.sqrt(3) * s
    dy = 1.5 * s
    xmin, xmax = lon0 * mlon, lon1 * mlon
    ymin, ymax = lat0 * mlat, lat1 * mlat
    row = 0
    y = ymin - dy
    while y <= ymax + dy:
        x = xmin - dx + (dx / 2 if row % 2 else 0)
        while x <= xmax + dx:
            if not (xmin - s <= x <= xmax + s and ymin - s <= y <= ymax + s):
                x += dx
                continue
            clat, clon = y / mlat, x / mlon
            ring = []
            for k in range(6):
                ang = math.radians(60 * k - 30)
                vx = (x + s * math.cos(ang)) / mlon
                vy = (y + s * math.sin(ang)) / mlat
                ring.append((vy, vx))
            centroids.append((clat, clon))
            cells.append(ring)
            x += dx
        row += 1
        y += dy
    return centroids, cells
