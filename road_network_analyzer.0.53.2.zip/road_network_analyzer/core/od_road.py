# -*- coding: utf-8 -*-
"""Matrice origine-destinazione di tempi e distanze sulla rete stradale.

Per ogni origine un solo calcolo di cammini minimi verso tutte le
destinazioni: il percorso è il più veloce (tempi per tratto e per verso di
travel_cost: velocità di ogni strada in auto, pendenza a piedi con il DEM)
e per quel percorso si riportano tempo e lunghezza. I punti si agganciano
al punto più vicino della strada, come nelle isocrone e nei percorsi; un
punto vicino a un pezzo di rete isolato (rampa, strada privata) si aggancia
alla rete principale se ce n'è una entro il raggio di aggancio.

Con scipy (incluso in QGIS) i cammini minimi si calcolano in C; senza,
in Python puro (più lento su reti grandi, stesso risultato).
"""
from ..i18n import tr
import heapq
import math

NAN = float("nan")


def _components(graph):
    from .routing import _components as comp
    return comp(graph)


def _seeds_out(graph, info):
    """[(nodo, secondi, metri)] dal piede dell'origine agli estremi del suo
    arco, nei versi percorribili."""
    a, b = info["edge"]
    L, t = info["L"], info["t"]
    out = []
    for node, other, m in ((b, a, (1.0 - t) * L), (a, b, t * L)):
        if m < 0.01:
            out.append((node, 0.0, 0.0))
        elif graph.can_go(other, node):
            out.append((node, m * graph.rate(other, node, L), m))
    return out


def _seeds_in(graph, info):
    """[(nodo, secondi, metri)] dagli estremi dell'arco al piede della
    destinazione, nei versi percorribili."""
    a, b = info["edge"]
    L, t = info["L"], info["t"]
    out = []
    for node, other, m in ((a, b, t * L), (b, a, (1.0 - t) * L)):
        if m < 0.01:
            out.append((node, 0.0, 0.0))
        elif graph.can_go(node, other):
            out.append((node, m * graph.rate(node, other, L), m))
    return out


def _same_edge(graph, si, di):
    """(secondi, metri) diretti lungo lo stesso arco, o None."""
    if si["edge"] != di["edge"]:
        return None
    a, b = si["edge"]
    L = si["L"]
    ts, td = si["t"], di["t"]
    best = None
    if td >= ts and graph.can_go(a, b):
        best = ((td - ts) * L * graph.rate(a, b, L), (td - ts) * L)
    if td <= ts and graph.can_go(b, a):
        c = ((ts - td) * L * graph.rate(b, a, L), (ts - td) * L)
        if best is None or c[0] < best[0]:
            best = c
    return best


def _dijkstra_py(adj, elen, n, seeds, targets, max_s, is_canceled=None):
    """Tempi e lunghezze (lungo il percorso più veloce) dai seed."""
    inf = float("inf")
    tm = [inf] * n
    ln = [0.0] * n
    heap = []
    for node, s, m in seeds:
        if s < tm[node]:
            tm[node] = s
            ln[node] = m
            heapq.heappush(heap, (s, node))
    left = set(targets)
    done = 0
    while heap and left:
        c, v = heapq.heappop(heap)
        if c > tm[v]:
            continue
        left.discard(v)
        done += 1
        if is_canceled and done % 20000 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        for w, cost in adj[v]:
            nc = c + cost
            if nc < tm[w] and nc <= max_s:
                tm[w] = nc
                ln[w] = ln[v] + elen[(v, w)]
                heapq.heappush(heap, (nc, w))
    return tm, ln


class _ScipyRunner(object):
    """Cammini minimi con scipy.sparse.csgraph: un nodo virtuale per origine
    collegato agli estremi del suo arco; lunghezze ricostruite dai
    predecessori solo per i nodi che servono."""

    def __init__(self, graph, elen):
        import numpy as np
        from scipy.sparse import csr_matrix  # noqa: F401
        self.np = np
        self.graph = graph
        self.elen = elen
        rows, cols, data = [], [], []
        for (u, v), c in graph.ecost.items():
            rows.append(u)
            cols.append(v)
            data.append(max(c, 1e-6))
        self.rows, self.cols, self.data = rows, cols, data

    def run(self, seeds_list, targets, max_s):
        """seeds_list = [[(nodo, s, m)] per origine] → [(tm, ln)] con tm e ln
        dict nodo → valore per i soli nodi in targets."""
        np = self.np
        from scipy.sparse import csr_matrix
        from scipy.sparse.csgraph import dijkstra
        n = self.graph.n
        k = len(seeds_list)
        rows, cols, data = list(self.rows), list(self.cols), list(self.data)
        vlen = {}
        for i, seeds in enumerate(seeds_list):
            for node, s, m in seeds:
                rows.append(n + i)
                cols.append(node)
                data.append(max(s, 1e-9))
                vlen[(n + i, node)] = m
        mat = csr_matrix((data, (rows, cols)), shape=(n + k, n + k))
        idx = list(range(n, n + k))
        try:
            dist, pred = dijkstra(mat, directed=True, indices=idx,
                                  return_predecessors=True, limit=max_s)
        except TypeError:  # scipy senza «limit»
            dist, pred = dijkstra(mat, directed=True, indices=idx,
                                  return_predecessors=True)
        out = []
        tl = list(targets)
        for i in range(k):
            drow = dist[i]
            prow = pred[i]
            src = n + i
            memo = {src: 0.0}
            tm, ln = {}, {}
            for t in tl:
                d = drow[t]
                if not np.isfinite(d) or d > max_s:
                    continue
                path = []
                v = t
                while v not in memo:
                    p = int(prow[v])
                    if p < 0:
                        break
                    path.append((p, v))
                    v = p
                if v not in memo:
                    continue
                base = memo[v]
                for p, u in reversed(path):
                    base += (vlen[(p, u)] if p >= n else self.elen[(p, u)])
                    memo[u] = base
                tm[t] = float(d)
                ln[t] = memo[t]
            out.append((tm, ln))
        return out


def road_od_matrix(roads, origins, dests, directions=None, edge_costs=None,
                   snap_m=500.0, max_min=None, use_scipy=True, progress=None,
                   is_canceled=None):
    """Tempi (s) e distanze (m) fra ogni origine e ogni destinazione.

    :param roads: segmenti puliti (lon/lat); edge_costs = tempi per
        segmento e verso (travel_cost), obbligatori.
    :param origins, dests: [(id, lat, lon)].
    :param max_min: oltre questo tempo la coppia è «non raggiungibile»
        (None = nessun limite).
    :return: dict {time_s: [[...]], dist_m: [[...]] (None se non
        raggiungibile), o_snap / d_snap: distanza di aggancio (m, None se
        fuori rete), o_moved / d_moved: agganciati alla rete principale
        invece che a un pezzo isolato, engine: "scipy" o "python"}.
    """
    from . import net_iso
    if edge_costs is None:
        raise ValueError(tr("Servono i tempi di percorrenza dei tratti."))
    pts = list(origins) + list(dests)
    if not pts:
        raise ValueError(tr("Nessun punto."))
    lat0 = sum(p[1] for p in pts) / len(pts)
    graph = net_iso.build_metric_graph(roads, lat0, directions=directions,
                                       edge_costs=edge_costs)
    if graph.n == 0:
        raise ValueError(tr("Rete vuota."))
    if progress:
        progress(10)
    elen = {}
    for a, b, d in graph.edges:
        if d < elen.get((a, b), float("inf")):
            elen[(a, b)] = d
            elen[(b, a)] = d
    comp = _components(graph)
    sizes = {}
    for c in comp:
        sizes[c] = sizes.get(c, 0) + 1
    main = max(sizes, key=sizes.get)

    def snap(lat, lon):
        info = graph.snap_edge_ll(lat, lon, snap_m)
        moved = False
        if info is not None and comp[info["edge"][0]] != main:
            alt = graph.snap_edge_ll(lat, lon, snap_m,
                                     accept=lambda e: comp[e[0]] == main)
            if alt is not None:
                info, moved = alt, True
        dist = None
        if info is not None:
            px, py = graph.to_m(lon, lat)
            dist = math.hypot(px - info["foot"][0], py - info["foot"][1])
        return info, dist, moved

    osn = [snap(la, lo) for _i, la, lo in origins]
    dsn = [snap(la, lo) for _i, la, lo in dests]
    dseeds = [(_seeds_in(graph, d[0]) if d[0] is not None else [])
              for d in dsn]
    targets = {n for s in dseeds for n, _s, _m in s}
    max_s = float(max_min) * 60.0 if max_min else float("inf")
    by_edge = {}
    for j, (info, _d, _m) in enumerate(dsn):
        if info is not None:
            by_edge.setdefault(info["edge"], []).append(j)

    runner = None
    if use_scipy:
        try:
            runner = _ScipyRunner(graph, elen)
        except Exception:
            runner = None
    adj = graph.adj
    no, nd = len(origins), len(dests)
    T = [[None] * nd for _ in range(no)]
    D = [[None] * nd for _ in range(no)]
    batch = max(1, min(64, int(4e7 // max(1, graph.n * 8))))
    i0 = 0
    while i0 < no:
        if is_canceled and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        ids = list(range(i0, min(no, i0 + (batch if runner else 1))))
        seeds = [(_seeds_out(graph, osn[i][0]) if osn[i][0] is not None
                  else []) for i in ids]
        if runner is not None:
            res = runner.run(seeds, targets, max_s)
        else:
            res = []
            for s in seeds:
                tm, ln = _dijkstra_py(adj, elen, graph.n, s, targets, max_s,
                                      is_canceled)
                res.append((tm, ln))
        for k, i in enumerate(ids):
            sinfo = osn[i][0]
            if sinfo is None:
                continue
            tm, ln = res[k]
            get_t = tm.get if isinstance(tm, dict) else (
                lambda n, _d=None, _t=tm: _t[n])
            get_l = ln.get if isinstance(ln, dict) else (
                lambda n, _d=None, _l=ln: _l[n])
            for j in range(nd):
                best = None
                for node, s, m in dseeds[j]:
                    tv = get_t(node, None)
                    if tv is None or tv == float("inf"):
                        continue
                    c = (tv + s, get_l(node, 0.0) + m)
                    if best is None or c[0] < best[0]:
                        best = c
                if j in by_edge.get(sinfo["edge"], ()):
                    c = _same_edge(graph, sinfo, dsn[j][0])
                    if c is not None and (best is None or c[0] < best[0]):
                        best = c
                if best is not None and best[0] <= max_s:
                    T[i][j], D[i][j] = best
        i0 = ids[-1] + 1
        if progress:
            progress(10 + int(88 * i0 / max(1, no)))
    if progress:
        progress(100)
    return {"time_s": T, "dist_m": D,
            "o_snap": [d for _i, d, _m in osn], "d_snap": [d for _i, d, _m in dsn],
            "o_moved": [m for _i, _d, m in osn], "d_moved": [m for _i, _d, m in dsn],
            "engine": "scipy" if runner is not None else "python"}


def write_excel(path, o_ids, d_ids, res, params):
    """Matrice in un .xlsx: tempi, distanze, elenco delle coppie, parametri.

    :param params: [(etichetta, valore)] per il foglio «Parametri».
    """
    from .excel_report import xlsxwriter
    wb = xlsxwriter.Workbook(path, {"nan_inf_to_errors": True,
                                    "constant_memory": False})
    bold = wb.add_format({"bold": True, "bg_color": "#E8EEF4", "border": 1})
    num1 = wb.add_format({"num_format": "0.0"})
    num2 = wb.add_format({"num_format": "0.00"})
    T, D = res["time_s"], res["dist_m"]
    no, nd = len(o_ids), len(d_ids)
    square = nd <= 16000

    def matrix(name, values, fmt, scale):
        ws = wb.add_worksheet(name)
        ws.write(0, 0, tr("Origine \\ Destinazione"), bold)
        for j, d in enumerate(d_ids):
            ws.write(0, j + 1, d, bold)
        for i, o in enumerate(o_ids):
            ws.write(i + 1, 0, o, bold)
            row = values[i]
            for j in range(nd):
                v = row[j]
                if v is not None:
                    ws.write_number(i + 1, j + 1, v * scale, fmt)
        ws.freeze_panes(1, 1)
        ws.set_column(0, 0, 18)
        if no and nd:
            ws.conditional_format(1, 1, no, nd, {
                "type": "3_color_scale", "min_color": "#1A9850",
                "mid_color": "#FEE08B", "max_color": "#D73027"})

    if square:
        matrix(tr("Tempi (min)"), T, num1, 1.0 / 60.0)
        matrix(tr("Distanze (km)"), D, num2, 1.0 / 1000.0)
    ws = wb.add_worksheet(tr("Coppie"))
    head = [tr("Origine"), tr("Destinazione"), tr("Tempo (min)"), tr("Distanza (km)"),
            tr("Velocità media (km/h)"), tr("Raggiungibile")]
    for c, h in enumerate(head):
        ws.write(0, c, h, bold)
    r = 1
    for i, o in enumerate(o_ids):
        for j, d in enumerate(d_ids):
            ws.write(r, 0, o)
            ws.write(r, 1, d)
            t, m = T[i][j], D[i][j]
            if t is not None:
                ws.write_number(r, 2, t / 60.0, num1)
                ws.write_number(r, 3, m / 1000.0, num2)
                if t > 0:
                    ws.write_number(r, 4, m / t * 3.6, num1)
                ws.write(r, 5, tr("sì"))
            else:
                ws.write(r, 5, "no")
            r += 1
    ws.freeze_panes(1, 0)
    ws.autofilter(0, 0, max(1, r - 1), len(head) - 1)
    ws.set_column(0, 1, 16)
    ws.set_column(2, 5, 14)
    wp = wb.add_worksheet(tr("Parametri"))
    rows = list(params)
    rows.append((tr("Motore di calcolo"), res.get("engine", "")))
    o_miss = [o for o, s in zip(o_ids, res["o_snap"]) if s is None]
    d_miss = [d for d, s in zip(d_ids, res["d_snap"]) if s is None]
    o_mv = [o for o, m in zip(o_ids, res["o_moved"]) if m]
    d_mv = [d for d, m in zip(d_ids, res["d_moved"]) if m]
    rows += [(tr("Origini fuori rete"), ", ".join(map(str, o_miss)) or "nessuna"),
             (tr("Destinazioni fuori rete"), ", ".join(map(str, d_miss)) or "nessuna"),
             (tr("Origini agganciate alla rete principale (vicino c'era solo "
              "un pezzo isolato)"), ", ".join(map(str, o_mv)) or "nessuna"),
             (tr("Destinazioni agganciate alla rete principale"),
              ", ".join(map(str, d_mv)) or "nessuna")]
    if not square:
        rows.append((tr("Nota"), tr("Più di 16 000 destinazioni: le matrici non "
                     "entrano in un foglio Excel, vedi «Coppie».")))
    for k, (a, b) in enumerate(rows):
        wp.write(k, 0, a, bold)
        wp.write(k, 1, b)
    wp.set_column(0, 0, 48)
    wp.set_column(1, 1, 60)
    wb.close()
    return path


def build_lines_layer(o_pts, d_pts, res, name=tr("MIC - Matrice OD su strada")):
    """Linee origine → destinazione (in linea d'aria) con tempo e distanza
    di rete, colorate per tempo. o_pts/d_pts = [(id, lat, lon)]."""
    from qgis.PyQt.QtCore import QVariant
    from qgis.PyQt.QtGui import QColor
    from qgis.core import (QgsFeature, QgsField, QgsGeometry, QgsPointXY,
                           QgsGradientColorRamp, QgsSymbol)
    from . import style_util
    from .isochrones import WGS84
    layer = style_util.memory_layer("LineString", WGS84, name)
    layer.dataProvider().addAttributes([
        QgsField("origine", QVariant.String),
        QgsField("destinazione", QVariant.String),
        QgsField("tempo_min", QVariant.Double),
        QgsField("distanza_km", QVariant.Double),
        QgsField("vel_kmh", QVariant.Double),
    ])
    layer.updateFields()
    feats = []
    T, D = res["time_s"], res["dist_m"]
    for i, (oid, ola, olo) in enumerate(o_pts):
        for j, (did, dla, dlo) in enumerate(d_pts):
            t = T[i][j]
            # stesso punto (anche da layer in CRS diversi: le coordinate
            # riproiettate differiscono di miliardesimi di grado)
            if t is None or (abs(ola - dla) < 1e-5 and abs(olo - dlo) < 1e-5):
                continue
            f = QgsFeature(layer.fields())
            f.setGeometry(QgsGeometry.fromPolylineXY(
                [QgsPointXY(olo, ola), QgsPointXY(dlo, dla)]))
            m = D[i][j]
            f.setAttributes([str(oid), str(did), round(t / 60.0, 2),
                             round(m / 1000.0, 3),
                             round(m / t * 3.6, 1) if t > 0 else None])
            feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    vals = {f["tempo_min"] for f in feats}
    if len(vals) >= 2:
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        ramp = QgsGradientColorRamp(QColor(26, 152, 80), QColor(215, 48, 39))
        r = style_util.graduated_from(layer, "tempo_min", min(5, len(vals)),
                                      sym, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer
