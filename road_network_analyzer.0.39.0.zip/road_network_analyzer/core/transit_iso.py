# -*- coding: utf-8 -*-
"""Isocrona di trasporto pubblico (Connection Scan Algorithm) sul GTFS.

Da una sorgente e un orario di partenza calcola le fermate raggiungibili entro
un budget di tempo combinando: cammino di accesso alle fermate (in linea
d'aria o lungo la rete, vedi network_access), viaggi in mezzo (orari GTFS,
anche da frequencies.txt), cambi alla stessa fermata o a piedi fra fermate
vicine (con penalità di trasferimento). Con reach_window la partenza è
campionata su una finestra oraria e il tempo per fermata è la mediana.
L'area è l'unione dei bacini attorno alle fermate raggiunte con il tempo
residuo.
"""
import bisect
import math
from collections import defaultdict


def _haversine(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


class PointIndex:
    """Indice a griglia di punti (lat, lon) per ricerche entro un raggio.

    Le celle in longitudine sono allargate di 1/cos(lat): con celle uguali in
    gradi, punti a distanza < raggio in direzione est-ovest finirebbero fuori
    dalle celle cercate.
    """

    def __init__(self, points_latlon, cell_m):
        self.pts = list(points_latlon)
        self.cell = max(1e-6, cell_m / 111000.0)
        lat_ref = max((abs(la) for la, _lo in self.pts), default=0.0)
        self.coslat = max(0.05, math.cos(math.radians(lat_ref)))
        self.cell_lon = self.cell / self.coslat
        self.grid = defaultdict(list)
        for i, (la, lo) in enumerate(self.pts):
            self.grid[(round(la / self.cell), round(lo / self.cell_lon))].append(i)

    def near(self, lat, lon, radius_m):
        """[(indice, distanza_m)] dei punti entro radius_m."""
        span_lat = int(radius_m / (self.cell * 111000.0)) + 1
        span_lon = int(radius_m / (self.cell_lon * 111000.0 * self.coslat)) + 1
        gi, gj = round(lat / self.cell), round(lon / self.cell_lon)
        out = []
        for di in range(-span_lat, span_lat + 1):
            for dj in range(-span_lon, span_lon + 1):
                for i in self.grid.get((gi + di, gj + dj), ()):
                    la, lo = self.pts[i]
                    d = _haversine(lat, lon, la, lo)
                    if d <= radius_m:
                        out.append((i, d))
        return out


def arrivals_at_points(index, source_latlon, reach, direct_mps, egress_m,
                       max_s, nbr_cache):
    """Orario di arrivo a ogni punto dell'indice (destinazioni/zone).

    Minimo fra lo spostamento diretto dall'origine (senza mezzi, velocità
    direct_mps, entro max_s) e l'egress dalle fermate raggiunte (entro
    egress_m). Le destinazioni vicine a ogni fermata sono calcolate una volta
    e riusate fra origini (nbr_cache).

    :param reach: risultato di reach_from / reach_window.
    :return: {indice_punto: orario_arrivo_s}.
    """
    earliest, stops_xy, start_s, egress_mps = reach
    best = {}
    for i, d in index.near(source_latlon[0], source_latlon[1],
                           max_s * direct_mps):
        best[i] = start_s + d / direct_mps
    for sid, t_arr in earliest.items():
        lst = nbr_cache.get(sid)
        if lst is None:
            la, lo = stops_xy[sid]
            lst = index.near(la, lo, egress_m)
            nbr_cache[sid] = lst
        for i, d in lst:
            a = t_arr + d / egress_mps
            if a < best.get(i, float("inf")):
                best[i] = a
    return best


def _to_sec(series):
    import pandas as pd
    parts = series.str.split(":", expand=True)
    if parts.shape[1] < 3:
        return pd.Series([float("nan")] * len(series), index=series.index)
    return (pd.to_numeric(parts[0], errors="coerce") * 3600
            + pd.to_numeric(parts[1], errors="coerce") * 60
            + pd.to_numeric(parts[2], errors="coerce"))


def _expand_frequencies(templates, freqs, start_s, end_s):
    """Corse esplicite dalle corse-modello di frequencies.txt.

    Per ogni riga (trip_id, start_time, end_time, headway_secs) genera una
    corsa ogni headway_secs a partire da start_time (end_time escluso),
    spostando gli orari della corsa-modello. Tiene solo le fermate con
    partenza nella finestra di calcolo.

    :param templates: DataFrame trip/stop/seq/arr/dep delle corse-modello.
    :param freqs: DataFrame di frequencies.txt (stringhe).
    """
    import pandas as pd
    if templates is None or templates.empty or freqs is None or freqs.empty:
        return None
    templates = templates.sort_values(["trip", "seq"])
    first_dep = templates.groupby("trip")["dep"].min()
    out = []
    f_start = _to_sec(freqs["start_time"])
    f_end = _to_sec(freqs["end_time"])
    headway = pd.to_numeric(freqs["headway_secs"], errors="coerce")
    for trip, s0, s1, hw in zip(freqs["trip_id"], f_start, f_end, headway):
        if trip not in first_dep.index or not (hw and hw > 0) \
                or pd.isna(s0) or pd.isna(s1):
            continue
        rows = templates[templates["trip"] == trip]
        t0 = first_dep[trip]
        k = 0
        t = s0
        while t < s1:
            off = t - t0
            dep = rows["dep"] + off
            mask = (dep >= start_s - 600) & (dep <= end_s)
            if mask.any():
                inst = rows[mask].copy()
                inst["trip"] = "%s#%d" % (trip, k)
                inst["arr"] = inst["arr"] + off
                inst["dep"] = inst["dep"] + off
                out.append(inst)
            k += 1
            t += hw
    return pd.concat(out, ignore_index=True) if out else None


def prepare_transit(source_path, start_h, budget_min, walk_speed_kmh=4.8,
                    transfer_m=200.0, service_date=None, progress=None,
                    is_canceled=None):
    """Legge il GTFS UNA volta e prepara i dati per il CSA (riusabili da più
    sorgenti e più orari di partenza). Restituisce un dict opaco da passare a
    `reach_from` / `reach_window`.

    La finestra letta va da start_h a start_h + budget_min: per una finestra
    di partenze il chiamante passa budget = finestra + tempo massimo.
    """
    import os
    import zipfile
    import pandas as pd
    from . import gtfs_static as gs

    start_s = float(start_h) * 3600.0
    end_s = start_s + float(budget_min) * 60.0
    walk_mps = walk_speed_kmh * 1000.0 / 3600.0

    stops = gs._read_table(source_path, "stops.txt")
    stops_xy = {}
    for r in stops.itertuples(index=False):
        try:
            stops_xy[r.stop_id] = (float(r.stop_lat), float(r.stop_lon))
        except (TypeError, ValueError):
            continue

    trips = gs._read_subset(source_path, "trips.txt",
                            ["trip_id", "service_id", "route_id"])
    route_of_trip = {}
    selection = "tutti i servizi"
    if trips is not None and not trips.empty:
        trips, selection = gs.select_trips(trips, source_path, service_date)
        allowed = set(trips["trip_id"])
        if "route_id" in trips.columns:
            route_of_trip = dict(zip(trips["trip_id"], trips["route_id"]))
    else:
        allowed = set()
    # etichette delle linee (per "Dividi per linea")
    route_label = {}
    routes = gs._read_table(source_path, "routes.txt")
    if routes is not None:
        for r in routes.itertuples(index=False):
            name = str(getattr(r, "route_short_name", "") or "").strip() \
                or str(getattr(r, "route_long_name", "") or "").strip() \
                or str(r.route_id)
            route_label[r.route_id] = name

    # corse definite a frequenza: la corsa-modello va letta tutta (i suoi
    # orari non sono quelli reali) e poi replicata
    freqs = gs._read_table(source_path, "frequencies.txt")
    freq_trips = set()
    if freqs is not None and not freqs.empty and "trip_id" in freqs.columns:
        freqs = freqs[freqs["trip_id"].isin(allowed)]
        freq_trips = set(freqs["trip_id"])

    st_cols = gs._table_columns(source_path, "stop_times.txt")
    use = [c for c in ["trip_id", "stop_id", "stop_sequence",
                       "arrival_time", "departure_time"] if c in st_cols]
    kept = []
    templates = []

    def _frame(chunk, arr, dep):
        return pd.DataFrame({
            "trip": chunk["trip_id"].values,
            "route": chunk["trip_id"].map(route_of_trip).values,
            "stop": chunk["stop_id"].values,
            "seq": pd.to_numeric(chunk["stop_sequence"], errors="coerce").values,
            "arr": arr.values,
            "dep": dep.values,
        })

    def _consume(reader):
        for chunk in reader:
            if is_canceled and is_canceled():
                from .gtfs_static import GtfsCancelled
                raise GtfsCancelled()
            chunk = chunk[chunk["trip_id"].isin(allowed)]
            if chunk.empty:
                continue
            dep = _to_sec(chunk["departure_time"])
            arr = _to_sec(chunk["arrival_time"]) if "arrival_time" in chunk else dep
            # fermate senza orario (non timepoint): orario interpolato
            dep = gs.interpolate_trip_times(chunk["trip_id"],
                                            chunk["stop_sequence"], dep)
            arr = gs.interpolate_trip_times(chunk["trip_id"],
                                            chunk["stop_sequence"], arr)
            arr = arr.fillna(dep)
            if freq_trips:
                is_tpl = chunk["trip_id"].isin(freq_trips)
                if is_tpl.any():
                    templates.append(_frame(chunk[is_tpl], arr[is_tpl],
                                            dep[is_tpl]))
                    keep = ~is_tpl
                    chunk, arr, dep = chunk[keep], arr[keep], dep[keep]
            mask = (dep >= start_s - 600) & (dep <= end_s)
            if not mask.any():
                continue
            kept.append(_frame(chunk[mask], arr[mask], dep[mask]))

    if os.path.isdir(source_path):
        path = os.path.join(source_path, "stop_times.txt")
        _consume(pd.read_csv(path, dtype=str, keep_default_na=False,
                             usecols=use, chunksize=400000))
    else:
        with zipfile.ZipFile(source_path) as zf:
            with zf.open("stop_times.txt") as fh:
                _consume(pd.read_csv(fh, dtype=str, keep_default_na=False,
                                     usecols=use, chunksize=400000))
    if templates:
        expanded = _expand_frequencies(pd.concat(templates, ignore_index=True),
                                       freqs, start_s, end_s)
        if expanded is not None:
            kept.append(expanded)
    if progress:
        progress(60)

    connections = []
    trip_index = {}
    trip_route = []
    if kept:
        df = pd.concat(kept, ignore_index=True).dropna(subset=["seq", "dep", "arr"])
        df = df.sort_values(["trip", "seq"])
        g = df.groupby("trip", sort=False)
        df["to_stop"] = g["stop"].shift(-1)
        df["to_arr"] = g["arr"].shift(-1)
        conn = df.dropna(subset=["to_stop"])
        conn = conn[conn["to_arr"] > conn["dep"]]
        # corse come interi: il CSA tiene traccia della corsa su cui si è
        codes, uniques = pd.factorize(conn["trip"])
        trip_index = {t: i for i, t in enumerate(uniques)}
        # linea di ogni corsa (indice = codice corsa)
        trip_route = list(pd.Series(conn["route"].values, index=codes)
                          .groupby(level=0).first()
                          .reindex(range(len(uniques))).values)
        connections = list(zip(conn["dep"].values, conn["stop"].values,
                               conn["to_arr"].values, conn["to_stop"].values,
                               codes))
        connections.sort(key=lambda c: c[0])

    grid = defaultdict(list)
    cell = transfer_m / 111000.0
    # in longitudine un grado e' piu' corto (cos lat): cella piu' ampia in
    # gradi, altrimenti fermate a < transfer_m in direzione E-O cadono a due
    # celle di distanza e il trasbordo non viene trovato
    lat_ref = max((abs(la) for la, _lo in stops_xy.values()), default=0.0)
    cell_lon = cell / max(0.05, math.cos(math.radians(lat_ref)))
    for sid, (la, lo) in stops_xy.items():
        grid[(round(la / cell), round(lo / cell_lon))].append(sid)
    if progress:
        progress(100)
    return {"connections": connections,
            "dep_times": [c[0] for c in connections],
            "n_trips": len(trip_index), "n_freq_trips": len(freq_trips),
            "trip_route": trip_route, "route_label": route_label,
            "selection": selection,
            "stops_xy": stops_xy, "grid": grid,
            "cell": cell, "cell_lon": cell_lon, "transfer_m": transfer_m,
            "walk_mps": walk_mps, "walk_speed_kmh": walk_speed_kmh,
            "start_s": start_s, "end_s": end_s}


def reach_from(data, source_latlon, access_speed_kmh=None, egress_speed_kmh=None,
               max_access_m=800.0, transfer_penalty_s=0.0, start_s=None,
               budget_s=None, access_dist=None, routes=None):
    """CSA earliest-arrival da una sorgente, usando i dati di `prepare_transit`.

    Il CSA tiene traccia della corsa su cui si viaggia: restare sulla stessa
    corsa è gratis, cambiare mezzo (anche alla stessa fermata) costa
    `transfer_penalty_s`, come il cambio a piedi fra fermate vicine.

    :param start_s: orario di partenza (s); default l'inizio della finestra
        letta da prepare_transit.
    :param budget_s: tempo massimo (s); default fino alla fine della finestra.
    :param access_dist: opzionale {stop_id: metri} con le distanze di accesso
        lungo la rete (network_access); senza, accesso in linea d'aria entro
        max_access_m.
    :param routes: opzionale, insieme di route_id utilizzabili (le altre
        linee sono ignorate): isocrona di una sola linea.
    :return: (earliest, stops_xy, start_s, egress_mps).
    """
    stops_xy = data["stops_xy"]
    grid = data["grid"]
    cell = data["cell"]
    cell_lon = data.get("cell_lon", cell)
    transfer_m = data["transfer_m"]
    walk_mps = data["walk_mps"]
    if start_s is None:
        start_s = data["start_s"]
    end_s = start_s + budget_s if budget_s is not None else data["end_s"]
    base_kmh = data["walk_speed_kmh"]
    access_mps = (access_speed_kmh or base_kmh) * 1000.0 / 3600.0
    egress_mps = (egress_speed_kmh or base_kmh) * 1000.0 / 3600.0
    slat, slon = source_latlon

    def neighbors(sid):
        la, lo = stops_xy[sid]
        gi, gj = round(la / cell), round(lo / cell_lon)
        out = []
        for di in (-1, 0, 1):
            for dj in (-1, 0, 1):
                for other in grid.get((gi + di, gj + dj), ()):
                    if other == sid:
                        continue
                    d = _haversine(la, lo, *stops_xy[other])
                    if d <= transfer_m:
                        out.append((other, d / walk_mps))
        return out

    INF = float("inf")
    earliest = {}
    arr_trip = {}   # corsa con cui si arriva alla fermata (-1 = a piedi)
    if access_dist is not None:
        for sid, d in access_dist.items():
            if sid in stops_xy and d <= max_access_m:
                earliest[sid] = start_s + d / access_mps
                arr_trip[sid] = -1
    else:
        for sid, (la, lo) in stops_xy.items():
            d = _haversine(slat, slon, la, lo)
            if d <= max_access_m:
                earliest[sid] = start_s + d / access_mps
                arr_trip[sid] = -1

    def relax_footpaths(sid):
        base = earliest[sid]
        for other, wt in neighbors(sid):
            nt = base + wt + transfer_penalty_s
            if nt < earliest.get(other, INF) and nt <= end_s:
                earliest[other] = nt
                arr_trip[other] = -1

    boarded = bytearray(data.get("n_trips", 0) or 1)
    usable = None
    if routes is not None:
        usable = bytearray(len(boarded))
        for k, r in enumerate(data.get("trip_route", ())):
            if r in routes:
                usable[k] = 1
    conns = data["connections"]
    i0 = bisect.bisect_left(data["dep_times"], start_s) \
        if "dep_times" in data else 0
    for k in range(i0, len(conns)):
        dep, dstop, arr, astop, trip = conns[k]
        if dep > end_s:
            break
        if usable is not None and not usable[trip]:
            continue
        if not boarded[trip]:
            ea = earliest.get(dstop, INF)
            if ea == INF:
                continue
            # cambio di mezzo alla stessa fermata: serve la penalità
            if arr_trip.get(dstop, -1) >= 0:
                ea += transfer_penalty_s
            if ea > dep:
                continue
            boarded[trip] = 1
        if arr < earliest.get(astop, INF) and arr <= end_s:
            earliest[astop] = arr
            arr_trip[astop] = trip
            relax_footpaths(astop)
    return earliest, stops_xy, start_s, egress_mps


def reach_window(data, source_latlon, start_s, window_s, step_s, budget_s,
                 percentile=50.0, **kwargs):
    """Come reach_from, ma su più partenze in una finestra oraria.

    Esegue il CSA a ogni partenza start, start+step, …, start+window e per
    ogni fermata prende il tempo di viaggio al percentile indicato (50 =
    mediana). Una fermata raggiunta in meno della metà delle partenze non ha
    mediana e resta esclusa: l'isocrona non dipende più dal minuto esatto di
    partenza rispetto al passaggio delle corse.

    :return: come reach_from; i tempi sono riferiti a start_s.
    """
    n_dep = int(window_s // step_s) + 1 if step_s > 0 else 1
    travel = defaultdict(list)
    egress_mps = None
    stops_xy = data["stops_xy"]
    for k in range(n_dep):
        d = start_s + k * step_s
        earliest, stops_xy, _s, egress_mps = reach_from(
            data, source_latlon, start_s=d, budget_s=budget_s, **kwargs)
        for sid, t in earliest.items():
            travel[sid].append(t - d)
    rank = max(0, int(math.ceil(percentile / 100.0 * n_dep)) - 1)
    typical = {}
    for sid, lst in travel.items():
        if len(lst) <= rank:
            continue  # raggiunta in troppo poche partenze
        lst.sort()
        typical[sid] = start_s + lst[rank]
    return typical, stops_xy, start_s, egress_mps


def routes_serving(data, source_latlon, max_access_m, start_s, end_s,
                   access_dist=None):
    """Linee che servono un punto: quelle con almeno una partenza, fra
    start_s ed end_s, da una fermata raggiungibile a piedi (entro
    max_access_m, lungo la rete se access_dist è dato).

    :return: insieme di route_id.
    """
    if access_dist is not None:
        near = {sid for sid, d in access_dist.items() if d <= max_access_m}
    else:
        near = {sid for sid, (la, lo) in data["stops_xy"].items()
                if _haversine(source_latlon[0], source_latlon[1], la, lo)
                <= max_access_m}
    trip_route = data.get("trip_route", [])
    out = set()
    conns = data["connections"]
    for k in range(bisect.bisect_left(data["dep_times"], start_s), len(conns)):
        dep, dstop, _arr, _astop, trip = conns[k]
        if dep > end_s:
            break
        if dstop in near and trip < len(trip_route):
            r = trip_route[trip]
            if r is not None and r == r:   # escluse le corse senza linea (NaN)
                out.add(r)
    return out


def network_access(graph, source_latlon, stops_xy, max_access_m,
                   snap_cache=None, snap_m=500.0):
    """Distanze di accesso dall'origine alle fermate LUNGO LA RETE.

    Considera solo le fermate entro max_access_m in linea d'aria (la distanza
    di rete non è mai minore) e calcola la distanza esatta piede-piede con
    Dijkstra (net_iso.MetricGraph). Ritorna None se l'origine non aggancia la
    rete (il chiamante userà la linea d'aria).

    :param snap_cache: dict condiviso fra sorgenti {stop_id: info snap_edge}.
    """
    src = graph.snap_edge_ll(source_latlon[0], source_latlon[1], snap_m)
    if src is None:
        return None
    if snap_cache is None:
        snap_cache = {}
    cand = [sid for sid, (la, lo) in stops_xy.items()
            if _haversine(source_latlon[0], source_latlon[1], la, lo)
            <= max_access_m]
    cost = graph.dijkstra_multi(graph.source_seeds(src), max_access_m)
    out = {}
    for sid in cand:
        info = snap_cache.get(sid, False)
        if info is False:
            la, lo = stops_xy[sid]
            info = graph.snap_edge_ll(la, lo, snap_m)
            snap_cache[sid] = info
        if info is None:
            continue
        d = graph.edge_distance(cost, src, info)
        if d <= max_access_m:
            out[sid] = d
    return out


def compute_transit_reach(source_path, source_latlon, start_h, budget_min,
                          walk_speed_kmh, transfer_m=200.0, max_access_m=800.0,
                          access_speed_kmh=None, egress_speed_kmh=None,
                          transfer_penalty_s=0.0, service_date=None,
                          progress=None, is_canceled=None):
    """Wrapper a singola sorgente: prepare_transit + reach_from."""
    data = prepare_transit(source_path, start_h, budget_min, walk_speed_kmh,
                           transfer_m, service_date, progress, is_canceled)
    if is_canceled and is_canceled():
        from .gtfs_static import GtfsCancelled
        raise GtfsCancelled()
    return reach_from(data, source_latlon, access_speed_kmh, egress_speed_kmh,
                      max_access_m, transfer_penalty_s)


def egress_budgets(results, sources_latlon, t_min, max_egress_m=None,
                   direct_mps=None):
    """Sorgenti con budget per l'egress su rete pedonale (compute_union_reach).

    Per ogni sorgente: lo spostamento diretto dall'origine (alla velocità
    `direct_mps`, default quella di egress) e ogni fermata raggiunta entro
    t_min, con il tempo residuo convertito in metri e limitato a
    max_egress_m (la distanza massima che si è disposti a fare dalla fermata).

    :param results: lista allineata alle sorgenti di risultati `reach_from`.
    :return: lista di (lat, lon, budget_m).
    """
    out = []
    for src, (earliest, stops_xy, start_s, egress_mps) in zip(sources_latlon,
                                                               results):
        out.append((src[0], src[1], t_min * 60.0 * (direct_mps or egress_mps)))
        limit = start_s + t_min * 60.0
        for sid, ta in earliest.items():
            if ta <= limit:
                la, lo = stops_xy[sid]
                b = (limit - ta) * egress_mps
                if max_egress_m is not None:
                    b = min(b, max_egress_m)
                out.append((la, lo, b))
    return out


def transit_circles_for_band(earliest, stops_xy, start_s, walk_mps,
                             source_latlon, t_min, max_access_m=800.0,
                             direct_mps=None):
    """Bacini (lat, lon, radius_m) raggiungibili entro t_min.

    Attorno all'origine lo spostamento diretto (velocità `direct_mps`,
    default walk_mps) per tutto il tempo; attorno a ogni fermata il tempo
    residuo, limitato a max_access_m (distanza massima dalla fermata).
    """
    limit = start_s + float(t_min) * 60.0
    out = [(source_latlon[0], source_latlon[1],
            float(t_min) * 60.0 * (direct_mps or walk_mps))]
    for sid, t in earliest.items():
        if t > limit:
            continue
        rem = limit - t
        if rem <= 0:
            continue
        la, lo = stops_xy[sid]
        out.append((la, lo, min(rem * walk_mps, max_access_m)))
    return out
