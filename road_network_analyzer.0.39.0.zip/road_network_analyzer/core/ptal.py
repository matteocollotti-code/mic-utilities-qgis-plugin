# -*- coding: utf-8 -*-
"""PTAL - Public Transport Accessibility Level (metodo Transport for London).

Per ogni punto di analisi si trovano le fermate raggiungibili a piedi entro le
soglie per modo; per ogni linea si calcola il tempo totale di accesso
(cammino + attesa programmata + affidabilità) e la frequenza equivalente
alla porta EDF = 30 / TAT. Come nel metodo TfL ogni linea conta UNA volta,
alla fermata con l'EDF più alto; per ogni modo si somma la linea migliore
(×1) e le altre (×0,5), poi si sommano i modi. Il risultato è
l'Accessibility Index, mappato sulle fasce PTAL 0..6b.

Riferimento: TfL - "Measuring Public Transport Accessibility Levels (PTALs)".
"""
import math
from collections import defaultdict

# soglie/parametri di default (TfL)
DEFAULT_PARAMS = {
    "walk_speed_kmh": 4.8,
    # soglia di cammino (m) per tipo di rotta GTFS base (route_type 0-4)
    "thresholds": {"0": 640, "1": 960, "2": 960, "3": 640, "4": 960},
    # affidabilita' (min) per tipo di rotta
    "reliability": {"0": 1.5, "1": 0.75, "2": 0.75, "3": 2.0, "4": 0.75},
    "default_threshold": 640,
    "default_reliability": 2.0,
    "weight_primary": 1.0,
    "weight_secondary": 0.5,
}

# profili orari standard (etichetta, ora_inizio, ora_fine, descrizione).
# Il primo e' il "primario" (AM peak TfL): da' i campi base ai/ptal/ptal_level.
TIME_BANDS = [
    ("am", 8.25, 9.25, "AM peak (08:15-09:15, TfL)"),
    ("ip", 10, 16, "Interpeak (10-16)"),
    ("pm", 16, 19, "PM peak (16-19)"),
]

# (limite superiore AI, etichetta, livello numerico)
PTAL_BANDS = [
    (0.0, "0", 0),
    (2.5, "1a", 1),
    (5.0, "1b", 2),
    (10.0, "2", 3),
    (15.0, "3", 4),
    (20.0, "4", 5),
    (25.0, "5", 6),
    (40.0, "6a", 7),
    (float("inf"), "6b", 8),
]


def map_band(ai):
    if ai <= 0:
        return "0", 0
    for hi, label, level in PTAL_BANDS:
        if ai <= hi:
            return label, level
    return "6b", 8


def _haversine(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def basic_route_type(rtype):
    """route_type GTFS (base o esteso) -> tipo base "0".."7" come stringa.

    I tipi estesi (100-1700, Google) sono ricondotti al modo base: senza,
    ad es. un treno suburbano (109) userebbe soglia e affidabilità del bus.
    """
    try:
        t = int(float(str(rtype).strip()))
    except (TypeError, ValueError):
        return "3"
    if t < 100:
        # 11 filobus -> bus, 12 monorotaia -> metro, 5 cable tram -> tram
        return {11: "3", 12: "1", 5: "0"}.get(t, str(t))
    if 100 <= t < 200:
        return "2"      # ferrovia
    if 200 <= t < 300 or 700 <= t < 900:
        return "3"      # pullman, bus, filobus
    if 400 <= t < 700:
        return "1"      # ferrovia urbana / metropolitana / sotterranea
    if 900 <= t < 1000:
        return "0"      # tram
    if 1000 <= t < 1100 or 1200 <= t < 1300:
        return "4"      # traghetti
    if 1300 <= t < 1400:
        return "6"      # funivie
    if 1400 <= t < 1500:
        return "7"      # funicolari
    return "3"


def compute_stop_frequencies(source, start_h, end_h, service_date=None,
                             info=None):
    """Frequenze (corse/ora) per fermata e rotta nella fascia oraria.

    Le fermate senza orario (non timepoint) ricevono un orario interpolato.

    :param service_date: data YYYYMMDD; None = giorno più carico del feed.
    :param info: dict opzionale in cui scrivere "selection" (giorno usato).
    :return: (stop_routes, stops_xy)
        stop_routes = {stop_id: [(route_id, route_type, freq_per_hour), ...]}
        stops_xy    = {stop_id: (lat, lon)}
    """
    import pandas as pd
    from . import gtfs_static as gs

    if float(end_h) <= float(start_h):
        raise ValueError("La fascia oraria deve finire dopo l'inizio "
                         "(%s-%s)." % (start_h, end_h))
    hours = float(end_h) - float(start_h)
    start_s = float(start_h) * 3600.0
    end_s = float(end_h) * 3600.0

    routes = gs._read_table(source, "routes.txt")
    route_type = {}
    if routes is not None:
        for r in routes.itertuples(index=False):
            route_type[r.route_id] = str(getattr(r, "route_type", "3") or "3")

    trips = gs._read_subset(source, "trips.txt",
                            ["trip_id", "route_id", "service_id"])
    if trips is None or trips.empty:
        raise ValueError("trips.txt mancante o vuoto.")
    trips, desc = gs.select_trips(trips, source, service_date)
    if info is not None:
        info["selection"] = desc
    trip_route = dict(zip(trips["trip_id"], trips["route_id"]))
    allowed = set(trips["trip_id"])

    stops = gs._read_table(source, "stops.txt")
    stops_xy = {}
    for r in stops.itertuples(index=False):
        try:
            stops_xy[r.stop_id] = (float(r.stop_lat), float(r.stop_lon))
        except (TypeError, ValueError):
            continue

    st_cols = gs._table_columns(source, "stop_times.txt")
    timecol = "departure_time" if "departure_time" in st_cols else "arrival_time"
    use = [c for c in ["trip_id", timecol, "stop_id", "stop_sequence"]
           if c in st_cols]
    counts = defaultdict(int)

    def _consume(reader):
        for chunk in reader:
            chunk = chunk[chunk["trip_id"].isin(allowed)]
            if chunk.empty:
                continue
            parts = chunk[timecol].str.split(":", expand=True)
            if parts.shape[1] < 3:
                continue
            sec = (pd.to_numeric(parts[0], errors="coerce") * 3600
                   + pd.to_numeric(parts[1], errors="coerce") * 60
                   + pd.to_numeric(parts[2], errors="coerce"))
            if "stop_sequence" in chunk:
                sec = gs.interpolate_trip_times(chunk["trip_id"],
                                                chunk["stop_sequence"], sec)
            chunk = chunk[(sec >= start_s) & (sec < end_s)]
            if chunk.empty:
                continue
            chunk = chunk.assign(route=chunk["trip_id"].map(trip_route))
            grp = chunk.groupby(["stop_id", "route"]).size()
            for (sid, rid), c in grp.items():
                counts[(sid, rid)] += int(c)

    import os
    import zipfile
    if os.path.isdir(source):
        path = os.path.join(source, "stop_times.txt")
        _consume(pd.read_csv(path, dtype=str, keep_default_na=False,
                             usecols=use, chunksize=400000))
    else:
        with zipfile.ZipFile(source) as zf:
            with zf.open("stop_times.txt") as fh:
                _consume(pd.read_csv(fh, dtype=str, keep_default_na=False,
                                     usecols=use, chunksize=400000))

    stop_routes = defaultdict(list)
    for (sid, rid), c in counts.items():
        if c <= 0:
            continue
        stop_routes[sid].append((rid, route_type.get(rid, "3"), c / hours))
    return dict(stop_routes), stops_xy


def _route_edfs(routes, dist, p, best):
    """Aggiorna best[route_id] = (edf, modo) con l'EDF delle linee servite da
    una fermata a `dist` metri (solo se migliore di quello già trovato)."""
    walk_time = dist / 1000.0 / p["walk_speed_kmh"] * 60.0
    for rid, rtype, freq in routes:
        if freq <= 0:
            continue
        bt = basic_route_type(rtype)
        if dist > p["thresholds"].get(bt, p["default_threshold"]):
            continue
        rel = p["reliability"].get(bt, p["default_reliability"])
        tat = walk_time + 0.5 * (60.0 / freq) + rel
        if tat <= 0:
            continue
        edf = 30.0 / tat
        if edf > best.get(rid, (0.0, None))[0]:
            best[rid] = (edf, bt)


def _ai_from_routes(best, p):
    """AI TfL: per modo linea migliore × w1 + altre × w2, sommato sui modi."""
    by_mode = defaultdict(list)
    for edf, mode in best.values():
        by_mode[mode].append(edf)
    ai = 0.0
    for edfs in by_mode.values():
        top = max(edfs)
        ai += top * p["weight_primary"] + (sum(edfs) - top) * p["weight_secondary"]
    return ai


def _params(params):
    p = dict(DEFAULT_PARAMS)
    if params:
        p.update(params)
    return p


def _max_threshold(p):
    return max(list(p["thresholds"].values()) + [p["default_threshold"]])


def compute_ptal_network(points_latlon, stop_routes, stops_xy, roads_lonlat,
                         params=None, progress=None, is_canceled=None):
    """PTAL con distanze pedonali sulla RETE (Dijkstra) invece che in linea d'aria.

    La distanza include i tratti dal punto alla strada e dalla strada alla
    fermata (fino al raggio di aggancio di 500 m).
    """
    from . import net_iso
    p = _params(params)
    max_thr = _max_threshold(p)

    pts = [(la, lo) for la, lo in points_latlon]
    lat0 = sum(la for la, lo in pts) / len(pts) if pts else 0.0
    graph = net_iso.build_metric_graph(roads_lonlat, lat0)
    if progress:
        progress(20)

    def offset(lat, lon, info):
        x, y = graph.to_m(lon, lat)
        return math.hypot(x - info["foot"][0], y - info["foot"][1])

    stop_info = {}
    for sid, (la, lo) in stops_xy.items():
        if sid in stop_routes:
            info = graph.snap_edge_ll(la, lo, 500.0)
            if info:
                stop_info[sid] = (info, offset(la, lo, info))

    out = []
    n = len(pts)
    for idx, (plat, plon) in enumerate(pts):
        if is_canceled and idx % 25 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and idx % 50 == 0 and n:
            progress(20 + int(75 * idx / n))
        src_info = graph.snap_edge_ll(plat, plon, 500.0)
        best = {}
        if src_info:
            src_off = offset(plat, plon, src_info)
            cost = graph.dijkstra_multi(src_info["seeds"], max_thr)
            for sid, (sinfo, s_off) in stop_info.items():
                d = graph.edge_distance(cost, src_info, sinfo) + src_off + s_off
                if d <= max_thr:
                    _route_edfs(stop_routes[sid], d, p, best)
        ai = _ai_from_routes(best, p)
        band, level = map_band(ai)
        out.append({"ai": ai, "band": band, "level": level})
    if progress:
        progress(100)
    return out


def compute_ptal(points_latlon, stop_routes, stops_xy, params=None,
                 progress=None, is_canceled=None):
    """Calcola AI e fascia PTAL per ogni punto di analisi (linea d'aria).

    :param points_latlon: lista [(lat, lon)] dei punti di analisi.
    :return: lista di dict {ai, band, level} allineata ai punti.
    """
    p = _params(params)
    max_thr = _max_threshold(p)
    cell = 0.01
    grid = defaultdict(list)
    for sid, (la, lo) in stops_xy.items():
        if sid in stop_routes:
            grid[(round(la / cell), round(lo / cell))].append(sid)
    # celle in gradi: in longitudine un grado è più corto (cos lat), quindi
    # servono più celle per coprire la stessa distanza verso est/ovest
    lat_ref = max((abs(la) for la, _lo in points_latlon), default=0.0)
    span_lat = int(max_thr / (cell * 111000.0)) + 1
    span_lon = int(max_thr / (cell * 111000.0 *
                              max(0.05, math.cos(math.radians(lat_ref))))) + 1

    out = []
    n = len(points_latlon)
    for idx, (plat, plon) in enumerate(points_latlon):
        if is_canceled and idx % 50 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if progress and idx % 100 == 0 and n:
            progress(int(100 * idx / n))
        gi, gj = round(plat / cell), round(plon / cell)
        best = {}
        for di in range(-span_lat, span_lat + 1):
            for dj in range(-span_lon, span_lon + 1):
                for sid in grid.get((gi + di, gj + dj), ()):
                    slat, slon = stops_xy[sid]
                    dist = _haversine(plat, plon, slat, slon)
                    if dist <= max_thr:
                        _route_edfs(stop_routes[sid], dist, p, best)
        ai = _ai_from_routes(best, p)
        band, level = map_band(ai)
        out.append({"ai": ai, "band": band, "level": level})
    if progress:
        progress(100)
    return out
