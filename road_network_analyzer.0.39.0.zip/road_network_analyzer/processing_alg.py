# -*- coding: utf-8 -*-
"""Provider e algoritmi Processing di MIC - Utilities.

Espone alcuni core come algoritmi Processing (batch, Model Builder, headless),
riusando le stesse funzioni del pannello. I core sono già senza GUI, quindi qui
si fa solo il "wrapping": materializza l'input, chiama il core, scrive nel sink.
"""
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsApplication,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterFile,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingProvider,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QVariant


def _parse_times(text):
    out = []
    for x in str(text).replace(";", ",").split(","):
        x = x.strip()
        if x:
            try:
                v = float(x)
                if v > 0:
                    out.append(v)
            except ValueError:
                pass
    return out


def _copy_to_sink(self, result_layer, parameters, context, out_key):
    sink, dest_id = self.parameterAsSink(
        parameters, out_key, context, result_layer.fields(),
        result_layer.wkbType(), result_layer.crs())
    for f in result_layer.getFeatures():
        sink.addFeature(f, QgsFeatureSink.FastInsert)
    return dest_id


class SpaceSyntaxAlgorithm(QgsProcessingAlgorithm):
    INPUT, RADIUS, OUTPUT = "INPUT", "RADIUS", "OUTPUT"

    def name(self):
        return "spacesyntax"

    def displayName(self):
        return "Space syntax (rete stradale)"

    def group(self):
        return "Rete stradale"

    def groupId(self):
        return "rete"

    def createInstance(self):
        return SpaceSyntaxAlgorithm()

    def shortHelpString(self):
        return ("Connettività, profondità, integrazione (HH), choice "
                "(betweenness), NAIN e NACH sul grafo dei tratti. Raggio 0 = "
                "globale, n = analisi locale entro n passi topologici.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, "Rete stradale", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(
            self.RADIUS, "Raggio (0 = globale)",
            QgsProcessingParameterNumber.Integer, 0, minValue=0))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Space syntax"))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import space_syntax, gtfs_layers
        source = self.parameterAsSource(parameters, self.INPUT, context)
        mat = source.materialize(QgsFeatureRequest())
        radius = self.parameterAsInt(parameters, self.RADIUS, context)
        fids, adjacency = space_syntax.build_adjacency(mat)
        if not fids:
            raise QgsProcessingException("Nessun tratto valido nella rete.")
        metrics = space_syntax.compute_metrics(
            adjacency, radius=radius,
            progress=lambda p: feedback.setProgress(int(p)))
        result = gtfs_layers.build_space_syntax_layer(mat, fids, metrics)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class RoadLengthsAlgorithm(QgsProcessingAlgorithm):
    INPUT, FIELD, OUTPUT = "INPUT", "FIELD", "OUTPUT"

    def name(self):
        return "roadlengths"

    def displayName(self):
        return "Lunghezze per tipologia (rete stradale)"

    def group(self):
        return "Rete stradale"

    def groupId(self):
        return "rete"

    def createInstance(self):
        return RoadLengthsAlgorithm()

    def shortHelpString(self):
        return ("Somma la lunghezza ellissoidale dei tratti raggruppata per il "
                "campo tipologia. Output: tabella tipologia / lunghezza.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, "Rete stradale", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterString(
            self.FIELD, "Campo tipologia (vuoto = tutte insieme)",
            optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Lunghezze per tipologia",
            QgsProcessing.TypeVector))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import analysis
        source = self.parameterAsSource(parameters, self.INPUT, context)
        mat = source.materialize(QgsFeatureRequest())
        field = self.parameterAsString(parameters, self.FIELD, context) or None
        da = analysis.distance_area(mat)
        lengths = analysis.compute_lengths_by_type(mat, field, da)
        fields = QgsFields()
        fields.append(QgsField("tipologia", QVariant.String))
        fields.append(QgsField("lunghezza_m", QVariant.Double))
        fields.append(QgsField("lunghezza_km", QVariant.Double))
        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields,
            QgsWkbTypes.NoGeometry, mat.crs())
        for typ, m in sorted(lengths.items(), key=lambda kv: -kv[1]):
            f = QgsFeature(fields)
            f.setAttributes([str(typ), round(m, 2), round(m / 1000.0, 3)])
            sink.addFeature(f, QgsFeatureSink.FastInsert)
        return {self.OUTPUT: dest_id}


class NetworkIsochronesAlgorithm(QgsProcessingAlgorithm):
    POINTS, ROADS, SPEED, TIMES, OUTPUT = (
        "POINTS", "ROADS", "SPEED", "TIMES", "OUTPUT")

    def name(self):
        return "netisochrones"

    def displayName(self):
        return "Isocrone su rete stradale"

    def group(self):
        return "Accessibilità"

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return NetworkIsochronesAlgorithm()

    def shortHelpString(self):
        return ("Isocrone concave (buffer sui tratti raggiunti) da punti "
                "sorgente lungo la rete stradale, per fasce di tempo. La "
                "velocità definisce la distanza percorribile.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, "Sorgenti (punti)", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, "Rete stradale", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPEED, "Velocità (km/h)",
            QgsProcessingParameterNumber.Double, 4.5, minValue=0.1))
        self.addParameter(QgsProcessingParameterString(
            self.TIMES, "Tempi (min, es. 5,10,15)", "5,10,15"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Isocrone"))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import net_iso, isochrones, net_clean
        ctx = context.transformContext()
        psrc = self.parameterAsSource(parameters, self.POINTS, context)
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        speed = self.parameterAsDouble(parameters, self.SPEED, context)
        times = _parse_times(self.parameterAsString(
            parameters, self.TIMES, context))
        if not times:
            raise QgsProcessingException("Tempi non validi.")

        ctp = QgsCoordinateTransform(psrc.sourceCrs(), isochrones.WGS84, ctx)
        coords = []
        for f in psrc.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ctp)
            p = g.centroid().asPoint()
            coords.append((p.y(), p.x()))
        if not coords:
            raise QgsProcessingException("Nessuna sorgente valida.")

        ctr = QgsCoordinateTransform(rsrc.sourceCrs(), isochrones.WGS84, ctx)
        roads = []
        for f in rsrc.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ctr)
            if g.isMultipart():
                for part in g.asMultiPolyline():
                    roads.append([(p.x(), p.y()) for p in part])
            else:
                roads.append([(p.x(), p.y()) for p in g.asPolyline()])
        ok, vmsg, _ = net_iso.validate_network(roads)
        if not ok:
            raise QgsProcessingException(vmsg)
        # stessa pulizia del pannello (snap vertici, nulli, duplicati)
        roads, _dirs, cstats = net_clean.clean_network(roads, 1.0)
        feedback.pushInfo(net_clean.clean_summary(cstats))

        per_source, n_snap = net_iso.compute_reachable_segments(
            roads, coords, speed, times,
            progress=lambda p: feedback.setProgress(int(p)), dissolve=True)
        result = isochrones.build_layer_from_segments(
            per_source, speed, "rete", "concave", 30.0, True,
            transform_context=ctx)
        feedback.pushInfo("Sorgenti agganciate: %d/%d" % (n_snap, len(coords)))
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


def _source_points_latlon(source, ctx):
    from .core import isochrones
    ct = QgsCoordinateTransform(source.sourceCrs(), isochrones.WGS84, ctx)
    coords = []
    for f in source.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        p = g.centroid().asPoint()
        coords.append((p.y(), p.x()))
    return coords


def _source_points_weighted(source, ctx, weight_field=None):
    from .core import isochrones
    ct = QgsCoordinateTransform(source.sourceCrs(), isochrones.WGS84, ctx)
    names = [fld.name() for fld in source.fields()]
    out = []
    for f in source.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        p = g.centroid().asPoint()
        w = 1.0
        if weight_field and weight_field in names:
            try:
                w = float(f[weight_field])
            except (TypeError, ValueError):
                w = 0.0  # peso mancante (NULL): non conta
        out.append((p.y(), p.x(), w))
    return out


def _source_roads(source, ctx):
    from .core import isochrones
    ct = QgsCoordinateTransform(source.sourceCrs(), isochrones.WGS84, ctx)
    roads = []
    for f in source.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        if g.isMultipart():
            for part in g.asMultiPolyline():
                roads.append([(p.x(), p.y()) for p in part])
        else:
            roads.append([(p.x(), p.y()) for p in g.asPolyline()])
    return roads


class PtalAlgorithm(QgsProcessingAlgorithm):
    GTFS, POINTS, START, END, ROADS, DATE, OUTPUT = (
        "GTFS", "POINTS", "START", "END", "ROADS", "DATE", "OUTPUT")

    def name(self):
        return "ptal"

    def displayName(self):
        return "PTAL (Public Transport Accessibility Level)"

    def group(self):
        return "Accessibilità"

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return PtalAlgorithm()

    def shortHelpString(self):
        return ("PTAL TfL per ogni punto. Senza rete pedonale usa la distanza in "
                "linea d'aria (standard TfL); con una rete pedonale usa le "
                "distanze di rete. Data servizio (YYYYMMDD) opzionale.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            self.GTFS, "Feed GTFS (.zip)", extension="zip"))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, "Punti di analisi", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterNumber(
            self.START, "Ora inizio fascia",
            QgsProcessingParameterNumber.Integer, 7, minValue=0, maxValue=23))
        self.addParameter(QgsProcessingParameterNumber(
            self.END, "Ora fine fascia",
            QgsProcessingParameterNumber.Integer, 10, minValue=1, maxValue=30))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, "Rete pedonale (opz. → PTAL su rete)",
            [QgsProcessing.TypeVectorLine], optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.DATE, "Data servizio YYYYMMDD (opz.)", "", optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "PTAL"))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import ptal, gtfs_layers
        ctx = context.transformContext()
        gtfs = self.parameterAsFile(parameters, self.GTFS, context)
        psrc = self.parameterAsSource(parameters, self.POINTS, context)
        start = self.parameterAsInt(parameters, self.START, context)
        end = self.parameterAsInt(parameters, self.END, context)
        date = self.parameterAsString(parameters, self.DATE, context).strip()
        date = date if (len(date) == 8 and date.isdigit()) else None
        coords = _source_points_latlon(psrc, ctx)
        if not coords:
            raise QgsProcessingException("Nessun punto valido.")
        feedback.setProgress(10)
        stop_routes, stops_xy = ptal.compute_stop_frequencies(
            gtfs, start, end, service_date=date)
        feedback.setProgress(40)
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        params = {"start_h": start, "end_h": end}
        if rsrc is not None:
            roads = _source_roads(rsrc, ctx)
            results = ptal.compute_ptal_network(
                coords, stop_routes, stops_xy, roads, params,
                progress=lambda p: feedback.setProgress(40 + int(p * 0.5)))
        else:
            results = ptal.compute_ptal(
                coords, stop_routes, stops_xy, params,
                progress=lambda p: feedback.setProgress(40 + int(p * 0.5)))
        mat = psrc.materialize(QgsFeatureRequest())
        result = gtfs_layers.build_ptal_layer(mat, results)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class AccessibilityAlgorithm(QgsProcessingAlgorithm):
    ORIGINS, DESTS, WEIGHT, ROADS, SPEED, TIMES, OUTPUT = (
        "ORIGINS", "DESTS", "WEIGHT", "ROADS", "SPEED", "TIMES", "OUTPUT")

    def name(self):
        return "accessibility"

    def displayName(self):
        return "Accessibilità cumulativa su rete"

    def group(self):
        return "Accessibilità"

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return AccessibilityAlgorithm()

    def shortHelpString(self):
        return ("Per ogni origine, quante destinazioni (o peso) sono "
                "raggiungibili entro ciascuna soglia di tempo, sulla rete.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ORIGINS, "Origini (punti)", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.DESTS, "Destinazioni",
            [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT, "Campo peso (opz.)", parentLayerParameterName=self.DESTS,
            optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, "Rete stradale", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPEED, "Velocità (km/h)",
            QgsProcessingParameterNumber.Double, 4.5, minValue=0.1))
        self.addParameter(QgsProcessingParameterString(
            self.TIMES, "Tempi (min, es. 15,30)", "15,30"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Accessibilità"))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import accessibility, gtfs_layers
        ctx = context.transformContext()
        osrc = self.parameterAsSource(parameters, self.ORIGINS, context)
        dsrc = self.parameterAsSource(parameters, self.DESTS, context)
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        wfield = self.parameterAsString(parameters, self.WEIGHT, context) or None
        speed = self.parameterAsDouble(parameters, self.SPEED, context)
        times = _parse_times(self.parameterAsString(
            parameters, self.TIMES, context))
        if not times:
            raise QgsProcessingException("Tempi non validi.")
        origins = [(la, lo) for la, lo, _ in _source_points_weighted(osrc, ctx)]
        dests = _source_points_weighted(dsrc, ctx, wfield)
        roads = _source_roads(rsrc, ctx)
        if not origins or not dests:
            raise QgsProcessingException("Origini/destinazioni vuote.")
        results, out_times = accessibility.accessibility_network(
            origins, dests, roads, speed, times,
            progress=lambda p: feedback.setProgress(int(p)))
        mat = osrc.materialize(QgsFeatureRequest())
        result = gtfs_layers.build_access_layer(mat, results, out_times)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


def _source_roads_dir(source, ctx, oneway_field=None):
    """Roads lon/lat + directions da un campo oneway (testuale o numerico)."""
    from .core import isochrones, osm_download
    ct = QgsCoordinateTransform(source.sourceCrs(), isochrones.WGS84, ctx)
    names = [f.name() for f in source.fields()]
    has_ow = bool(oneway_field) and oneway_field in names
    roads, dirs = [], ([] if has_ow else None)
    for f in source.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        d = osm_download._oneway_value(f[oneway_field]) if has_ow else 0
        parts = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
        for part in parts:
            roads.append([(p.x(), p.y()) for p in part])
            if has_ow:
                dirs.append(d)
    return roads, dirs


class PrepareNetworkAlgorithm(QgsProcessingAlgorithm):
    INPUT, SNAP, MINSEG, ONEWAY, OUTPUT = (
        "INPUT", "SNAP", "MINSEG", "ONEWAY", "OUTPUT")

    def name(self):
        return "preparenetwork"

    def displayName(self):
        return "Prepara rete (noding + snap)"

    def group(self):
        return "Rete stradale"

    def groupId(self):
        return "rete"

    def createInstance(self):
        return PrepareNetworkAlgorithm()

    def shortHelpString(self):
        return ("Spezza le linee alle intersezioni (noding), unisce gli estremi "
                "vicini (snap) e rimuove segmenti nulli/duplicati: produce una "
                "rete 'analysis-ready' per isocrone, accessibilità, PTAL, space "
                "syntax.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, "Rete stradale", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(
            self.SNAP, "Tolleranza snap (m)",
            QgsProcessingParameterNumber.Double, 1.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MINSEG, "Lunghezza minima segmento (m)",
            QgsProcessingParameterNumber.Double, 0.2, minValue=0.0))
        self.addParameter(QgsProcessingParameterField(
            self.ONEWAY, "Campo senso unico (opz.)",
            parentLayerParameterName=self.INPUT, optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Rete preparata"))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import network_prepare, net_layers
        ctx = context.transformContext()
        source = self.parameterAsSource(parameters, self.INPUT, context)
        owf = self.parameterAsString(parameters, self.ONEWAY, context) or None
        roads, dirs = _source_roads_dir(source, ctx, owf)
        if not roads:
            raise QgsProcessingException("Nessuna geometria valida.")
        seg, sdir, stats = network_prepare.node_network(
            roads, self.parameterAsDouble(parameters, self.SNAP, context),
            self.parameterAsDouble(parameters, self.MINSEG, context),
            directions=dirs,
            progress=lambda p: feedback.setProgress(int(p)))
        feedback.pushInfo(network_prepare.prepare_summary(stats))
        result = net_layers.build_prepared_layer(seg, sdir)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class NetworkDiagnosticsAlgorithm(QgsProcessingAlgorithm):
    ROADS, SOURCES, DESTS, SPEED, TIMES, SNAP_MAX = (
        "ROADS", "SOURCES", "DESTS", "SPEED", "TIMES", "SNAP_MAX")
    OUT_COMP, OUT_CROSS = "OUTPUT_COMPONENTS", "OUTPUT_CROSSINGS"

    def name(self):
        return "networkdiagnostics"

    def displayName(self):
        return "Diagnostica rete"

    def group(self):
        return "Rete stradale"

    def groupId(self):
        return "rete"

    def createInstance(self):
        return NetworkDiagnosticsAlgorithm()

    def shortHelpString(self):
        return ("Valida la rete: componenti scollegate, sorgenti/destinazioni "
                "non agganciate o isolate, incroci non noded. Output: componenti "
                "(linee) e incroci non noded (punti); i problemi nel Log.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS, "Rete stradale", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.SOURCES, "Sorgenti (opz.)", [QgsProcessing.TypeVectorPoint],
            optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.DESTS, "Destinazioni (opz.)", [QgsProcessing.TypeVectorPoint],
            optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPEED, "Velocità (km/h)",
            QgsProcessingParameterNumber.Double, 4.8, minValue=0.1))
        self.addParameter(QgsProcessingParameterString(
            self.TIMES, "Tempi (min)", "5,10,15"))
        self.addParameter(QgsProcessingParameterNumber(
            self.SNAP_MAX, "Distanza max snap (m)",
            QgsProcessingParameterNumber.Double, 500.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUT_COMP, "Componenti"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUT_CROSS, "Incroci non noded"))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import network_diagnostics as nd, net_layers
        ctx = context.transformContext()
        rsrc = self.parameterAsSource(parameters, self.ROADS, context)
        roads, dirs = _source_roads_dir(rsrc, ctx, None)
        ssrc = self.parameterAsSource(parameters, self.SOURCES, context)
        dsrc = self.parameterAsSource(parameters, self.DESTS, context)
        sources = _source_points_latlon(ssrc, ctx) if ssrc else None
        dests = _source_points_latlon(dsrc, ctx) if dsrc else None
        times = _parse_times(self.parameterAsString(parameters, self.TIMES, context))
        rep = nd.diagnose_network(
            roads, sources_latlon=sources, dests_latlon=dests, times_min=times,
            speed_kmh=self.parameterAsDouble(parameters, self.SPEED, context),
            snap_max_m=self.parameterAsDouble(parameters, self.SNAP_MAX, context),
            progress=lambda p: feedback.setProgress(int(p)))
        for it in rep["issues"]:
            feedback.pushInfo("[%s] %s" % (it["severity"], it["message"]))
        comp = net_layers.build_components_layer(
            rep["segments"], rep["comp_of_seg"], rep["main_comp"])
        cross = net_layers.build_points_diag_layer(
            [(la, lo, {}) for la, lo in rep["crossings"]], "incroci")
        dc = _copy_to_sink(self, comp, parameters, context, self.OUT_COMP)
        dx = _copy_to_sink(self, cross, parameters, context, self.OUT_CROSS)
        return {self.OUT_COMP: dc, self.OUT_CROSS: dx}


class ScenarioCompareAlgorithm(QgsProcessingAlgorithm):
    ROADS_A, ROADS_B, ORIGINS, DESTS, WEIGHT, SPEED, TIMES, OUTPUT = (
        "ROADS_A", "ROADS_B", "ORIGINS", "DESTS", "WEIGHT", "SPEED",
        "TIMES", "OUTPUT")

    def name(self):
        return "scenariocompare"

    def displayName(self):
        return "Scenario A/B — accessibilità (rete)"

    def group(self):
        return "Accessibilità"

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return ScenarioCompareAlgorithm()

    def shortHelpString(self):
        return ("Confronta l'accessibilità cumulativa sulle stesse origini con "
                "due reti (A = stato attuale, B = progetto). Output: origini con "
                "a_value/b_value/delta/delta_pct/classe (gain/loss/unchanged).")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS_A, "Rete A", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ROADS_B, "Rete B", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ORIGINS, "Origini", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.DESTS, "Destinazioni",
            [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterField(
            self.WEIGHT, "Campo peso (opz.)",
            parentLayerParameterName=self.DESTS, optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPEED, "Velocità (km/h)",
            QgsProcessingParameterNumber.Double, 4.5, minValue=0.1))
        self.addParameter(QgsProcessingParameterString(
            self.TIMES, "Tempi (min)", "15,30"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Scenario A/B"))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import scenarios, net_layers
        ctx = context.transformContext()
        osrc = self.parameterAsSource(parameters, self.ORIGINS, context)
        dsrc = self.parameterAsSource(parameters, self.DESTS, context)
        ra = _source_roads(self.parameterAsSource(parameters, self.ROADS_A, context), ctx)
        rb = _source_roads(self.parameterAsSource(parameters, self.ROADS_B, context), ctx)
        wf = self.parameterAsString(parameters, self.WEIGHT, context) or None
        speed = self.parameterAsDouble(parameters, self.SPEED, context)
        times = _parse_times(self.parameterAsString(parameters, self.TIMES, context))
        if not times:
            raise QgsProcessingException("Tempi non validi.")
        origins = [(la, lo) for la, lo, _ in _source_points_weighted(osrc, ctx)]
        dests = _source_points_weighted(dsrc, ctx, wf)
        if not origins or not dests:
            raise QgsProcessingException("Origini/destinazioni vuote.")
        rows, t = scenarios.accessibility_ab(
            origins, dests, ra, rb, speed, times,
            progress=lambda p: feedback.setProgress(int(p)))
        s = scenarios.scenario_summary(rows)
        feedback.pushInfo("Migliorate: %d, peggiorate: %d, invariate: %d; "
                          "delta medio %.2f (@%g min)."
                          % (s["migliorate"], s["peggiorate"], s["invariate"],
                             s["delta_medio"], t))
        mat = osrc.materialize(QgsFeatureRequest())
        result = net_layers.build_scenario_layer(mat, rows)
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class ScenarioPtalAlgorithm(QgsProcessingAlgorithm):
    GTFS_A, GTFS_B, POINTS, START, END, DATE, OUTPUT = (
        "GTFS_A", "GTFS_B", "POINTS", "START", "END", "DATE", "OUTPUT")

    def name(self):
        return "scenarioptal"

    def displayName(self):
        return "Scenario A/B — PTAL (due GTFS)"

    def group(self):
        return "Accessibilità"

    def groupId(self):
        return "accessibilita"

    def createInstance(self):
        return ScenarioPtalAlgorithm()

    def shortHelpString(self):
        return ("Confronta il PTAL sugli stessi punti con due feed GTFS "
                "(A = attuale, B = progetto). Output: punti con a_value/b_value "
                "(livello PTAL 0..8), delta e classe gain/loss/unchanged.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            self.GTFS_A, "Feed GTFS A (.zip)", extension="zip"))
        self.addParameter(QgsProcessingParameterFile(
            self.GTFS_B, "Feed GTFS B (.zip)", extension="zip"))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, "Punti di analisi", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterNumber(
            self.START, "Ora inizio",
            QgsProcessingParameterNumber.Integer, 7, minValue=0, maxValue=23))
        self.addParameter(QgsProcessingParameterNumber(
            self.END, "Ora fine",
            QgsProcessingParameterNumber.Integer, 10, minValue=1, maxValue=30))
        self.addParameter(QgsProcessingParameterString(
            self.DATE, "Data servizio YYYYMMDD (opz.)", "", optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Scenario PTAL A/B"))

    def processAlgorithm(self, parameters, context, feedback):
        from .core import scenarios, net_layers
        ctx = context.transformContext()
        ga = self.parameterAsFile(parameters, self.GTFS_A, context)
        gb = self.parameterAsFile(parameters, self.GTFS_B, context)
        psrc = self.parameterAsSource(parameters, self.POINTS, context)
        start = self.parameterAsInt(parameters, self.START, context)
        end = self.parameterAsInt(parameters, self.END, context)
        date = self.parameterAsString(parameters, self.DATE, context).strip()
        date = date if (len(date) == 8 and date.isdigit()) else None
        coords = _source_points_latlon(psrc, ctx)
        if not coords:
            raise QgsProcessingException("Nessun punto valido.")
        rows = scenarios.ptal_ab(
            coords, ga, gb, start, end, service_date=date,
            progress=lambda p: feedback.setProgress(int(p)))
        s = scenarios.scenario_summary(rows)
        feedback.pushInfo("PTAL migliorato in %d punti, peggiorato in %d, "
                          "invariato in %d." % (s["migliorate"], s["peggiorate"],
                                                s["invariate"]))
        mat = psrc.materialize(QgsFeatureRequest())
        result = net_layers.build_scenario_layer(mat, rows, "Scenario PTAL A/B")
        dest = _copy_to_sink(self, result, parameters, context, self.OUTPUT)
        return {self.OUTPUT: dest}


class MicProvider(QgsProcessingProvider):
    def id(self):
        return "mic"

    def name(self):
        return "MIC - Utilities"

    def icon(self):
        return QIcon(self.svgIconPath())

    def svgIconPath(self):  # noqa: N802 (API QGIS)
        import os
        return os.path.join(os.path.dirname(__file__), "icon.svg")

    def loadAlgorithms(self):
        self.addAlgorithm(SpaceSyntaxAlgorithm())
        self.addAlgorithm(RoadLengthsAlgorithm())
        self.addAlgorithm(NetworkIsochronesAlgorithm())
        self.addAlgorithm(PtalAlgorithm())
        self.addAlgorithm(AccessibilityAlgorithm())
        self.addAlgorithm(PrepareNetworkAlgorithm())
        self.addAlgorithm(NetworkDiagnosticsAlgorithm())
        self.addAlgorithm(ScenarioCompareAlgorithm())
        self.addAlgorithm(ScenarioPtalAlgorithm())
