# -*- coding: utf-8 -*-
"""Generazione del report Excel con grafici della velocita' per linea.

Usa XlsxWriter incluso in road_network_analyzer/vendor (puro Python), cosi'
da non dipendere da openpyxl/xlsxwriter installati nel Python di QGIS.
"""
import os
import sys

_VENDOR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "vendor")
if _VENDOR not in sys.path:
    sys.path.insert(0, _VENDOR)

import xlsxwriter  # noqa: E402  (import dopo l'aggiunta del path vendor)


def _line_label(key, line_metrics):
    rid, direction = key
    meta = line_metrics.get(key, {})
    name = meta.get("route_short_name") or rid
    return "%s (dir %s)" % (name, direction)


def write_equity_report(path, summary, value_name="valore"):
    """Scrive un .xlsx con sintesi ed equità + grafico della curva di Lorenz.

    :param summary: dict da equity.compute_equity (n, media, mediana, gini,
        pct_servita, lorenz=[(quota_pop, quota_valore), ...]).
    """
    wb = xlsxwriter.Workbook(path, {"nan_inf_to_errors": True})
    bold = wb.add_format({"bold": True})
    num3 = wb.add_format({"num_format": "0.000"})

    ws = wb.add_worksheet("Sintesi")
    ws.write(0, 0, "Metrica", bold)
    ws.write(0, 1, "Valore", bold)
    rows = [
        ("Campo valutato", value_name),
        ("N. feature", summary.get("n", 0)),
        ("Peso totale", summary.get("peso_totale", 0.0)),
        ("Media pesata", summary.get("media", 0.0)),
        ("Mediana pesata", summary.get("mediana", 0.0)),
        ("Indice di Gini", summary.get("gini", 0.0)),
    ]
    if summary.get("pct_servita") is not None:
        rows.append(("% servita (>= soglia)", summary["pct_servita"]))
    for r, (k, v) in enumerate(rows, start=1):
        ws.write(r, 0, k)
        ws.write(r, 1, v)

    # curva di Lorenz
    lor = summary.get("lorenz") or []
    lw = wb.add_worksheet("Lorenz")
    lw.write(0, 0, "quota_popolazione", bold)
    lw.write(0, 1, "quota_valore", bold)
    lw.write(0, 2, "uguaglianza", bold)
    for i, (x, y) in enumerate(lor, start=1):
        lw.write(i, 0, x)
        lw.write(i, 1, y, num3)
        lw.write(i, 2, x, num3)
    nrow = len(lor)
    if nrow >= 2:
        chart = wb.add_chart({"type": "scatter",
                              "subtype": "straight"})
        chart.add_series({
            "name": "Curva di Lorenz",
            "categories": ["Lorenz", 1, 0, nrow, 0],
            "values": ["Lorenz", 1, 1, nrow, 1],
        })
        chart.add_series({
            "name": "Uguaglianza perfetta",
            "categories": ["Lorenz", 1, 0, nrow, 0],
            "values": ["Lorenz", 1, 2, nrow, 2],
        })
        chart.set_x_axis({"name": "Quota cumulata di popolazione"})
        chart.set_y_axis({"name": "Quota cumulata di accessibilità"})
        chart.set_title({"name": "Curva di Lorenz (Gini=%.3f)"
                         % summary.get("gini", 0.0)})
        lw.insert_chart("E2", chart)
    wb.close()
    return path


def write_line_speed_report(path, line_metrics, sched_hourly, obs_hourly,
                            rt_lines=None):
    """Scrive un .xlsx con dati e grafici velocita' teorica vs osservata.

    :param line_metrics: {(route_id, dir): {...}} dal GTFS statico
    :param sched_hourly: {(route_id, dir): {hour: kmh}} programmata per ora
    :param obs_hourly:   {(route_id, dir): {hour: kmh}} osservata per ora
    :param rt_lines:     {(route_id, dir): {eff_speed_kmh, ...}} opzionale
    """
    rt_lines = rt_lines or {}
    keys = sorted(set(line_metrics) | set(sched_hourly) | set(obs_hourly))

    wb = xlsxwriter.Workbook(path, {"nan_inf_to_errors": True})
    bold = wb.add_format({"bold": True})
    num2 = wb.add_format({"num_format": "0.00"})

    _write_summary(wb, bold, num2, keys, line_metrics, rt_lines)
    n_rows = _write_data(wb, bold, num2, keys, line_metrics, sched_hourly, obs_hourly)
    _write_charts(wb, keys, line_metrics, n_rows)

    wb.close()
    return path


def _write_summary(wb, bold, num2, keys, line_metrics, rt_lines):
    ws = wb.add_worksheet("Riepilogo")
    headers = ["Linea", "Direzione", "Commerciale prog. (km/h)",
               "Esercizio prog. (km/h)", "Effettiva RT (km/h)",
               "Sosta media (s)", "N corse"]
    for c, h in enumerate(headers):
        ws.write(0, c, h, bold)
    for r, key in enumerate(keys, start=1):
        m = line_metrics.get(key, {})
        eff = rt_lines.get(key, {}).get("eff_speed_kmh")
        ws.write(r, 0, m.get("route_short_name") or key[0])
        ws.write(r, 1, key[1])
        ws.write_number(r, 2, round(m.get("commercial_speed_kmh", 0), 2), num2)
        ws.write_number(r, 3, round(m.get("running_speed_kmh", 0), 2), num2)
        if eff is not None:
            ws.write_number(r, 4, round(eff, 2), num2)
        else:
            ws.write(r, 4, "-")
        ws.write_number(r, 5, round(m.get("mean_dwell_s", 0), 0))
        ws.write_number(r, 6, m.get("n_trips", 0))
    ws.set_column(0, 6, 22)


def _write_data(wb, bold, num2, keys, line_metrics, sched_hourly, obs_hourly):
    """Foglio Dati: una riga per ora (0-23), due colonne per linea."""
    ws = wb.add_worksheet("Dati")
    ws.write(0, 0, "Ora", bold)
    col = 1
    cols = {}
    for key in keys:
        label = _line_label(key, line_metrics)
        ws.write(0, col, "%s teorica" % label, bold)
        ws.write(0, col + 1, "%s osservata" % label, bold)
        cols[key] = (col, col + 1)
        col += 2

    hours = list(range(24))
    for i, h in enumerate(hours):
        row = i + 1
        ws.write_number(row, 0, h)
        for key in keys:
            c0, c1 = cols[key]
            sc = sched_hourly.get(key, {}).get(h)
            ob = obs_hourly.get(key, {}).get(h)
            if sc is not None:
                ws.write_number(row, c0, round(sc, 2), num2)
            if ob is not None:
                ws.write_number(row, c1, round(ob, 2), num2)
    ws._rna_cols = cols  # passato a _write_charts
    return len(hours)


def _write_charts(wb, keys, line_metrics, n_rows):
    ws = wb.add_worksheet("Grafici")
    data_ws = wb.get_worksheet_by_name("Dati")
    cols = getattr(data_ws, "_rna_cols", {})
    chart_row = 1
    for key in keys:
        if key not in cols:
            continue
        c0, c1 = cols[key]
        chart = wb.add_chart({"type": "line"})
        chart.add_series({
            "name": "Teorica",
            "categories": ["Dati", 1, 0, n_rows, 0],
            "values": ["Dati", 1, c0, n_rows, c0],
            "line": {"dash_type": "dash", "color": "#1565C0"},
        })
        chart.add_series({
            "name": "Osservata",
            "categories": ["Dati", 1, 0, n_rows, 0],
            "values": ["Dati", 1, c1, n_rows, c1],
            "line": {"color": "#C62828"},
        })
        chart.set_title({"name": "Linea %s" % _line_label(key, line_metrics)})
        chart.set_x_axis({"name": "Ora del giorno"})
        # sono velocità di esercizio (tempi di marcia, soste escluse)
        chart.set_y_axis({"name": "Velocita' di esercizio (km/h)"})
        chart.set_size({"width": 720, "height": 320})
        ws.insert_chart(chart_row, 1, chart)
        chart_row += 17
