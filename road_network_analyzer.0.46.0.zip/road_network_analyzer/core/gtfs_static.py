# -*- coding: utf-8 -*-
"""Lettura del GTFS statico e calcolo delle metriche programmate.

Costruisce:
  * geometrie delle linee dalle shapes;
  * segmenti stop-to-stop con lunghezza, tempo e velocita' programmati;
  * metriche di linea (velocita' commerciale e di esercizio, sosta media).

Usa pandas (disponibile nel Python di QGIS) per join e aggregazioni.
Le distanze sono misurate in modo ellissoidale su WGS84.
"""
import contextlib
import math
import os
import zipfile
from array import array
from collections import defaultdict

try:  # pandas è opzionale: serve solo alle funzioni GTFS
    import pandas as pd
except ImportError:  # pragma: no cover
    pd = None

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsDistanceArea,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsUnitTypes,
)

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


class GtfsCancelled(Exception):
    """Sollevata quando l'utente annulla il caricamento in background."""


def _geod():
    da = QgsDistanceArea()
    da.setSourceCrs(WGS84, QgsProject.instance().transformContext())
    da.setEllipsoid("WGS84")
    return da


def interpolate_trip_times(trip_ids, seq, sec):
    """Orari mancanti delle fermate senza orario (non timepoint), interpolati.

    Nel GTFS le fermate intermedie possono avere arrival/departure vuoti: qui
    prendono un tempo interpolato fra la fermata con orario precedente e la
    successiva della stessa corsa (ordine stop_sequence). Senza, quelle
    fermate risultano senza passaggi.

    :param trip_ids, seq, sec: Series allineate (seq e sec numerici o NaN).
    :return: Series dei secondi allineata a sec.
    """
    if not sec.isna().any():
        return sec
    tmp = pd.DataFrame({"t": trip_ids.values,
                        "q": pd.to_numeric(seq, errors="coerce").values,
                        "s": sec.values}, index=sec.index)
    tmp = tmp.sort_values(["t", "q"])
    tmp["s"] = tmp.groupby("t", sort=False)["s"].transform(
        lambda x: x.interpolate(limit_area="inside"))
    return tmp["s"].reindex(sec.index)


def _require_pandas():
    if pd is None:
        raise RuntimeError(
            "Le funzioni GTFS richiedono il modulo 'pandas', non installato nel "
            "Python di QGIS. Installalo dalla OSGeo4W Shell: "
            "python -m pip install pandas.")


_ANCHORS = ("stop_times.txt", "trips.txt", "stops.txt")


def _zip_prefix(names):
    """Cartella del feed dentro lo zip: quella (meno profonda) che contiene
    le tabelle principali. Con più feed in sottocartelle diverse le tabelle
    si leggono tutte dalla stessa (prima si mescolavano)."""
    best = None
    for anchor in _ANCHORS:
        for n in names:
            m = n.replace("\\", "/")
            if "__MACOSX" in m or m.rsplit("/", 1)[-1] != anchor:
                continue
            pre = m[:-len(anchor)]
            if best is None or pre.count("/") < best.count("/"):
                best = pre
        if best is not None:
            return best
    return ""


def _zip_member(zf, name):
    """Nome del membro dello zip che corrisponde alla tabella `name`.

    Accetta anche i feed con i file dentro una sottocartella (zip creati
    comprimendo la cartella).
    """
    names = zf.namelist()
    if name in names:
        return name
    pre = _zip_prefix(names)
    for n in names:
        if n.replace("\\", "/") == pre + name:
            return n
    return None


def _feed_dir(source):
    """Cartella del feed: la sorgente o la sottocartella (meno profonda, al
    massimo due livelli) che contiene le tabelle principali."""
    for anchor in _ANCHORS:
        if os.path.exists(os.path.join(source, anchor)):
            return source
    for anchor in _ANCHORS:
        found = []
        for root, dirs, files in os.walk(source):
            depth = root[len(source):].count(os.sep)
            if depth >= 2:
                dirs[:] = []
            if anchor in files:
                found.append((depth, root))
        if found:
            return min(found)[1]
    return source


def _dir_member(source, name):
    path = os.path.join(_feed_dir(source), name)
    return path if os.path.exists(path) else None


def feed_files(source):
    """Nomi (senza cartella) delle tabelle presenti nel feed."""
    if os.path.isdir(source):
        return set(os.listdir(_feed_dir(source)))
    with zipfile.ZipFile(source) as zf:
        names = zf.namelist()
        pre = _zip_prefix(names)
        return {n.replace("\\", "/")[len(pre):] for n in names
                if n.replace("\\", "/").startswith(pre)
                and not n.endswith("/") and "__MACOSX" not in n
                and "/" not in n.replace("\\", "/")[len(pre):]}


def feed_signature(source):
    """Chiave che cambia quando cambia il feed (anche un file dentro una
    cartella: la data della cartella da sola non cambia)."""
    try:
        if os.path.isdir(source):
            d = _feed_dir(source)
            return (os.path.abspath(source),) + tuple(sorted(
                (f, os.path.getmtime(os.path.join(d, f)),
                 os.path.getsize(os.path.join(d, f)))
                for f in os.listdir(d) if f.endswith(".txt")))
        return (os.path.abspath(source), os.path.getmtime(source),
                os.path.getsize(source))
    except OSError:
        return None


@contextlib.contextmanager
def open_table(source, name):
    """File binario della tabella GTFS (cartella o zip, anche in una
    sottocartella), o None se assente. Da usare con `with`."""
    if os.path.isdir(source):
        path = _dir_member(source, name)
        if path is None:
            yield None
            return
        with open(path, "rb") as fh:
            yield fh
        return
    with zipfile.ZipFile(source) as zf:
        member = _zip_member(zf, name)
        if member is None:
            yield None
            return
        with zf.open(member) as fh:
            yield fh


_ENC_CACHE = {}
_ENC_LIMIT = 64 * 1024 * 1024
_BOM = b"\xef\xbb\xbf"


def table_encoding(source, name):
    """Codifica della tabella: UTF-8 (con o senza BOM) o, se non è UTF-8
    valido, Windows-1252/Latin-1 (feed esportati da Excel o da sistemi
    vecchi). Si controllano i primi 64 MB; prima un nome accentato in
    latin-1 faceva fallire l'intero caricamento."""
    sig = feed_signature(source)
    key = (sig, name) if sig is not None else None
    if key is not None and key in _ENC_CACHE:
        return _ENC_CACHE[key]
    enc = "utf-8-sig"
    with open_table(source, name) as fh:
        data = fh.read(_ENC_LIMIT) if fh is not None else b""
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # un carattere multibyte tagliato conta solo se il blocco letto è
        # stato troncato al limite (altrimenti il file finisce lì)
        if len(data) < _ENC_LIMIT or exc.start < len(data) - 4:
            try:
                data.decode("cp1252")
                enc = "cp1252"
            except UnicodeDecodeError:
                enc = "latin-1"
    if key is not None:
        _ENC_CACHE[key] = enc
    return enc


def _skip_bom(fh, enc):
    """Con una codifica non UTF-8 il BOM finirebbe nel primo nome di
    colonna ("ï»¿stop_id"): lo si salta."""
    if enc == "utf-8-sig":
        return
    try:
        head = fh.peek(3)[:3]
    except Exception:
        return
    if head == _BOM:
        fh.read(3)


def read_csv_table(source, name, **kwargs):
    """pandas.read_csv della tabella (None se assente o vuota), con la
    codifica giusta. Con `chunksize` usare read_csv_chunks."""
    _require_pandas()
    enc = table_encoding(source, name)
    with open_table(source, name) as fh:
        if fh is None:
            return None
        _skip_bom(fh, enc)
        try:
            return pd.read_csv(fh, encoding=enc, **kwargs)
        except pd.errors.EmptyDataError:
            return None  # file di 0 byte: come se mancasse


def read_csv_chunks(source, name, consume, **kwargs):
    """Legge la tabella a blocchi passando ogni blocco a consume(chunk).

    :return: False se la tabella non c'è (o è vuota).
    """
    _require_pandas()
    enc = table_encoding(source, name)
    with open_table(source, name) as fh:
        if fh is None:
            return False
        _skip_bom(fh, enc)
        try:
            reader = pd.read_csv(fh, encoding=enc, **kwargs)
        except pd.errors.EmptyDataError:
            return False
        for chunk in reader:
            consume(chunk)
    return True


def read_trip_blocks(source, consume, allowed, usecols, chunksize=400000,
                     is_canceled=None):
    """stop_times a blocchi di corse INTERE (solo le corse in `allowed`).

    Le righe dell'ultima corsa di ogni blocco letto passano al blocco dopo:
    così l'interpolazione degli orari e il riconoscimento dell'ultima
    fermata non si spezzano a metà corsa (vale per i file ordinati per corsa,
    cioè quasi tutti).
    """
    held = []

    def _feed(chunk):
        if is_canceled and is_canceled():
            raise GtfsCancelled()
        chunk = chunk[chunk["trip_id"].isin(allowed)]
        if held:
            chunk = pd.concat([held.pop(), chunk], ignore_index=True)
        if chunk.empty:
            return
        tail = chunk["trip_id"] == chunk["trip_id"].iloc[-1]
        held.append(chunk[tail])
        body = chunk[~tail]
        if not body.empty:
            consume(body)

    read_csv_chunks(source, "stop_times.txt", _feed, dtype=str,
                    keep_default_na=False, usecols=usecols,
                    chunksize=chunksize)
    if held and not held[0].empty:
        consume(held.pop())


def service_date_used(source, trips, service_date=None):
    """Data YYYYMMDD che select_trips usa (quella indicata se il feed la
    copre, altrimenti il giorno più carico); None senza calendario."""
    if "service_id" not in trips.columns:
        return None
    if service_date:
        act = active_services(source, service_date)
        if act is not None and trips["service_id"].isin(act).any():
            return str(service_date)
    best = busiest_service_date(source, trips)
    return best[0] if best else None


def previous_day_trips(source, trips, service_date=None):
    """Corse del giorno prima di quello analizzato.

    Le loro fermate con orario ≥ 24:00 cadono nel giorno analizzato (dalle
    00:00 alle ~04:00): senza, il servizio notturno spariva.
    """
    import datetime
    d = service_date_used(source, trips, service_date)
    if not d:
        return set()
    try:
        prev = (datetime.date(int(d[:4]), int(d[4:6]), int(d[6:8]))
                - datetime.timedelta(days=1)).strftime("%Y%m%d")
    except ValueError:
        return set()
    act = active_services(source, prev)
    if not act:
        return set()
    return set(trips.loc[trips["service_id"].isin(act), "trip_id"])


def _read_table(source, name, usecols=None, dtype=str):
    """Legge una tabella GTFS da cartella o zip; None se assente."""
    _require_pandas()
    return read_csv_table(source, name, dtype=dtype, keep_default_na=False,
                          usecols=usecols)


def _table_columns(source, name):
    """Colonne presenti in una tabella GTFS senza caricarne i dati."""
    df = read_csv_table(source, name, nrows=0)
    return None if df is None else [str(c) for c in df.columns]


def _read_subset(source, name, needed):
    """Legge solo le colonne richieste (se presenti) per ridurre la memoria."""
    cols = _table_columns(source, name)
    if cols is None:
        return None
    use = [c for c in needed if c in cols]
    return _read_table(source, name, usecols=use or None)


def list_routes(source):
    """Elenco delle linee del feed (per il filtro pre-caricamento).

    Legge solo routes.txt (file piccolo): [{route_id, short_name, long_name}].
    """
    routes = _read_table(source, "routes.txt")
    if routes is None:
        return []
    out = []
    for r in routes.itertuples(index=False):
        out.append({
            "route_id": r.route_id,
            "short_name": getattr(r, "route_short_name", ""),
            "long_name": getattr(r, "route_long_name", ""),
        })
    out.sort(key=lambda d: (d["short_name"] or d["route_id"]))
    return out


_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday",
             "saturday", "sunday"]
REQUIRED_FILES = ["agency.txt", "stops.txt", "routes.txt", "trips.txt",
                  "stop_times.txt"]


def active_services(source, service_date):
    """Set di service_id attivi in una data (YYYYMMDD).

    Combina calendar.txt (giorno della settimana + intervallo di validità) e
    calendar_dates.txt (eccezioni: 1=aggiunto, 2=rimosso). Ritorna None se non
    c'è alcun calendario (il chiamante userà il giorno di servizio dominante).
    """
    import datetime
    s = str(service_date)
    if len(s) != 8 or not s.isdigit():
        return None
    try:
        d = datetime.date(int(s[0:4]), int(s[4:6]), int(s[6:8]))
    except ValueError:
        return None
    wcol = _WEEKDAYS[d.weekday()]
    cal = _read_table(source, "calendar.txt")
    cd = _read_table(source, "calendar_dates.txt")
    if (cal is None or cal.empty) and (cd is None or cd.empty):
        return None
    active = set()
    if cal is not None and not cal.empty and wcol in cal.columns:
        for r in cal.itertuples(index=False):
            if str(getattr(r, wcol, "0")) != "1":
                continue
            sd = str(getattr(r, "start_date", "") or "")
            ed = str(getattr(r, "end_date", "") or "")
            if (not sd or sd <= s) and (not ed or s <= ed):
                active.add(getattr(r, "service_id"))
    if cd is not None and not cd.empty and "date" in cd.columns:
        for r in cd.itertuples(index=False):
            if str(getattr(r, "date", "")) != s:
                continue
            sid = getattr(r, "service_id")
            et = str(getattr(r, "exception_type", "1"))
            if et == "1":
                active.add(sid)
            elif et == "2":
                active.discard(sid)
    return active


_BUSIEST_CACHE = {}


def busiest_service_date(source, trips):
    """Giorno del calendario con più corse attive: (YYYYMMDD, n_corse) o None.

    Combina calendar.txt (giorni della settimana nell'intervallo di validità,
    al massimo 400 giorni) e calendar_dates.txt (aggiunte/rimozioni). È il
    giorno da usare quando l'utente non indica una data: tutti i servizi
    attivi quel giorno (bus, tram, metro…), non un solo service_id.
    """
    import datetime
    key = feed_signature(source)
    if key is not None and key in _BUSIEST_CACHE:
        return _BUSIEST_CACHE[key]
    per_service = trips["service_id"].value_counts().to_dict()
    date_services = defaultdict(set)
    cal = _read_table(source, "calendar.txt")
    if cal is not None and not cal.empty and "start_date" in cal.columns:
        for r in cal.itertuples(index=False):
            try:
                d0 = datetime.datetime.strptime(str(r.start_date), "%Y%m%d").date()
                d1 = datetime.datetime.strptime(str(r.end_date), "%Y%m%d").date()
            except (ValueError, AttributeError):
                continue
            d1 = min(d1, d0 + datetime.timedelta(days=400))
            d = d0
            while d <= d1:
                if str(getattr(r, _WEEKDAYS[d.weekday()], "0")) == "1":
                    date_services[d.strftime("%Y%m%d")].add(r.service_id)
                d += datetime.timedelta(days=1)
    cd = _read_table(source, "calendar_dates.txt")
    if cd is not None and not cd.empty and "date" in cd.columns             and "service_id" in cd.columns:
        ets = (cd["exception_type"].astype(str) if "exception_type" in cd.columns
               else ["1"] * len(cd))
        for date, sid, et in zip(cd["date"], cd["service_id"], ets):
            if et == "1":
                date_services[str(date)].add(sid)
            elif et == "2":
                date_services[str(date)].discard(sid)
    best = None
    for date, sids in date_services.items():
        n = sum(per_service.get(s, 0) for s in sids)
        # a parità di corse, la data più vicina all'inizio del feed
        if n and (best is None or n > best[1] or (n == best[1] and date < best[0])):
            best = (date, n)
    if key is not None:
        _BUSIEST_CACHE[key] = best
    return best


def select_trips(trips, source, service_date=None):
    """Filtra il DataFrame trips per data reale (calendario) o giorno più carico.

    Senza data (o con una data non coperta dal feed) usa il giorno del
    calendario con più corse: prima si usava il solo service_id più frequente,
    che in feed come quello di Roma esclude interi modi (metro, tram).

    :return: (trips_filtrato, descrizione testuale del criterio).
    """
    if "service_id" not in trips.columns or trips["service_id"].empty:
        return trips, "tutti i servizi"
    note = ""
    if service_date:
        active = active_services(source, service_date)
        if active is not None:
            sub = trips[trips["service_id"].isin(active)]
            if not sub.empty:
                return sub, "data %s (%d servizi attivi, %d corse)" % (
                    service_date, len(active), len(sub))
            note = "la data %s non è coperta dal feed: " % service_date
    best = busiest_service_date(source, trips)
    if best is not None:
        active = active_services(source, best[0]) or set()
        sub = trips[trips["service_id"].isin(active)]
        if not sub.empty:
            return sub, "%sgiorno più carico del feed %s (%d corse)" % (
                note, best[0], len(sub))
    dominant = trips["service_id"].value_counts().idxmax()
    return (trips[trips["service_id"] == dominant],
            "%sservizio più frequente (%s): il feed non ha calendario"
            % (note, dominant))


def validate_feed(source, progress=None, is_canceled=None):
    """Controlli sul feed GTFS. Ritorna (ok, messaggi, info).

    Errori (ok=False): file richiesti mancanti, corse senza linea o senza
    calendario, orari che citano fermate inesistenti. Avvisi: fermate senza
    coordinate, orari mancanti (interpolati in analisi), fuso non valido,
    codifica non UTF-8, file in una sottocartella dello zip. Informazioni:
    numero di linee/corse/fermate, periodo di validità (anche con il solo
    calendar_dates.txt) e giorno più carico.
    """
    msgs = []
    warn = []
    info = {}

    def _p(v):
        if progress:
            progress(v)
        if is_canceled and is_canceled():
            raise GtfsCancelled()

    try:
        present = feed_files(source)
    except Exception as exc:
        return False, ["Impossibile aprire il feed: %s" % exc], {}
    missing = [f for f in REQUIRED_FILES if f not in present]
    ok = not missing
    if missing:
        msgs.append("File richiesti mancanti: %s." % ", ".join(missing))
    if not os.path.isdir(source):
        with zipfile.ZipFile(source) as zf:
            if any("/" in n.replace("\\", "/").rstrip("/")
                   for n in zf.namelist() if n.endswith(".txt")):
                warn.append("i file sono in una sottocartella dello zip "
                            "(letti comunque)")
    has_cal = "calendar.txt" in present
    has_cd = "calendar_dates.txt" in present
    info["calendar"] = has_cal
    info["calendar_dates"] = has_cd
    if not has_cal and not has_cd:
        msgs.append("Né calendar.txt né calendar_dates.txt: si useranno tutte "
                    "le corse del servizio più frequente.")
    for name in ("stops.txt", "stop_times.txt", "trips.txt", "routes.txt"):
        if name in present and table_encoding(source, name) != "utf-8-sig":
            warn.append("%s non è in UTF-8 (letto come %s)"
                        % (name, table_encoding(source, name)))
    _p(5)
    if missing:
        return False, msgs + (["Avvisi: " + "; ".join(warn) + "."]
                              if warn else []), info

    routes = _read_subset(source, "routes.txt", ["route_id"])
    trips = _read_subset(source, "trips.txt",
                         ["trip_id", "route_id", "service_id"])
    stops = _read_subset(source, "stops.txt",
                         ["stop_id", "stop_lat", "stop_lon", "location_type"])
    info.update(n_routes=len(routes), n_trips=len(trips), n_stops=len(stops))
    msgs.append("%d linee, %d corse, %d fermate." % (len(routes), len(trips),
                                                    len(stops)))
    bad_route = int((~trips["route_id"].isin(set(routes["route_id"]))).sum())
    if bad_route:
        ok = False
        msgs.append("%d corse citano linee inesistenti." % bad_route)
    # periodo di validità
    services = set()
    dates = []
    cal = _read_table(source, "calendar.txt") if has_cal else None
    if cal is not None and not cal.empty:
        if "service_id" in cal.columns:
            services |= set(cal["service_id"])
        for c in ("start_date", "end_date"):
            if c in cal.columns:
                dates += [d for d in cal[c] if d]
            else:
                warn.append("calendar.txt senza %s" % c)
    cd = _read_table(source, "calendar_dates.txt") if has_cd else None
    if cd is not None and not cd.empty:
        if "exception_type" not in cd.columns:
            warn.append("calendar_dates.txt senza exception_type (date "
                        "considerate aggiunte)")
            ets = pd.Series("1", index=cd.index)
        else:
            ets = cd["exception_type"].astype(str)
        if "service_id" in cd.columns:
            services |= set(cd.loc[ets == "1", "service_id"])
        if "date" in cd.columns:
            dates += [d for d in cd["date"] if d]
    if dates:
        info["date_min"], info["date_max"] = min(dates), max(dates)
        msgs.append("Validità del servizio: %s – %s."
                    % (info["date_min"], info["date_max"]))
    if services:
        no_cal = int((~trips["service_id"].isin(services)).sum())
        if no_cal:
            ok = False
            msgs.append("%d corse hanno un service_id assente dal "
                        "calendario." % no_cal)
    best = busiest_service_date(source, trips)
    if best:
        info["busiest"] = best
        msgs.append("Giorno più carico: %s (%d corse)." % best)
    _p(20)
    # fermate
    lat = pd.to_numeric(stops["stop_lat"], errors="coerce")
    lon = pd.to_numeric(stops["stop_lon"], errors="coerce")
    bad_xy = int((lat.isna() | lon.isna() | (lat.abs() > 90)
                  | (lon.abs() > 180)).sum())
    if bad_xy:
        warn.append("%d fermate senza coordinate valide" % bad_xy)
    # orari: fermate inesistenti e orari vuoti (lettura a blocchi)
    stop_ids = set(stops["stop_id"])
    trip_ids = set(trips["trip_id"])
    cnt = {"rows": 0, "bad_stop": 0, "bad_trip": 0, "no_time": 0}
    cols = _table_columns(source, "stop_times.txt")
    use = [c for c in ("trip_id", "stop_id", "arrival_time", "departure_time")
           if c in cols]

    def _consume(ch):
        cnt["rows"] += len(ch)
        cnt["bad_stop"] += int((~ch["stop_id"].isin(stop_ids)).sum())
        cnt["bad_trip"] += int((~ch["trip_id"].isin(trip_ids)).sum())
        if "arrival_time" in ch and "departure_time" in ch:
            cnt["no_time"] += int(((ch["arrival_time"].str.strip() == "")
                                   & (ch["departure_time"].str.strip() == ""))
                                  .sum())
        _p(min(95, 20 + cnt["rows"] // 100000))
    read_csv_chunks(source, "stop_times.txt", _consume, dtype=str,
                    keep_default_na=False, usecols=use, chunksize=500000)
    info["n_stop_times"] = cnt["rows"]
    if cnt["bad_stop"]:
        ok = False
        msgs.append("%d righe di stop_times citano fermate inesistenti."
                    % cnt["bad_stop"])
    if cnt["bad_trip"]:
        warn.append("%d righe di stop_times di corse inesistenti (ignorate)"
                    % cnt["bad_trip"])
    if cnt["no_time"]:
        warn.append("%d fermate senza orario (non timepoint): orari "
                    "interpolati per distanza in analisi" % cnt["no_time"])
    st_cols = cols or []
    if "shape_dist_traveled" not in st_cols:
        warn.append("stop_times senza shape_dist_traveled: le fermate "
                    "vengono proiettate sulla shape")
    if "shapes.txt" not in present:
        warn.append("nessun shapes.txt: linee disegnate dalle fermate")
    if "frequencies.txt" in present:
        msgs.append("Corse a frequenza (frequencies.txt) espanse in analisi.")
    tz = _agency_timezone(source)
    if not tz:
        warn.append("agency_timezone mancante")
    else:
        try:
            import pytz
            if tz not in pytz.all_timezones_set:
                warn.append("agency_timezone non valido: %s" % tz)
        except ImportError:
            pass
        info["timezone"] = tz
    if warn:
        msgs.append("Avvisi: " + "; ".join(warn) + ".")
    msgs.insert(0, "Feed valido." if ok else "Feed con errori.")
    _p(100)
    return ok, msgs, info


def _read_stop_times_filtered(source, use, allowed_trips, chunksize=400000):
    """Legge stop_times.txt a blocchi tenendo solo le righe dei trip ammessi.

    Tiene basso il picco di memoria: il file (anche centinaia di MB) viene
    letto a pezzi e di ciascuno si conserva solo il sottoinsieme filtrato.
    """
    frames = []

    def _consume(chunk):
        sub = chunk[chunk["trip_id"].isin(allowed_trips)]
        if not sub.empty:
            frames.append(sub)

    read_csv_chunks(source, "stop_times.txt", _consume, dtype=str,
                    keep_default_na=False, usecols=use, chunksize=chunksize)
    if frames:
        return pd.concat(frames, ignore_index=True)
    return pd.DataFrame(columns=use)


def _seconds_series(col):
    """Serie di orari HH:MM:SS (anche ≥ 24:00) in secondi; NaN se vuoti."""
    parts = col.astype(str).str.strip().str.split(":", expand=True)
    if parts.shape[1] < 3:
        return pd.Series(float("nan"), index=col.index)
    return (pd.to_numeric(parts[0], errors="coerce") * 3600
            + pd.to_numeric(parts[1], errors="coerce") * 60
            + pd.to_numeric(parts[2], errors="coerce"))


def _time_to_seconds(value):
    """HH:MM:SS -> secondi (ammette ore >= 24); None se non valido."""
    if not value or value.count(":") != 2:
        return None
    try:
        h, m, s = value.split(":")
        return int(h) * 3600 + int(m) * 60 + int(s)
    except ValueError:
        return None


# ----------------------------------------------------------------- geometrie
def build_shapes(source):
    """{shape_id: [(lat, lon, dist|None), ...]} ordinato per sequenza."""
    shapes = _read_table(source, "shapes.txt")
    out = {}
    if shapes is None or shapes.empty:
        return out
    has_dist = "shape_dist_traveled" in shapes.columns
    shapes = shapes.copy()
    shapes["seq"] = pd.to_numeric(shapes["shape_pt_sequence"], errors="coerce")
    shapes["lat"] = pd.to_numeric(shapes["shape_pt_lat"], errors="coerce")
    shapes["lon"] = pd.to_numeric(shapes["shape_pt_lon"], errors="coerce")
    if has_dist:
        shapes["dist"] = pd.to_numeric(shapes["shape_dist_traveled"], errors="coerce")
    for sid, grp in shapes.groupby("shape_id"):
        grp = grp.sort_values("seq")
        if has_dist:
            out[sid] = list(zip(grp["lat"], grp["lon"],
                                [d if pd.notna(d) else None for d in grp["dist"]]))
        else:
            out[sid] = [(la, lo, None) for la, lo in zip(grp["lat"], grp["lon"])]
    return out


def _cut_shape(points, d0, d1):
    """Sotto-polilinea della shape tra le distanze d0 e d1 (interpola i capi).

    :return: lista di (lat, lon) oppure None se le distanze non sono usabili.
    """
    dists = [p[2] for p in points]
    if any(d is None for d in dists) or d0 is None or d1 is None:
        return None
    if d1 < d0:
        d0, d1 = d1, d0

    def interp(d):
        if d <= dists[0]:
            return points[0][0], points[0][1]
        if d >= dists[-1]:
            return points[-1][0], points[-1][1]
        for i in range(len(points) - 1):
            a, b = points[i], points[i + 1]
            if a[2] <= d <= b[2]:
                if b[2] == a[2]:
                    return a[0], a[1]
                t = (d - a[2]) / (b[2] - a[2])
                return a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])
        return points[-1][0], points[-1][1]

    coords = [interp(d0)]
    coords.extend((p[0], p[1]) for p in points if d0 < p[2] < d1)
    coords.append(interp(d1))
    return coords


def _geodesic_length(coords_latlon, da):
    """Lunghezza ellissoidale (m) di una polilinea [(lat, lon), ...]."""
    pts = [QgsPointXY(lon, lat) for lat, lon in coords_latlon]
    if len(pts) < 2:
        return 0.0
    return da.convertLengthMeasurement(
        da.measureLength(QgsGeometry.fromPolylineXY(pts)),
        QgsUnitTypes.DistanceMeters,
    )


def _shape_metric(points):
    """Shape in metri locali: (xy, distanze cumulate, punti (lat, lon, m))."""
    lat0 = points[0][0]
    mlat = 111320.0
    mlon = 111320.0 * math.cos(math.radians(lat0))
    xy = [(lo * mlon, la * mlat) for la, lo, _d in points]
    cum = [0.0]
    for (ax, ay), (bx, by) in zip(xy, xy[1:]):
        cum.append(cum[-1] + math.hypot(bx - ax, by - ay))
    pts = [(la, lo, c) for (la, lo, _d), c in zip(points, cum)]
    return xy, cum, pts, (mlon, mlat)


def _project_stops(shape_m, stops_latlon):
    """Posizione (m lungo la shape) di ogni fermata, in ordine di corsa.

    Proiezione in avanti: ogni fermata si cerca dopo la precedente, così le
    linee che ripassano dallo stesso punto (anelli) restano in ordine. Fra
    segmenti di shape quasi equidistanti (entro 25 m) vince il primo.
    """
    xy, cum, _pts, (mlon, mlat) = shape_m
    n = len(xy)
    out = []
    k0 = 0
    for lat, lon in stops_latlon:
        if lat is None or lon is None or lat != lat or lon != lon:
            out.append(float("nan"))
            continue
        px, py = lon * mlon, lat * mlat
        cands = []
        best = None
        for k in range(k0, n - 1):
            ax, ay = xy[k]
            bx, by = xy[k + 1]
            dx, dy = bx - ax, by - ay
            l2 = dx * dx + dy * dy
            t = ((px - ax) * dx + (py - ay) * dy) / l2 if l2 > 0 else 0.0
            t = 0.0 if t < 0 else (1.0 if t > 1 else t)
            d = math.hypot(px - ax - t * dx, py - ay - t * dy)
            cands.append((k, d, cum[k] + t * math.sqrt(l2)))
            if best is None or d < best:
                best = d
            # trovata una buona proiezione: inutile scorrere tutta la shape
            if best < 30.0 and cum[k] - cands[0][2] > 3000.0:
                break
        if not cands:
            out.append(float("nan"))
            continue
        # fra passaggi quasi equidistanti vince il primo, ma con un margine
        # stretto: con 25 m una fermata del ritorno di fronte all'ultima
        # dell'andata finiva sul passaggio sbagliato
        k, _d, pos = next(c for c in cands
                          if c[1] <= best + max(5.0, 0.5 * best))
        out.append(pos)
        k0 = k
    return out


def _fix_times(trip_codes, pos, arr, dep):
    """Orari mancanti e coppie a tempo zero, interpolati per distanza.

    Una fermata senza orario (non timepoint) o con arrivo non successivo alla
    partenza dalla precedente pur essendo più avanti (orari al minuto: due
    fermate alle 10:00) ha un orario ignoto: lo si ricava interpolando per
    distanza fra gli orari noti della corsa. Prima queste coppie venivano
    scartate: la loro lunghezza spariva dal totale della corsa ma il tempo
    restava, e le fermate senza orario facevano perdere interi segmenti.

    :return: (arr, dep, n_eventi_ricostruiti) come array numpy.
    """
    import numpy as np
    arr = np.asarray(arr, dtype="float64").copy()
    dep = np.asarray(dep, dtype="float64").copy()
    arr = np.where(np.isnan(arr), dep, arr)
    dep = np.where(np.isnan(dep), arr, dep)
    tc = np.asarray(trip_codes)
    same = np.r_[False, tc[1:] == tc[:-1]]
    prev_dep = np.r_[np.nan, dep[:-1]]
    prev_pos = np.r_[np.nan, pos[:-1]]
    with np.errstate(invalid="ignore"):
        zero = same & (arr <= prev_dep) & (pos > prev_pos + 1e-6)
        dep_zero = zero & (dep <= arr)
    arr[zero] = np.nan
    dep[dep_zero] = np.nan
    ev_t = np.column_stack((arr, dep)).ravel()
    ev_p = np.repeat(np.asarray(pos, dtype="float64"), 2)
    ev_c = np.repeat(tc, 2)
    known = ~np.isnan(ev_t)
    n_missing = int((~known).sum())
    if n_missing == 0:
        return arr, dep, 0
    st_ = pd.Series(np.where(known, ev_t, np.nan))
    sp_ = pd.Series(np.where(known, ev_p, np.nan))
    pt = st_.groupby(ev_c).ffill().values
    pp = sp_.groupby(ev_c).ffill().values
    nt = st_.groupby(ev_c).bfill().values
    npos = sp_.groupby(ev_c).bfill().values
    with np.errstate(invalid="ignore", divide="ignore"):
        span = npos - pp
        frac = np.where(span > 0, (ev_p - pp) / span, 0.0)
        fill = pt + (nt - pt) * frac
    ev_t = np.where(known, ev_t, fill)
    n_fixed = int((~known & ~np.isnan(ev_t)).sum())
    return ev_t[0::2], ev_t[1::2], n_fixed


def frequency_departures(source, allowed_trips):
    """Partenze (s) delle corse definite in frequencies.txt.

    Una corsa di frequencies.txt è un modello: parte da start_time ogni
    headway_secs fino a end_time (escluso). Prima l'analisi statica la
    contava come una sola corsa.

    :return: {trip_id: [partenze in secondi]} (solo le corse ammesse).
    """
    fr = _read_subset(source, "frequencies.txt",
                      ["trip_id", "start_time", "end_time", "headway_secs"])
    out = {}
    if fr is None or fr.empty:
        return out
    for tid, a, b, h in zip(fr["trip_id"], fr["start_time"], fr["end_time"],
                            fr["headway_secs"]):
        if tid not in allowed_trips:
            continue
        t0 = _time_to_seconds(str(a).strip())
        t1 = _time_to_seconds(str(b).strip())
        try:
            hw = float(h)
        except (TypeError, ValueError):
            continue
        if t0 is None or t1 is None or hw <= 0 or t1 <= t0:
            continue
        lst = out.setdefault(tid, [])
        t = float(t0)
        while t < t1:
            lst.append(t)
            t += hw
    return out


def _agency_timezone(source):
    ag = _read_subset(source, "agency.txt", ["agency_timezone"])
    if ag is not None and "agency_timezone" in ag.columns:
        for tz in ag["agency_timezone"]:
            if str(tz).strip():
                return str(tz).strip()
    return None


def merge_static(acc, new):
    """Unisce un nuovo caricamento (stesso feed e stesso giorno) in `acc`.

    I dizionari di `acc` vengono aggiornati sul posto: chi li tiene (logger
    RT, layer) vede subito le linee aggiunte.
    """
    for k in ("routes", "stops", "shapes_geom", "segments", "trip_index",
              "shape_routes", "line_metrics", "line_hourly_sched",
              "trip_stops"):
        if k in new:
            acc.setdefault(k, {}).update(new[k])
    if "freq_templates" in new:
        acc.setdefault("freq_templates", set()).update(new["freq_templates"])
    for k in ("selection", "timezone", "source", "service_date"):
        if k in new:
            acc[k] = new[k]
    acc["times_fixed"] = acc.get("times_fixed", 0) + new.get("times_fixed", 0)
    return acc


# ------------------------------------------------------------------ pipeline
def analyze_static(source, route_ids=None, progress=None, is_canceled=None,
                   service_date=None):
    """Analizza un feed GTFS (cartella o zip) e restituisce le strutture base.

    :param route_ids: se valorizzato, limita l'analisi a queste linee (route_id).
        Riduce drasticamente la memoria: stop_times viene letto a blocchi
        tenendo solo le corse delle linee scelte.
    :param service_date: YYYYMMDD; si analizzano solo le corse di quel giorno
        (senza data: il giorno più carico del feed). Prima si mescolavano
        tutti i giorni (feriali, festivi…) nei tempi e nel numero di corse.
    :param progress: callable(pct 0-100) opzionale per il progresso.
    :param is_canceled: callable() -> bool opzionale per l'annullamento.
    :return: dict con chiavi
        routes, stops, shapes_geom, segments, trip_index, shape_routes,
        line_metrics, line_hourly_sched
    """
    def _progress(pct):
        if progress:
            progress(pct)

    def _check():
        if is_canceled and is_canceled():
            raise GtfsCancelled()

    da = _geod()
    routes = _read_table(source, "routes.txt")
    trips = _read_subset(source, "trips.txt",
                         ["trip_id", "route_id", "direction_id", "shape_id",
                          "service_id"])
    stops = _read_table(source, "stops.txt")
    if trips is None or stops is None:
        raise ValueError("Feed GTFS incompleto: servono trips.txt, "
                         "stop_times.txt e stops.txt.")

    # un solo giorno di servizio (data scelta o giorno più carico)
    trips, selection = select_trips(trips, source, service_date)
    freq_deps = frequency_departures(source, set(trips["trip_id"]))
    allowed_trips = set(trips["trip_id"])
    # filtro per linea (riduce drasticamente i dati da elaborare)
    if route_ids:
        wanted = set(route_ids)
        trips = trips[trips["route_id"].isin(wanted)].copy()
        allowed_trips = set(trips["trip_id"])
        if not allowed_trips:
            raise ValueError("Nessuna corsa per le linee selezionate nel "
                             "giorno di servizio (%s)." % selection)

    st_need = ["trip_id", "arrival_time", "departure_time",
               "stop_id", "stop_sequence", "shape_dist_traveled"]
    st_cols = _table_columns(source, "stop_times.txt")
    if st_cols is None:
        raise ValueError("Feed GTFS incompleto: manca stop_times.txt.")
    use = [c for c in st_need if c in st_cols]
    if allowed_trips is not None:
        # lettura a blocchi filtrata: poca memoria
        stop_times = _read_stop_times_filtered(source, use, allowed_trips)
    else:
        # dtype compatti: category sulle colonne ad alta ripetizione
        cat = {c: "category" for c in use
               if c in ("trip_id", "stop_id", "arrival_time",
                        "departure_time", "stop_sequence")}
        stop_times = _read_table(source, "stop_times.txt", usecols=use,
                                 dtype=cat or str)
    _check()
    _progress(15)

    shapes_geom = build_shapes(source)
    _check()
    _progress(25)

    # mappa fermate
    stops = stops.copy()
    stops["lat"] = pd.to_numeric(stops["stop_lat"], errors="coerce")
    stops["lon"] = pd.to_numeric(stops["stop_lon"], errors="coerce")
    name_col = "stop_name" if "stop_name" in stops.columns else "stop_id"
    stops_map = {r.stop_id: (r.lat, r.lon, getattr(r, name_col))
                 for r in stops.itertuples(index=False)}

    # mappe trip -> route/direction/shape (evita un merge pesante su milioni
    # di righe; le colonne risultanti restano compatte come category).
    # direction_id vuoto = "0", come nei TripUpdates (prima non combaciavano)
    if "direction_id" not in trips.columns:
        trips = trips.assign(direction_id="0")
    else:
        trips = trips.assign(direction_id=trips["direction_id"].astype(str)
                             .str.strip().replace("", "0"))
    if "shape_id" not in trips.columns:
        trips = trips.assign(shape_id="")
    route_map = dict(zip(trips["trip_id"], trips["route_id"]))
    dir_map = dict(zip(trips["trip_id"], trips["direction_id"].astype(str)))
    shape_map = dict(zip(trips["trip_id"], trips["shape_id"]))

    import numpy as np
    st = stop_times
    st["seq"] = pd.to_numeric(st["stop_sequence"], errors="coerce").astype("float32")
    st["arr_s"] = st["arrival_time"].map(_time_to_seconds).astype("float64") \
        if "arrival_time" in st.columns else np.nan
    st["dep_s"] = st["departure_time"].map(_time_to_seconds).astype("float64") \
        if "departure_time" in st.columns else np.nan
    if "shape_dist_traveled" in st.columns:
        st["sdt"] = pd.to_numeric(
            st["shape_dist_traveled"], errors="coerce").astype("float64")
    else:
        st["sdt"] = np.nan
    st["route_id"] = st["trip_id"].map(route_map).astype("category")
    st["direction_id"] = st["trip_id"].map(dir_map).astype("category")
    st["shape_id"] = st["trip_id"].map(shape_map).astype("category")
    st = st[["trip_id", "stop_id", "seq", "arr_s", "dep_s", "sdt",
             "route_id", "direction_id", "shape_id"]].copy()
    del stop_times
    st = st.sort_values(["trip_id", "seq"]).reset_index(drop=True)
    tc = pd.factorize(st["trip_id"])[0]
    same_prev = np.r_[False, tc[1:] == tc[:-1]]

    # ---- posizione delle fermate lungo la corsa ----
    # shape_dist_traveled; senza, proiezione delle fermate sulla shape (prima i
    # segmenti diventavano linee dritte fra le fermate: lunghezze e velocità
    # sottostimate); senza shape, distanza in linea retta.
    sid_str = st["stop_id"].astype(str)
    lat = sid_str.map({k: v[0] for k, v in stops_map.items()}).astype("float64").values
    lon = sid_str.map({k: v[1] for k, v in stops_map.items()}).astype("float64").values
    mlat_ = 111320.0
    mlon_ = 111320.0 * math.cos(math.radians(float(np.nanmean(lat)) if len(lat) and not np.isnan(lat).all() else 0.0))
    step = np.hypot(np.diff(lon, prepend=np.nan) * mlon_,
                    np.diff(lat, prepend=np.nan) * mlat_)
    step = np.where(same_prev, np.nan_to_num(step), 0.0)
    straight = pd.Series(step).groupby(tc).cumsum().values

    shape_str = st["shape_id"].astype(str).values
    shapes_ok = {sid for sid, pts in shapes_geom.items() if len(pts) >= 2}
    shapes_dist = {sid for sid in shapes_ok
                   if all(p[2] is not None for p in shapes_geom[sid])}
    sdt = st["sdt"].values
    trip_sdt_ok = pd.Series(~np.isnan(sdt)).groupby(tc).transform("all").values
    # shape_dist_traveled di stop_times e shapes in unità diverse (km contro
    # m): le posizioni non si possono usare, si proietta sulla shape
    shape_maxd = {sid: max(p[2] for p in shapes_geom[sid])
                  for sid in shapes_dist}
    trip_max = pd.Series(sdt).groupby(tc).transform("max").values
    smax = pd.Series(shape_str).map(shape_maxd).astype("float64").values
    with np.errstate(invalid="ignore", divide="ignore"):
        ratio = trip_max / smax
    bad_units = (~np.isnan(ratio)) & ((ratio > 1.5) | (ratio < 0.01))
    trip_sdt_ok = trip_sdt_ok & ~bad_units
    sdt_units_fixed = int(len(set(tc[bad_units]))) if bad_units.any() else 0
    has_shape = pd.Series(shape_str).isin(shapes_ok).values
    has_sdist = pd.Series(shape_str).isin(shapes_dist).values
    need = has_shape & ~(trip_sdt_ok & has_sdist)
    pm = np.full(len(st), np.nan)
    shape_m = {}
    if need.any():
        rows = np.flatnonzero(need)
        rtc = tc[rows]
        brk = list(np.flatnonzero(np.r_[True, rtc[1:] != rtc[:-1]])) + [len(rows)]
        cache = {}
        stop_vals = sid_str.values
        for a, b in zip(brk, brk[1:]):
            idx = rows[a:b]
            sid = shape_str[idx[0]]
            pat = (sid, tuple(stop_vals[idx]))
            if pat not in cache:
                if sid not in shape_m:
                    shape_m[sid] = _shape_metric(shapes_geom[sid])
                cache[pat] = _project_stops(
                    shape_m[sid], list(zip(lat[idx], lon[idx])))
            pm[idx] = cache[pat]
        _check()
    pos = np.where(trip_sdt_ok & ~need, sdt, np.where(~np.isnan(pm), pm, straight))

    # ---- orari mancanti e coppie a tempo zero ----
    arr, dep, times_fixed = _fix_times(tc, pos, st["arr_s"].values,
                                       st["dep_s"].values)
    st["arr_s"] = arr
    st["dep_s"] = dep
    st["pm"] = pm
    _check()

    # ---- orari programmati per corsa (per il confronto RT corsa per corsa) ----
    trip_stops = {}
    starts = np.flatnonzero(np.r_[True, tc[1:] != tc[:-1]])
    ends = list(starts[1:]) + [len(st)]
    tid_vals = st["trip_id"].astype(str).values
    seq_vals = st["seq"].values
    stop_vals = sid_str.values
    for a, b in zip(starts, ends):
        trip_stops[tid_vals[a]] = (
            tuple(stop_vals[a:b]),
            array("i", [int(x) if x == x else -1 for x in seq_vals[a:b]]),
            array("d", arr[a:b]),
            array("d", dep[a:b]),
        )

    # coppie di fermate consecutive (shift dentro ogni trip)
    grp = st.groupby("trip_id", sort=False, observed=True)
    st["to_stop"] = grp["stop_id"].shift(-1)
    st["to_arr_s"] = grp["arr_s"].shift(-1)
    st["to_sdt"] = grp["sdt"].shift(-1)
    st["to_pm"] = grp["pm"].shift(-1)
    pairs = st.dropna(subset=["to_stop"]).copy()
    pairs["travel_s"] = pairs["to_arr_s"] - pairs["dep_s"]
    del st, grp
    _check()
    _progress(45)

    trip_index = {r.trip_id: (r.route_id, str(r.direction_id))
                  for r in trips.itertuples(index=False)}

    # mappa shape -> route (per costruire il layer delle linee)
    shape_routes = {}
    for r in trips.itertuples(index=False):
        if r.shape_id and r.shape_id not in shape_routes:
            shape_routes[r.shape_id] = (r.route_id, str(r.direction_id))

    # con il filtro per linea, tieni solo le shape delle linee scelte
    if route_ids:
        shapes_geom = {sid: pts for sid, pts in shapes_geom.items()
                       if sid in shape_routes}

    # linee senza shape: geometria dalla sequenza di fermate più lunga (prima
    # il layer delle linee restava vuoto con i feed senza shapes.txt)
    with_shape = {rd for sid, rd in shape_routes.items() if sid in shapes_geom}
    best_trip = {}
    for tid, (rid, d) in trip_index.items():
        if (rid, d) in with_shape or tid not in trip_stops:
            continue
        n = len(trip_stops[tid][0])
        if n > best_trip.get((rid, d), ("", 0))[1]:
            best_trip[(rid, d)] = (tid, n)
    for (rid, d), (tid, _n) in best_trip.items():
        pts = [(stops_map[sid][0], stops_map[sid][1], None)
               for sid in trip_stops[tid][0]
               if sid in stops_map and pd.notna(stops_map[sid][0])]
        if len(pts) >= 2:
            fid = "fermate:%s:%s" % (rid, d)
            shapes_geom[fid] = pts
            shape_routes[fid] = (rid, d)

    routes_map = {}
    if routes is not None:
        rcols = routes.set_index("route_id")
        for rid, row in rcols.iterrows():
            routes_map[rid] = {
                "short_name": row.get("route_short_name", ""),
                "long_name": row.get("route_long_name", ""),
                "route_type": row.get("route_type", ""),
            }

    # ---- segmenti unici (route, direction, from_stop, to_stop) ----
    keys = ["route_id", "direction_id", "stop_id", "to_stop"]
    geo = pairs.groupby(keys, observed=True, sort=False).agg(
        shape_id=("shape_id", "first"), sdt=("sdt", "first"),
        to_sdt=("to_sdt", "first"), pm=("pm", "first"),
        to_pm=("to_pm", "first"))
    ok = pairs["travel_s"] > 0
    tim = pairs[ok].groupby(keys, observed=True, sort=False)["travel_s"].agg(
        ["mean", "std", "count"])
    if freq_deps:
        # una corsa modello di frequencies.txt vale tante corse quante partenze
        mult = pairs["trip_id"].astype(str).map(
            {t: len(v) for t, v in freq_deps.items()}).fillna(1.0)
        tim["count"] = mult[ok].groupby(
            [pairs.loc[ok, c] for c in keys], observed=True, sort=False
        ).sum().reindex(tim.index).values
    tim_d = {k: (m, sd, c) for k, m, sd, c in zip(
        tim.index, tim["mean"], tim["std"], tim["count"])}
    segments = {}
    seg_len = {}
    n_seg = len(geo)
    for idx, (key, row) in enumerate(zip(geo.index, geo.itertuples(index=False))):
        if idx % 2000 == 0:
            _check()
            _progress(45 + int(45 * idx / n_seg) if n_seg else 90)
        route_id, direction_id, from_stop, to_stop = key
        direction_id = str(direction_id)
        coords = None
        sid = str(row.shape_id)
        # posizioni proiettate (metri) se la corsa ne ha avuto bisogno (niente
        # shape_dist_traveled o unità diverse dalla shape), altrimenti quelle
        # del feed
        if pd.notna(row.pm) and pd.notna(row.to_pm) and sid in shapes_ok:
            if sid not in shape_m:
                shape_m[sid] = _shape_metric(shapes_geom[sid])
            coords = _cut_shape(shape_m[sid][2], row.pm, row.to_pm)
        elif sid in shapes_dist and pd.notna(row.sdt) and pd.notna(row.to_sdt):
            coords = _cut_shape(shapes_geom[sid], row.sdt, row.to_sdt)
        if coords is None:
            a = stops_map.get(from_stop)
            b = stops_map.get(to_stop)
            if a and b and pd.notna(a[0]) and pd.notna(b[0]):
                coords = [(a[0], a[1]), (b[0], b[1])]
            else:
                continue
        length_m = _geodesic_length(coords, da)
        if length_m <= 0:
            continue
        nkey = (route_id, direction_id, from_stop, to_stop)
        seg_len[nkey] = length_m
        t = tim_d.get(key)
        if t is None or not t[2]:
            continue  # nessun tempo programmato utilizzabile
        sched_time = float(t[0])
        segments[nkey] = {
            "route_id": route_id,
            "direction_id": direction_id,
            "from_stop": from_stop,
            "to_stop": to_stop,
            "from_name": stops_map.get(from_stop, ("", "", from_stop))[2],
            "to_name": stops_map.get(to_stop, ("", "", to_stop))[2],
            "route_short_name": routes_map.get(route_id, {}).get("short_name", ""),
            "length_m": length_m,
            "sched_time_s": sched_time,
            "sched_speed_kmh": length_m / sched_time * 3.6 if sched_time > 0 else 0.0,
            "n_trips": int(t[2]),
            "coords": coords,
        }

    # ---- metriche di linea (commerciale / esercizio) ----
    # su TUTTE le coppie: lunghezza e tempo restano coerenti anche dove il
    # tempo di una coppia è nullo
    len_df = pd.DataFrame(list(seg_len.keys()), columns=keys)
    len_df["seg_len"] = list(seg_len.values())
    pk = pairs[keys + ["trip_id", "dep_s", "to_arr_s", "travel_s"]].copy()
    for c in keys:
        pk[c] = pk[c].astype(str)
    pk = pk.merge(len_df, on=keys, how="left")
    pk["run"] = pk["travel_s"].clip(lower=0).fillna(0)
    pk["no_len"] = pk["seg_len"].isna()
    # coppie senza tempo (es. prima fermata senza orario): fuori sia la
    # lunghezza sia il tempo, altrimenti la velocità della corsa si gonfia
    pk.loc[pk["travel_s"].isna(), "seg_len"] = 0.0
    trip_stats = pk.groupby(["route_id", "direction_id", "trip_id"]).agg(
        total_len=("seg_len", "sum"),
        running_time=("run", "sum"),
        first_dep=("dep_s", "min"),
        last_arr=("to_arr_s", "max"),
        no_len=("no_len", "sum"),
    ).reset_index()
    del pk, pairs
    trip_stats = trip_stats[trip_stats["no_len"] == 0]
    trip_stats["total_time"] = trip_stats["last_arr"] - trip_stats["first_dep"]
    trip_stats = trip_stats[(trip_stats["total_time"] > 0) &
                            (trip_stats["running_time"] > 0)]
    if freq_deps:
        # corse a frequenza: una riga per ogni partenza (stessi tempi relativi)
        rows = []
        for r in trip_stats.itertuples(index=False):
            deps = freq_deps.get(str(r.trip_id))
            if not deps:
                rows.append(r._asdict())
                continue
            for k, t in enumerate(deps):
                d = r._asdict()
                d["trip_id"] = "%s#%d" % (r.trip_id, k)
                d["last_arr"] = r.last_arr - r.first_dep + t
                d["first_dep"] = t
                rows.append(d)
        trip_stats = pd.DataFrame(rows, columns=trip_stats.columns)
    trip_stats["commercial_kmh"] = trip_stats["total_len"] / trip_stats["total_time"] * 3.6
    trip_stats["running_kmh"] = trip_stats["total_len"] / trip_stats["running_time"] * 3.6
    trip_stats["dwell_s"] = trip_stats["total_time"] - trip_stats["running_time"]

    line_metrics = {}
    for (rid, direction), grp2 in trip_stats.groupby(["route_id", "direction_id"]):
        line_metrics[(rid, str(direction))] = {
            "route_id": rid,
            "direction_id": str(direction),
            "route_short_name": routes_map.get(rid, {}).get("short_name", ""),
            "n_trips": int(len(grp2)),
            "mean_length_m": float(grp2["total_len"].mean()),
            "commercial_speed_kmh": float(grp2["commercial_kmh"].mean()),
            "running_speed_kmh": float(grp2["running_kmh"].mean()),
            "mean_dwell_s": float(grp2["dwell_s"].mean()),
        }

    # ---- velocita' programmata per linea e per ora di partenza ----
    # Definizione space-mean (sum lunghezze / sum tempi di percorrenza) per
    # confrontabilita' con l'osservato ricavato dai segmenti RT.
    ts = trip_stats.copy()
    ts["hour"] = (ts["first_dep"] // 3600 % 24).astype(int)
    line_hourly_sched = {}
    grp_h = ts.groupby(["route_id", "direction_id", "hour"]).agg(
        len_sum=("total_len", "sum"), time_sum=("running_time", "sum"))
    for (rid, direction, hour), row in grp_h.iterrows():
        if row["time_sum"] <= 0:
            continue
        speed = row["len_sum"] / row["time_sum"] * 3.6
        line_hourly_sched.setdefault((rid, str(direction)), {})[int(hour)] = speed
    _progress(100)

    return {
        "routes": routes_map,
        "stops": stops_map,
        "shapes_geom": shapes_geom,
        "segments": segments,
        "trip_index": trip_index,
        "trip_stops": trip_stops,
        "shape_routes": shape_routes,
        "line_metrics": line_metrics,
        "line_hourly_sched": line_hourly_sched,
        "selection": selection,
        "timezone": _agency_timezone(source),
        "times_fixed": times_fixed,
        "sdt_units_fixed": sdt_units_fixed,
        "frequency_trips": sum(len(v) for v in freq_deps.values()),
        "freq_templates": set(freq_deps),
        "source": source,
        "service_date": service_date,
    }
