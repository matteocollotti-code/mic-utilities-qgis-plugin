# -*- coding: utf-8 -*-
"""Logger GTFS-Realtime: polling periodico dei TripUpdates e accumulo.

Per ogni coppia di fermate consecutive di una corsa nei TripUpdates calcola il
tempo di percorrenza e lo associa al segmento statico corrispondente.
Accumulando su molte corse e molti poll si ottiene una velocita' effettiva per
segmento (e relativo scarto rispetto al programmato).

Regole (v0.41):
- la coppia è consecutiva nella corsa STATICA (stop_sequence può saltare
  10, 20, 30…); lo stop_id mancante si ricava da (trip_id, stop_sequence);
- gli eventi con solo il ritardo valgono: orario programmato + ritardo;
- le fermate SKIPPED / NO_DATA e le corse CANCELED non sono osservazioni;
- si confronta come con come: se della fermata di partenza c'è solo l'arrivo,
  anche il programmato è arrivo→arrivo, della STESSA corsa (lo scarto non
  confonde più l'orario della giornata con il ritardo);
- una coppia conta solo quando la fermata d'arrivo è già passata secondo
  l'ultimo feed: le previsioni per il futuro non sono osservazioni;
- le osservazioni passate da più di 30 minuti vengono riassunte in totali per
  segmento e per ora: la memoria non cresce con la durata del logging.
"""
from collections import defaultdict
from datetime import datetime

from qgis.core import QgsApplication
from qgis.PyQt.QtCore import QObject, QTimer, pyqtSignal

from .gtfs_tasks import GtfsPollTask

SKIPPED, NO_DATA = 1, 2
CANCELED = 3
FINAL_AFTER_S = 1800


def _event_time(event):
    return event.get("time") if event else None


def _event_delay(event):
    return event.get("delay") if event else None


def timezone_of(name):
    """Fuso dell'agenzia (pytz; zoneinfo su Windows spesso non ha i dati)."""
    if not name:
        return None
    try:
        import pytz
        return pytz.timezone(name)
    except Exception:
        pass
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(name)
    except Exception:
        return None


def day_epoch(yyyymmdd, tz):
    """Istante (epoch) della mezzanotte "di servizio" del giorno: mezzogiorno
    locale − 12 h, come da specifica GTFS (corretto anche nei giorni del cambio
    d'ora)."""
    try:
        s = str(yyyymmdd)
        noon = datetime(int(s[0:4]), int(s[4:6]), int(s[6:8]), 12)
    except (TypeError, ValueError):
        return None
    if tz is None:
        return noon.timestamp() - 43200
    if hasattr(tz, "localize"):
        return tz.localize(noon).timestamp() - 43200
    return noon.replace(tzinfo=tz).timestamp() - 43200


def _hms(text):
    """Secondi da HH:MM:SS (anche ≥ 24:00); None se non valido."""
    try:
        h, m, sec = str(text).strip().split(":")
        return int(h) * 3600 + int(m) * 60 + int(sec)
    except (TypeError, ValueError):
        return None


def local_hour(epoch, tz):
    return datetime.fromtimestamp(epoch, tz).hour if tz else \
        datetime.fromtimestamp(epoch).hour


class GtfsRealtimeLogger(QObject):
    """Esegue il polling di un feed GTFS-RT TripUpdates e accumula osservazioni.

    Segnali:
        polled(int n_poll, int n_obs, str msg)
        failed(str msg)
    """

    polled = pyqtSignal(int, int, str)
    failed = pyqtSignal(str)

    def __init__(self, url, interval_s, static_result, parent=None):
        super().__init__(parent)
        self.url = url
        self.static = static_result
        # stessi dizionari del pannello: le linee caricate dopo l'avvio
        # (merge_static) sono viste subito
        self.segments = static_result["segments"]
        self.trip_index = static_result["trip_index"]
        self.trip_stops = static_result.setdefault("trip_stops", {})
        # corse-modello di frequencies.txt: una corsa RT per ogni partenza
        self.freq_templates = static_result.setdefault("freq_templates", set())
        self.tz = timezone_of(static_result.get("timezone"))
        # (seg_key, trip_uid) -> (travel_s, sched_s|None, delay|None,
        #                         arr_time|None, hour|None)
        self.pending = {}
        # seg_key -> [n, somma tempi, somma programmati, somma ritardi, n rit.]
        self.agg = defaultdict(lambda: [0, 0.0, 0.0, 0.0, 0])
        # (route, dir, ora) -> [lunghezza, tempo]
        self.hour_agg = defaultdict(lambda: [0.0, 0.0])
        self.last_feed_ts = None
        self.poll_count = 0
        self.skipped = defaultdict(int)
        self._active_task = None
        self._cache = None
        self._day0 = {}
        self.timer = QTimer(self)
        self.timer.setInterval(max(10, int(interval_s)) * 1000)
        self.timer.timeout.connect(self.poll_once)

    # -------------------------------------------------------------- controllo
    def start(self):
        self.poll_once()  # primo poll immediato
        self.timer.start()

    def stop(self):
        self.timer.stop()

    def is_running(self):
        return self.timer.isActive()

    # --------------------------------------------------------------- polling
    def poll_once(self):
        if self._active_task is not None:
            return  # poll precedente ancora in corso, salta questo tick
        task = GtfsPollTask(self.url)
        self._active_task = task
        task.taskCompleted.connect(lambda t=task: self._on_poll_done(t))
        task.taskTerminated.connect(lambda t=task: self._on_poll_failed(t))
        QgsApplication.taskManager().addTask(task)

    def _on_poll_done(self, task):
        # eseguito nel thread principale: ingest sicuro
        self._active_task = None
        added = self.ingest(task.trip_updates or [],
                            getattr(task, "feed_timestamp", None))
        self.poll_count += 1
        n_obs = self.n_observations()
        n_pred = self.n_predictions()
        self.polled.emit(
            self.poll_count, n_obs,
            "poll #%d: %d coppie aggiornate; %d osservazioni su %d segmenti "
            "(fermate già passate), %d previsioni in attesa"
            % (self.poll_count, added, n_obs, len(self.segment_results()),
               n_pred))

    def _on_poll_failed(self, task):
        self._active_task = None
        self.failed.emit(str(task.exception) if task.exception else "poll annullato")

    # ---------------------------------------------------------------- ingest
    def _day0_of(self, start_date):
        if not start_date:
            return None
        if start_date not in self._day0:
            self._day0[start_date] = day_epoch(start_date, self.tz)
        return self._day0[start_date]

    def ingest(self, trip_updates, feed_ts=None):
        """Registra le coppie di fermate dei TripUpdates; ritorna quante."""
        import time
        if feed_ts is None:
            feed_ts = int(time.time())
        if self.last_feed_ts is None or feed_ts > self.last_feed_ts:
            self.last_feed_ts = feed_ts
        added = 0
        for tu in trip_updates:
            added += self._ingest_trip(tu, feed_ts)
        self._fold()
        self._cache = None
        return added

    def _service_day0(self, sched, feed_ts):
        """Mezzanotte di servizio senza start_date: il giorno del feed, o
        quello prima se la corsa (orari ≥ 24:00) è partita ieri."""
        if feed_ts is None:
            return None
        today = datetime.fromtimestamp(feed_ts, self.tz) if self.tz else \
            datetime.fromtimestamp(feed_ts)
        d0 = self._day0_of(today.strftime("%Y%m%d"))
        first = None
        if sched is not None and len(sched[3]):
            first = next((x for x in sched[3] if x == x), None)
        if d0 is not None and first is not None and d0 + first - feed_ts > 43200:
            from datetime import timedelta
            d0 = self._day0_of((today - timedelta(days=1)).strftime("%Y%m%d"))
        return d0

    def _ingest_trip(self, tu, feed_ts=None):
        trip = tu.get("trip", {})
        if trip.get("schedule_relationship") == CANCELED:
            self.skipped["corse cancellate"] += 1
            return 0
        trip_id = trip.get("trip_id")
        if trip_id in self.trip_index:
            # la corsa statica è il riferimento (anche per la direzione: un
            # direction_id vuoto nel GTFS combacia con 0 nel RT)
            route_id, direction = self.trip_index[trip_id]
        else:
            route_id = trip.get("route_id")
            direction = trip.get("direction_id")
            if route_id is None:
                self.skipped["corse sconosciute"] += 1
                return 0
            direction = str(direction if direction is not None else "0")
        sched = self.trip_stops.get(trip_id)
        start_date = trip.get("start_date", "")
        start_time = trip.get("start_time", "")
        # più partenze della stessa corsa-modello (frequencies.txt) girano
        # insieme: l'orario di partenza distingue le corse e sposta il
        # programmato del modello
        trip_uid = (trip_id, start_date, start_time)
        if sched is not None and trip_id in self.freq_templates and start_time:
            off = _hms(start_time)
            first = next((x for x in sched[3] if x == x), None)
            if off is not None and first is not None:
                off -= first
                sched = (sched[0], sched[1],
                         [x + off for x in sched[2]],
                         [x + off for x in sched[3]])
        day0 = self._day0_of(start_date) if start_date else \
            self._service_day0(sched, feed_ts)

        # eventi validi: (indice nella corsa statica, stop_id, update)
        evs = []
        last_idx = -1
        seq_pos = {q: i for i, q in enumerate(sched[1])} if sched else {}
        for stu in tu.get("stop_time_updates", []):
            rel = stu.get("schedule_relationship", 0)
            seq = stu.get("stop_sequence")
            stop = stu.get("stop_id")
            idx = None
            if sched is not None:
                stops = sched[0]
                if seq is not None:
                    idx = seq_pos.get(int(seq))
                    # stop_sequence che contraddice lo stop_id (es. numerato
                    # da 0 nel RT e da 1 nel GTFS): vale lo stop_id
                    if idx is not None and stop and stops[idx] != stop:
                        idx = None
                if idx is None and stop:
                    idx = self._visit(stops, stop, last_idx, stu, sched, day0)
                if idx is not None and not stop:
                    stop = stops[idx]
            if rel in (SKIPPED, NO_DATA) or not stop:
                if rel in (SKIPPED, NO_DATA):
                    self.skipped["fermate SKIPPED/NO_DATA"] += 1
                evs.append(None)
                continue
            if idx is not None:
                last_idx = idx
            evs.append((idx, stop, stu))

        added = 0
        for a, b in zip(evs, evs[1:]):
            if a is None or b is None:
                continue
            ia, sa, ua = a
            ib, sb, ub = b
            if sched is not None and ia is not None and ib is not None \
                    and ib != ia + 1:
                continue  # non consecutive nella corsa
            key = (route_id, direction, sa, sb)
            seg = self.segments.get(key)
            if seg is None:
                continue
            obs = self._pair(ua, ub, ia, ib, sched, day0)
            if obs is None:
                continue
            hour = None
            if sched is not None and len(sched[3]) and sched[3][0] == sched[3][0]:
                hour = int(sched[3][0] // 3600) % 24  # ora di partenza corsa
            elif obs[3] is not None:
                hour = local_hour(obs[3], self.tz)
            # l'indice del passaggio distingue le linee ad anello (stessa
            # coppia di fermate percorsa due volte nella corsa)
            self.pending[(key, trip_uid, ia)] = obs[:4] + (hour,)
            added += 1
        return added

    @staticmethod
    def _visit(stops, stop, last_idx, stu, sched, day0):
        """Indice della fermata nella corsa statica. Se la fermata ricorre
        (anello) vince il passaggio con l'orario programmato più vicino a
        quello dell'aggiornamento; senza orario, il primo dopo l'ultimo."""
        cands = [i for i in range(last_idx + 1, len(stops)) if stops[i] == stop]
        if len(cands) <= 1 or day0 is None:
            return cands[0] if cands else None
        t = None
        for kind in ("arrival", "departure"):
            ev = stu.get(kind)
            if ev and ev.get("time") is not None:
                t = ev["time"] - day0
                break
        if t is None:
            return cands[0]
        return min(cands, key=lambda i: abs((sched[2][i] if sched[2][i] == sched[2][i]
                                             else sched[3][i]) - t))

    @staticmethod
    def _side(update, prefer):
        """(tipo, istante, ritardo) dell'evento preferito o dell'altro."""
        order = ("departure", "arrival") if prefer == "departure" \
            else ("arrival", "departure")
        for kind in order:
            ev = update.get(kind)
            if ev and (ev.get("time") is not None or ev.get("delay") is not None):
                return kind, ev.get("time"), ev.get("delay")
        return None, None, None

    def _pair(self, ua, ub, ia, ib, sched, day0):
        ka, ta, da = self._side(ua, "departure")
        kb, tb, db = self._side(ub, "arrival")
        if ka is None or kb is None:
            return None
        sa = sb = None
        if sched is not None and ia is not None and ib is not None:
            col = {"arrival": 2, "departure": 3}
            sa = sched[col[ka]][ia]
            sb = sched[col[kb]][ib]
            if sa != sa or sb != sb:  # NaN
                sa = sb = None
        # istanti assoluti: dichiarati o programmato + ritardo
        if ta is None and da is not None and sa is not None and day0 is not None:
            ta = day0 + sa + da
        if tb is None and db is not None and sb is not None and day0 is not None:
            tb = day0 + sb + db
        if ta is not None and tb is not None:
            travel = tb - ta
        elif da is not None and db is not None and sa is not None:
            travel = (sb + db) - (sa + da)
        else:
            return None
        if travel <= 0:
            return None
        sched_s = (sb - sa) if sa is not None and sb > sa else None
        delay = db if db is not None else (
            tb - (day0 + sb) if tb is not None and day0 is not None
            and sb is not None else None)
        return (float(travel), sched_s, delay, tb)

    def _passed(self, arr_time):
        """La fermata d'arrivo è già passata secondo l'ultimo feed? Senza un
        istante non si può dire: non conta (prima contava, e una previsione
        con il solo ritardo diventava un'osservazione)."""
        if arr_time is None or self.last_feed_ts is None:
            return False
        return arr_time <= self.last_feed_ts

    def _fold(self):
        """Riassume le osservazioni ormai definitive (memoria limitata)."""
        if self.last_feed_ts is None:
            return
        limit = self.last_feed_ts - FINAL_AFTER_S
        done = [k for k, o in self.pending.items()
                if o[3] is not None and o[3] <= limit]
        for k in done:
            self._add_to_agg(k[0], self.pending.pop(k))

    def _add_to_agg(self, key, obs, agg=None, hour_agg=None):
        seg = self.segments.get(key)
        if seg is None:
            return
        agg = self.agg if agg is None else agg
        hour_agg = self.hour_agg if hour_agg is None else hour_agg
        travel, sched_s, delay, _arr, hour = obs
        a = agg[key]
        a[0] += 1
        a[1] += travel
        a[2] += sched_s if sched_s is not None else seg["sched_time_s"]
        if delay is not None:
            a[3] += delay
            a[4] += 1
        if hour is not None:
            h = hour_agg[(key[0], key[1], hour)]
            h[0] += seg["length_m"]
            h[1] += travel

    def _totals(self):
        """Totali definitivi + osservazioni in attesa già passate."""
        if self._cache is not None:
            return self._cache
        agg = defaultdict(lambda: [0, 0.0, 0.0, 0.0, 0])
        hour_agg = defaultdict(lambda: [0.0, 0.0])
        for k, v in self.agg.items():
            agg[k] = list(v)
        for k, v in self.hour_agg.items():
            hour_agg[k] = list(v)
        for k, obs in self.pending.items():
            key = k[0]
            if self._passed(obs[3]):
                self._add_to_agg(key, obs, agg, hour_agg)
        self._cache = (agg, hour_agg)
        return self._cache

    def n_observations(self):
        return sum(v[0] for v in self._totals()[0].values())

    def n_predictions(self):
        return sum(1 for o in self.pending.values() if not self._passed(o[3]))

    # --------------------------------------------------------------- risultati
    def segment_results(self):
        """{seg_key: {eff_speed_kmh, sched_trips_kmh, dev_kmh, dev_pct,
        mean_delay_s, n_obs}}.

        Lo scarto è rispetto al programmato delle STESSE corse osservate
        (sched_trips_kmh), non alla media dell'intera giornata.
        """
        out = {}
        for key, a in self._totals()[0].items():
            seg = self.segments.get(key)
            if not seg or a[0] <= 0 or a[1] <= 0:
                continue
            eff = seg["length_m"] / (a[1] / a[0]) * 3.6
            sched = seg["length_m"] / (a[2] / a[0]) * 3.6 if a[2] > 0 \
                else seg["sched_speed_kmh"]
            out[key] = {
                "eff_speed_kmh": eff,
                "sched_trips_kmh": sched,
                "dev_kmh": eff - sched,
                "dev_pct": (eff - sched) / sched * 100 if sched > 0 else 0.0,
                "mean_delay_s": a[3] / a[4] if a[4] else None,
                "n_obs": a[0],
            }
        return out

    def line_results(self):
        """Velocita' effettiva media per linea (pesata sulla lunghezza)."""
        acc = defaultdict(lambda: {"len": 0.0, "time": 0.0, "n": 0})
        for key, res in self.segment_results().items():
            seg = self.segments[key]
            eff = res["eff_speed_kmh"]
            if eff <= 0:
                continue
            a = acc[(key[0], key[1])]
            a["len"] += seg["length_m"]
            a["time"] += seg["length_m"] / (eff / 3.6)  # tempo effettivo
            a["n"] += 1
        out = {}
        for k, a in acc.items():
            if a["time"] > 0:
                out[k] = {
                    "eff_speed_kmh": a["len"] / a["time"] * 3.6,
                    "n_segments": a["n"],
                }
        return out

    def line_hourly(self):
        """Velocita' osservata per linea e per ora (space-mean sui segmenti).

        L'ora è quella di partenza della corsa programmata, come per il
        programmato (prima: ora d'arrivo al segmento nel fuso del computer).

        :return: {(route_id, direction): {hour: speed_kmh}}
        """
        out = defaultdict(dict)
        for (rid, direction, hour), (ln, tm) in self._totals()[1].items():
            if tm > 0:
                out[(rid, direction)][hour] = ln / tm * 3.6
        return dict(out)
