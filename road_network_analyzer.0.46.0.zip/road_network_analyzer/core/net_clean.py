# -*- coding: utf-8 -*-
"""Pulizia/preparazione della rete stradale per le analisi su grafo.

Operazioni (v1, leggere e veloci):
- snap dei vertici vicini a una tolleranza (unisce estremi che dovrebbero
  coincidere ma differiscono per rumore di coordinate → migliora la
  connettività del grafo);
- rimozione dei segmenti di lunghezza nulla;
- rimozione dei segmenti duplicati (preservando i sensi unici).

Restituisce una lista di segmenti [[(lon,lat),(lon,lat)], ...], valida come
input per net_iso.build_metric_graph. Tutto in puro Python (thread-safe).

Raffinamenti futuri: noding alle intersezioni (split dei segmenti che si
incrociano senza condividere un vertice), aggancio dei tratti pendenti.
"""
import math


class Snapper(object):
    """Aggancio dei vertici per DISTANZA (non per cella di griglia).

    Un vertice entro `tol` metri da un vertice già visto prende quello
    (il più vicino); altrimenti diventa un nuovo vertice. Si guardano anche
    le celle vicine: prima, arrotondando alla griglia, due vertici a 5 cm a
    cavallo di una cella restavano separati e due a 1,3 m nella stessa cella
    venivano uniti.
    """

    def __init__(self, tol, mlon, mlat):
        self.cell = max(0.001, float(tol))
        self.tol2 = self.cell * self.cell
        self.mlon = mlon
        self.mlat = mlat
        self.grid = {}
        self.n = 0

    def snap(self, lon, lat):
        """(indice del vertice, nuovo?) per il punto lon/lat."""
        x, y = lon * self.mlon, lat * self.mlat
        c = self.cell
        ix, iy = int(math.floor(x / c)), int(math.floor(y / c))
        best = None
        grid = self.grid
        for gx in (ix - 1, ix, ix + 1):
            for gy in (iy - 1, iy, iy + 1):
                for rx, ry, rid in grid.get((gx, gy), ()):
                    d2 = (rx - x) * (rx - x) + (ry - y) * (ry - y)
                    if d2 <= self.tol2 and (best is None or d2 < best[0]):
                        best = (d2, rid)
        if best is not None:
            return best[1], False
        rid = self.n
        self.n += 1
        grid.setdefault((ix, iy), []).append((x, y, rid))
        return rid, True


def clean_network(roads_lonlat, snap_tol_m=1.0, directions=None,
                  sources=None, src_out=None, pairs_out=None):
    """Pulisce la rete. Ritorna (segmenti, directions_out, stats).

    :param snap_tol_m: tolleranza di snap dei vertici (metri).
    :param directions: senso di marcia per polilinea (1/-1/0); se None,
        directions_out è None.
    :param sources: opzionale, id d'origine per polilinea; con `src_out`
        (lista) vi si aggiunge l'origine di ogni segmento restituito.
    :param pairs_out: opzionale, lista in cui aggiungere per ogni segmento
        restituito (indice della polilinea in ingresso, indice della coppia
        di vertici): serve a portare sui segmenti dati per tratto, come i
        tempi di travel_cost.edge_times (il segmento ha lo stesso verso).
    :return: (segmenti lon/lat, directions allineate ai segmenti o None, stats).
    """
    keep = [i for i, r in enumerate(roads_lonlat or []) if r and len(r) >= 2]
    polys = [roads_lonlat[i] for i in keep]
    if directions is not None:
        directions = [directions[i] if i < len(directions) else 0
                      for i in keep]
    if sources is not None:
        sources = [sources[i] for i in keep]
    stats = {"segmenti_in": 0, "segmenti_out": 0, "nulli": 0,
             "duplicati": 0, "nodi": 0}
    if not polys:
        return [], (None if directions is None else []), stats

    lat0 = polys[0][0][1]
    mlat = 111320.0
    mlon = 111320.0 * math.cos(math.radians(lat0))
    snapper = Snapper(snap_tol_m, mlon, mlat)
    rep = []

    def snap(pt):
        rid, new = snapper.snap(pt[0], pt[1])
        if new:
            rep.append((pt[0], pt[1]))
        return rep[rid]

    out = []
    out_dirs = []
    seg_index = {}
    n_in = n_zero = n_dup = 0
    for ri, road in enumerate(polys):
        rd = directions[ri] if directions and ri < len(directions) else 0
        snapped = [snap(p) for p in road]
        for k, (a, b) in enumerate(zip(snapped, snapped[1:])):
            n_in += 1
            if a == b:
                n_zero += 1
                continue
            uk = (a, b) if a <= b else (b, a)
            idx = seg_index.get(uk)
            if idx is not None:
                n_dup += 1
                ea, eb = out[idx][0], out[idx][1]
                # senso di questa occorrenza nell'orientamento esistente
                if a == ea and b == eb:
                    d_this = rd
                else:
                    d_this = -rd if rd in (1, -1) else 0
                if out_dirs[idx] != d_this:
                    out_dirs[idx] = 0  # sensi in conflitto → doppio senso
                continue
            seg_index[uk] = len(out)
            out.append([a, b])
            out_dirs.append(rd)
            if src_out is not None and sources is not None:
                src_out.append(sources[ri])
            if pairs_out is not None:
                pairs_out.append((keep[ri], k))

    stats.update({"segmenti_in": n_in, "segmenti_out": len(out),
                  "nulli": n_zero, "duplicati": n_dup, "nodi": len(rep)})
    return out, (None if directions is None else out_dirs), stats


def clean_summary(stats):
    """Riga di testo riassuntiva della pulizia."""
    return ("rete pulita: %d segmenti (−%d nulli, −%d duplicati), %d nodi"
            % (stats.get("segmenti_out", 0), stats.get("nulli", 0),
               stats.get("duplicati", 0), stats.get("nodi", 0)))
