# -*- coding: utf-8 -*-
"""Percorso più breve (distanza) e più veloce (tempo) su rete stradale.

Tra due o più punti, in sequenza (A→B→C…) o fra tutte le coppie. I punti si
agganciano al punto più vicino della strada (come per le isocrone) e il
percorso parte e arriva lì, non al nodo più vicino.

Il più veloce usa per ogni strada la velocità: campo scelto dall'utente,
altrimenti il limite OSM (maxspeed, anche nella forma «IT:urban»),
altrimenti un valore tipico per tipo di strada (highway), altrimenti la
velocità di default; tutto moltiplicato per un fattore (es. 80 % per il
traffico). Si escludono le strade dove le auto non passano e si rispettano i
sensi unici. Puro Python: gira in un QgsTask.
"""
import heapq
import math

# km/h tipici per tipo di strada OSM quando manca maxspeed (limiti italiani,
# ambito urbano per le strade principali)
DEFAULT_KMH = {
    "motorway": 130, "motorway_link": 60, "trunk": 90, "trunk_link": 50,
    "primary": 50, "primary_link": 40, "secondary": 50, "secondary_link": 40,
    "tertiary": 50, "tertiary_link": 40, "unclassified": 50,
    "residential": 30, "living_street": 10, "service": 20, "road": 30,
    "busway": 50, "track": 15,
}
# strade OSM dove le auto non passano (esclusi dal più veloce)
NOT_FOR_CARS = {
    "footway", "path", "cycleway", "steps", "pedestrian", "corridor",
    "bridleway", "platform", "elevator", "sidewalk", "crossing", "proposed",
    "construction", "busway",
}
# percorribili solo a piedi: nel «più breve» il tempo stimato su questi
# tratti è a passo d'uomo, non alla velocità di un'auto
WALK_ONLY = NOT_FOR_CARS - {"busway", "proposed", "construction"}
WALK_KMH = 4.5
_ZONE_KMH = {"urban": 50, "rural": 90, "trunk": 110, "motorway": 130,
             "living_street": 20, "zone30": 30, "zone:30": 30,
             "zone20": 20, "zone:20": 20, "walk": 6, "none": 130}


def parse_maxspeed(value):
    """km/h da un valore maxspeed OSM ("50", "30 mph", "5 knots",
    "IT:urban", "IT:zone30", "50;30", "walk"…); None se non interpretabile
    (anche valori negativi)."""
    if value is None:
        return None
    s = str(value).strip().lower()
    if s in ("", "null", "signals", "variable", "unknown"):
        return None
    s = s.split(";")[0].strip()
    if s.startswith("-"):
        return None
    mph = "mph" in s
    knots = "knot" in s
    num = ""
    for ch in s:
        if ch.isdigit() or ch == ".":
            num += ch
        elif num:
            break
    if num and not s.split(":")[-1].startswith("zone"):
        try:
            v = float(num)
        except ValueError:
            v = None
        if v and v > 0 and math.isfinite(v):
            return v * (1.609344 if mph else 1.852 if knots else 1.0)
    key = s.split(":", 1)[1] if ":" in s else s
    if key in _ZONE_KMH:
        return float(_ZONE_KMH[key])
    if key.startswith("zone") and num:
        return float(num)
    return None


def _valid_kmh(v):
    # oltre 300 km/h è un errore nel dato (unità sbagliata, refuso)
    return v is not None and math.isfinite(v) and 0 < v <= 300


def speed_reader(field_names, speed_field=None, default_kmh=50.0,
                 factor=1.0, walk_only_ways=False):
    """Funzione feature → velocità (m/s) per il percorso più veloce.

    :param walk_only_ways: True nel «più breve» (rete con anche marciapiedi
        e scale): sulle strade solo pedonali il tempo è a WALK_KMH.
    """
    low = {n.lower(): n for n in field_names}
    sf = speed_field if speed_field in field_names else None
    ms = low.get("maxspeed")
    hw = low.get("highway")
    fac = max(0.05, float(factor))

    def speed_of(f):
        if walk_only_ways and hw and \
                str(f[hw] or "").strip().lower() in WALK_ONLY:
            return WALK_KMH / 3.6
        kmh = None
        if sf:
            try:
                kmh = float(f[sf])
            except (TypeError, ValueError):
                kmh = parse_maxspeed(f[sf])
        if not _valid_kmh(kmh) and ms:
            kmh = parse_maxspeed(f[ms])
        if not _valid_kmh(kmh) and hw:
            kmh = DEFAULT_KMH.get(str(f[hw] or "").strip().lower())
        if not _valid_kmh(kmh):
            kmh = default_kmh
        return kmh * fac / 3.6
    return speed_of


def car_allowed(highway):
    return str(highway or "").strip().lower() not in NOT_FOR_CARS


def _edge_lookup(graph):
    """(a, b) → indice dell'arco (entrambi i versi)."""
    out = {}
    for k, (a, b, _d) in enumerate(graph.edges):
        out.setdefault((a, b), k)
        out.setdefault((b, a), k)
    return out


def _dijkstra(adj, seeds, targets, is_canceled=None):
    """Dijkstra con predecessori; si ferma quando i target sono fissati."""
    dist = {}
    pred = {}
    heap = []
    for node, c in seeds:
        if c < dist.get(node, float("inf")):
            dist[node] = c
            pred[node] = None
            heapq.heappush(heap, (c, node))
    left = set(targets)
    done = set()
    k = 0
    while heap:
        c, v = heapq.heappop(heap)
        if v in done or c > dist.get(v, float("inf")):
            continue
        done.add(v)
        left.discard(v)
        if not left:
            break
        k += 1
        if is_canceled and k % 5000 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        for w, cost in adj[v]:
            nc = c + cost
            if nc < dist.get(w, float("inf")):
                dist[w] = nc
                pred[w] = v
                heapq.heappush(heap, (nc, w))
    return dist, pred


def compute_routes(roads_lonlat, points_latlon, mode="shortest",
                   pairs="sequence", directions=None, speeds=None,
                   snap_m=500.0, progress=None, is_canceled=None):
    """Percorsi fra i punti.

    :param mode: "shortest" (distanza) o "fastest" (tempo, serve `speeds`).
    :param pairs: "sequence" (1→2→3…) o "all" (ogni coppia, entrambi i versi).
    :param speeds: velocità (m/s) per polilinea; con "shortest" serve solo a
        stimare il tempo.
    :return: lista di dict {da, a, coords [(lon, lat)], length_m, time_s,
        ok, msg}.
    """
    from . import net_iso
    polys = [r for r in (roads_lonlat or []) if r and len(r) >= 2]
    if not polys or len(points_latlon) < 2:
        return []
    ok, vmsg, _i = net_iso.validate_network(polys)
    if not ok:
        raise ValueError(vmsg)
    lat0 = sum(p[0] for p in points_latlon) / len(points_latlon)
    graph = net_iso.build_metric_graph(roads_lonlat, lat0,
                                       directions=directions, speeds=speeds)
    fastest = mode == "fastest" and graph.adj_t is not None
    adj = graph.adj_t if fastest else graph.adj
    elook = _edge_lookup(graph)
    esp = graph.edge_speed

    def cost_of(a, b, dist_m):
        """Costo di un tratto lungo l'arco (a, b)."""
        if not fastest:
            return dist_m
        return dist_m / esp[elook[(a, b)]]

    # componenti (non orientate): se i due punti di una tratta cadono su
    # pezzi di rete scollegati (rampa, strada di servizio isolata), chi è
    # fuori dalla rete principale si aggancia ad essa, come fanno i
    # navigatori. Se stanno sullo stesso pezzo restano dove sono.
    comp = _components(graph)
    sizes = {}
    for c in comp:
        sizes[c] = sizes.get(c, 0) + 1
    main = max(sizes, key=sizes.get) if sizes else None
    infos = []
    alts = []
    for la, lo in points_latlon:
        info = graph.snap_edge_ll(la, lo, snap_m)
        alt = None
        if info is not None and comp[info["edge"][0]] != main:
            alt = graph.snap_edge_ll(
                la, lo, snap_m, accept=lambda e: comp[e[0]] == main)
        infos.append(info)
        alts.append(alt)

    def pick(i, j):
        a, b = infos[i], infos[j]
        if a is None or b is None or comp[a["edge"][0]] == comp[b["edge"][0]]:
            return a, b
        return (alts[i] or a), (alts[j] or b)

    if progress:
        progress(10)

    if pairs == "all":
        legs = [(i, j) for i in range(len(infos)) for j in range(len(infos))
                if i != j]
    else:
        legs = [(i, i + 1) for i in range(len(infos) - 1)]
    by_origin = {}
    for i, j in legs:
        by_origin.setdefault(i, []).append(j)

    out = []
    n_o = len(by_origin)
    for k, (i, targets) in enumerate(sorted(by_origin.items())):
        if progress:
            progress(10 + int(85 * k / max(1, n_o)))
        if infos[i] is None:
            for j in targets:
                out.append(_fail(i, j, "punto %d non agganciato alla rete "
                                 "(entro %.0f m)" % (i + 1, snap_m)))
            continue
        # tratte raggruppate per aggancio d'origine (al più due: quello più
        # vicino e quello sulla rete principale)
        groups = []
        for j in targets:
            src, dst = pick(i, j)
            for g in groups:
                if g[0] is src:
                    g[1].append((j, dst))
                    break
            else:
                groups.append((src, [(j, dst)]))
        res = {}
        for src, lst in groups:
            a, b = src["edge"]
            seeds = [(n, cost_of(a, b, off))
                     for n, off in graph.source_seeds(src)]
            tnodes = set()
            for _j, dst in lst:
                if dst is not None:
                    tnodes.update(n for n, _o in graph.dest_seeds(dst))
            dist, pred = _dijkstra(adj, seeds, tnodes, is_canceled)
            for j, dst in lst:
                res[j] = (src, dst, dist, pred)
        for j in targets:
            src, dst, dist, pred = res[j]
            if dst is None:
                out.append(_fail(i, j, "punto %d non agganciato alla rete "
                                 "(entro %.0f m)" % (j + 1, snap_m)))
                continue
            leg = _leg(graph, src, dst, dist, pred, cost_of, i, j,
                       fastest, esp, elook)
            if not leg["ok"]:
                if comp[src["edge"][0]] == comp[dst["edge"][0]]:
                    leg["msg"] = ("nessun percorso rispettando i sensi unici: "
                                  "il punto %d è raggiungibile solo "
                                  "contromano (spesso ai bordi di una rete "
                                  "ritagliata)" % (j + 1))
                else:
                    leg["msg"] = ("nessun percorso: i punti %d e %d sono su "
                                  "parti di rete scollegate" % (i + 1, j + 1))
            out.append(leg)
    if progress:
        progress(100)
    return out


def _components(graph):
    """Componente connessa (archi senza verso) di ogni nodo."""
    nb = [[] for _ in range(graph.n)]
    for a, b, _d in graph.edges:
        nb[a].append(b)
        nb[b].append(a)
    comp = [-1] * graph.n
    c = 0
    for s in range(graph.n):
        if comp[s] >= 0:
            continue
        stack = [s]
        comp[s] = c
        while stack:
            v = stack.pop()
            for w in nb[v]:
                if comp[w] < 0:
                    comp[w] = c
                    stack.append(w)
        c += 1
    return comp


def _fail(i, j, msg):
    return {"da": i + 1, "a": j + 1, "coords": [], "length_m": None,
            "time_s": None, "ok": False, "msg": msg}


def _leg(graph, src, dst, dist, pred, cost_of, i, j, fastest, esp, elook):
    """Ricostruisce il percorso src → dst (piede → nodi → piede)."""
    da, db = dst["edge"]
    best = None
    for n, off in graph.dest_seeds(dst):
        if n in dist:
            c = dist[n] + cost_of(da, db, off)
            if best is None or c < best[0]:
                best = (c, n)
    # stesso arco: diretto lungo l'arco se il verso è percorribile
    direct = None
    if src["edge"] == dst["edge"]:
        a, b = dst["edge"]
        ts, td = src["t"], dst["t"]
        if (td >= ts and graph.can_go(a, b)) or (td <= ts and graph.can_go(b, a)):
            direct = cost_of(a, b, abs(ts - td) * dst["L"])
    if best is None and direct is None:
        return _fail(i, j, "nessun percorso (componenti scollegate o sensi "
                     "unici)")
    if direct is not None and (best is None or direct <= best[0]):
        total = direct
        xy = [src["foot"], dst["foot"]]
    else:
        total = best[0]
        nodes = []
        n = best[1]
        while n is not None:
            nodes.append(n)
            n = pred.get(n)
        nodes.reverse()
        xy = [src["foot"]] + [graph.node_xy[n] for n in nodes] + [dst["foot"]]
    pts = []
    for p in xy:
        if not pts or pts[-1] != p:
            pts.append(p)
    length = sum(math.hypot(q[0] - p[0], q[1] - p[1])
                 for p, q in zip(pts, pts[1:]))
    if fastest:
        time_s = total
    elif esp is not None:
        # più breve: tempo stimato con le velocità delle strade percorse
        time_s = 0.0
        for k, (p, q) in enumerate(zip(pts, pts[1:])):
            e = elook.get(_node_pair(graph, p, q))
            if e is None:
                e = elook[src["edge"]] if k == 0 else elook[dst["edge"]]
            time_s += math.hypot(q[0] - p[0], q[1] - p[1]) / esp[e]
    else:
        time_s = None
    coords = [graph.to_ll(x, y) for x, y in pts]
    return {"da": i + 1, "a": j + 1, "coords": coords, "length_m": length,
            "time_s": time_s, "ok": True, "msg": ""}


def _node_pair(graph, p, q):
    """Nodi del grafo alle coordinate p e q (tratti interni del percorso)."""
    idx = getattr(graph, "_xy_index", None)
    if idx is None:
        idx = {xy: n for n, xy in enumerate(graph.node_xy)}
        graph._xy_index = idx
    return idx.get(p), idx.get(q)


def read_roads_for_routing(features, transform, oneway=False, speed_of=None,
                           cars_only=False, is_canceled=None):
    """Polilinee lon/lat, sensi unici e velocità (m/s) da feature lineari.

    Thread-safe con un QgsVectorLayerFeatureSource. Con cars_only salta le
    strade dove le auto non passano (campo highway OSM).
    """
    from qgis.core import QgsGeometry
    from .osm_download import oneway_reader
    roads, dirs, speeds = [], [], []
    names = None
    direction_of = None
    for i, f in enumerate(features):
        if is_canceled and i % 1000 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        if names is None:
            names = f.fields().names()
            direction_of = oneway_reader(names)
        if cars_only and "highway" in names and not car_allowed(f["highway"]):
            continue
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        if transform is not None:
            g.transform(transform)
        d = direction_of(f) if oneway else 0
        sp = speed_of(f) if speed_of else None
        for part in (g.asMultiPolyline() if g.isMultipart()
                     else [g.asPolyline()]):
            roads.append([(p.x(), p.y()) for p in part])
            dirs.append(d)
            speeds.append(sp)
    return roads, dirs, (speeds if speed_of else None)
