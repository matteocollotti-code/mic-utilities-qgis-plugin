# -*- coding: utf-8 -*-
"""Aggiornamenti del plugin da QGIS.

- `ensure_repository`: aggiunge (una volta sola) il repository del plugin al
  gestore plugin di QGIS, così chi lo ha installato da uno zip riceve gli
  aggiornamenti in «Plugin → Gestisci e installa plugin → Aggiornabili».
- `UpdateChecker`: all'avvio legge il plugins.xml del repository e, se c'è
  una versione più recente di quella installata, mostra un avviso con il
  pulsante «Aggiorna» (apre il gestore plugin sulla scheda degli
  aggiornamenti). Senza rete non fa nulla.
"""
import os
import xml.etree.ElementTree as ET

from qgis.PyQt.QtCore import QObject, QUrl
from qgis.PyQt.QtNetwork import QNetworkReply, QNetworkRequest
from qgis.PyQt.QtWidgets import QPushButton
from qgis.core import Qgis, QgsNetworkAccessManager, QgsSettings

PLUGIN_ID = "road_network_analyzer"
REPO_NAME = "MIC - Utilities"
REPO_URL = ("https://raw.githubusercontent.com/matteocollotti-code/"
            "mic-utilities-qgis-plugin/main/plugins.xml")
_FLAG = "MIC-Utilities/repo_added"
_REPOS = "app/plugin_repositories"


def installed_version():
    """Versione dal metadata.txt del plugin installato."""
    path = os.path.join(os.path.dirname(__file__), "metadata.txt")
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("version="):
                    return line.split("=", 1)[1].strip()
    except OSError:
        pass
    return ""


def _parts(v):
    out = []
    for p in str(v).replace("-", ".").split("."):
        num = "".join(ch for ch in p if ch.isdigit())
        out.append(int(num) if num else 0)
    return out


def is_newer(available, installed):
    """True se `available` è più recente di `installed` (stesso criterio del
    gestore plugin di QGIS quando disponibile)."""
    try:
        from pyplugin_installer.version_compare import compareVersions
        return compareVersions(available, installed) == 1
    except Exception:
        return _parts(available) > _parts(installed)


def ensure_repository():
    """Aggiunge il repository del plugin al gestore plugin di QGIS.

    Una volta sola: se l'utente poi lo toglie, non viene rimesso.
    :return: True se è stato aggiunto ora.
    """
    s = QgsSettings()
    if s.value(_FLAG, False, type=bool):
        return False
    s.beginGroup(_REPOS)
    present = any(s.value(k + "/url", "", type=str).strip() == REPO_URL
                  for k in s.childGroups())
    s.endGroup()
    if not present:
        base = "%s/%s/" % (_REPOS, REPO_NAME)
        s.setValue(base + "url", REPO_URL)
        s.setValue(base + "enabled", True)
        s.setValue(base + "valid", True)
        s.setValue(base + "authcfg", "")
    s.setValue(_FLAG, True)
    return not present


def latest_in_xml(data):
    """Versione del plugin nel plugins.xml (bytes), o None."""
    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        return None
    best = None
    for p in root.findall("pyqgis_plugin"):
        pid = p.get("plugin_id") or ""
        fname = (p.findtext("file_name") or "").split(".")[0]
        if PLUGIN_ID not in (pid, fname):
            continue
        v = p.get("version") or p.findtext("version")
        if v and (best is None or is_newer(v, best)):
            best = v
    return best


class UpdateChecker(QObject):
    """Controllo asincrono degli aggiornamenti all'avvio di QGIS."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._reply = None
        self.latest = None

    def start(self):
        req = QNetworkRequest(QUrl(REPO_URL))
        self._reply = QgsNetworkAccessManager.instance().get(req)
        self._reply.finished.connect(self._done)

    def _done(self):
        reply = self._reply
        self._reply = None
        if reply is None:
            return
        try:
            if reply.error() != QNetworkReply.NoError:
                return  # offline o repository non raggiungibile: niente avviso
            latest = latest_in_xml(bytes(reply.readAll()))
        finally:
            reply.deleteLater()
        current = installed_version()
        if latest and current and is_newer(latest, current):
            self.latest = latest
            self._notify(latest, current)

    def _notify(self, latest, current):
        bar = self.iface.messageBar()
        w = bar.createMessage(
            "MIC - Utilities",
            "È disponibile la versione %s (installata %s)." % (latest, current))
        btn = QPushButton("Aggiorna")
        btn.clicked.connect(self.open_manager)
        w.layout().addWidget(btn)
        bar.pushWidget(w, Qgis.Info, 0)

    def open_manager(self):
        """Gestore plugin sulla scheda «Aggiornabili» (repository ricaricati,
        così compare anche se il repository è stato aggiunto ora)."""
        self.iface.messageBar().clearWidgets()
        try:
            import pyplugin_installer
            inst = pyplugin_installer.instance()
            inst.fetchAvailablePlugins(reloadMode=True)
            inst.showPluginManagerWhenReady(3)  # scheda Aggiornabili
        except Exception:
            self.iface.actionManagePlugins().trigger()
