# -*- coding: utf-8 -*-
"""Scarico della rete stradale (OSM/Overpass) per l'estensione corrente.

`fetch_ways` fa solo I/O di rete e parsing (sicuro in un QgsTask di background);
`build_roads_layer` crea il QgsVectorLayer e va chiamato sul thread principale.
"""

from ..i18n import tr
OVERPASS_URLS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
]

# Overpass rifiuta (HTTP 406) gli User-Agent generici: ne serve uno esplicito.
OVERPASS_HEADERS = {"User-Agent": "MIC-Utilities-QGIS/1.0 (QGIS plugin)"}

# tipi highway da ESCLUDERE per modo di trasporto (regex Overpass).
# pedonale: niente autostrade/superstrade; bici: anche niente scale/marciapiedi
# stretti; veicolare: niente percorsi pedonali/ciclabili.
MODE_EXCLUDE = {
    "pedestrian": "motorway|motorway_link|trunk|trunk_link",
    "bicycle": "motorway|motorway_link|trunk|trunk_link|footway|steps|corridor",
    "vehicular": "footway|path|pedestrian|steps|cycleway|bridleway|corridor",
}

MODE_LABEL = {
    "pedestrian": "pedonale",
    "bicycle": "ciclabile",
    "vehicular": "veicolare",
    "all": "completa",
}

# classi di strade OSM (highway), dalla più importante: (etichetta, tipi,
# colore, spessore in mm). Le usano lo stile dei layer della rete OSM e le
# mappe del report.
ROAD_CLASSES = [
    (tr("Autostrade e superstrade"), {"motorway", "motorway_link", "trunk",
                                      "trunk_link"}, "#e11d48", 1.5),
    (tr("Principali"), {"primary", "primary_link"}, "#f97316", 1.25),
    (tr("Secondarie"), {"secondary", "secondary_link"}, "#f59e0b", 1.05),
    (tr("Terziarie"), {"tertiary", "tertiary_link"}, "#ca8a04", 0.85),
    (tr("Locali"), {"residential", "unclassified", "living_street", "road"},
     "#3f3f46", 0.55),
    (tr("Di servizio"), {"service"}, "#a1a1aa", 0.35),
    (tr("Pedonali e ciclabili"), {"pedestrian", "footway", "path", "steps",
                                  "cycleway", "bridleway", "corridor",
                                  "platform", "sidewalk", "crossing", "track"},
     "#10b981", 0.3),
]
OTHER_CLASS = (tr("Altro"), "#a8a29e", 0.3)


def road_class(highway):
    """Classe (etichetta) di un tipo di strada OSM; «Altro» se non noto."""
    hw = str(highway or "").strip().lower()
    for lab, kinds, _c, _w in ROAD_CLASSES:
        if hw in kinds:
            return lab
    return OTHER_CLASS[0]


def build_query(south, west, north, east, mode="all"):
    """Query Overpass: le way highway nell'inquadratura, filtrate per modo."""
    bbox = "%.6f,%.6f,%.6f,%.6f" % (south, west, north, east)
    excl = MODE_EXCLUDE.get(mode)
    if excl:
        sel = '(way["highway"]["highway"!~"%s"](%s););' % (excl, bbox)
    else:
        sel = '(way["highway"](%s););' % bbox
    return "[out:json][timeout:90];%sout geom;" % sel


def _check_remark(data):
    """Overpass può rispondere HTTP 200 con un avviso di timeout o memoria
    esaurita e un risultato troncato: va trattato come errore, non come dati
    (altrimenti finisce in cache una rete incompleta)."""
    remark = str(data.get("remark", "") or "")
    low = remark.lower()
    if remark and ("error" in low or "timed out" in low or "memory" in low):
        raise RuntimeError(tr("Overpass ha interrotto la richiesta (%s): riduci "
                           "l'area inquadrata.") % remark.strip()[:120])


def overpass_json(query, timeout=120, is_canceled=None):
    """Risposta JSON di Overpass alla query, provando i server in ordine;
    None se annullato. RuntimeError se nessun server risponde."""
    import requests
    last_err = None
    for url in OVERPASS_URLS:
        if is_canceled and is_canceled():
            return None
        try:
            resp = requests.post(url, data={"data": query},
                                 headers=OVERPASS_HEADERS, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
            _check_remark(data)
            return data
        except Exception as exc:  # mirror server / timeout -> prova il prossimo
            last_err = exc
    raise RuntimeError(tr("Overpass non raggiungibile: %s") % last_err)


def fetch_ways(south, west, north, east, mode="all",
               progress=None, is_canceled=None):
    """Interroga Overpass e restituisce
    [(osm_id, highway, name, [(lon,lat),...], oneway, livello)] dove livello è
    un dict con i tag bridge / tunnel / layer (ponti e sottopassi), level
    (piano dei percorsi interni) e maxspeed (limite di velocità).

    `mode` filtra i tipi di strada (pedestrian/bicycle/vehicular/all).
    Nessun oggetto QGIS qui dentro: e' sicuro eseguirlo in background.
    """
    query = build_query(south, west, north, east, mode)
    if progress:
        progress(10)
    data = overpass_json(query, 120, is_canceled)
    if data is None:
        return []
    if progress:
        progress(70)
    ways = parse_ways(data)
    if progress:
        progress(100)
    return ways


def comune_query(pro_com, mode="all"):
    """Query Overpass per le strade dentro i confini di un comune italiano
    (relazione amministrativa OSM con ref:ISTAT = codice a 6 cifre) e per
    la relazione stessa, da cui si ricava il confine."""
    excl = MODE_EXCLUDE.get(mode)
    flt = '["highway"!~"%s"]' % excl if excl else ""
    return ('[out:json][timeout:300];'
            'area["boundary"="administrative"]["admin_level"="8"]'
            '["ref:ISTAT"="%06d"]->.a;'
            'way["highway"]%s(area.a);out geom;'
            'rel(pivot.a);out geom;' % (int(pro_com), flt))


def fetch_comune_ways(pro_com, mode="all", progress=None, is_canceled=None):
    """Strade di un comune italiano dai suoi confini OSM.

    :return: (ways come fetch_ways, confine WKT lon/lat o None); None se
        annullato. Il confine è None se OSM non ha la relazione del comune
        con quel codice ISTAT: le strade allora sono vuote.
    """
    if progress:
        progress(5)
    data = overpass_json(comune_query(pro_com, mode), 330, is_canceled)
    if data is None:
        return None
    if progress:
        progress(70)
    boundary = None
    rels = [el for el in data.get("elements", [])
            if el.get("type") == "relation"]
    if rels:
        from .osm_basemap import _multipolygon_wkt
        boundary = _multipolygon_wkt(rels[0])
    ways = parse_ways(data)
    if progress:
        progress(100)
    return ways, boundary


def parse_ways(data):
    """Way stradali della risposta Overpass, nel formato di fetch_ways."""
    ways = []
    for el in data.get("elements", []):
        if el.get("type") != "way":
            continue
        geom = el.get("geometry")
        if not geom or len(geom) < 2:
            continue
        coords = [(p["lon"], p["lat"]) for p in geom
                  if p.get("lon") is not None and p.get("lat") is not None]
        if len(coords) < 2:
            continue
        tags = el.get("tags", {})
        ways.append((el.get("id"), tags.get("highway", ""),
                     tags.get("name", ""), coords,
                     oneway_from_tags(tags.get("oneway", ""),
                                      tags.get("highway"),
                                      tags.get("junction")),
                     {k: tags[k] for k in ("bridge", "tunnel", "layer", "level",
                                           "maxspeed")
                      if tags.get(k)}))
    return ways


def _text(v):
    """Valore di campo/tag come testo minuscolo ("" se vuoto o NULL)."""
    if v is None:
        return ""
    try:
        from qgis.PyQt.QtCore import QVariant
        if isinstance(v, QVariant) and v.isNull():
            return ""
    except Exception:
        pass
    t = str(v).strip().lower()
    return "" if t == "null" else t


def _oneway_value(raw):
    """Normalizza il tag oneway OSM: 1=avanti, -1=indietro, 0=doppio senso.

    Accetta anche i numeri dei campi reali (1.0 / -1.0).
    """
    v = _text(raw)
    if v in ("yes", "true", "1"):
        return 1
    if v in ("-1", "reverse"):
        return -1
    try:
        x = float(v)
    except ValueError:
        return 0
    if x == 1:
        return 1
    if x == -1:
        return -1
    return 0


def oneway_from_tags(oneway, highway=None, junction=None):
    """Senso di marcia con i sensi unici IMPLICITI di OSM: rotatorie
    (junction=roundabout/circular) e autostrade (highway=motorway) sono a
    senso unico anche senza il tag oneway, salvo oneway=no esplicito.
    """
    d = _oneway_value(oneway)
    if d:
        return d
    if _text(oneway) in ("no", "false"):
        return 0
    if _text(junction) in ("roundabout", "circular") or \
            _text(highway) == "motorway":
        return 1
    return 0


def oneway_reader(field_names, oneway_field="oneway"):
    """Funzione feature → senso di marcia (1/-1/0) dal campo oneway e, se
    presenti, dai campi highway e junction (sensi unici impliciti OSM)."""
    names = list(field_names)
    low = {n.lower(): n for n in names}
    ow = oneway_field if oneway_field in names else \
        low.get((oneway_field or "").lower())
    hw = low.get("highway")
    jn = low.get("junction")

    def direction_of(f):
        return oneway_from_tags(f[ow] if ow else None,
                                f[hw] if hw else None,
                                f[jn] if jn else None)
    return direction_of


def fetch_crossings(south, west, north, east, progress=None, is_canceled=None):
    """Scarica gli attraversamenti pedonali (node highway=crossing) nel bbox.

    Ritorna [(osm_id, lon, lat), ...]. Solo I/O+parsing: sicuro in background.
    """
    import requests

    bbox = "%.6f,%.6f,%.6f,%.6f" % (south, west, north, east)
    query = ("[out:json][timeout:90];"
             '(node["highway"="crossing"](%s);'
             'node["footway"="crossing"](%s););out;' % (bbox, bbox))
    if progress:
        progress(10)
    last_err = None
    data = None
    for url in OVERPASS_URLS:
        if is_canceled and is_canceled():
            return []
        try:
            resp = requests.post(url, data={"data": query},
                                 headers=OVERPASS_HEADERS, timeout=120)
            resp.raise_for_status()
            data = resp.json()
            _check_remark(data)
            break
        except Exception as exc:
            last_err = exc
            data = None
    if data is None:
        raise RuntimeError(tr("Overpass non raggiungibile: %s") % last_err)
    if progress:
        progress(80)
    out = []
    for el in data.get("elements", []):
        if el.get("type") != "node":
            continue
        lon, lat = el.get("lon"), el.get("lat")
        if lon is not None and lat is not None:
            out.append((el.get("id"), lon, lat))
    if progress:
        progress(100)
    return out


def build_points_layer(points, name=tr("OSM - Attraversamenti")):
    """Memory layer di punti (EPSG:4326) da [(osm_id, lon, lat), ...]."""
    from qgis.core import (
        QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField,
    )
    from qgis.PyQt.QtCore import QVariant

    layer = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
    dp = layer.dataProvider()
    dp.addAttributes([QgsField("osm_id", QVariant.LongLong)])
    layer.updateFields()
    feats = []
    for osm_id, lon, lat in points:
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        f.setAttributes([osm_id])
        feats.append(f)
    dp.addFeatures(feats)
    layer.updateExtents()
    return layer


def build_roads_layer(ways, name=tr("OSM - Rete stradale"), labels=True):
    """Costruisce un memory layer di linee (EPSG:4326) dalle way scaricate,
    con il campo «classe» e lo stile per classe di strada (style_roads).

    Da chiamare sul thread principale.
    """
    from qgis.core import (
        QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField,
    )
    from qgis.PyQt.QtCore import QVariant

    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    dp = layer.dataProvider()
    dp.addAttributes([
        QgsField("osm_id", QVariant.LongLong),
        QgsField("highway", QVariant.String),
        QgsField("name", QVariant.String),
        QgsField("oneway", QVariant.Int),
        QgsField("bridge", QVariant.String),
        QgsField("tunnel", QVariant.String),
        QgsField("layer", QVariant.Int),
        QgsField("level", QVariant.String),
        QgsField("maxspeed", QVariant.String),
        QgsField("classe", QVariant.String),
    ])
    layer.updateFields()
    fields = layer.fields()
    feats = []
    for row in ways:
        osm_id, hw, nm, coords = row[0], row[1], row[2], row[3]
        oneway = row[4] if len(row) > 4 else 0
        lv = row[5] if len(row) > 5 and isinstance(row[5], dict) else {}
        try:
            layer_tag = int(round(float(str(lv["layer"]).split(";")[0])))
        except (KeyError, TypeError, ValueError):
            layer_tag = None
        f = QgsFeature(fields)
        f.setGeometry(QgsGeometry.fromPolylineXY(
            [QgsPointXY(x, y) for x, y in coords]))
        f.setAttributes([osm_id, hw, nm, oneway, lv.get("bridge"),
                         lv.get("tunnel"), layer_tag, lv.get("level"),
                         lv.get("maxspeed"), road_class(hw)])
        feats.append(f)
    dp.addFeatures(feats)
    layer.updateExtents()
    style_roads(layer, labels)
    return layer


def style_roads(layer, labels=True):
    """Stile della rete OSM: un colore e uno spessore per classe di strada
    (campo «classe»), le strade importanti disegnate sopra le altre, le
    gallerie più chiare; con `labels` i nomi delle vie lungo la strada
    sotto 1:15.000. Da chiamare sul thread principale."""
    from qgis.PyQt.QtGui import QColor
    from qgis.core import (QgsCategorizedSymbolRenderer, QgsLineSymbol,
                           QgsProperty, QgsRendererCategory, QgsSymbolLayer)
    if layer.fields().indexOf("classe") < 0:
        return
    present = {f["classe"] for f in layer.getFeatures()}
    styles = [(lab, col, wd) for lab, _k, col, wd in ROAD_CLASSES]
    styles.append(OTHER_CLASS)
    cats = []
    for lab, col, wd in styles:
        if present and lab not in present:
            continue
        sym = QgsLineSymbol.createSimple({
            "line_color": col, "line_width": str(wd), "capstyle": "round",
            "joinstyle": "round"})
        if layer.fields().indexOf("tunnel") >= 0:
            sym.symbolLayer(0).setDataDefinedProperty(
                QgsSymbolLayer.PropertyStrokeColor, QgsProperty.fromExpression(
                    "CASE WHEN \"tunnel\" IS NOT NULL AND \"tunnel\" <> 'no' "
                    "THEN set_color_part(@symbol_color, 'alpha', 90) "
                    "ELSE @symbol_color END"))
        cats.append(QgsRendererCategory(lab, sym, lab))
    rend = QgsCategorizedSymbolRenderer("classe", cats)
    try:  # strade importanti sopra le altre
        rend.setUsingSymbolLevels(True)
        for i, cat in enumerate(rend.categories()):
            for sl in cat.symbol().symbolLayers():
                sl.setRenderingPass(len(cats) - i)
    except Exception:
        pass
    layer.setRenderer(rend)
    if labels and layer.fields().indexOf("name") >= 0:
        from qgis.core import (QgsPalLayerSettings, QgsTextBufferSettings,
                               QgsTextFormat,
                               QgsVectorLayerSimpleLabeling)
        pal = QgsPalLayerSettings()
        pal.fieldName = "name"
        try:
            pal.placement = QgsPalLayerSettings.Curved
        except AttributeError:
            pass
        fmt = QgsTextFormat()
        fmt.setSize(8)
        fmt.setColor(QColor("#27272a"))
        buf = QgsTextBufferSettings()
        buf.setEnabled(True)
        buf.setSize(0.8)
        buf.setColor(QColor("#ffffff"))
        fmt.setBuffer(buf)
        pal.setFormat(fmt)
        pal.scaleVisibility = True
        pal.minimumScale = 15000   # visibili da 1:15.000 in giù
        pal.maximumScale = 0
        try:
            pal.mergeLines = True
        except AttributeError:
            pass
        layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        layer.setLabelsEnabled(True)
