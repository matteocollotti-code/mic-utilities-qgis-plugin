# -*- coding: utf-8 -*-
"""Download Data: la rete stradale OSM di un'area, pronta da usare.

Area: un comune italiano (strade dentro i suoi confini OSM, cercati con il
codice ISTAT), l'inquadratura della mappa o i poligoni di un layer (strade
del riquadro ritagliate sui poligoni). Tutto thread-safe (Overpass, parsing
e ritaglio con le geometrie QGIS): si chiama in un QgsTask. I dati ISTAT
arrivano dai moduli istat, addetti e pendolarismo; i layer e il GeoPackage
li prepara il pannello.
"""
from ..i18n import tr

# riquadri più grandi di così chiedono conferma prima di scaricare la rete
WARN_KM2 = 400.0


def bbox_of_wkt(wkt):
    """Riquadro (W, S, E, N) di una geometria WKT lon/lat."""
    from qgis.core import QgsGeometry
    bb = QgsGeometry.fromWkt(wkt).boundingBox()
    return (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(), bb.yMaximum())


def bbox_km2(box):
    from .osm_basemap import bbox_km2 as km2
    w, s, e, n = box
    return km2(s, w, n, e)


def clip_ways(ways, wkt, is_canceled=None):
    """Le strade ritagliate sul poligono (lon/lat): i tratti fuori spariscono,
    una strada che esce e rientra dà più pezzi con lo stesso osm_id. Il
    verso dei vertici (sensi unici) resta quello della strada."""
    from qgis.core import QgsGeometry, QgsPointXY, QgsWkbTypes
    area = QgsGeometry.fromWkt(wkt)
    if area is None or area.isEmpty():
        return list(ways)
    eng = QgsGeometry.createGeometryEngine(area.constGet())
    eng.prepareGeometry()
    box = area.boundingBox()
    out = []
    for k, w in enumerate(ways):
        if is_canceled and k % 2000 == 0 and is_canceled():
            from .gtfs_static import GtfsCancelled
            raise GtfsCancelled()
        line = QgsGeometry.fromPolylineXY([QgsPointXY(x, y) for x, y in w[3]])
        if not line.boundingBox().intersects(box):
            continue
        if eng.contains(line.constGet()):
            out.append(w)
            continue
        if not eng.intersects(line.constGet()):
            continue
        cut = line.intersection(area)
        if cut is None or cut.isEmpty():
            continue
        parts = (cut.asGeometryCollection()
                 if QgsWkbTypes.flatType(cut.wkbType())
                 == QgsWkbTypes.GeometryCollection else [cut])
        for g in parts:
            if g.type() != QgsWkbTypes.LineGeometry:
                continue
            for pl in (g.asMultiPolyline() if g.isMultipart()
                       else [g.asPolyline()]):
                if len(pl) >= 2:
                    out.append((w[0], w[1], w[2],
                                [(p.x(), p.y()) for p in pl]) + tuple(w[4:]))
    return out


def fetch_roads(area, mode="all", progress=None, is_canceled=None):
    """Rete stradale OSM dell'area, con la cache dei download OSM.

    :param area: {"pro_com": codice ISTAT} (comune: strade dentro i confini
        OSM), {"rect": (W, S, E, N)} o {"wkt": poligono lon/lat} (strade del
        riquadro ritagliate sul poligono).
    :return: dict {ways, boundary (WKT del confine del comune o None),
        bbox, notes, cached}; None se annullato.
    """
    from . import istat, osm_cache, osm_download
    notes = []
    if "pro_com" in area:
        code = int(area["pro_com"])
        bbox = istat.comune_bbox(code)
        if bbox is None:
            raise ValueError(tr("comune %s sconosciuto") % code)
        key = (bbox[1], bbox[0], bbox[3], bbox[2])
        tag = "%s@%06d" % (mode, code)
        c = osm_cache.get_cached("roads", key, tag)
        if c and c.get("features"):
            return {"ways": [tuple(w) for w in c["features"]],
                    "boundary": c.get("boundary"), "bbox": bbox,
                    "notes": notes, "cached": True}
        got = osm_download.fetch_comune_ways(code, mode, progress,
                                             is_canceled)
        if got is None:
            return None
        ways, boundary = got
        if boundary and ways:
            # Overpass dà intere le strade che attraversano il confine
            ways = clip_ways(ways, boundary, is_canceled)
            osm_cache.put_cached("roads", key, tag, ways,
                                 {"boundary": boundary})
            return {"ways": ways, "boundary": boundary, "bbox": bbox,
                    "notes": notes, "cached": False}
        # OSM non ha i confini del comune con quel codice: il riquadro
        notes.append(tr("confini del comune non trovati in OpenStreetMap: "
                        "rete del riquadro del comune, non ritagliata"))
        area = {"rect": bbox}
    if "wkt" in area:
        bbox = bbox_of_wkt(area["wkt"])
    else:
        bbox = tuple(area["rect"])
    w, s, e, n = bbox
    key = (s, w, n, e)
    cached = True
    c = osm_cache.get_cached("roads", key, mode)
    if c and c.get("features"):
        ways = [tuple(x) for x in c["features"]]
    else:
        cached = False
        ways = osm_download.fetch_ways(s, w, n, e, mode=mode,
                                       progress=progress,
                                       is_canceled=is_canceled)
        if is_canceled and is_canceled():
            return None
        if ways:
            osm_cache.put_cached("roads", key, mode, ways)
    if "wkt" in area and ways:
        ways = clip_ways(ways, area["wkt"], is_canceled)
    return {"ways": ways, "boundary": None, "bbox": bbox, "notes": notes,
            "cached": cached}


def build_area_layer(wkt, name):
    """Contorno dell'area (lon/lat) come layer in memoria: solo il bordo,
    scuro, sopra gli altri. Thread principale."""
    from qgis.core import (QgsFeature, QgsFillSymbol, QgsGeometry,
                           QgsSingleSymbolRenderer, QgsVectorLayer)
    lay = QgsVectorLayer("MultiPolygon?crs=EPSG:4326&field=nome:string",
                         name, "memory")
    g = QgsGeometry.fromWkt(wkt)
    g.convertToMultiType()
    f = QgsFeature(lay.fields())
    f.setGeometry(g)
    f.setAttributes([name])
    lay.dataProvider().addFeatures([f])
    lay.updateExtents()
    lay.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
        "color": "0,0,0,0", "outline_color": "#18181b",
        "outline_width": "0.6", "outline_style": "dash"})))
    return lay
