# -*- coding: utf-8 -*-
"""Conteggio di opportunità/popolazione dentro poligoni (es. isocrone).

Per ogni poligono conta i punti (POI) contenuti e somma un campo peso opzionale
(es. popolazione). Usato per misurare cosa raggiunge un'isocrona.
"""
from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsSpatialIndex,
)


def count_in_polygons(poly_layer, point_layer, weight_field=None,
                      transform_context=None):
    """Aggiunge n_poi (conteggio) e peso_poi (somma peso) a ogni poligono.

    Ogni punto conta in ogni poligono che lo contiene (bordo compreso): le
    isocrone sono annidate. Modifica il layer poligonale in-place (aggiunge i
    campi) e ritorna le somme sui poligoni (n_poi, peso): con fasce annidate
    contano più volte lo stesso punto, il riepilogo va fatto per fascia.
    """
    if transform_context is None:
        from qgis.core import QgsProject
        transform_context = QgsProject.instance().transformContext()
    ct = QgsCoordinateTransform(point_layer.crs(), poly_layer.crs(),
                                transform_context)
    names = point_layer.fields().names()
    use_w = bool(weight_field) and weight_field in names

    pts = []
    for f in point_layer.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(ct)
        c = g.centroid()
        w = 1.0
        if use_w:
            try:
                w = float(f[weight_field])
            except (TypeError, ValueError):
                w = 0.0  # peso mancante (NULL): non conta
        pts.append((c.asPoint(), w))

    poly_layer.startEditing()
    poly_layer.dataProvider().addAttributes([
        QgsField("n_poi", QVariant.Int),
        QgsField("peso_poi", QVariant.Double),
    ])
    poly_layer.updateFields()
    i_n = poly_layer.fields().indexOf("n_poi")
    i_w = poly_layer.fields().indexOf("peso_poi")

    tot_n = 0
    tot_w = 0.0
    from .gap import assign_points_to_cells
    cells = [c for c in poly_layer.getFeatures()
             if c.geometry() is not None and not c.geometry().isEmpty()]
    # le isocrone sono annidate (15 min contiene 5 min) e, per sorgente o per
    # linea, sovrapposte: ogni punto conta in ogni poligono che lo contiene
    counts, sums = assign_points_to_cells([c.geometry() for c in cells], pts,
                                          unique=False)
    for cell, cnt, wsum in zip(cells, counts, sums):
        poly_layer.changeAttributeValue(cell.id(), i_n, cnt)
        poly_layer.changeAttributeValue(cell.id(), i_w, round(wsum, 2))
        tot_n += cnt
        tot_w += wsum
    poly_layer.commitChanges()
    return tot_n, tot_w
