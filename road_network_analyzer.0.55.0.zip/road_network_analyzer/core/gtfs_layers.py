# -*- coding: utf-8 -*-
"""Costruzione dei memory layer QGIS dai risultati GTFS."""
from ..i18n import tr
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsGradientColorRamp,
    QgsGraduatedSymbolRenderer,
    QgsPalLayerSettings,
    QgsPointXY,
    QgsProject,
    QgsRendererCategory,
    QgsSymbol,
    QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
    QgsWkbTypes,
)

from . import style_util


def _line_from_latlon(coords):
    pts = [QgsPointXY(lon, lat) for lat, lon in coords]
    return QgsGeometry.fromPolylineXY(pts)


def _make_layer(name, fields):
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes(fields)
    layer.updateFields()
    return layer


def _apply_line_categories(layer, field="linea"):
    """Renderer categorizzato (un colore per linea) + etichette col nome linea."""
    values = sorted({f[field] for f in layer.getFeatures() if f[field]})
    cats = []
    n = max(1, len(values))
    for i, val in enumerate(values):
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setWidth(0.8)
        sym.setColor(QColor.fromHsv(int(360 * i / n), 200, 230))
        cats.append(QgsRendererCategory(val, sym, str(val)))
    if cats:
        layer.setRenderer(QgsCategorizedSymbolRenderer(field, cats))
    settings = QgsPalLayerSettings()
    settings.fieldName = field
    try:
        settings.enabled = True
    except Exception:
        pass
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    layer.setLabelsEnabled(True)
    layer.triggerRepaint()


def update_lines_layer(layer, acc, name=tr("GTFS - Linee")):
    """Crea o aggiorna l'UNICO layer delle linee, categorizzato per linea.

    :param acc: accumulatore {shapes:{id:coords}, shape_routes:{id:(rid,dir)},
                routes:{rid:{short_name,..}}}
    """
    if layer is None or not layer.isValid():
        layer = _make_layer(name, [
            QgsField("shape_id", QVariant.String),
            QgsField("route_id", QVariant.String),
            QgsField("linea", QVariant.String),
            QgsField("direction", QVariant.String),
        ])
    else:
        layer.dataProvider().truncate()

    routes = acc.get("routes", {})
    shape_routes = acc.get("shape_routes", {})
    feats = []
    for shape_id, coords in acc.get("shapes", {}).items():
        c = [(la, lo) for la, lo, _ in coords]
        if len(c) < 2:
            continue
        route_id, direction = shape_routes.get(shape_id, ("", ""))
        linea = routes.get(route_id, {}).get("short_name", "") or route_id
        f = QgsFeature(layer.fields())
        f.setGeometry(_line_from_latlon(c))
        f.setAttributes([shape_id, route_id, linea, direction])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    _apply_line_categories(layer, "linea")
    return layer


def update_metrics_layer(layer, line_metrics, rt_lines=None,
                         name=tr("GTFS - Metriche linee")):
    """Crea o aggiorna l'UNICO layer (tabella) con le metriche per linea."""
    rt_lines = rt_lines or {}
    fields = [
        QgsField("route_id", QVariant.String),
        QgsField("linea", QVariant.String),
        QgsField("direction", QVariant.String),
        QgsField("lunghezza_km", QVariant.Double),
        QgsField("commerciale_kmh", QVariant.Double),
        QgsField("esercizio_kmh", QVariant.Double),
        QgsField("eff_rt_kmh", QVariant.Double),
        QgsField("sosta_s", QVariant.Double),
        QgsField("n_corse", QVariant.Int),
    ]
    if layer is None or not layer.isValid():
        layer = QgsVectorLayer("None", name, "memory")
        layer.dataProvider().addAttributes(fields)
        layer.updateFields()
    else:
        layer.dataProvider().truncate()

    feats = []
    for key, m in sorted(line_metrics.items()):
        eff = rt_lines.get(key, {}).get("eff_speed_kmh")
        f = QgsFeature(layer.fields())
        f.setAttributes([
            m["route_id"], m.get("route_short_name") or m["route_id"],
            m["direction_id"],
            round(m["mean_length_m"] / 1000.0, 3),
            round(m["commercial_speed_kmh"], 2),
            round(m["running_speed_kmh"], 2),
            round(eff, 2) if eff is not None else None,
            round(m["mean_dwell_s"], 0),
            m["n_trips"],
        ])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    return layer


def style_segments_by_deviation(layer, classes=5):
    """Stile graduato sullo scarto di velocita' (rosso = osservata << teorica).

    :return: numero di feature con dev_kmh valorizzato.
    """
    values = []
    for f in layer.getFeatures():
        try:
            values.append(float(f["dev_kmh"]))
        except (TypeError, ValueError):
            continue  # NULL di QGIS (non None): segmento senza dati RT
    if not values:
        return 0
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol.setWidth(0.9)
    # rampa: valore basso (scarto molto negativo) = rosso, alto = verde
    ramp = QgsGradientColorRamp(QColor(198, 40, 40), QColor(46, 125, 50))
    n_classes = min(classes, len(set(values)))
    for mode in (QgsGraduatedSymbolRenderer.Jenks,
                 QgsGraduatedSymbolRenderer.Quantile,
                 QgsGraduatedSymbolRenderer.EqualInterval):
        renderer = QgsGraduatedSymbolRenderer.createRenderer(
            layer, "dev_kmh", n_classes, mode, symbol.clone(), ramp.clone())
        if renderer and renderer.ranges():
            layer.setRenderer(renderer)
            layer.triggerRepaint()
            return len(values)
    return 0


def select_worst_segments(layer, top_n):
    """Seleziona gli N segmenti con lo scarto piu' negativo (osservata << teorica).

    Solo i segmenti davvero più lenti del programmato (scarto < 0): un
    segmento più veloce non è un divario da evidenziare.
    """
    feats = []
    for f in layer.getFeatures():
        try:
            dev = float(f["dev_kmh"])
        except (TypeError, ValueError):
            continue  # NULL / senza osservazioni
        if dev < 0:
            feats.append((dev, f.id()))
    feats.sort(key=lambda x: x[0])  # piu' negativo prima
    ids = [fid for _, fid in feats[:max(1, top_n)]]
    layer.selectByIds(ids)
    return len(ids)


def build_matched_roads_layer(road_layer, results,
                              name=tr("Rete stradale - velocita trasporto")):
    """Clona la rete stradale aggiungendo le velocita' GTFS map-matchate.

    :param results: dict {fid: {v_sched, v_eff, dev, n_seg, n_routes, routes}}
    """
    wkb = QgsWkbTypes.displayString(road_layer.wkbType()) or "LineString"
    layer = style_util.memory_layer(wkb, road_layer.crs(), name)
    prov = layer.dataProvider()

    src_fields = road_layer.fields()
    extra = [
        QgsField("v_sched_kmh", QVariant.Double),
        QgsField("v_eff_kmh", QVariant.Double),
        QgsField("dev_kmh", QVariant.Double),
        QgsField("n_seg", QVariant.Int),
        QgsField("n_routes", QVariant.Int),
        QgsField("routes", QVariant.String),
        QgsField("copertura", QVariant.Double),
    ]
    prov.addAttributes(list(src_fields) + extra)
    layer.updateFields()

    n_src = len(src_fields)
    feats = []
    for f in road_layer.getFeatures():
        r = results.get(f.id())
        out = QgsFeature(layer.fields())
        out.setGeometry(f.geometry())
        attrs = list(f.attributes())
        if len(attrs) < n_src:
            attrs += [None] * (n_src - len(attrs))
        if r:
            attrs += [
                round(r["v_sched"], 2),
                round(r["v_eff"], 2) if r["v_eff"] is not None else None,
                round(r["dev"], 2) if r["dev"] is not None else None,
                r["n_seg"], r["n_routes"], r["routes"], r.get("cover"),
            ]
        else:
            attrs += [None] * 7
        out.setAttributes(attrs)
        feats.append(out)
    prov.addFeatures(feats)
    layer.updateExtents()
    return layer


def _ptal_fields(profiles):
    """Campi base ai/ptal/ptal_level + (se profili) un set per fascia."""
    fields = [
        QgsField("ai", QVariant.Double),
        QgsField("ptal", QVariant.String),
        QgsField("ptal_level", QVariant.Int),
    ]
    if profiles:
        for label, _res in profiles:
            fields.append(QgsField("ai_%s" % label, QVariant.Double))
            fields.append(QgsField("ptal_%s" % label, QVariant.String))
    return fields


def _ptal_attrs(idx, results, profiles):
    """Attributi: primario (results[idx]) + un valore per fascia se profili."""
    r = results[idx]
    attrs = [round(r["ai"], 2), r["band"], r["level"]]
    if profiles:
        for _label, res in profiles:
            rb = res[idx]
            attrs.append(round(rb["ai"], 2))
            attrs.append(rb["band"])
    return attrs


class FeatureSnapshot(object):
    """Copia delle feature (e del CRS) di un layer presa al lancio di un
    calcolo in background: i risultati restano allineati ai punti anche se
    nel frattempo il layer viene filtrato, modificato o rimosso. Offre i
    metodi usati dai costruttori di layer (crs, wkbType, fields,
    getFeatures)."""

    def __init__(self, layer):
        from qgis.core import QgsCoordinateReferenceSystem, QgsFields
        self._crs = QgsCoordinateReferenceSystem(layer.crs())
        self._wkb = layer.wkbType()
        self._fields = QgsFields(layer.fields())
        self._feats = [QgsFeature(f) for f in layer.getFeatures()]

    def crs(self):
        return self._crs

    def wkbType(self):
        return self._wkb

    def fields(self):
        return self._fields

    def getFeatures(self):
        return iter(self._feats)


def build_ptal_layer(points_layer, results, name="PTAL", profiles=None):
    """Copia i punti di analisi con AI, fascia PTAL e livello; stile per livello.

    Se `profiles` (lista di (label, results)) e' dato, aggiunge i campi
    ai_<label>/ptal_<label> per ogni fascia oraria; i campi base usano la fascia
    primaria (`results`).
    """
    wkb = QgsWkbTypes.displayString(points_layer.wkbType()) or "Point"
    layer = style_util.memory_layer(wkb, points_layer.crs(), name)
    layer.dataProvider().addAttributes(_ptal_fields(profiles))
    layer.updateFields()
    feats = []
    idx = 0
    # salta le feature senza geometria: `results` è allineato alle SOLE feature
    # valide (le coordinate sono costruite con lo stesso filtro a monte).
    for src in points_layer.getFeatures():
        g = src.geometry()
        if g is None or g.isEmpty() or idx >= len(results):
            continue
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        f.setAttributes(_ptal_attrs(idx, results, profiles))
        feats.append(f)
        idx += 1
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    apply_ptal_style(layer)
    return layer


# palette PTAL (tutte le fasce 0..6b)
PTAL_COLORS = [
    ("0", "#9e9e9e"), ("1a", "#08306b"), ("1b", "#2171b5"),
    ("2", "#41b6c4"), ("3", "#78c679"), ("4", "#c2e699"),
    ("5", "#fee08b"), ("6a", "#fc8d59"), ("6b", "#d73027"),
]


def apply_ptal_style(layer):
    """Renderer categorizzato con TUTTE le fasce PTAL in legenda."""
    cats = []
    for band, hexc in PTAL_COLORS:
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        sym.setColor(QColor(hexc))
        cats.append(QgsRendererCategory(band, sym, "PTAL " + band))
    layer.setRenderer(QgsCategorizedSymbolRenderer("ptal", cats))


def build_ptal_grid_layer(cells, results, name="PTAL", profiles=None):
    """Layer poligonale a celle (esagoni/quadrati) colorato per fascia PTAL.

    :param cells: lista di anelli [[(lat, lon), ...], ...].
    :param results: lista di dict {ai, band, level} (fascia primaria).
    :param profiles: opzionale, lista di (label, results) per i profili orari.
    """
    layer = QgsVectorLayer("Polygon?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes(_ptal_fields(profiles))
    layer.updateFields()
    feats = []
    for idx, ring in enumerate(cells):
        pts = [QgsPointXY(lo, la) for la, lo in ring]
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolygonXY([pts]))
        f.setAttributes(_ptal_attrs(idx, results, profiles))
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    apply_ptal_style(layer)
    return layer


def build_walkability_layer(cells_latlon, results, name="Walkability",
                            holes=None):
    """Layer poligonale degli indici di walkability, graduato 0-100."""
    layer = QgsVectorLayer("Polygon?crs=EPSG:4326", name, "memory")
    layer.dataProvider().addAttributes([
        QgsField("walkability", QVariant.Double),
        QgsField("design", QVariant.Double),
        QgsField("destinazioni", QVariant.Double),
        QgsField("pendenza", QVariant.Double),
        QgsField("attraversam", QVariant.Double),
        QgsField("n_incroci", QVariant.Int),
        QgsField("dens_incroci", QVariant.Double),
        QgsField("dens_strade", QVariant.Double),
        QgsField("link_node", QVariant.Double),
        QgsField("conn_media", QVariant.Double),
        QgsField("n_poi", QVariant.Int),
        QgsField("n_attrav", QVariant.Int),
        QgsField("grade_pct", QVariant.Double),
    ])
    layer.updateFields()
    feats = []
    holes = list(holes or [])
    holes += [None] * (len(cells_latlon) - len(holes))
    for ring, hl, r in zip(cells_latlon, holes, results):
        pts = [QgsPointXY(lo, la) for la, lo in ring]
        f = QgsFeature(layer.fields())
        f.setGeometry(QgsGeometry.fromPolygonXY(
            [pts] + [[QgsPointXY(lo, la) for la, lo in h] for h in (hl or ())]))
        f.setAttributes([
            r["walkability"], r.get("design", 0.0), r.get("destinazioni", 0.0),
            r.get("pendenza", 0.0), r.get("attraversamenti", 0.0),
            r["n_incroci"], r["int_density"],
            r["street_density"], r["link_node"], r["mean_conn"],
            r.get("n_poi", 0), r.get("n_attrav", 0), r.get("grade_pct", 0.0)])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    values = [f["walkability"] for f in layer.getFeatures()
              if f["walkability"] is not None]
    n = min(6, len(set(values))) if values else 0
    if n >= 1:
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        ramp = QgsGradientColorRamp(QColor(215, 48, 39), QColor(26, 152, 80))
        r = style_util.graduated_from(layer, "walkability", n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer


def build_access_layer(origins_layer, results, times, name=tr("Accessibilita")):
    """Copia le origini, con i loro attributi, più un campo di
    accessibilita' per ogni fascia. Gli attributi delle origini servono a
    valle: per esempio i residenti (POP21 delle sezioni ISTAT) come peso
    nella sintesi di equità."""
    wkb = QgsWkbTypes.displayString(origins_layer.wkbType()) or "Point"
    layer = style_util.memory_layer(wkb, origins_layer.crs(), name)
    acc_names = ["acc_%gmin" % t for t in times]
    try:
        keep = [(i, QgsField(f)) for i, f in enumerate(
            origins_layer.fields()) if f.name() not in acc_names]
    except Exception:
        keep = []
    fields = [f for _i, f in keep] + [QgsField(n, QVariant.Double)
                                      for n in acc_names]
    layer.dataProvider().addAttributes(fields)
    layer.updateFields()
    feats = []
    # salta le origini senza geometria per restare allineati a `results`
    # (le coordinate origine sono costruite con lo stesso filtro a monte).
    res_iter = iter(results)
    for src in origins_layer.getFeatures():
        g = src.geometry()
        if g is None or g.isEmpty():
            continue
        res = next(res_iter, None)
        if res is None:
            break
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        attrs = src.attributes()
        f.setAttributes([attrs[i] if i < len(attrs) else None
                         for i, _f in keep]
                        + [round(res.get(t, 0.0), 2) for t in times])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    field = "acc_%gmin" % max(times)
    values = [f[field] for f in layer.getFeatures() if f[field] is not None]
    n = min(6, len(set(values))) if values else 0
    if n >= 1:
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        ramp = QgsGradientColorRamp(QColor(255, 255, 204), QColor(0, 104, 55))
        r = style_util.graduated_from(layer, field, n, symbol, ramp)
        if r and r.ranges():
            layer.setRenderer(r)
    return layer


SS_FIELDS = [
    ("connettivita", QVariant.Int),
    ("profondita_media", QVariant.Double),
    ("profondita_tot", QVariant.Double),
    ("integrazione", QVariant.Double),
    ("choice", QVariant.Double),
    ("nain", QVariant.Double),
    ("nach", QVariant.Double),
    ("lunghezza_m", QVariant.Double),
    ("n_feature", QVariant.Int),
    ("src_fid", QVariant.LongLong),
]


def space_syntax_source_attrs(road_layer, fids):
    """{id: attributi} delle feature d'origine (senza geometria)."""
    from qgis.core import QgsFeatureRequest
    req = QgsFeatureRequest().setFilterFids(list(set(fids)))
    req.setFlags(QgsFeatureRequest.NoGeometry)
    return {f.id(): f.attributes() for f in road_layer.getFeatures(req)}


def build_space_syntax_layer(road_layer, result, src_attrs=None,
                             name=tr("Space syntax"), transform_context=None):
    """Un tratto per segmento della segment map (tra incroci reali) con gli
    attributi della strada d'origine e i campi space syntax; stile per
    integrazione. Geometrie nel CRS della rete.

    :param result: risultato di SpaceSyntaxTask (metriche + coords/src).
    :param src_attrs: {id feature: attributi} (space_syntax_source_attrs).
    """
    from qgis.core import (QgsCoordinateReferenceSystem,
                           QgsCoordinateTransform, QgsPointXY)
    names = {n for n, _t in SS_FIELDS}
    fields = QgsFields()
    copy_idx = []
    src_fields = road_layer.fields()
    for i in range(src_fields.count()):
        fld = src_fields.at(i)
        if fld.name().lower() == "fid" or fld.name() in names:
            continue
        fields.append(QgsField(fld))
        copy_idx.append((i, fields.count() - 1))
    base = fields.count()
    for n, t in SS_FIELDS:
        fields.append(QgsField(n, t))
    layer = style_util.memory_layer("LineString", road_layer.crs(), name)
    layer.dataProvider().addAttributes(fields.toList())
    layer.updateFields()
    ctx = transform_context or QgsProject.instance().transformContext()
    ct = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"),
                                road_layer.crs(), ctx)
    src_attrs = src_attrs or {}
    feats = []
    nf = fields.count()
    m = result
    for i, coords in enumerate(m["coords"]):
        g = QgsGeometry.fromPolylineXY([QgsPointXY(lo, la)
                                        for lo, la in coords])
        try:
            g.transform(ct)
        except Exception:
            continue
        f = QgsFeature(layer.fields())
        f.setGeometry(g)
        vals = [None] * nf
        attrs = src_attrs.get(m["src"][i])
        if attrs is not None:
            for a, b in copy_idx:
                if a < len(attrs):
                    vals[b] = attrs[a]
        vals[base:] = [
            m["connectivity"][i],
            round(m["mean_depth"][i], 4),
            round(m["total_depth"][i], 1),
            round(m["integration"][i], 4),
            round(m["choice"][i], 2),
            round(m["nain"][i], 4),
            round(m["nach"][i], 4),
            round(m["length_m"][i], 1),
            m["n_feature"][i],
            m["src"][i],
        ]
        f.setAttributes(vals)
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol.setWidth(0.7)
    ramp = QgsGradientColorRamp(QColor(43, 131, 186), QColor(215, 25, 28))
    values = [v for v in m["integration"] if v is not None]
    n = min(6, len(set(values))) if values else 0
    if n >= 1:
        renderer = style_util.graduated_from(layer, "integrazione", n, symbol, ramp)
        if renderer and renderer.ranges():
            layer.setRenderer(renderer)
    return layer


def build_segments_layer(result, rt_stats=None, name=tr("GTFS - Segmenti")):
    """Un feature per segmento stop-to-stop, con metriche programmate e (se
    disponibili) effettive da GTFS-RT."""
    fields = [
        QgsField("route_id", QVariant.String),
        QgsField("direction", QVariant.String),
        QgsField("from_stop", QVariant.String),
        QgsField("from_name", QVariant.String),
        QgsField("to_stop", QVariant.String),
        QgsField("to_name", QVariant.String),
        QgsField("length_m", QVariant.Double),
        QgsField("sched_t_s", QVariant.Double),
        QgsField("v_sched_kmh", QVariant.Double),
        QgsField("v_eff_kmh", QVariant.Double),
        # programmato delle stesse corse osservate: base dello scarto
        QgsField("v_sched_obs", QVariant.Double),
        QgsField("dev_kmh", QVariant.Double),
        QgsField("dev_pct", QVariant.Double),
        QgsField("delay_s", QVariant.Double),
        QgsField("n_obs", QVariant.Int),
    ]
    layer = _make_layer(name, fields)
    rt_stats = rt_stats or {}
    feats = []
    for key, seg in result["segments"].items():
        f = QgsFeature(layer.fields())
        f.setGeometry(_line_from_latlon(seg["coords"]))
        rt = rt_stats.get(key)
        f.setAttributes([
            seg["route_id"], seg["direction_id"],
            seg["from_stop"], seg["from_name"],
            seg["to_stop"], seg["to_name"],
            round(seg["length_m"], 1),
            round(seg["sched_time_s"], 1),
            round(seg["sched_speed_kmh"], 2),
            round(rt["eff_speed_kmh"], 2) if rt else None,
            round(rt["sched_trips_kmh"], 2) if rt and
            rt.get("sched_trips_kmh") is not None else None,
            round(rt["dev_kmh"], 2) if rt else None,
            round(rt["dev_pct"], 1) if rt else None,
            round(rt["mean_delay_s"], 1) if rt and rt["mean_delay_s"] is not None else None,
            rt["n_obs"] if rt else None,
        ])
        feats.append(f)
    layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    return layer
